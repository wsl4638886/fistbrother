package com.hzyc.filmsystem.sale.data;

import java.util.List;

import com.hzyc.filmsystem.data.BaseDao;

import java.sql.Date;
import java.sql.ResultSet;
import java.util.ArrayList;


public class SaleDao extends BaseDao{

	public List<Sale> queryAll() {
    	List<Sale> set = new ArrayList<Sale>();
    	try{
			String sql="select * from sale";
			Object[] params = new Object[]{};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Sale result = new Sale();
				result.id = rs.getInt("id");
				
				result.id_fangyingting = rs.getInt("id_fangyingting");
				result.id_movie = rs.getInt("id_movie");
				result.show_date = rs.getDate("show_date");
				result.start_time = rs.getTime("start_time");
				result.end_time = rs.getTime("end_time");
				result.language = rs.getString("language");
				result.price = rs.getDouble("price");
				
				result.code = rs.getString("code");
				result.row = rs.getInt("row");
				result.col = rs.getInt("col");
				result.name = rs.getString("name");
				
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
		return set;
	}
	
	
	public List<Sale> search_fangyingting(Integer id_fangyingting){
    	List<Sale> set = new ArrayList<Sale>();
    	try{
			String sql="select * from sale where id_fangyingting = ?";
			Object[] params = new Object[]{id_fangyingting};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Sale result = new Sale();
				result.id = rs.getInt("id");
				
				result.id_fangyingting = rs.getInt("id_fangyingting");
				result.id_movie = rs.getInt("id_movie");
				result.show_date = rs.getDate("show_date");
				result.start_time = rs.getTime("start_time");
				result.end_time = rs.getTime("end_time");
				result.language = rs.getString("language");
				result.price = rs.getDouble("price");
				
				result.code = rs.getString("code");
				result.row = rs.getInt("row");
				result.col = rs.getInt("col");
				result.name = rs.getString("name");
				
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
		return set;
	}
	
	public List<Sale> search_movie(Integer id_movie){
    	List<Sale> set = new ArrayList<Sale>();
    	try{
			String sql="select * from sale where id_movie = ?";
			Object[] params = new Object[]{id_movie};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Sale result = new Sale();
				result.id = rs.getInt("id");
				
				result.id_fangyingting = rs.getInt("id_fangyingting");
				result.id_movie = rs.getInt("id_movie");
				result.show_date = rs.getDate("show_date");
				result.start_time = rs.getTime("start_time");
				result.end_time = rs.getTime("end_time");
				result.language = rs.getString("language");
				result.price = rs.getDouble("price");
				
				result.code = rs.getString("code");
				result.row = rs.getInt("row");
				result.col = rs.getInt("col");
				result.name = rs.getString("name");
				
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
		return set;
	}
	
	public List<Sale> search_date(Date key){
    	List<Sale> set = new ArrayList<Sale>();
    	try{
			String sql="select * from sale where show_date = ?";
			Object[] params = new Object[]{key};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Sale result = new Sale();
				result.id = rs.getInt("id");
				
				result.id_fangyingting = rs.getInt("id_fangyingting");
				result.id_movie = rs.getInt("id_movie");
				result.show_date = rs.getDate("show_date");
				result.start_time = rs.getTime("start_time");
				result.end_time = rs.getTime("end_time");
				result.language = rs.getString("language");
				result.price = rs.getDouble("price");
				
				result.code = rs.getString("code");
				result.row = rs.getInt("row");
				result.col = rs.getInt("col");
				result.name = rs.getString("name");
				
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
		return set;
	}
	
	public List<Sale> search_name(String name){
    	List<Sale> set = new ArrayList<Sale>();
    	try{
			String sql="select * from sale where name like '%" + name + "%'";
			Object[] params = new Object[]{};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Sale result = new Sale();
				result.id = rs.getInt("id");
				
				result.id_fangyingting = rs.getInt("id_fangyingting");
				result.id_movie = rs.getInt("id_movie");
				result.show_date = rs.getDate("show_date");
				result.start_time = rs.getTime("start_time");
				result.end_time = rs.getTime("end_time");
				result.language = rs.getString("language");
				result.price = rs.getDouble("price");
				
				result.code = rs.getString("code");
				result.row = rs.getInt("row");
				result.col = rs.getInt("col");
				result.name = rs.getString("name");
				
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
		return set;
	}
	
	public boolean add(Sale f){
		boolean flag;
		String  sql="insert into sale ("
				+ "id_fangyingting,id_movie,show_date,start_time,end_time,language,price,code,row,col,name) "
				+ "values(?,?,?,?,?,?,?,?,?,?,?)";
		@SuppressWarnings("null")
		Object[] params = new Object[]{
				f.id_fangyingting,
				f.id_movie,
				f.show_date,
				f.start_time,
				f.end_time,
				f.language,
				f.price,
				f.code,
				f.row,
				f.col,
				f.name
				};
		flag = executeUpdate(sql, params);
		
		destroy();
		return flag;
	}


}
