package com.hzyc.filmsystem.movie;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.hzyc.filmsystem.movie.MovieFrame;
import com.hzyc.filmsystem.movie.data.Movie;
import com.hzyc.filmsystem.movie.data.MovieDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class MovieAddFrame extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MovieAddFrame frame = new MovieAddFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public MovieFrame movieFrame;
	public Movie movie;
	private JTextField textField1;
	private JTextField textField3;
	private JTextField textField4;
	private JButton button;
	private JTextField textField2;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label_8;
	private JTextField textField5;
	private JTextArea textField6;
	private JTextField textField71;
	private JLabel label_7;
	private JTextField textField72;
	private JLabel label_9;
	private JTextField textField73;
	private JLabel label_10;
	private JTextField textField81;
	private JLabel label_11;
	private JLabel label_12;
	private JTextField textField82;
	private JTextField textField83;
	private JLabel label_13;
	public void init() {
		// TODO Auto-generated method stub
		textField1.setText(movie.name);

		
		textField1.setText(movie.name);
		textField2.setText(movie.state);
		textField3.setText(movie.director);
		textField4.setText(movie.length);
		textField5.setText(movie.language);
		textField6.setText(movie.description);
		textField71.setText(movie.start_time.getYear()+1900+"");
		textField72.setText(movie.start_time.getMonth()+1+"");
		textField73.setText(movie.start_time.getDate()+"");
		textField81.setText(movie.end_time.getYear()+1900+"");
		textField82.setText(movie.end_time.getMonth()+1+"");
		textField83.setText(movie.end_time.getDate()+"");
	}
	
	/**
	 * Create the frame.
	 */
	public MovieAddFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 478, 454);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u540D\u79F0\uFF1A");
		label.setBounds(113, 33, 72, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u56FD\u5BB6\uFF1A");
		label_1.setBounds(113, 64, 72, 18);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u5BFC\u6F14\uFF1A");
		label_2.setBounds(113, 96, 72, 18);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u8BED\u8A00\uFF1A");
		label_3.setBounds(113, 158, 72, 18);
		contentPane.add(label_3);
		
		textField1 = new JTextField();
		textField1.setBounds(199, 33, 156, 24);
		contentPane.add(textField1);
		textField1.setColumns(10);
		
		textField3 = new JTextField();
		textField3.setColumns(10);
		textField3.setBounds(199, 98, 156, 24);
		contentPane.add(textField3);
		
		textField4 = new JTextField();
		textField4.setColumns(10);
		textField4.setBounds(199, 127, 156, 24);
		contentPane.add(textField4);
		
		JButton btn_ok = new JButton("\u786E\u8BA4");
		btn_ok.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {
				if(textField4.getText().isEmpty() || textField3.getText().isEmpty() || textField1.getText().isEmpty()){
					JOptionPane.showMessageDialog(null, "��������Ϊ��");
				}else {
					Movie movie = new Movie(
							textField1.getText().trim(), 
							textField2.getText().trim(), 
							textField3.getText().trim(), 
							textField4.getText().trim(), 
							textField5.getText().trim(), 
							textField6.getText().trim(), 
							new Date(Integer.valueOf(textField71.getText())-1900, 
									Integer.valueOf(textField72.getText())-1, 
									Integer.valueOf(textField73.getText())),
							new Date(Integer.valueOf(textField81.getText())-1900, 
									Integer.valueOf(textField82.getText())-1, 
									Integer.valueOf(textField83.getText()))
							);
					if(MovieAddFrame.this.movie == null){
						(new MovieDao()).add(movie);
					}else {
						movie.id = MovieAddFrame.this.movie.id;
						(new MovieDao()).update(movie);
					}
				}
				
				if(movieFrame!=null){
					movieFrame.loadData();
				}
				dispose();
			}
		});
		btn_ok.setBounds(98, 367, 113, 27);
		contentPane.add(btn_ok);
		
		setLocationRelativeTo(null);
		
		button = new JButton("\u53D6\u6D88");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		button.setBounds(256, 367, 113, 27);
		contentPane.add(button);
		
		textField2 = new JTextField();
		textField2.setColumns(10);
		textField2.setBounds(199, 64, 156, 24);
		contentPane.add(textField2);
		
		label_4 = new JLabel("\u7B80\u4ECB\uFF1A");
		label_4.setBounds(113, 189, 72, 18);
		contentPane.add(label_4);
		
		label_5 = new JLabel("\u7247\u957F\uFF1A");
		label_5.setBounds(113, 127, 72, 18);
		contentPane.add(label_5);
		
		label_6 = new JLabel("\u4E0A\u6620\u65F6\u95F4\uFF1A");
		label_6.setBounds(86, 284, 90, 18);
		contentPane.add(label_6);
		
		label_8 = new JLabel("\u4E0B\u7EBF\u65F6\u95F4\uFF1A");
		label_8.setBounds(86, 315, 90, 18);
		contentPane.add(label_8);
		
		textField5 = new JTextField();
		textField5.setColumns(10);
		textField5.setBounds(199, 155, 156, 24);
		contentPane.add(textField5);
		
		textField6 = new JTextArea();
		textField6.setLineWrap(true);
		textField6.setColumns(10);
		textField6.setBounds(199, 186, 156, 85);
		contentPane.add(textField6);
		
		textField71 = new JTextField();
		textField71.setColumns(10);
		textField71.setBounds(167, 284, 53, 24);
		contentPane.add(textField71);
		
		label_7 = new JLabel("\u5E74");
		label_7.setBounds(224, 287, 22, 18);
		contentPane.add(label_7);
		
		textField72 = new JTextField();
		textField72.setColumns(10);
		textField72.setBounds(248, 284, 53, 24);
		contentPane.add(textField72);
		
		label_9 = new JLabel("\u6708");
		label_9.setBounds(305, 287, 22, 18);
		contentPane.add(label_9);
		
		textField73 = new JTextField();
		textField73.setColumns(10);
		textField73.setBounds(337, 284, 53, 24);
		contentPane.add(textField73);
		
		label_10 = new JLabel("\u65E5");
		label_10.setBounds(394, 287, 22, 18);
		contentPane.add(label_10);
		
		textField81 = new JTextField();
		textField81.setColumns(10);
		textField81.setBounds(167, 315, 53, 24);
		contentPane.add(textField81);
		
		label_11 = new JLabel("\u5E74");
		label_11.setBounds(224, 318, 22, 18);
		contentPane.add(label_11);
		
		label_12 = new JLabel("\u6708");
		label_12.setBounds(305, 318, 22, 18);
		contentPane.add(label_12);
		
		textField82 = new JTextField();
		textField82.setColumns(10);
		textField82.setBounds(248, 315, 53, 24);
		contentPane.add(textField82);
		
		textField83 = new JTextField();
		textField83.setColumns(10);
		textField83.setBounds(337, 315, 53, 24);
		contentPane.add(textField83);
		
		label_13 = new JLabel("\u65E5");
		label_13.setBounds(394, 318, 22, 18);
		contentPane.add(label_13);
	}
}
