package com.hzyc.filmsystem.plan;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.hzyc.filmsystem.fangyingting.data.Fangyingting;
import com.hzyc.filmsystem.fangyingting.data.FangyingtingDao;
import com.hzyc.filmsystem.movie.data.Movie;
import com.hzyc.filmsystem.movie.data.MovieDao;
import com.hzyc.filmsystem.plan.PlanFrame;
import com.hzyc.filmsystem.plan.data.Plan;
import com.hzyc.filmsystem.plan.data.PlanDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.Time;
import java.util.Calendar;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class PlanAddFrame extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PlanAddFrame frame = new PlanAddFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public PlanFrame planFrame;
	public Plan plan;
	private JButton button;
	private JLabel label_4;
	private JLabel label_5;
	private JTextField textField5;
	private JTextField textField6;
	private JTextField textField31;
	private JLabel label_14;
	private JTextField textField32;
	private JLabel label_15;
	private JTextField textField33;
	private JLabel label_16;
	private JComboBox textField1;
	private JComboBox textField2;
	private JTextField textField41;
	private JLabel label_17;
	private JTextField textField42;
	private JLabel label_18;
	public void init() {
		// TODO Auto-generated method stub
		
		Fangyingting fangyingting = (new FangyingtingDao()).get(plan.id_fangyingting);
		Movie movie = (new MovieDao()).get(plan.id_movie);
		
		textField1.setSelectedIndex(findFangyingting(fangyingting.name));
		textField2.setSelectedIndex(findMovie(movie.name));
		textField31.setText(plan.show_date.getYear()+1900+"");
		textField32.setText(plan.show_date.getMonth()+1+"");
		textField33.setText(plan.show_date.getDate()+"");
		textField41.setText(plan.start_time.getHours()+"");
		textField42.setText(plan.start_time.getMinutes()+"");
		textField5.setText(plan.language);
		textField6.setText(plan.price.toString());
	}
	
	
	List<Fangyingting> list_fangyingting = (new FangyingtingDao()).queryAll();
	List<Movie> list_movie = (new MovieDao()).queryAll();
	int findFangyingting(String name){
		int index = 0;
		for(int i=0;i<list_fangyingting.size();i++){
			if(list_fangyingting.get(i).name.equals(name)){
				index = i;
				break;
			}
		}
		return index;
	}
	int findMovie(String name){
		int index = 0;
		for(int i=0;i<list_movie.size();i++){
			if(list_movie.get(i).name.equals(name)){
				index = i;
				break;
			}
		}
		return index;
	}
	/**
	 * Create the frame.
	 */
	public PlanAddFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 478, 342);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u653E\u6620\u5385\uFF1A");
		label.setBounds(113, 33, 72, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u7535\u5F71\uFF1A");
		label_1.setBounds(113, 64, 72, 18);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u65E5\u671F\uFF1A");
		label_2.setBounds(113, 96, 72, 18);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u8BED\u8A00\uFF1A");
		label_3.setBounds(113, 158, 72, 18);
		contentPane.add(label_3);
		
		JButton btn_ok = new JButton("\u786E\u8BA4");
		btn_ok.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {
				if(textField31.getText().isEmpty() || 
						textField32.getText().isEmpty() || 
						textField33.getText().isEmpty() ||
						textField41.getText().isEmpty() || 
						textField42.getText().isEmpty() || 
						textField5.getText().isEmpty() || 
						textField6.getText().isEmpty()
						){
					JOptionPane.showMessageDialog(null, "��������Ϊ��");
				}else {
					
					Date start_date = new Date(Integer.valueOf(textField31.getText())-1900, 
							Integer.valueOf(textField32.getText())-1, 
							Integer.valueOf(textField33.getText())
							);
					
					Time start_time = new Time(
							Integer.valueOf(textField41.getText()), 
							Integer.valueOf(textField42.getText()), 
							0
							);
					Calendar calendar = Calendar.getInstance();
					calendar.set(start_date.getYear(), start_date.getMonth(), start_date.getDate(), start_time.getHours(), start_time.getMinutes());
					int length = Integer.valueOf(list_movie.get(textField2.getSelectedIndex()).length);
					calendar.add(Calendar.MINUTE, length);
					Time end_time = new Time(calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),0);
					
					Plan plan = new Plan(
							list_fangyingting.get(textField1.getSelectedIndex()).id, 
							list_movie.get(textField2.getSelectedIndex()).id, 
							start_date,
							start_time,
							end_time,
							textField5.getText().trim(), 
							Double.valueOf(textField6.getText().trim())
							);
					if(PlanAddFrame.this.plan == null){
						(new PlanDao()).add(plan);
					}else {
						plan.id = PlanAddFrame.this.plan.id;
						(new PlanDao()).update(plan);
					}
					
				}
				
				if(planFrame!=null){
					planFrame.loadData();
				}
				dispose();
			}
		});
		btn_ok.setBounds(97, 248, 113, 27);
		contentPane.add(btn_ok);
		
		setLocationRelativeTo(null);
		
		button = new JButton("\u53D6\u6D88");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		button.setBounds(255, 248, 113, 27);
		contentPane.add(button);
		
		label_4 = new JLabel("\u4EF7\u683C\uFF1A");
		label_4.setBounds(113, 189, 72, 18);
		contentPane.add(label_4);
		
		label_5 = new JLabel("\u5F00\u59CB\u65F6\u95F4\uFF1A");
		label_5.setBounds(86, 127, 99, 18);
		contentPane.add(label_5);
		
		textField5 = new JTextField();
		textField5.setColumns(10);
		textField5.setBounds(199, 155, 156, 24);
		contentPane.add(textField5);
		
		textField6 = new JTextField();
		textField6.setColumns(10);
		textField6.setBounds(199, 186, 156, 24);
		contentPane.add(textField6);
		
		textField31 = new JTextField();
		textField31.setColumns(10);
		textField31.setBounds(197, 96, 53, 24);
		contentPane.add(textField31);
		
		label_14 = new JLabel("\u5E74");
		label_14.setBounds(254, 99, 22, 18);
		contentPane.add(label_14);
		
		textField32 = new JTextField();
		textField32.setColumns(10);
		textField32.setBounds(278, 96, 53, 24);
		contentPane.add(textField32);
		
		label_15 = new JLabel("\u6708");
		label_15.setBounds(335, 99, 22, 18);
		contentPane.add(label_15);
		
		textField33 = new JTextField();
		textField33.setColumns(10);
		textField33.setBounds(367, 96, 53, 24);
		contentPane.add(textField33);
		
		label_16 = new JLabel("\u65E5");
		label_16.setBounds(424, 99, 22, 18);
		contentPane.add(label_16);
		
		textField1 = new JComboBox();
		textField1.setBounds(199, 30, 156, 24);
		contentPane.add(textField1);
		
		textField2 = new JComboBox();
		textField2.setBounds(199, 61, 156, 24);
		contentPane.add(textField2);
		
		textField41 = new JTextField();
		textField41.setColumns(10);
		textField41.setBounds(199, 127, 53, 24);
		contentPane.add(textField41);
		
		label_17 = new JLabel("\u65F6");
		label_17.setBounds(256, 130, 22, 18);
		contentPane.add(label_17);
		
		textField42 = new JTextField();
		textField42.setColumns(10);
		textField42.setBounds(280, 127, 53, 24);
		contentPane.add(textField42);
		
		label_18 = new JLabel("\u5206");
		label_18.setBounds(337, 130, 22, 18);
		contentPane.add(label_18);
		
		
		String[] fangyingtingStrings = new String[list_fangyingting.size()];
		String[] movieStrings = new String[list_movie.size()];
		for(int i=0;i<list_fangyingting.size();i++){
			fangyingtingStrings[i] = list_fangyingting.get(i).name;
		}
		for(int i=0;i<list_movie.size();i++){
			movieStrings[i] = list_movie.get(i).name;
		}
		
		textField1.setModel(new DefaultComboBoxModel<String>(fangyingtingStrings));
		textField2.setModel(new DefaultComboBoxModel<String>(movieStrings));
	}
}
