package com.hzyc.filmsystem.admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.hzyc.filmsystem.admin.data.Shangzuolv;
import com.hzyc.filmsystem.fangyingting.data.Fangyingting;
import com.hzyc.filmsystem.fangyingting.data.FangyingtingDao;
import com.hzyc.filmsystem.movie.data.Movie;
import com.hzyc.filmsystem.movie.data.MovieDao;
import com.hzyc.filmsystem.plan.data.Plan;
import com.hzyc.filmsystem.plan.data.PlanDao;
import com.hzyc.filmsystem.sale.data.SaleDao;
import com.hzyc.filmsystem.sale.data.Sale;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JLabel;

public class MonthXiaoshouFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private long lastPopTime = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MonthXiaoshouFrame frame = new MonthXiaoshouFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	List<Shangzuolv> list = new ArrayList<Shangzuolv>();
	private JScrollPane scrollPane;
	private JTextField textField11;
	private JLabel label_1;
	private JButton button;
	
	
	public void loadData(int year) {
		year -= 1900;
		List<Sale> sales = (new SaleDao()).queryAll();
		
		list.clear();
		double total = 0;
		for(int month=1;month<=12;month++){
			Shangzuolv s = new Shangzuolv();
			s.name = month+"��";
			double num_month = 0;
			for (Sale sale : sales) {
				if(sale.show_date.getYear()==year && sale.show_date.getMonth() == (month-1)){
					num_month += sale.price;
					total += sale.price;
				}
			}
			s.rate = num_month;
			list.add(s);
		}
		
		String[] titles = new String[]{"�·�","���","ռȫ�����"};
		String[][] data = new String[list.size()][4];
		int i=0;
		for (Shangzuolv  sale : list) {
			double total_month = sale.rate;
			sale.rate = ((double)total_month) / total;
			String[] dataLine = new String[]{sale.name,
					total_month+"",
					sale.getRate()
					};
			data[i++] = dataLine;
		}
		
		DefaultTableModel model = new DefaultTableModel(data, titles){
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setModel(model);
	}

	
	/**
	 * Create the frame.
	 */
	public MonthXiaoshouFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 524, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 99, 478, 311);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		textField11 = new JTextField();
		textField11.setColumns(10);
		textField11.setBounds(152, 34, 53, 24);
		contentPane.add(textField11);
		
		label_1 = new JLabel("\u5E74");
		label_1.setBounds(209, 37, 22, 18);
		contentPane.add(label_1);
		
		button = new JButton("\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadData(Integer.valueOf(textField11.getText()));
			}
		});
		button.setBounds(287, 33, 113, 27);
		contentPane.add(button);
		
		setLocationRelativeTo(null);
		
		loadData(2017);
	}



}
