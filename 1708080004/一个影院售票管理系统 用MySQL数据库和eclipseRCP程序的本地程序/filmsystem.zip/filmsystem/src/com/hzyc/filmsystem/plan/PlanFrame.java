package com.hzyc.filmsystem.plan;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.hzyc.filmsystem.fangyingting.data.Fangyingting;
import com.hzyc.filmsystem.fangyingting.data.FangyingtingDao;
import com.hzyc.filmsystem.movie.data.Movie;
import com.hzyc.filmsystem.movie.data.MovieDao;
import com.hzyc.filmsystem.plan.data.Plan;
import com.hzyc.filmsystem.plan.data.PlanDao;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.print.DocFlavor.STRING;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class PlanFrame extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;
	private long lastPopTime = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PlanFrame frame = new PlanFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	List<Plan> list = new ArrayList<Plan>();
	private JScrollPane scrollPane;
	public void loadData() {
		List<Plan> temp = (new PlanDao()).queryAll();
		list.clear();
		list.addAll(temp);
		showData();
	}
	
	void showData(){
		String[] titles = new String[]{"��ӳ��","��Ӱ����", "����","��ʼʱ��", "����ʱ��", "����", "�۸�"};
		String[][] data = new String[list.size()][7];
		int i=0;
		for (Plan plan : list) {
			Fangyingting fangyingting = (new FangyingtingDao()).get(plan.id_fangyingting);
			Movie movie = (new MovieDao()).get(plan.id_movie);
			String[] dataLine = new String[]{fangyingting.name,movie.name,plan.getShow_date(),
					plan.getStart_time(),plan.getEnd_time(),plan.language,plan.price.toString()
					};
			data[i++] = dataLine;
		}
		
		DefaultTableModel model = new DefaultTableModel(data, titles){
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setModel(model);
		
		table.addMouseListener(new MouseAdapter() { 

			public void mouseClicked(MouseEvent e) { 
				
				if(e.getClickCount() == 2){
					long gap = System.currentTimeMillis() - lastPopTime;
					if(gap > 1000){
	            	  	int row = ((JTable)e.getSource()).rowAtPoint(e.getPoint()); //�����λ�� 
	            	  	PlanAddFrame frame = new PlanAddFrame();
	            	  	frame.planFrame = PlanFrame.this;
	            	  	frame.plan = list.get(row);
	            	  	frame.init();
	            	  	frame.setVisible(true);
	            	  	lastPopTime = System.currentTimeMillis();
					}
              	}
			}
		});
	}

	
	/**
	 * Create the frame.
	 */
	public PlanFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 758, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 99, 712, 311);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		textField = new JTextField();
		textField.setBounds(154, 37, 134, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String key = textField.getText().trim();
				if(key.isEmpty()){
					JOptionPane.showMessageDialog(null, "��������Ϊ��");
					return;
				}
				List<Fangyingting> list_fangyingting = (new FangyingtingDao()).search(key);
				List<Movie> list_movie = (new MovieDao()).search(key);
				List<Plan> temp = new ArrayList<Plan>();
				for (Fangyingting f : list_fangyingting) {
					List<Plan> result = (new PlanDao()).search_fangyingting(f.id);
					temp.addAll(result);
				}
				for (Movie f : list_movie) {
					List<Plan> result = (new PlanDao()).search_movie(f.id);
					temp.addAll(result);
				}

				list.clear();
				list.addAll(temp);
				showData();
			}
		});
		btnNewButton.setBounds(334, 36, 113, 27);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("\u6DFB\u52A0");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PlanAddFrame frame = new PlanAddFrame();
				frame.planFrame = PlanFrame.this;
				frame.setVisible(true);
			}
		});
		button.setBounds(489, 36, 113, 27);
		contentPane.add(button);
		
		setLocationRelativeTo(null);
		
		loadData();
	}



}
