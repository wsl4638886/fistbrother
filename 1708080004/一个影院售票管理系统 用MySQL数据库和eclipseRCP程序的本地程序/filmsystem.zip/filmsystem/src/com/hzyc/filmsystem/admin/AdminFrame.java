package com.hzyc.filmsystem.admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.hzyc.filmsystem.fangyingting.FangyingtingFrame;
import com.hzyc.filmsystem.movie.MovieFrame;
import com.hzyc.filmsystem.plan.PlanFrame;
import com.hzyc.filmsystem.sale.SaleFrame;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AdminFrame extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminFrame frame = new AdminFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 476);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("\u653E\u6620\u5385\u7BA1\u7406");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FangyingtingFrame frame = new FangyingtingFrame();
				frame.setVisible(true);
			}
		});
		button.setBounds(43, 70, 142, 27);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u7535\u5F71\u7BA1\u7406");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MovieFrame frame = new MovieFrame();
				frame.setVisible(true);
			}
		});
		button_1.setBounds(245, 70, 142, 27);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("\u4E0A\u6620\u8BA1\u5212\u7BA1\u7406");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PlanFrame frame = new PlanFrame();
				frame.setVisible(true);
			}
		});
		button_2.setBounds(418, 70, 142, 27);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("\u552E\u7968\u67E5\u8BE2");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SaleFrame frame = new SaleFrame();
				frame.setVisible(true);
			}
		});
		button_3.setBounds(591, 70, 142, 27);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("\u9500\u552E\u660E\u7EC6");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				XiaoshowmingxiFrame frame = new XiaoshowmingxiFrame();
				frame.setVisible(true);
			}
		});
		button_4.setBounds(43, 142, 142, 27);
		contentPane.add(button_4);
		
		JButton button_5 = new JButton("\u653E\u6620\u5385\u4E0A\u5EA7\u7387");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FangyingtingShangzuolvFrame frame = new FangyingtingShangzuolvFrame();
				frame.setVisible(true);
			}
		});
		button_5.setBounds(245, 142, 142, 27);
		contentPane.add(button_5);
		
		JButton button_6 = new JButton("\u5F71\u7247\u4E0A\u5EA7\u7387");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MovieShangzuolvFrame frame = new MovieShangzuolvFrame();
				frame.setVisible(true);
			}
		});
		button_6.setBounds(418, 142, 142, 27);
		contentPane.add(button_6);
		
		JButton button_7 = new JButton("\u6BCF\u6708\u9500\u552E\u989D");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MonthXiaoshouFrame frame = new MonthXiaoshouFrame();
				frame.setVisible(true);
			}
		});
		button_7.setBounds(591, 142, 142, 27);
		contentPane.add(button_7);
		
		setLocationRelativeTo(null);
	}
}
