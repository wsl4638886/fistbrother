package com.hzyc.filmsystem.sale;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.hzyc.filmsystem.fangyingting.data.Fangyingting;
import com.hzyc.filmsystem.fangyingting.data.FangyingtingDao;
import com.hzyc.filmsystem.movie.data.Movie;
import com.hzyc.filmsystem.movie.data.MovieDao;
import com.hzyc.filmsystem.sale.data.SaleDao;
import com.hzyc.filmsystem.sale.data.Sale;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class SaleFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTextField textField;
	private long lastPopTime = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SaleFrame frame = new SaleFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	List<Sale> list = new ArrayList<Sale>();
	private JScrollPane scrollPane;
	public void loadData() {
		List<Sale> temp = (new SaleDao()).queryAll();
		list.clear();
		list.addAll(temp);
		showData();
	}
	
	void showData(){
		String[] titles = new String[]{"��ӳ��","��Ӱ����", "����","��ʼʱ��", "����ʱ��", "����", "�۸�"
				,"������","��λ","��Ʊ��"};
		String[][] data = new String[list.size()][10];
		int i=0;
		for (Sale sale : list) {
			Fangyingting fangyingting = (new FangyingtingDao()).get(sale.id_fangyingting);
			Movie movie = (new MovieDao()).get(sale.id_movie);
			String[] dataLine = new String[]{fangyingting.name,movie.name,sale.getShow_date(),
					sale.getStart_time(),sale.getEnd_time(),sale.language,sale.price.toString(),
					sale.code,
					sale.row + "��" + sale.col +"��",
					sale.name
					};
			data[i++] = dataLine;
		}
		
		DefaultTableModel model = new DefaultTableModel(data, titles){
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setModel(model);
		
		/*
		table.addMouseListener(new MouseAdapter() { 

			public void mouseClicked(MouseEvent e) { 
				
				if(e.getClickCount() == 2){
					long gap = System.currentTimeMillis() - lastPopTime;
					if(gap > 1000){
	            	  	int row = ((JTable)e.getSource()).rowAtPoint(e.getPoint()); //�����λ�� 
	            	  	SaleAddFrame frame = new SaleAddFrame();
	            	  	frame.saleFrame = SaleFrame.this;
	            	  	frame.sale = list.get(row);
	            	  	frame.init();
	            	  	frame.setVisible(true);
	            	  	lastPopTime = System.currentTimeMillis();
					}
              	}
			}
		});
		*/
	}

	
	/**
	 * Create the frame.
	 */
	public SaleFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 758, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 99, 712, 311);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		textField = new JTextField();
		textField.setBounds(216, 39, 134, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String key = textField.getText().trim();
				if(key.isEmpty()){
					JOptionPane.showMessageDialog(null, "��������Ϊ��");
					return;
				}
				
				List<Fangyingting> list_fangyingting = (new FangyingtingDao()).search(key);
				List<Movie> list_movie = (new MovieDao()).search(key);
				List<Sale> temp = new ArrayList<Sale>();
				for (Fangyingting f : list_fangyingting) {
					List<Sale> result = (new SaleDao()).search_fangyingting(f.id);
					temp.addAll(result);
				}
				for (Movie f : list_movie) {
					List<Sale> result = (new SaleDao()).search_movie(f.id);
					temp.addAll(result);
				}
				List<Sale> result = (new SaleDao()).search_name(key);
				temp.addAll(result);
				
				list.clear();
				list.addAll(temp);
				showData();
			}
		});
		btnNewButton.setBounds(396, 38, 113, 27);
		contentPane.add(btnNewButton);
		
		setLocationRelativeTo(null);
		
		loadData();
	}



}
