package com.hzyc.filmsystem.main;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.hzyc.filmsystem.admin.LoginFrame;
import com.hzyc.filmsystem.sale.SaleAddFrame;

import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainFrame extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 490, 321);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("\u81EA\u52A9\u8D2D\u7968");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SaleAddFrame frame = new SaleAddFrame();
				frame.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 30));
		btnNewButton.setBounds(139, 55, 186, 81);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u7BA1\u7406\u5458");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginFrame frame = new LoginFrame();
				frame.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(174, 234, 113, 27);
		contentPane.add(btnNewButton_1);
		
		setLocationRelativeTo(null);
	}

}
