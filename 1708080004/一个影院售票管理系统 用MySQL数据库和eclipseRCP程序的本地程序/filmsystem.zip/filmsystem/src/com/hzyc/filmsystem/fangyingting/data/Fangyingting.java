package com.hzyc.filmsystem.fangyingting.data;

import java.util.List;
import java.util.ArrayList;


//������ӳ�������ơ����ͣ���ͨ��3D��IMAX������λ������������չ��....�ȡ�
public class Fangyingting {
	public Integer id;
	public String name,type;
	public Integer row,col;
	
	public List<Zuowei> zuoweiList = new ArrayList<Zuowei>();
	public Integer getZuoweiNum(){
		return zuoweiList.size();
	}
	public Zuowei getZuoWei(int index){
		return zuoweiList.get(index);
	}
	
	public Fangyingting() {
		// TODO Auto-generated constructor stub
	}
	
	public Fangyingting(String name, String type, int row, int col) {
		super();
		this.name = name;
		this.type = type;
		this.row = row;
		this.col = col;
		for(int i=0;i<row;i++){
			for(int j=0;j<col;j++){
				zuoweiList.add(new Zuowei(name, i+1, j+1));
			}
		}
	}
	
	public void addZuowei(Zuowei zuowei) {
		zuoweiList.add(zuowei);
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return id.equals( ((Fangyingting)obj).id );
	}
}
