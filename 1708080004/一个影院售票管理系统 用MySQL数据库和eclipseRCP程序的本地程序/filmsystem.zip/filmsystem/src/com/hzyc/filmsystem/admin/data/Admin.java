package com.hzyc.filmsystem.admin.data;

public class Admin {
	public Integer id;
	public String username,password;
}
