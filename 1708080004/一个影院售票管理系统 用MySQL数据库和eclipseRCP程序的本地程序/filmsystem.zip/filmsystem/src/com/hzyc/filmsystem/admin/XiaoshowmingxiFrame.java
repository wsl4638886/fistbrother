package com.hzyc.filmsystem.admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.hzyc.filmsystem.fangyingting.data.Fangyingting;
import com.hzyc.filmsystem.fangyingting.data.FangyingtingDao;
import com.hzyc.filmsystem.movie.data.Movie;
import com.hzyc.filmsystem.movie.data.MovieDao;
import com.hzyc.filmsystem.sale.data.SaleDao;
import com.hzyc.filmsystem.sale.data.Sale;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JLabel;

public class XiaoshowmingxiFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private long lastPopTime = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					XiaoshowmingxiFrame frame = new XiaoshowmingxiFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	List<Sale> list = new ArrayList<Sale>();
	private JScrollPane scrollPane;
	private JLabel label;
	private JTextField textField11;
	private JLabel label_1;
	private JTextField textField12;
	private JLabel label_2;
	private JTextField textField13;
	private JLabel label_3;
	private JLabel label_4;
	private JTextField textField21;
	private JLabel label_5;
	private JTextField textField22;
	private JLabel label_6;
	private JTextField textField23;
	private JLabel label_7;
	private JButton button;
	
	
	public void loadData() {
		List<Sale> temp = (new SaleDao()).queryAll();
		list.clear();
		list.addAll(temp);
		showData();
	}
	
	public void searchData(Date start, Date end){
		List<Sale> temp = (new SaleDao()).queryAll();
		list.clear();
		for (Sale sale : temp) {
			if(sale.show_date.after(start) && sale.show_date.before(end)){
				list.add(sale);
			}
		}
		showData();
	}
	
	void showData(){
		String[] titles = new String[]{"��ӳ��","��Ӱ����", "����","��ʼʱ��", "����ʱ��", "����", "�۸�"
				,"������","��λ","��Ʊ��"};
		String[][] data = new String[list.size()][10];
		int i=0;
		for (Sale sale : list) {
			Fangyingting fangyingting = (new FangyingtingDao()).get(sale.id_fangyingting);
			Movie movie = (new MovieDao()).get(sale.id_movie);
			String[] dataLine = new String[]{fangyingting.name,movie.name,sale.getShow_date(),
					sale.getStart_time(),sale.getEnd_time(),sale.language,sale.price.toString(),
					sale.code,
					sale.row + "��" + sale.col +"��",
					sale.name
					};
			data[i++] = dataLine;
		}
		
		DefaultTableModel model = new DefaultTableModel(data, titles){
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setModel(model);
	}

	
	/**
	 * Create the frame.
	 */
	public XiaoshowmingxiFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 758, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 99, 712, 311);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		label = new JLabel("\u5F00\u59CB\uFF1A");
		label.setBounds(109, 16, 72, 18);
		contentPane.add(label);
		
		textField11 = new JTextField();
		textField11.setColumns(10);
		textField11.setBounds(195, 13, 53, 24);
		contentPane.add(textField11);
		
		label_1 = new JLabel("\u5E74");
		label_1.setBounds(252, 16, 22, 18);
		contentPane.add(label_1);
		
		textField12 = new JTextField();
		textField12.setColumns(10);
		textField12.setBounds(276, 13, 53, 24);
		contentPane.add(textField12);
		
		label_2 = new JLabel("\u6708");
		label_2.setBounds(333, 16, 22, 18);
		contentPane.add(label_2);
		
		textField13 = new JTextField();
		textField13.setColumns(10);
		textField13.setBounds(365, 13, 53, 24);
		contentPane.add(textField13);
		
		label_3 = new JLabel("\u65E5");
		label_3.setBounds(422, 16, 22, 18);
		contentPane.add(label_3);
		
		label_4 = new JLabel("\u7ED3\u675F\uFF1A");
		label_4.setBounds(109, 50, 72, 18);
		contentPane.add(label_4);
		
		textField21 = new JTextField();
		textField21.setColumns(10);
		textField21.setBounds(195, 47, 53, 24);
		contentPane.add(textField21);
		
		label_5 = new JLabel("\u5E74");
		label_5.setBounds(252, 50, 22, 18);
		contentPane.add(label_5);
		
		textField22 = new JTextField();
		textField22.setColumns(10);
		textField22.setBounds(276, 47, 53, 24);
		contentPane.add(textField22);
		
		label_6 = new JLabel("\u6708");
		label_6.setBounds(333, 50, 22, 18);
		contentPane.add(label_6);
		
		textField23 = new JTextField();
		textField23.setColumns(10);
		textField23.setBounds(365, 47, 53, 24);
		contentPane.add(textField23);
		
		label_7 = new JLabel("\u65E5");
		label_7.setBounds(422, 50, 22, 18);
		contentPane.add(label_7);
		
		button = new JButton("\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date start = new Date(
						Integer.valueOf(textField11.getText())-1900, 
						Integer.valueOf(textField12.getText())-1, 
						Integer.valueOf(textField13.getText())-1
						);
				Date end = new Date(
						Integer.valueOf(textField21.getText())-1900, 
						Integer.valueOf(textField22.getText())-1, 
						Integer.valueOf(textField23.getText())+1
						);
				
				searchData(start, end);
			}
		});
		button.setBounds(482, 29, 113, 27);
		contentPane.add(button);
		
		setLocationRelativeTo(null);
		
		loadData();
	}



}
