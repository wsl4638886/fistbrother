package com.hzyc.filmsystem.data;

/**
 * ��Ա��DAO
 */
import java.sql.ResultSet;

public class BaseDao  {

	SqlManager manage;
	
	public BaseDao(){
		manage=SqlManager.createInstance();
		manage.connectDB();
	}

	public void destroy(){
		manage.closeDB();
	}
	
	public ResultSet executeQuery(String sql, Object[] params) {
		return manage.executeQuery(sql, params);
	}
	
	public boolean executeUpdate(String sql, Object[] params) {
		return manage.executeUpdate(sql, params);
	}
}

