package com.hzyc.filmsystem.fangyingting.data;

public class Zuowei {
	public Integer id;
	public String name_fangyingting;
	public String name;
	public Integer row,col;
	
	
	public Zuowei() {
		// TODO Auto-generated constructor stub
	}
	
	public Zuowei(String name_fangyingting, Integer row, Integer col) {
		super();
		this.name_fangyingting = name_fangyingting;
		this.row = row;
		this.col = col;
		this.name = "R" + row + "C" + col;
	}

	
}
