package com.hzyc.filmsystem.admin.data;

import java.util.List;

import com.hzyc.filmsystem.data.BaseDao;
import com.hzyc.filmsystem.admin.data.Admin;

import java.sql.ResultSet;
import java.util.ArrayList;


public class AdminDao extends BaseDao{

	public List<Admin> search(String username, String password){
    	List<Admin> set = new ArrayList<Admin>();
    	try{
			String sql="select * from admin where username = ? and password = ?";
			Object[] params = new Object[]{username,password};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Admin result = new Admin();
				result.id = rs.getInt("id");
				
				result.username = rs.getString("username");
				result.password = rs.getString("username");
				
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
		return set;
	}
}
