package com.hzyc.filmsystem.sale;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.hzyc.filmsystem.fangyingting.data.Fangyingting;
import com.hzyc.filmsystem.fangyingting.data.FangyingtingDao;
import com.hzyc.filmsystem.fangyingting.data.Zuowei;
import com.hzyc.filmsystem.movie.data.Movie;
import com.hzyc.filmsystem.movie.data.MovieDao;
import com.hzyc.filmsystem.plan.data.Plan;
import com.hzyc.filmsystem.plan.data.PlanDao;
import com.hzyc.filmsystem.sale.data.SaleDao;
import com.hzyc.filmsystem.sale.data.Sale;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.awt.event.ActionEvent;

public class SaleAddFrame extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SaleAddFrame frame = new SaleAddFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public SaleFrame saleFrame;
	public Sale sale;
	private JButton button;
	private JLabel label_4;
	private JLabel label_5;
	private JTextField textField5;
	private JTextField textField6;
	private JComboBox textField1;
	private JComboBox textField2;
	public void init() {
		// TODO Auto-generated method stub
	}
	
	
	List<Sale> list_sale = (new SaleDao()).queryAll();
	List<Plan> list_plan = (new PlanDao()).queryAll();
	
	List<Date> list_date_show = new ArrayList<Date>();
	List<Movie> list_movie_show = new ArrayList<Movie>();
	List<Time> list_time_show = new ArrayList<Time>();
	List<Fangyingting> list_fangyingting_show = new ArrayList<Fangyingting>();
	List<Zuowei> list_zuowei_show = new ArrayList<Zuowei>();
	
	Plan currentPlan = null;
	
	void setAvailableDate(){
		list_date_show.clear(); 
		for (Plan plan : list_plan) {
			System.out.println(list_plan.size());
			if(!list_date_show.contains(plan.show_date)){
				long diff = plan.show_date.getTime() - (new Date(System.currentTimeMillis())).getTime();
				if(diff > 0 && diff < 3 * 24 * 60 * 60 * 1000){//������
					//if(!list_date_show.contains(plan.show_date)){
						list_date_show.add(plan.show_date);
					//}
				}
			}
		}
		
		String[] itemStrings = new String[list_date_show.size()];
		for(int i=0;i<list_date_show.size();i++){
			itemStrings[i] = new SimpleDateFormat("yyyy-MM-dd").format(list_date_show.get(i)).toString();
		}
		textField3.setModel(new DefaultComboBoxModel<String>(itemStrings));
		
		if(list_date_show.size()>0){
			setDate(list_date_show.get(0));
		}
	}
	
	void setDate(Date date){
		list_movie_show.clear();
		for (Plan plan : list_plan) {
			if(plan.show_date.equals(date)){
				Movie movie = (new MovieDao()).get(plan.id_movie);
				if(!list_movie_show.contains(movie)){
					list_movie_show.add(movie);
				}
			}
		}
		
		String[] itemStrings = new String[list_movie_show.size()];
		for(int i=0;i<list_movie_show.size();i++){
			itemStrings[i] = list_movie_show.get(i).name.toString();
		}
		textField2.setModel(new DefaultComboBoxModel<String>(itemStrings));
		
		if(list_movie_show.size()>0){
			setMovie(date, list_movie_show.get(0));
		}
	}
	
	void setMovie(Date date, Movie movie){
		list_time_show.clear();
		for (Plan plan : list_plan) {
			if(plan.show_date.equals(date)){
				if(plan.id_movie.equals(movie.id)){
					if(!list_time_show.contains(plan.start_time)){
						list_time_show.add(plan.start_time);
					}
				}
			}
		}
		
		String[] itemStrings = new String[list_time_show.size()];
		for(int i=0;i<list_time_show.size();i++){
			itemStrings[i] = new SimpleDateFormat("hh:mm").format(list_time_show.get(i)).toString();
		}
		textField4.setModel(new DefaultComboBoxModel<String>(itemStrings));
		
		if(list_time_show.size()>0){
			setStartTime(date, movie, list_time_show.get(0));
		}
	}
	
	void setStartTime(Date date, Movie movie, Time time) {
		list_fangyingting_show.clear();
		for (Plan plan : list_plan) {
			if(plan.show_date.equals(date)){
				if(plan.id_movie.equals(movie.id)){
					if(plan.start_time.equals(time)){
						Fangyingting f = (new FangyingtingDao()).get(plan.id_fangyingting);
						if(!list_fangyingting_show.contains(f)){
							list_fangyingting_show.add(f);
						}
					}
				}
			}
		}
		
		String[] itemStrings = new String[list_fangyingting_show.size()];
		for(int i=0;i<list_fangyingting_show.size();i++){
			itemStrings[i] = list_fangyingting_show.get(i).name.toString();
		}
		textField1.setModel(new DefaultComboBoxModel<String>(itemStrings));
		
		if(list_fangyingting_show.size()>0){
			setFangyingting(date, movie, time, list_fangyingting_show.get(0));
		}
	}

	void setFangyingting(Date date, Movie movie, Time time, Fangyingting fangyingting) {
		list_zuowei_show.clear();
		for (Plan plan : list_plan) {
			if(plan.show_date.equals(date)){
				if(plan.id_movie.equals(movie.id)){
					if(plan.start_time.equals(time)){
						if(plan.id_fangyingting.equals(fangyingting.id)){
							for(Zuowei zuowei : fangyingting.zuoweiList){
								boolean out = false;
								for (Sale sale : list_sale) {
									if(sale.show_date.equals(date) &&
									        sale.id_movie.equals(movie.id) &&
									        sale.start_time.equals(time) &&
									        sale.id_fangyingting.equals(fangyingting.id)
											){
										if(zuowei.row.equals(sale.row) && zuowei.col.equals(sale.col)){
											out = true;
										}
									}
								}
								if(!out){
									list_zuowei_show.add(zuowei);
								}
							}
							currentPlan = plan;
							textField5.setText(plan.language.toString());
							textField6.setText(plan.price.toString());
							textField7.setText( Math.abs((new Random(System.currentTimeMillis())).nextLong())%100000000 + "");
						}
					}
				}
			}
		}
		
		String[] itemStrings = new String[list_zuowei_show.size()];
		for(int i=0;i<list_zuowei_show.size();i++){
			itemStrings[i] = list_zuowei_show.get(i).row + "��" + list_zuowei_show.get(i).col + "��";
		}
		textField8.setModel(new DefaultComboBoxModel<String>(itemStrings));
	}

	int findFangyingting(String name){
		int index = 0;
		for(int i=0;i<list_fangyingting_show.size();i++){
			if(list_fangyingting_show.get(i).name.equals(name)){
				index = i;
				break;
			}
		}
		return index;
	}
	int findMovie(String name){
		int index = 0;
		for(int i=0;i<list_movie_show.size();i++){
			if(list_movie_show.get(i).name.equals(name)){
				index = i;
				break;
			}
		}
		return index;
	}
	
	
	private JLabel label_6;
	private JLabel label_7;
	private JLabel label_8;
	private JTextField textField7;
	private JTextField textField9;
	private JComboBox textField8;
	private JComboBox textField3;
	private JComboBox textField4;

	/**
	 * Create the frame.
	 */
	public SaleAddFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 478, 424);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u653E\u6620\u5385\uFF1A");
		label.setBounds(113, 118, 72, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u7535\u5F71\uFF1A");
		label_1.setBounds(113, 50, 72, 18);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u65E5\u671F\uFF1A");
		label_2.setBounds(113, 16, 72, 18);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u8BED\u8A00\uFF1A");
		label_3.setBounds(113, 186, 72, 18);
		contentPane.add(label_3);
		
		JButton btn_ok = new JButton("\u786E\u8BA4");
		btn_ok.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {
				if(textField9.getText().isEmpty()
						){
					JOptionPane.showMessageDialog(null, "��������Ϊ��");
				}else {
					if(list_zuowei_show.size()==0){
						JOptionPane.showMessageDialog(null, "Ʊ������");
						return;
					}
					Sale sale = new Sale(
							currentPlan.id_fangyingting,//list_fangyingting_show.get(textField1.getSelectedIndex()).id, 
							currentPlan.id_movie,//list_movie_show.get(textField2.getSelectedIndex()).id, 
							currentPlan.show_date,//list_date_show.get(textField3.getSelectedIndex()),
							currentPlan.start_time,//list_time_show.get(textField4.getSelectedIndex()),
							currentPlan.end_time,//end_time,
							currentPlan.language,//textField5.getText().trim(), 
							currentPlan.price,//Double.valueOf(textField6.getText().trim())
							textField7.getText().toString(),
							list_zuowei_show.get(textField8.getSelectedIndex()).row,
							list_zuowei_show.get(textField8.getSelectedIndex()).col,
							textField9.getText().toString()
							);
					if(SaleAddFrame.this.sale == null){
						(new SaleDao()).add(sale);
						list_sale = (new SaleDao()).queryAll();
						if(list_date_show.size()>0){
							setDate(list_date_show.get(textField3.getSelectedIndex()));
						}
					}else {
						//sale.id = SaleAddFrame.this.sale.id;
						//(new SaleDao()).update(sale);
					}
					
					if(saleFrame!=null){
						saleFrame.loadData();
					}
				}
			}
		});
		btn_ok.setBounds(98, 334, 113, 27);
		contentPane.add(btn_ok);
		
		setLocationRelativeTo(null);
		
		button = new JButton("\u53D6\u6D88");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		button.setBounds(256, 334, 113, 27);
		contentPane.add(button);
		
		label_4 = new JLabel("\u4EF7\u683C\uFF1A");
		label_4.setBounds(113, 217, 72, 18);
		contentPane.add(label_4);
		
		label_5 = new JLabel("\u5F00\u59CB\u65F6\u95F4\uFF1A");
		label_5.setBounds(86, 84, 99, 18);
		contentPane.add(label_5);
		
		textField5 = new JTextField();
		textField5.setEditable(false);
		textField5.setColumns(10);
		textField5.setBounds(199, 183, 156, 24);
		contentPane.add(textField5);
		
		textField6 = new JTextField();
		textField6.setEditable(false);
		textField6.setColumns(10);
		textField6.setBounds(199, 214, 156, 24);
		contentPane.add(textField6);
		
		textField1 = new JComboBox();
		textField1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setFangyingting(
						list_date_show.get(textField3.getSelectedIndex()), 
						list_movie_show.get(textField2.getSelectedIndex()),
						list_time_show.get(textField4.getSelectedIndex()),
						list_fangyingting_show.get(textField1.getSelectedIndex())
						);
			}
		});
		textField1.setBounds(199, 115, 156, 24);
		contentPane.add(textField1);
		
		textField2 = new JComboBox();
		textField2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setMovie(list_date_show.get(textField3.getSelectedIndex()), 
						list_movie_show.get(textField2.getSelectedIndex())
						);
			}
		});
		textField2.setBounds(199, 47, 156, 24);
		contentPane.add(textField2);
		
		label_6 = new JLabel("\u6761\u5F62\u7801\uFF1A");
		label_6.setBounds(113, 248, 72, 18);
		contentPane.add(label_6);
		
		label_7 = new JLabel("\u5EA7\u4F4D\uFF1A");
		label_7.setBounds(113, 152, 72, 18);
		contentPane.add(label_7);
		
		label_8 = new JLabel("\u8D2D\u7968\u4EBA\uFF1A");
		label_8.setBounds(113, 282, 72, 18);
		contentPane.add(label_8);
		
		textField7 = new JTextField();
		textField7.setEditable(false);
		textField7.setColumns(10);
		textField7.setBounds(199, 245, 156, 24);
		contentPane.add(textField7);
		
		textField9 = new JTextField();
		textField9.setColumns(10);
		textField9.setBounds(199, 279, 156, 24);
		contentPane.add(textField9);
		
		textField8 = new JComboBox();
		textField8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		textField8.setBounds(199, 149, 156, 24);
		contentPane.add(textField8);
		
		textField3 = new JComboBox();
		textField3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setDate(list_date_show.get(textField3.getSelectedIndex()));
			}
		});
		textField3.setBounds(199, 13, 156, 24);
		contentPane.add(textField3);
		
		textField4 = new JComboBox();
		textField4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setStartTime(
						list_date_show.get(textField3.getSelectedIndex()), 
						list_movie_show.get(textField2.getSelectedIndex()),
						list_time_show.get(textField4.getSelectedIndex())
						);
			}
		});
		textField4.setBounds(199, 81, 156, 24);
		contentPane.add(textField4);
		
		
		setAvailableDate();
	}
	
	
}
