package com.hzyc.filmsystem.admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.hzyc.filmsystem.admin.data.Shangzuolv;
import com.hzyc.filmsystem.fangyingting.data.Fangyingting;
import com.hzyc.filmsystem.fangyingting.data.FangyingtingDao;
import com.hzyc.filmsystem.plan.data.Plan;
import com.hzyc.filmsystem.plan.data.PlanDao;
import com.hzyc.filmsystem.sale.data.SaleDao;
import com.hzyc.filmsystem.sale.data.Sale;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JLabel;

public class FangyingtingShangzuolvFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private long lastPopTime = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FangyingtingShangzuolvFrame frame = new FangyingtingShangzuolvFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	List<Shangzuolv> list = new ArrayList<Shangzuolv>();
	private JScrollPane scrollPane;
	private JTextField textField11;
	private JLabel label_1;
	private JTextField textField12;
	private JLabel label_2;
	private JButton button;
	
	
	public void loadData() {
		List<Sale> sales = (new SaleDao()).queryAll();
		List<Plan> plans = (new PlanDao()).queryAll();
		List<Fangyingting> fangyingtings = (new FangyingtingDao()).queryAll();
		
		list.clear();
		for (Fangyingting fangyingting : fangyingtings) {
			Shangzuolv s = new Shangzuolv();
			s.name = fangyingting.name;
			s.num_zuowei = fangyingting.getZuoweiNum();
			
			int num_total = 0;
			int num_sale = 0;
			s.num_show = 0;
			
			for (Plan plan : plans) {
				if(plan.id_fangyingting.equals(fangyingting.id)){
					int num_zuowei = fangyingting.getZuoweiNum();
					int num_piao = 0;
					for (Sale sale : sales) {
						if(plan.equals(sale)){
							num_piao++;
						}
					}
					//System.out.println(num_zuowei + " " + num_piao);
					num_total += num_zuowei;
					num_sale += num_piao;
					s.num_show++;
				}
			}
			s.rate = ((double)num_sale) / num_total;
			
			list.add(s);
		}
		
		showData();
	}
	
	public void searchData(int year,int month){
		List<Sale> sales = (new SaleDao()).queryAll();
		List<Plan> plans = (new PlanDao()).queryAll();
		List<Fangyingting> fangyingtings = (new FangyingtingDao()).queryAll();
		
		
		List<Plan> plansTemp = new ArrayList<Plan>();
		for (Plan sale : plans) {
			if(sale.show_date.getYear() == year && sale.show_date.getMonth() == month){
				plansTemp.add(sale);
			}
		}
		plans.clear();
		plans.addAll(plansTemp);
		
		
		list.clear();
		for (Fangyingting fangyingting : fangyingtings) {
			Shangzuolv s = new Shangzuolv();
			s.name = fangyingting.name;
			s.num_zuowei = fangyingting.getZuoweiNum();
			
			int num_total = 0;
			int num_sale = 0;
			s.num_show = 0;
			
			for (Plan plan : plans) {
				if(plan.id_fangyingting.equals(fangyingting.id)){
					int num_zuowei = fangyingting.getZuoweiNum();
					int num_piao = 0;
					for (Sale sale : sales) {
						if(plan.equals(sale)){
							num_piao++;
						}
					}
					//System.out.println(num_zuowei + " " + num_piao);
					num_total += num_zuowei;
					num_sale += num_piao;
					s.num_show++;
				}
			}
			s.rate = ((double)num_sale) / num_total;
			
			list.add(s);
		}
		
		showData();
	}
	
	void showData(){
		String[] titles = new String[]{"��ӳ��","��λ��","��ӳ����","������"};
		String[][] data = new String[list.size()][4];
		int i=0;
		for (Shangzuolv  sale : list) {
			String[] dataLine = new String[]{sale.name,
					sale.num_zuowei.toString(),
					sale.num_show.toString(),
					sale.getRate()
					};
			data[i++] = dataLine;
		}
		
		DefaultTableModel model = new DefaultTableModel(data, titles){
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setModel(model);
	}

	
	/**
	 * Create the frame.
	 */
	public FangyingtingShangzuolvFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 524, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 99, 478, 311);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		textField11 = new JTextField();
		textField11.setColumns(10);
		textField11.setBounds(82, 35, 53, 24);
		contentPane.add(textField11);
		
		label_1 = new JLabel("\u5E74");
		label_1.setBounds(139, 38, 22, 18);
		contentPane.add(label_1);
		
		textField12 = new JTextField();
		textField12.setColumns(10);
		textField12.setBounds(163, 35, 53, 24);
		contentPane.add(textField12);
		
		label_2 = new JLabel("\u6708");
		label_2.setBounds(220, 38, 22, 18);
		contentPane.add(label_2);
		
		button = new JButton("\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchData(Integer.valueOf(textField11.getText())-1900, Integer.valueOf(textField12.getText())-1);
			}
		});
		button.setBounds(310, 34, 113, 27);
		contentPane.add(button);
		
		setLocationRelativeTo(null);
		
		loadData();
	}



}
