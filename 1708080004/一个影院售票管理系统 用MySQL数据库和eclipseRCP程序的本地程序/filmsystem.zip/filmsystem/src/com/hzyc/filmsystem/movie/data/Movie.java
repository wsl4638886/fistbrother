package com.hzyc.filmsystem.movie.data;

import java.util.List;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


//2.1 ӰƬ��Ϣ���ӣ�������Ӱ���ơ����ҡ����ݡ�Ƭ�������ӣ������ԣ���\Ӣ\��Ӣ�������ݼ�顢��ӳʱ�䡢����ʱ��...... 
//������չ����ӰƬ�ķ��溣����Ϣ�ȵȣ�

public class Movie implements Comparable<Movie> {
	public Integer id;
	public String name,state,director,length;
	public String language,description;
	public Date start_time,end_time;

	public Movie() {
		// TODO Auto-generated constructor stub
	}

	public Movie(String name, String state, String director, String length, String language, String description,
			Date start_time, Date end_time) {
		super();
		this.name = name;
		this.state = state;
		this.director = director;
		this.length = length;
		this.language = language;
		this.description = description;
		this.start_time = start_time;
		this.end_time = end_time;
	}
	
	public String getStart_time() {
		return new SimpleDateFormat("yyyy-MM-dd").format(start_time).toString();
	}
	public String getEnd_time() {
		return new SimpleDateFormat("yyyy-MM-dd").format(end_time).toString();
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return this.compareTo((Movie)obj) == 0;
	}
	
	@Override
	public int compareTo(Movie o) {
		// TODO Auto-generated method stub
		return id.compareTo(o.id);
	}

	@Override
	public String toString() {
		return "Movie [id=" + id + ", name=" + name + ", state=" + state + ", director=" + director + ", length="
				+ length + ", language=" + language + ", description=" + description + ", start_time=" + start_time
				+ ", end_time=" + end_time + "]";
	}
	
	
}
