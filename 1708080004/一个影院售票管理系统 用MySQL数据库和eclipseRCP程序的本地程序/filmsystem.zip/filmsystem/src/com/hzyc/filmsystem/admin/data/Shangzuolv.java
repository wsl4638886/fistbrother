package com.hzyc.filmsystem.admin.data;

public class Shangzuolv {
	public String name;
	public Integer num_zuowei;
	public Integer num_show;
	public Double rate;
	
	public String getRate() {
		Double d = rate;
		d *= 10000;
		d = (double) d.intValue();
		d /= 100;
		return d + "%";
	}
}
