package com.hzyc.filmsystem.movie.data;

import java.util.List;

import com.hzyc.filmsystem.data.BaseDao;
import com.hzyc.filmsystem.movie.data.Movie;

import java.sql.ResultSet;
import java.util.ArrayList;


public class MovieDao extends BaseDao{

	public List<Movie> search(String key){
    	List<Movie> set = new ArrayList<Movie>();
    	try{
			String sql="select * from movie where name like '%" + key + "%'";
			Object[] params = new Object[]{};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Movie result = new Movie();
				result.id = rs.getInt("id");
				
				result.name = rs.getString("name");
				result.state = rs.getString("state");
				result.director = rs.getString("director");
				result.length = rs.getString("length");
				result.language = rs.getString("language");
				result.description = rs.getString("description");
				result.start_time = rs.getDate("start_time");
				result.end_time = rs.getDate("end_time");
				
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
		return set;
	}
	
	public Movie get(Integer id){
    	List<Movie> set = new ArrayList<Movie>();
    	try{
			String sql="select * from movie where id=?";
			Object[] params = new Object[]{id};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Movie result = new Movie();
				result.id = rs.getInt("id");
				
				result.name = rs.getString("name");
				result.state = rs.getString("state");
				result.director = rs.getString("director");
				result.length = rs.getString("length");
				result.language = rs.getString("language");
				result.description = rs.getString("description");
				result.start_time = rs.getDate("start_time");
				result.end_time = rs.getDate("end_time");
				
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
    	
    	if(set.size()>0){
    		return set.get(0);
    	}else {
    		return null;
    	}
	}
	
	public List<Movie> queryAll(){
		return search("");
	}
	
	public boolean update(Movie f){
		boolean flag;
		String  sql="update movie set name=?,state=?,director=?,length=?,language=?,description=?"
				+ ",start_time=?, end_time=? where id = ?";
		Object[] params = new Object[]{
				f.name,
				f.state,
				f.director,
				f.length,
				f.language,
				f.description,
				f.start_time,
				f.end_time,
				f.id
				};
		flag = executeUpdate(sql, params);
		destroy();
		return flag;
	}
	
	public boolean add(Movie f){
		boolean flag;
		String  sql="insert into movie ("
				+ "name,state,director,length,language,description,start_time,end_time) "
				+ "values(?,?,?,?,?,?,?,?)";
		@SuppressWarnings("null")
		Object[] params = new Object[]{
				f.name,
				f.state,
				f.director,
				f.length,
				f.language,
				f.description,
				f.start_time,
				f.end_time
				};
		flag = executeUpdate(sql, params);
		
		destroy();
		return flag;
	}
}
