package com.hzyc.filmsystem.plan.data;

import java.util.List;

import com.hzyc.filmsystem.data.BaseDao;
import com.hzyc.filmsystem.plan.data.Plan;

import java.sql.Date;
import java.sql.ResultSet;
import java.util.ArrayList;


public class PlanDao extends BaseDao{

	public List<Plan> queryAll() {
    	List<Plan> set = new ArrayList<Plan>();
    	try{
			String sql="select * from plan";
			Object[] params = new Object[]{};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Plan result = new Plan();
				result.id = rs.getInt("id");
				
				result.id_fangyingting = rs.getInt("id_fangyingting");
				result.id_movie = rs.getInt("id_movie");
				result.show_date = rs.getDate("show_date");
				result.start_time = rs.getTime("start_time");
				result.end_time = rs.getTime("end_time");
				result.language = rs.getString("language");
				result.price = rs.getDouble("price");
				
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
		return set;
	}
	
	
	public List<Plan> search_fangyingting(Integer id_fangyingting){
    	List<Plan> set = new ArrayList<Plan>();
    	try{
			String sql="select * from plan where id_fangyingting = ?";
			Object[] params = new Object[]{id_fangyingting};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Plan result = new Plan();
				result.id = rs.getInt("id");
				
				result.id_fangyingting = rs.getInt("id_fangyingting");
				result.id_movie = rs.getInt("id_movie");
				result.show_date = rs.getDate("show_date");
				result.start_time = rs.getTime("start_time");
				result.end_time = rs.getTime("end_time");
				result.language = rs.getString("language");
				result.price = rs.getDouble("price");
				
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
		return set;
	}
	
	public List<Plan> search_movie(Integer id_movie){
    	List<Plan> set = new ArrayList<Plan>();
    	try{
			String sql="select * from plan where id_movie = ?";
			Object[] params = new Object[]{id_movie};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Plan result = new Plan();
				result.id = rs.getInt("id");
				
				result.id_fangyingting = rs.getInt("id_fangyingting");
				result.id_movie = rs.getInt("id_movie");
				result.show_date = rs.getDate("show_date");
				result.start_time = rs.getTime("start_time");
				result.end_time = rs.getTime("end_time");
				result.language = rs.getString("language");
				result.price = rs.getDouble("price");
				
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
		return set;
	}
	
	public List<Plan> search_date(Date key){
    	List<Plan> set = new ArrayList<Plan>();
    	try{
			String sql="select * from plan where show_date = ?";
			Object[] params = new Object[]{key};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Plan result = new Plan();
				result.id = rs.getInt("id");
				
				result.id_fangyingting = rs.getInt("id_fangyingting");
				result.id_movie = rs.getInt("id_movie");
				result.show_date = rs.getDate("show_date");
				result.start_time = rs.getTime("start_time");
				result.end_time = rs.getTime("end_time");
				result.language = rs.getString("language");
				result.price = rs.getDouble("price");
				
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
		return set;
	}
	
	public boolean update(Plan f){
		boolean flag;
		String  sql="update plan set id_fangyingting=?,id_movie=?,show_date=?,start_time=?,end_time=?,language=?,"
				+ "price=? where id = ?";
		Object[] params = new Object[]{
				f.id_fangyingting,
				f.id_movie,
				f.show_date,
				f.start_time,
				f.end_time,
				f.language,
				f.price,
				f.id
				};
		flag = executeUpdate(sql, params);
		destroy();
		return flag;
	}
	
	public boolean add(Plan f){
		boolean flag;
		String  sql="insert into plan ("
				+ "id_fangyingting,id_movie,show_date,start_time,end_time,language,price) "
				+ "values(?,?,?,?,?,?,?)";
		@SuppressWarnings("null")
		Object[] params = new Object[]{
				f.id_fangyingting,
				f.id_movie,
				f.show_date,
				f.start_time,
				f.end_time,
				f.language,
				f.price,
				};
		flag = executeUpdate(sql, params);
		
		destroy();
		return flag;
	}


}
