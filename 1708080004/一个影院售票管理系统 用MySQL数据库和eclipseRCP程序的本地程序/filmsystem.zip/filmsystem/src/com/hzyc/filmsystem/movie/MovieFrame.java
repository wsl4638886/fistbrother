package com.hzyc.filmsystem.movie;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.hzyc.filmsystem.movie.data.Movie;
import com.hzyc.filmsystem.movie.data.MovieDao;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.print.DocFlavor.STRING;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class MovieFrame extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;
	private long lastPopTime = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MovieFrame frame = new MovieFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	List<Movie> list = new ArrayList<Movie>();
	private JScrollPane scrollPane;
	public void loadData() {
		List<Movie> temp = (new MovieDao()).queryAll();
		list.clear();
		list.addAll(temp);
		showData();
	}
	
	void showData(){
		String[] titles = new String[]{"����","����", "����","Ƭ�������ӣ�", "����", "���ݼ��", "��ӳʱ��", "����ʱ��"};
		String[][] data = new String[list.size()][8];
		int i=0;
		for (Movie movie : list) {
			String[] dataLine = new String[]{movie.name,movie.state,movie.director,
					movie.length,movie.language,movie.description,
					movie.getStart_time(),movie.getEnd_time()};
			data[i++] = dataLine;
		}
		
		DefaultTableModel model = new DefaultTableModel(data, titles){
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setModel(model);
		
		table.addMouseListener(new MouseAdapter() { 

			public void mouseClicked(MouseEvent e) { 
				
				if(e.getClickCount() == 2){
					long gap = System.currentTimeMillis() - lastPopTime;
					if(gap > 1000){
	            	  	int row = ((JTable)e.getSource()).rowAtPoint(e.getPoint()); //�����λ�� 
	            	  	MovieAddFrame frame = new MovieAddFrame();
	            	  	frame.movieFrame = MovieFrame.this;
	            	  	frame.movie = list.get(row);
	            	  	frame.init();
	            	  	frame.setVisible(true);
	            	  	lastPopTime = System.currentTimeMillis();
					}
              	}
			}
		});
	}

	
	/**
	 * Create the frame.
	 */
	public MovieFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 758, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 99, 712, 311);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		textField = new JTextField();
		textField.setBounds(154, 37, 134, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String key = textField.getText().trim();
				if(key.isEmpty()){
					JOptionPane.showMessageDialog(null, "��������Ϊ��");
					return;
				}
				List<Movie> temp = (new MovieDao()).search(key);
				list.clear();
				list.addAll(temp);
				showData();
			}
		});
		btnNewButton.setBounds(334, 36, 113, 27);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("\u6DFB\u52A0");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MovieAddFrame frame = new MovieAddFrame();
				frame.movieFrame = MovieFrame.this;
				frame.setVisible(true);
			}
		});
		button.setBounds(489, 36, 113, 27);
		contentPane.add(button);
		
		setLocationRelativeTo(null);
		
		loadData();
	}



}
