package com.hzyc.filmsystem.fangyingting.data;

import java.util.List;

import com.hzyc.filmsystem.data.BaseDao;

import java.sql.ResultSet;
import java.util.ArrayList;


//������ӳ�������ơ����ͣ���ͨ��3D��IMAX������λ������������չ��....�ȡ�
public class FangyingtingDao extends BaseDao{

	public List<Fangyingting> search(String key){
    	List<Fangyingting> set = new ArrayList<Fangyingting>();
    	try{
			String sql="select * from fangyingting where name like '%" + key + "%'";
			Object[] params = new Object[]{};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Fangyingting result = new Fangyingting();
				result.id = rs.getInt("id");
				result.name = rs.getString("name");
				result.type = rs.getString("type");//����
				result.col = rs.getInt("col");
				result.row = rs.getInt("row");
				ResultSet rs2 = executeQuery("select * from zuowei where name_fangyingting = ?", new Object[]{result.name});
				while(rs2.next()){
					Zuowei zuowei = new Zuowei();
					zuowei.id = rs2.getInt("id");
					zuowei.name = rs2.getString("name");
					zuowei.name_fangyingting = rs2.getString("name_fangyingting");
					zuowei.row = rs2.getInt("row");
					zuowei.col = rs2.getInt("col");
					result.addZuowei(zuowei);
				}
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
		return set;
	}
	
	public Fangyingting get(Integer id){
    	List<Fangyingting> set = new ArrayList<Fangyingting>();
    	try{
			String sql="select * from fangyingting where id=?";
			Object[] params = new Object[]{id};
			ResultSet rs = executeQuery(sql, params);
			while(rs.next()){
				Fangyingting result = new Fangyingting();
				result.id = rs.getInt("id");
				result.name = rs.getString("name");
				result.type = rs.getString("type");//����
				result.col = rs.getInt("col");
				result.row = rs.getInt("row");
				ResultSet rs2 = executeQuery("select * from zuowei where name_fangyingting = ?", new Object[]{result.name});
				while(rs2.next()){
					Zuowei zuowei = new Zuowei();
					zuowei.id = rs2.getInt("id");
					zuowei.name = rs2.getString("name");
					zuowei.name_fangyingting = rs2.getString("name_fangyingting");
					zuowei.row = rs2.getInt("row");
					zuowei.col = rs2.getInt("col");
					result.addZuowei(zuowei);
				}
				set.add(result);
			}
		}catch (Exception e){
			System.out.println(e.getMessage());
		}finally {
			destroy();
		}
    	
    	if(set.size()>0){
    		return set.get(0);
    	}else {
    		return null;
    	}
	}
	
	public List<Fangyingting> queryAll(){
		return search("");
	}
	
	public boolean update(Fangyingting f){
		boolean flag;
		String  sql="update fangyingting set name=?,type=?,num=?,col=?,row=? where id = ?";
		Object[] params = new Object[]{
				f.name,
				f.type,
				f.getZuoweiNum(),
				f.col,
				f.row,
				f.id
				};
		flag = executeUpdate(sql, params);
		
		sql = "delete from zuowei where name_fangyingting = ?";
		params = new Object[]{f.name};
		flag = executeUpdate(sql, params) && flag;
		
		for(int i=0;i<f.getZuoweiNum();i++){
			Zuowei zuowei = f.getZuoWei(i);
			
			sql="insert into zuowei ("
					+ "name,name_fangyingting,row,col) "
					+ "values(?,?,?,?)";

			params = new Object[]{
					zuowei.name,
					zuowei.name_fangyingting,
					zuowei.row,
					zuowei.col
					};
			flag = executeUpdate(sql, params) && flag;
		}
		
		destroy();
		return flag;
	}
	
	public boolean add(Fangyingting f){
		boolean flag;
		String  sql="insert into fangyingting ("
				+ "name,type,num,col,row) "
				+ "values(?,?,?,?,?)";
		@SuppressWarnings("null")
		Object[] params = new Object[]{
				f.name,
				f.type,
				f.getZuoweiNum(),
				f.col,
				f.row
				};
		flag = executeUpdate(sql, params);
		
		for(int i=0;i<f.getZuoweiNum();i++){
			Zuowei zuowei = f.getZuoWei(i);
			
			sql="insert into zuowei ("
					+ "name,name_fangyingting,row,col) "
					+ "values(?,?,?,?)";

			params = new Object[]{
					zuowei.name,
					zuowei.name_fangyingting,
					zuowei.row,
					zuowei.col
					};
			flag = executeUpdate(sql, params) && flag;
		}
		destroy();
		return flag;
	}
	

}
