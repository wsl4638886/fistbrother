package com.hzyc.filmsystem.fangyingting;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.hzyc.filmsystem.fangyingting.data.Fangyingting;
import com.hzyc.filmsystem.fangyingting.data.FangyingtingDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FangyingtingAddFrame extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FangyingtingAddFrame frame = new FangyingtingAddFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public FangyingtingFrame fangyingtingFrame;
	public Fangyingting fangyingting;
	private JTextField textField_name;
	private JComboBox comboBox_type;
	private JTextField textField_row;
	private JTextField textField_col;
	private JButton button;
	public void init() {
		// TODO Auto-generated method stub
		textField_name.setText(fangyingting.name);
		textField_col.setText(fangyingting.col+"");
		textField_row.setText(fangyingting.row+"");

		int index = fangyingting.type.equals("��ͨ") ? 0 : fangyingting.type.equals("3D") ? 1 : 2;
		comboBox_type.setSelectedIndex(index);
	}
	
	/**
	 * Create the frame.
	 */
	public FangyingtingAddFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 451, 306);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u540D\u79F0\uFF1A");
		label.setBounds(113, 33, 72, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u7C7B\u578B\uFF1A");
		label_1.setBounds(113, 64, 72, 18);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u5EA7\u4F4D\u884C\u6570\uFF1A");
		label_2.setBounds(84, 96, 88, 18);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u5EA7\u4F4D\u5217\u6570\uFF1A");
		label_3.setBounds(84, 127, 88, 18);
		contentPane.add(label_3);
		
		textField_name = new JTextField();
		textField_name.setBounds(199, 33, 156, 24);
		contentPane.add(textField_name);
		textField_name.setColumns(10);
		
		comboBox_type = new JComboBox();
		comboBox_type.setModel(new DefaultComboBoxModel(new String[] {"\u666E\u901A", "3D", "IMAX"}));
		comboBox_type.setBounds(199, 67, 156, 24);
		contentPane.add(comboBox_type);
		
		textField_row = new JTextField();
		textField_row.setColumns(10);
		textField_row.setBounds(199, 98, 156, 24);
		contentPane.add(textField_row);
		
		textField_col = new JTextField();
		textField_col.setColumns(10);
		textField_col.setBounds(199, 127, 156, 24);
		contentPane.add(textField_col);
		
		JButton btn_ok = new JButton("\u786E\u8BA4");
		btn_ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(textField_col.getText().isEmpty() || textField_row.getText().isEmpty() || textField_name.getText().isEmpty()){
					JOptionPane.showMessageDialog(null, "��������Ϊ��");
				}else {
					Fangyingting fangyingting = new Fangyingting(
							textField_name.getText().trim(), 
							comboBox_type.getSelectedItem().toString(), 
							Integer.valueOf(textField_row.getText()),
							Integer.valueOf(textField_col.getText())
							);
					if(FangyingtingAddFrame.this.fangyingting == null){
						(new FangyingtingDao()).add(fangyingting);
					}else {
						fangyingting.id = FangyingtingAddFrame.this.fangyingting.id;
						(new FangyingtingDao()).update(fangyingting);
					}
				}
				
				if(fangyingtingFrame!=null){
					fangyingtingFrame.loadData();
				}
				dispose();
			}
		});
		btn_ok.setBounds(84, 179, 113, 27);
		contentPane.add(btn_ok);
		
		setLocationRelativeTo(null);
		
		button = new JButton("\u53D6\u6D88");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		button.setBounds(242, 179, 113, 27);
		contentPane.add(button);
	}
}
