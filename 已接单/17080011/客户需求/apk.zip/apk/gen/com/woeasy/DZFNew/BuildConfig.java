/** Automatically generated file. DO NOT MODIFY */
package com.woeasy.DZFNew;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}