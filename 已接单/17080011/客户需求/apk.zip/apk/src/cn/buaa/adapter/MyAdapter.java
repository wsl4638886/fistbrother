package cn.buaa.adapter;

import java.util.List;

import com.woeasy.DZFNew.R;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout.LayoutParams;
import cn.buaa.util.ImageLoader;
import cn.buaa.util.VideoFrameImageLoader;

public class MyAdapter extends BaseAdapter {

	private List<String> urls;
	private Context context;
	private VideoFrameImageLoader mVideoFrameImageLoader;
	private ImageLoader mImageLoader;
	private int imageWidth;

	public MyAdapter(Context context, List<String> urls, VideoFrameImageLoader videoFrameImageLoader, int screenWidth) {

		this.context = context;
		this.urls = urls;
		this.mVideoFrameImageLoader = videoFrameImageLoader;
		mImageLoader = new ImageLoader(context);
		imageWidth = (screenWidth - dp2px(context, 10) * 4) / 3;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return urls == null ? 0 : urls.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return urls.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(R.layout.item_gv, null);
		}

		ImageView imageView = (ImageView) convertView.findViewById(R.id.item_iv);
		imageView.setLayoutParams(new LayoutParams(imageWidth, imageWidth));
		imageView.setScaleType(ImageView.ScaleType.FIT_XY);
		// imageView.setPadding(25, 0, 0, 0);

		String url = urls.get(position);
		if (url.toLowerCase().endsWith(".mp4")) {
			// �ӻ����л�ȡͼƬ
			Bitmap bitmap = mVideoFrameImageLoader.showCacheBitmap(VideoFrameImageLoader.formatVideoUrl(url));
			if (bitmap != null) {
				imageView.setImageBitmap(bitmap);
			} else {
				mVideoFrameImageLoader.showImage(url, imageView);
			}
		} else {
			mImageLoader.DisplayImage(url, imageView, false, 0);
		}

		return convertView;
	}

	public static int dp2px(Context context, float dpVal)

	{

		return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,

				dpVal, context.getResources().getDisplayMetrics());

	}

}
