package cn.buaa.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Environment;
import android.util.Base64;

@SuppressLint("NewApi")
public class FileUtils {
	 private static String SDPATH=Environment.getExternalStorageDirectory()+ "/";   
	 public String getSDPATH() { 
		 return SDPATH; } 

	 /** * ��SD���ϴ����ļ� *  * @throws IOException */
	 public static File creatSDFile(String fileName) throws IOException { 
		 File file = new File(SDPATH+fileName); 
		 file.createNewFile();
		 return file; }   
	 /** * ��SD���ϴ���Ŀ¼ *  * @param dirName */
	 public static File creatSDDir(String dirName) { 
		 File dir = new File(SDPATH + dirName); 
		 if (!dir.exists()) {
			 dir.mkdirs(); 
		 	}
		 return dir; }   
	 /** * �ж�SD���ϵ��ļ��Ƿ���� */
	 public static boolean isFileExist(String fileName){ 
		 File file = new File(SDPATH + fileName); 
		 return file.exists(); }   
	 /** * ��һ��InputStream���������д�뵽SD���� ���������������СС������ģ�дHTMLʱ���дһ��������ȥ��������л�������Ǹ�������*/
	 public File write2SDFromInput(String path,String fileName,InputStream input){ 
		 File file = null; 
		 OutputStream output = null; 
		 try{
			 creatSDDir(path); 
			 file = creatSDFile(path+fileName); 
			 output = new FileOutputStream(file); 
			 byte buffer[] = new byte[4 * 1024]; 
			 
			while((input.read(buffer))!=-1){ 
				 output.write(buffer); 
				 } 
			 	 output.flush(); 
			 	 
		 }catch(Exception e){ e.printStackTrace(); } 
		 finally{ 
			 try{ 
				 output.close(); 
				 }catch(Exception e){ e.printStackTrace(); } } 
		 return file; 
		 } 
	 
	 public static void deleteFolderFile(String filePath, boolean deleteThisPath)  
	            throws IOException {  
	        //if (!TextUtils.isEmpty(SDPATH + filePath)) {  
	            File file = new File(filePath);  
	            if (file.isDirectory()) {
	                File files[] = file.listFiles();  
	                for (int i = 0; i < files.length; i++) {  
	                    deleteFolderFile(files[i].getAbsolutePath(), true);  
	                } 
	            }  
	            if (deleteThisPath) {  
	                if (!file.isDirectory()) {
	                	file.delete();  
	                } else {
	                    if (file.listFiles().length == 0) {
	                    	file.delete();  
	                    }  
	                }  
	        }  
	    }  
	 
	 public static File write2SDFromInput2(String path,String fileName,String input){
		 File file = null; 
		 OutputStream output = null; 
		 try{ 
			 creatSDDir(path);
			 file = creatSDFile(path+fileName); 
			 output = new FileOutputStream(file); 
			 output.write(input.getBytes()); 
			 output.flush(); 
			 	 
		 }catch(Exception e){ e.printStackTrace(); } 
		 finally{ 
			 try{ 
				 output.close(); 
				 }catch(Exception e){ e.printStackTrace(); } } 
		 return file; 
		 } 
	 
	 //����ͼƬʱ��Ҫ����(2013.5.25)
	 public static File write2SDFromInput3(String path,String fileName,String input){
		 File file = null; 
		 OutputStream output = null; 
		 try{ 
			 creatSDDir(path);
			 file=creatSDFile(path+"/"+fileName); 
			 output = new FileOutputStream(file); 
			 
			 output.write(Base64.decode(input,1)); 
			 output.flush(); 
			 	 
		 }catch(Exception e){ e.printStackTrace(); } 
		 finally{ 
			 try{ 
				 output.close(); 
			 }catch(Exception e){ e.printStackTrace(); } } 
		 return file; 
		 } 
	 
	 public static String saveBitmap(Bitmap bm, String picName) {
			try {
			if (!isFileExist("")) {
				File tempf = createSDDir("");
			}
			File f = new File(SDPATH, picName); 
			if (f.exists()) {
				f.delete();
			}
			FileOutputStream out = new FileOutputStream(f);
			bm.compress(Bitmap.CompressFormat.JPEG, 90, out);
			out.flush();
			out.close();
			} catch (FileNotFoundException e) {
			e.printStackTrace();
			} catch (IOException e) {
			e.printStackTrace();
			}
			return SDPATH+picName;
			}
	 
	 public static File createSDDir(String dirName) throws IOException {
			File dir = new File(SDPATH + dirName);
			if (Environment.getExternalStorageState().equals(
					Environment.MEDIA_MOUNTED)) {
				//System.out.println("createSDDir:" + dir.getAbsolutePath());
				//System.out.println("createSDDir:" + dir.mkdir());
			}
			return dir;
		}
	 
	 
	 }
		
		
