package cn.buaa.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by jiana on 16-4-3.
 */
public class VideoFileManager {
    private static final String TAG = "VideoFileManager";
    /**
     * Ӧ�û����·��
     */
    private static String imgCachePath;
    /**
     * �����Ŀ¼��
     */
    private final static String FOLDER_NAME = "/VideoImage";

    public VideoFileManager(Context context) {
        imgCachePath = context.getExternalCacheDir().getPath();
        Log.e(TAG, "imgCachePath = " + imgCachePath);
    }

    /**
     * ��ȡͼƬ����·��
     * @return
     */
    private String getImageDirectory() {
        return imgCachePath + FOLDER_NAME;
    }

    /**
     * ����image�ķ���
     * @param fileName �ļ���
     */
    public void saveBitmap(String fileName, Bitmap bitmap) throws IOException {
        if (bitmap == null) {
            return;
        }
        String path = getImageDirectory();
        File folderFile = new File(path);
        if (!folderFile.exists()) {
            folderFile.mkdir();
        }
        File file = new File(path + File.separator + fileName);
        file.createNewFile();
        FileOutputStream fos = new FileOutputStream(file);
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
        fos.flush();
        fos.close();
    }

    /**
     *
     * ���ֻ���ȡbitmap
     */
    public Bitmap getBitmap(String fileName) {
        return BitmapFactory.decodeFile(getImageDirectory() + File.separator + fileName);
    }

    /**
     * �ж��ļ��Ƿ����
     */
    public boolean isFileExists(String fileName) {
        return new File(getImageDirectory() + File.separator + fileName).exists();
    }

    /**
     * ��ȡ�ļ��Ĵ�С
     */
    public long getFileSize(String fileName) {
        return new File(getImageDirectory() + File.separator + fileName).length();
    }

    /**
     * ɾ������
     */
    public void deleteFile() {
        File dirFile = new File(getImageDirectory());
        if (! dirFile.exists()) {
            return;
        }
        if (dirFile.isDirectory()) {
            String[] subFile = dirFile.list();
            for (int i = 0; i < subFile.length; i++) {
                new File(dirFile, subFile[i]).delete();
            }
        }
        dirFile.delete();
    }
}


















