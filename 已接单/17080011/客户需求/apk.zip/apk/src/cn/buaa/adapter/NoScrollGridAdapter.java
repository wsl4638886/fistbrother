package cn.buaa.adapter;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.woeasy.DZFNew.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class NoScrollGridAdapter extends BaseAdapter {
	private String[] files;
	private LayoutInflater mLayoutInflater;

	public NoScrollGridAdapter(String[] files, Context context) {
		this.files = files;
		mLayoutInflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		int cou=files.length;
		if(cou>6){cou=6;}
		return files == null ? 0 : cou;
	}

	@Override
	public String getItem(int position) {
		return files[position];
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		MyGridViewHolder viewHolder = null;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.noscrollgridview_item,parent, false);
			viewHolder = new MyGridViewHolder();
			viewHolder.imageView=(ImageView)convertView.findViewById(R.id.album_image);
			convertView.setTag(viewHolder);
		}else {
			viewHolder = (MyGridViewHolder) convertView.getTag();
		}
		
		String url = getItem(position);
		ImageLoader.getInstance().displayImage(url, viewHolder.imageView);
		return convertView;
	}

	class MyGridViewHolder {
		ImageView imageView;
	}
}
