package cn.buaa.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

@SuppressLint("SimpleDateFormat")
public class DB {
	
	private Context mctx;
	private DatabaseHelper dbHelper;
	private SQLiteDatabase db;
	
	public DB(Context mctx){
		this.mctx=mctx;
	}
	public void open() {
		dbHelper=new DatabaseHelper(mctx);
	try{
		db=dbHelper.getWritableDatabase();
	}catch(SQLiteException e){
		db=dbHelper.getReadableDatabase();
	}
	}
	
	public void close() {
		dbHelper.close();
		db.close();
	}
	
	private static class DatabaseHelper extends SQLiteOpenHelper{
		private static final String DATABASE_NAME="YDJT.db";
		private static final int DATABASE_VERSION=1;
		
		@Override
		public synchronized void close() {
			
			super.close();
		}

		static final String DATABASE_TABLE01="Users";
		static final String DATABASE_TABLE02="GCXX";
		
		private static final String DATABASE_CREATE01 =
			"CREATE TABLE Users(Users_id integer PRIMARY KEY,"+"Users_name VARCHAR(20),"+"Users_pw VARCHAR(20),"+"Users_xm VARCHAR(20),"+"YH_lsdq VARCHAR(20)"+");" ;
		
		private static final String DATABASE_CREATE02 =
				"CREATE TABLE GCXX(GCXX_ID integer PRIMARY KEY,"+"GCXX_GCMC VARCHAR(20),"+"GCXX_GCDD VARCHAR(20),"+
				"GCXX_SSDQ VARCHAR(20),"+"GCXX_JD VARCHAR(20),"+"GCXX_WD VARCHAR(20),"+"GCXX_JDZCH VARCHAR(20),"+
				"GCXX_FWQID integer,"+"GCXX_SJHM VARCHAR(20),"+"GCXX_XMBH VARCHAR(20),"+"GCXX_JGLX VARCHAR(20),"+
				"GCXX_CS VARCHAR(20),"+"GCXX_SMCL VARCHAR(20),"+"GCXX_ZMJ VARCHAR(20),"+"GCXX_JZWLX1 VARCHAR(20),"+
				"GCXX_JZWLX2 VARCHAR(20),"+"GCXX_JHKGSJ VARCHAR(30),"+"GCXX_BJSJ VARCHAR(30),"+"GCXX_JHJGSJ VARCHAR(30),"+
				"GCXX_ZXJNBZ VARCHAR(20),"+"GCXX_WHJGSJFF VARCHAR(20),"+"GCXX_KZSNYLX VARCHAR(20),"+"GCXX_ZYCL VARCHAR(20),"+
				"XMInfo_zls integer,"+"XMInfo_whsj VARCHAR(20),"+"YH_LSDQ VARCHAR(20),"+"GCXX_SBSM VARCHAR(50)"+");" ;
		
		public DatabaseHelper(Context context) {
				super(context,DATABASE_NAME,null,DATABASE_VERSION);
				
			}
			@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE01);
			db.execSQL(DATABASE_CREATE02);
			
		}
			@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			db.execSQL("DROP TABLE IF EXISTS "+DATABASE_TABLE01);
			db.execSQL("DROP TABLE IF EXISTS "+DATABASE_TABLE02);
			
			onCreate(db);
		}}
	
	//��1�������û�
	public long addQDXX_YH(String sjhm,String mm,String xm,String YH_LSDQ,String lsdw){
		ContentValues args=new ContentValues();
		args.put("YH_SJHM", sjhm);
		args.put("YH_MM", mm);
		args.put("YH_XM", xm);
		args.put("YH_LSDQ",YH_LSDQ);
		args.put("YH_LSDW", lsdw);
		args.put("UPDATETIME1","2012-09-13 11:29");
		args.put("UPDATETIME2","2012-09-13 11:29");
		args.put("UPDATETIME3","2012-09-13 11:29");
		args.put("UPDATETIME4","2012-09-13 11:29");
		
		long result=db.insert(DatabaseHelper.DATABASE_TABLE01, null, args);
	
		return result;
	}
	public void startSW(){
		db.beginTransaction();
	}

	public void SW(String a){
		Log.d("yin","��ӡ��"+a);
		db.execSQL(a);
	}
	
	public void endSW(){
		db.setTransactionSuccessful();
		db.endTransaction();
	}
	
	//��1����ȡ����ʱ��1
	public String getUPDATETIME1(String sjhm,String YH_LSDQ){
		Cursor results=db.query(DatabaseHelper.DATABASE_TABLE01, new String[]{"UPDATETIME1"},"YH_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\"", null, null, null, null);
		int resultCounts=results.getCount();
		if(resultCounts==0||!results.moveToFirst()){
			return  null;
		}
		String UPDATETIME1=results.getString(results.getColumnIndex("UPDATETIME1"));
		results.moveToNext();
		results.close();
		return UPDATETIME1;
	} 
	//��1����ȡ����ʱ��2
	public String getUPDATETIME2(String sjhm,String YH_LSDQ){
		Cursor results=db.query(DatabaseHelper.DATABASE_TABLE01, new String[]{"UPDATETIME2"},"YH_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\"", null, null, null, null);
		int resultCounts=results.getCount();
		if(resultCounts==0||!results.moveToFirst()){
			return  null;
		}
		String UPDATETIME2=results.getString(results.getColumnIndex("UPDATETIME2"));
		results.moveToNext();
		results.close();
		return UPDATETIME2;
	} 
	//��1����ȡ����ʱ��3
	public String getUPDATETIME3(String sjhm,String YH_LSDQ){
		Cursor results=db.query(DatabaseHelper.DATABASE_TABLE01, new String[]{"UPDATETIME3"},"YH_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\"", null, null, null, null);
		int resultCounts=results.getCount();
		if(resultCounts==0||!results.moveToFirst()){
			return  null;
		}
		String UPDATETIME3=results.getString(results.getColumnIndex("UPDATETIME3"));
		results.moveToNext();
		results.close();
		return UPDATETIME3;
	} 
	//��1����ȡ����ʱ��4
	public String getUPDATETIME4(String sjhm,String YH_LSDQ){
		Cursor results=db.query(DatabaseHelper.DATABASE_TABLE01, new String[]{"UPDATETIME4"},"YH_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\"", null, null, null, null);
		int resultCounts=results.getCount();
		if(resultCounts==0||!results.moveToFirst()){
			return  null;
		}
		String UPDATETIME3=results.getString(results.getColumnIndex("UPDATETIME4"));
		results.moveToNext();
		results.close();
		return UPDATETIME3;
	} 
	//��1������ʱ��1
	public long updateUPDATETIME1(String UPDATETIME1,String sjhm,String YH_LSDQ){
		ContentValues args=new ContentValues();

		args.put("UPDATETIME1", UPDATETIME1);
		return db.update(DatabaseHelper.DATABASE_TABLE01,args,"YH_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\"",null);
	}
	//��1������ʱ��2
	public long updateUPDATETIME2(String UPDATETIME2,String sjhm,String YH_LSDQ){
		ContentValues args=new ContentValues();

		args.put("UPDATETIME2", UPDATETIME2);
		return db.update(DatabaseHelper.DATABASE_TABLE01,args,"YH_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\"",null);
	}
	//��1������ʱ��3
	public long updateUPDATETIME3(String UPDATETIME3,String sjhm,String YH_LSDQ){
		ContentValues args=new ContentValues();

		args.put("UPDATETIME3", UPDATETIME3);
		return db.update(DatabaseHelper.DATABASE_TABLE01,args,"YH_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\"",null);
	}
	//��1������ʱ��4
	public long updateUPDATETIME4(String UPDATETIME4,String sjhm,String YH_LSDQ){
		ContentValues args=new ContentValues();

		args.put("UPDATETIME4", UPDATETIME4);
		return db.update(DatabaseHelper.DATABASE_TABLE01,args,"YH_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\"",null);
	}
	//��1�������Ƿ����û�
	public Cursor checkUser(String YH_SJHM,String YH_MM,String YH_LSDQ){
		Cursor mCursor=(SQLiteCursor) db.query(true, DatabaseHelper.DATABASE_TABLE01,
				new String[]{"YH_SJHM"}, "YH_SJHM=? and YH_MM=? and YH_LSDQ=?",
				new String[]{YH_SJHM,YH_MM,YH_LSDQ}, null, null, null, null);
		
		return mCursor;
	}
	//��1����ȡ����
	public String getXM(String sjhm,String YH_LSDQ){
		Cursor results=db.query(DatabaseHelper.DATABASE_TABLE01, new String[]{"YH_XM"},"YH_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\"", null, null, null, null);
		int resultCounts=results.getCount();
		if(resultCounts==0||!results.moveToFirst()){
			return  null;
		}
		String xm=results.getString(results.getColumnIndex("YH_XM"));
		results.moveToNext();
		results.close();
		return xm;
	} 
	//��1����ȡ������λ
	public String getLSDW(String sjhm,String YH_LSDQ) {
		Cursor results=db.query(DatabaseHelper.DATABASE_TABLE01, new String[]{"YH_LSDW"},"YH_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\"", null, null, null, null);
		
		//��仰�����Ĳ����ˣ���߲��ӻᱨ��............
		int resultCounts=results.getCount();
		if(resultCounts==0||!results.moveToFirst()){
			return  null;
		}
		String lsdw=results.getString(results.getColumnIndex("YH_LSDW"));
		results.close();
		return lsdw;
	}
	//��2����½ʱ�洢��Ŀ������Ϣ
	public long addQDXX_GCXX(String gcmc,String gcdd,String ssdq,String jdzch,int fwqid,String sjhm,
			String xmbh,String jglx,String cs,String smcl,String zmj,String jzwlx1,String jzwlx2,
			String jhkgsj,String bjsj,String jhjgsj,String sbsm,int XMInfo_zls,String XMInfo_whsj,
			String YH_LSDQ,String GCXX_JD,String GCXX_WD){
		ContentValues args=new ContentValues();
		
		args.put("GCXX_GCMC", gcmc);
		args.put("GCXX_GCDD", gcdd);
		args.put("GCXX_SSDQ", ssdq);
		args.put("GCXX_JDZCH", jdzch);
		args.put("GCXX_FWQID", fwqid);
		args.put("GCXX_SJHM", sjhm);
		args.put("GCXX_XMBH",xmbh);
		args.put("GCXX_JGLX",jglx);
		args.put("GCXX_CS",cs);
		args.put("GCXX_SMCL",smcl);
		args.put("GCXX_ZMJ",zmj);
		args.put("GCXX_JZWLX1",jzwlx1);
		args.put("GCXX_JZWLX2",jzwlx2);
		args.put("GCXX_JHKGSJ",jhkgsj);
		args.put("GCXX_BJSJ",bjsj);
		args.put("GCXX_JHJGSJ",jhjgsj);
		args.put("GCXX_SBSM",sbsm);
		args.put("XMInfo_zls",XMInfo_zls);
		args.put("XMInfo_whsj",XMInfo_whsj);
		args.put("YH_LSDQ",YH_LSDQ);
		args.put("GCXX_JD",GCXX_JD);
		args.put("GCXX_WD",GCXX_WD);
		
		return db.insert(DatabaseHelper.DATABASE_TABLE02, null, args);
	}
	//��2������Ƿ��������������Ϣ
	public boolean checkQDXX_GCXX(int GCXX_FWQID,String GCXX_SJHM,String YH_LSDQ){
		boolean b=false;
		Cursor mCursor=db.query(DatabaseHelper.DATABASE_TABLE02,null,"GCXX_SJHM=\""+GCXX_SJHM+"\" and GCXX_FWQID="+GCXX_FWQID+" and YH_LSDQ=\""+YH_LSDQ+"\"",null,null,null,null);
		b=mCursor.moveToFirst();
		mCursor.close();
		return b;
	}
	//��2�����¹�����Ϣ
	public long updateQDXX_GCXX(String gcmc,String gcdd,String ssdq,String jdzch,int fwqid,String sjhm,
			String xmbh,String jglx,String cs,String smcl,String zmj,String jzwlx1,String jzwlx2,
			String jhkgsj,String bjsj,String jhjgsj,String sbsm,int XMInfo_zls,String XMInfo_whsj,
			String YH_LSDQ,String GCXX_JD,String GCXX_WD){
		ContentValues args=new ContentValues();
		args.put("GCXX_GCMC", gcmc);
		args.put("GCXX_GCDD", gcdd);
		args.put("GCXX_SSDQ", ssdq);
		args.put("GCXX_JDZCH", jdzch);
		args.put("GCXX_FWQID", fwqid);
		args.put("GCXX_SJHM", sjhm);
		args.put("GCXX_XMBH",xmbh);
		args.put("GCXX_JGLX",jglx);
		args.put("GCXX_CS",cs);
		args.put("GCXX_SMCL",smcl);
		args.put("GCXX_ZMJ",zmj);
		args.put("GCXX_JZWLX1",jzwlx1);
		args.put("GCXX_JZWLX2",jzwlx2);
		args.put("GCXX_JHKGSJ",jhkgsj);
		args.put("GCXX_BJSJ",bjsj);
		args.put("GCXX_JHJGSJ",jhjgsj);
		args.put("GCXX_SBSM",sbsm);
		args.put("XMInfo_zls",XMInfo_zls);
		args.put("XMInfo_whsj",XMInfo_whsj);
		args.put("GCXX_JD",GCXX_JD);
		args.put("GCXX_WD",GCXX_WD);
		
		return db.update(DatabaseHelper.DATABASE_TABLE02,args,"GCXX_SJHM=\""+sjhm+"\" and GCXX_FWQID="+fwqid+" and YH_LSDQ=\""+YH_LSDQ+"\"",null);
	}
	//��2�������û���ȡ�ù������ƣ�ID��������ID,������
	public List<Map<String, Object>> getProjectname_ID(String sjhm,String YH_LSDQ){
		Cursor results=db.query(DatabaseHelper.DATABASE_TABLE02, new String[]{"GCXX_GCMC","GCXX_ID","GCXX_FWQID","XMInfo_zls","XMInfo_whsj"},"GCXX_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\"", null, null, null,"XMInfo_whsj desc");
		int resultCounts=results.getCount();
		if(resultCounts==0||!results.moveToFirst()){
			return  null;
		}
		List<Map<String, Object>> namelist=new ArrayList<Map<String,Object>>();
		for (int i=0;i<resultCounts;i++){
			
			HashMap<String,Object> map=new HashMap<String, Object>();
			map.put("GCXX_GCMC", results.getString(results.getColumnIndex("GCXX_GCMC")));
			map.put("GCXX_ID", results.getInt(results.getColumnIndex("GCXX_ID")));
			map.put("GCXX_FWQID", results.getInt(results.getColumnIndex("GCXX_FWQID")));
			map.put("XMInfo_zls", results.getInt(results.getColumnIndex("XMInfo_zls")));
			map.put("XMInfo_whsj", results.getString(results.getColumnIndex("XMInfo_whsj")));
			
			namelist.add(map);
			results.moveToNext();
		}
		results.close();
			
		return namelist;
		
	}
	//��2�������û���ȡ�ù������ƣ�ID��������ID,������
	public List<Map<String, Object>> getProjectname_ZG(String sjhm,String GCXX_GCMC,String YH_LSDQ){
		Cursor results=db.query(DatabaseHelper.DATABASE_TABLE02, new String[]{"GCXX_GCMC","GCXX_XMBH","GCXX_FWQID"},"GCXX_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\" and GCXX_GCMC like \"%"+GCXX_GCMC+"%\"", null, null, null,null);
		int resultCounts=results.getCount();
		if(resultCounts==0||!results.moveToFirst()){
			//Log.d("yin","null");
			return  null;
		}
		List<Map<String, Object>> namelist=new ArrayList<Map<String,Object>>();
		for (int i=0;i<resultCounts;i++){
			
			HashMap<String,Object> map=new HashMap<String, Object>();
			map.put("GCXX_GCMC", results.getString(results.getColumnIndex("GCXX_GCMC")));
			map.put("GCXX_XMBH", results.getString(results.getColumnIndex("GCXX_XMBH")));
			map.put("GCXX_FWQID", results.getInt(results.getColumnIndex("GCXX_FWQID")));
			
			namelist.add(map);
			results.moveToNext();
		}
		results.close();
		return namelist;
		
	}
	//��2�������û����͹�������ȡ�ù������ƣ�ID��������ID
	public List<Map<String, Object>> getProjectname_ID2(String sjhm,String GCXX_GCMC,String YH_LSDQ){
		Cursor results=db.query(DatabaseHelper.DATABASE_TABLE02, new String[]{"GCXX_GCMC","GCXX_ID","GCXX_FWQID","XMInfo_zls"},"GCXX_SJHM=\""+sjhm+"\" and YH_LSDQ=\""+YH_LSDQ+"\" and GCXX_GCMC like \"%"+GCXX_GCMC+"%\"", null, null, null, null);
		int resultCounts=results.getCount();
		if(resultCounts==0||!results.moveToFirst()){
			return  null;
		}
		List<Map<String, Object>> namelist=new ArrayList<Map<String,Object>>();
		for (int i=0;i<resultCounts;i++){
			HashMap<String,Object> map=new HashMap<String, Object>();
			map.put("GCXX_GCMC", results.getString(results.getColumnIndex("GCXX_GCMC")));
			map.put("GCXX_ID", results.getInt(results.getColumnIndex("GCXX_ID")));
			map.put("GCXX_FWQID", results.getInt(results.getColumnIndex("GCXX_FWQID")));
			map.put("XMInfo_zls", results.getInt(results.getColumnIndex("XMInfo_zls")));
			
			namelist.add(map);
			results.moveToNext();
		}
		results.close();
		return namelist;
		
	}
	//��2�������ֻ������ѯ������Ϣ(2013.5.22)
	public List<Map<String, Object>> getProjectAll(int xmmc_id,String GCXX_SJHM,String YH_LSDQ){
		Cursor results=db.query(DatabaseHelper.DATABASE_TABLE02, new String[]{"GCXX_GCMC","GCXX_FWQID",
				"GCXX_GCDD","GCXX_SSDQ","GCXX_XMBH","GCXX_JGLX","GCXX_CS","GCXX_SMCL","GCXX_ZMJ",
				"GCXX_JZWLX1","GCXX_JZWLX2","GCXX_JHKGSJ","GCXX_BJSJ","GCXX_JHJGSJ","GCXX_SBSM"},
				"GCXX_SJHM=\""+GCXX_SJHM+"\" and YH_LSDQ=\""+YH_LSDQ+"\" and GCXX_ID="+xmmc_id, null, null, null, null);
		
		int resultCounts=results.getCount();
		
		if(resultCounts==0||!results.moveToFirst()){
			return  null;
		}
		List<Map<String, Object>> namelist=new ArrayList<Map<String,Object>>();
		for (int i=0;i<resultCounts;i++){
			HashMap<String,Object> map=new HashMap<String, Object>();
			
			map.put("GCXX_GCMC", results.getString(results.getColumnIndex("GCXX_GCMC")));
			map.put("GCXX_FWQID", results.getInt(results.getColumnIndex("GCXX_FWQID")));
			map.put("GCXX_GCDD", results.getString(results.getColumnIndex("GCXX_GCDD")));
			map.put("GCXX_SSDQ", results.getString(results.getColumnIndex("GCXX_SSDQ")));
			map.put("GCXX_XMBH", results.getString(results.getColumnIndex("GCXX_XMBH")));
			map.put("GCXX_JGLX", results.getString(results.getColumnIndex("GCXX_JGLX")));
			map.put("GCXX_CS", results.getString(results.getColumnIndex("GCXX_CS")));
			map.put("GCXX_SMCL", results.getString(results.getColumnIndex("GCXX_SMCL")));
			map.put("GCXX_ZMJ", results.getString(results.getColumnIndex("GCXX_ZMJ")));
			map.put("GCXX_JZWLX1", results.getString(results.getColumnIndex("GCXX_JZWLX1")));
			map.put("GCXX_JZWLX2", results.getString(results.getColumnIndex("GCXX_JZWLX2")));
			map.put("GCXX_JHKGSJ", results.getString(results.getColumnIndex("GCXX_JHKGSJ")));
			map.put("GCXX_BJSJ", results.getString(results.getColumnIndex("GCXX_BJSJ")));
			map.put("GCXX_JHJGSJ", results.getString(results.getColumnIndex("GCXX_JHJGSJ")));
			map.put("GCXX_SBSM", results.getString(results.getColumnIndex("GCXX_SBSM")));
			
			namelist.add(map);
			results.moveToNext();
		}
		results.close();
		return namelist;
		
	}		
	//��2��������Ŀ���Ʋ�ѯ��Ŀ�ص�
	public String getProjectplace(int xmmc_id,String GCXX_SJHM,String YH_LSDQ){
		Cursor results=db.query(DatabaseHelper.DATABASE_TABLE02, new String[]{"GCXX_GCDD"},"GCXX_SJHM=\""+GCXX_SJHM+"\" and YH_LSDQ=\""+YH_LSDQ+"\" and GCXX_ID="+xmmc_id, null, null, null, null);
		int resultCounts=results.getCount();
		if(resultCounts==0||!results.moveToFirst()){
			return  null;
		}
		String a="";
		for (int i=0;i<resultCounts;i++){
			a+=(results.getString(results.getColumnIndex("GCXX_GCDD")));
			
			results.moveToNext();
		}	
		results.close();
		return a;
	}
	//��2�����¾�γ��
	public long updateQDXX_GCXX_JWD(int gcmc_id,String jd,String wd,String GCXX_SJHM,String YH_LSDQ){
		ContentValues args=new ContentValues();

		args.put("GCXX_JD", jd);
		args.put("GCXX_WD", wd);
		return db.update(DatabaseHelper.DATABASE_TABLE02,args,"GCXX_SJHM=\""+GCXX_SJHM+"\" and YH_LSDQ=\""+YH_LSDQ+"\" and GCXX_ID="+gcmc_id,null);
	}
	//��2��ȡ��γ��
	public List<Map<String, Object>> getQDXX_GCXX_JWD(String GCXX_SJHM,String YH_LSDQ){
		Cursor results=db.query(DatabaseHelper.DATABASE_TABLE02, new String[]{"GCXX_GCMC","GCXX_FWQID",
				"GCXX_ID","GCXX_JD","GCXX_WD"},
				"GCXX_SJHM=\""+GCXX_SJHM+"\" and YH_LSDQ=\""+YH_LSDQ+"\" and GCXX_JD!=\"0\"", null, null, null, null);
		
		int resultCounts=results.getCount();
		
		if(resultCounts==0||!results.moveToFirst()){
			return  null;
		}
		List<Map<String, Object>> namelist=new ArrayList<Map<String,Object>>();
		for (int i=0;i<resultCounts;i++){
			HashMap<String,Object> map=new HashMap<String, Object>();
			
			map.put("GCXX_GCMC", results.getString(results.getColumnIndex("GCXX_GCMC")));
			map.put("GCXX_FWQID", results.getInt(results.getColumnIndex("GCXX_FWQID")));
			map.put("GCXX_ID", results.getInt(results.getColumnIndex("GCXX_ID")));
			map.put("GCXX_JD", results.getString(results.getColumnIndex("GCXX_JD")));
			map.put("GCXX_WD", results.getString(results.getColumnIndex("GCXX_WD")));
			
			namelist.add(map);
			results.moveToNext();
		}
		results.close();
		return namelist;
	}
	
}
