package cn.buaa.util;

import java.io.IOException;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import android.util.Log;

public class WebServiceUtil {
	// ����Web Service�������ռ�
	static final String SERVICE_NS = "http://tempuri.org/";
	// ����Web Service�ṩ�����URL
	// static final String SERVICE_URL =
	// "http://103.28.44.198/WebService/BaseInfoS.asmx";
	static String SERVICE_URL = "http://218.92.212.198:4888/webservice/mobiles.asmx";
	// static String SERVICE_URL =
	// "http://www.wo-easy.com:8003/webservice/mobiles.asmx";
	// static String SERVICE_URL =
	// "http://58.241.219.122:8003/webservice/mobiles.asmx";
	static String SERVICE_URL2 = "http://218.92.212.198:4888/";

	public static String getURL() {
		return SERVICE_URL;
	}

	public static String getURL2() {
		return SERVICE_URL2;
	}

	public static String UpdateGXJWD(String lat, String lng, int fwqid,
			String dd, String method) {

		String methodName = method;
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		soapObject.addProperty("gcid", fwqid);
		soapObject.addProperty("jd", lat);
		soapObject.addProperty("wd", lng);

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				SoapObject result = (SoapObject) envelope.bodyIn;

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			Log.e("yin", "IOException e");
			return null;
		} catch (XmlPullParserException e) {
			Log.e("yin", "XmlPullParserException e");
			return null;
		}
		Log.e("yin", "XmlPullParserException e222");
		return null;
	}

	public static String SaveDZGGPL(int DZGGPL_GGID, int DZGGPL_FID,
			int DZGGPL_NM, String DZGGPL_PLNR, String DZGGPL_PLR,
			String DZGGPL_PLRID) {

		String methodName = "SaveDZGGPL";
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		soapObject.addProperty("DZGGPL_GGID", DZGGPL_GGID);
		soapObject.addProperty("DZGGPL_FID", DZGGPL_FID);
		soapObject.addProperty("DZGGPL_NM", DZGGPL_NM);
		soapObject.addProperty("DZGGPL_PLNR", DZGGPL_PLNR);
		soapObject.addProperty("DZGGPL_PLR", DZGGPL_PLR);
		soapObject.addProperty("DZGGPL_PLRID", DZGGPL_PLRID);

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				SoapObject result = (SoapObject) envelope.bodyIn;

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			Log.e("yin", "IOException e");
			return null;
		} catch (XmlPullParserException e) {
			Log.e("yin", "XmlPullParserException e");
			return null;
		}
		Log.e("yin", "XmlPullParserException e222");
		return null;
	}

	public static String InsertKQJL(String lat, String lng, String user,
			String sj, String method) {
		String methodName = method;
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		soapObject.addProperty("user", user);
		soapObject.addProperty("sj", sj);
		soapObject.addProperty("jd", lat);
		soapObject.addProperty("wd", lng);

		envelope.bodyOut = soapObject;
		// System.out.println("jinrule ...............05");
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			System.out.println("jinrule ...............06");
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				System.out.println("����ֵ�ǿա�������������������������������");
				SoapObject result = (SoapObject) envelope.bodyIn;

				System.out.println(result.toString());

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			return null;
		} catch (XmlPullParserException e) {
			return null;
		}
		return null;
	}

	public static String Insertpicture(String picture, String tpsm, int fwqid,
			String sj, String method) {
		String methodName = method;
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		soapObject.addProperty("imagebuffer", picture);
		soapObject.addProperty("imagesm", tpsm);
		soapObject.addProperty("fwqid", fwqid);

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			System.out.println("jinrule ...............06");
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				System.out.println("����ֵ�ǿա�������������������������������");
				SoapObject result = (SoapObject) envelope.bodyIn;

				System.out.println(result.toString());
				System.out.println("" + result.getProperty(0));
				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			return null;
		} catch (XmlPullParserException e) {
			return null;
		}
		return null;
	}

	// ��ȡ���ϵ�HTML
	public static String GetZLNR(int iZLID, String method) {
		// ���õķ���
		String methodName = method;
		// ����HttpTransportSE�������
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		// ʹ��SOAP1.1Э�鴴��Envelop���󣬴˶���������������˴���ͻ������������
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		// ʵ����SoapObject������Ҫ����������Web Service�������ռ��Web Service������
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		// ��ߴ�����Ҫ����Ĳ���
		soapObject.addProperty("id", iZLID);

		// ��soapObject���󴫵ݸ�������
		envelope.bodyOut = soapObject;
		// ������.Net�ṩ��Web Service���ֽϺõļ�����
		System.out.println("jinrule ...............05");
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			// ����Web Service
			System.out.println("jinrule ...............06");
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				// ��ȡ��������Ӧ���ص�SOAP��Ϣ
				System.out.println("����ֵ�ǿա�������������������������������");
				SoapObject result = (SoapObject) envelope.bodyIn;

				System.out.println(result.toString());

				// SoapObject detail = (SoapObject)result.getProperty(0);
				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			return null;
		} catch (XmlPullParserException e) {
			return null;
		}
		return null;
	}

	// ���������Ե��õķ���(name1��name2,name3�����ӵ����Բ���������Ϊ""ʱ�����ӵ�����ֵ��)
	public static String everycanforStr(String name1, String name2,
			String name3, String name4, String value1, String value2,
			String value3, int value4, String method) {
		// Log.d("yin","webservice��ַ"+SERVICE_URL);
		String methodName = method;
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		// Log.d("yin","��ӡ��SERVICE_URL��"+SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		if (!name1.equals("")) {
			soapObject.addProperty(name1, value1);
		}
		if (!name2.equals("")) {
			soapObject.addProperty(name2, value2);
		}
		if (!name3.equals("")) {
			soapObject.addProperty(name3, value3);
		}
		if (!name4.equals("")) {
			soapObject.addProperty(name4, value4);
		}

		envelope.bodyOut = soapObject;
		// System.out.println("jinrule ...............05");
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			System.out.println("jinrule ...............06");
			ht.call(SERVICE_NS + methodName, envelope);
			System.out.println("jinrule ...............07");
			if (envelope.getResponse() != null) {
				System.out.println("����ֵ�ǿա�������������������������������");
				SoapObject result = (SoapObject) envelope.bodyIn;

				// System.out.println(result.toString());

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}

	public static String fordzgg(String name1, String name2,
			String SERVICE_URLs, String value1, String value2, String method) {
		String methodName = method;
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URLs);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		if (!name1.equals("")) {
			soapObject.addProperty(name1, value1);
		}
		if (!name2.equals("")) {
			soapObject.addProperty(name2, value2);
		}

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			System.out.println("jinrule ...............06");
			ht.call(SERVICE_NS + methodName, envelope);
			System.out.println("jinrule ...............07");
			if (envelope.getResponse() != null) {
				System.out.println("����ֵ�ǿա�������������������������������");
				SoapObject result = (SoapObject) envelope.bodyIn;

				// System.out.println(result.toString());

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}

	// ���������һ������
	public static String ZGTZSave(int ZGTZID, int iGCID, int sZGDW,
			String sJCBW, String sBH, String dJDRQ, String dZGRQ, String sZGNR,
			String sQFR, String userid, String sOperate) {

		String methodName = "ZGTZSave";
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		soapObject.addProperty("iGCID", iGCID);
		soapObject.addProperty("sZGDW", sZGDW);
		soapObject.addProperty("sJCBW", sJCBW);
		soapObject.addProperty("sBH", sBH);
		soapObject.addProperty("dJDRQ", dJDRQ);
		soapObject.addProperty("dZGRQ", dZGRQ);
		soapObject.addProperty("sZGNR", sZGNR);
		soapObject.addProperty("sQFR", sQFR);
		soapObject.addProperty("userid", userid);

		soapObject.addProperty("id", ZGTZID);
		soapObject.addProperty("sOperate", sOperate);
		soapObject.addProperty("iGRPID", 0);
		soapObject.addProperty("iJDJCID", 0);
		soapObject.addProperty("cFSSZ", "N");

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			System.out.println("jinrule ...............06");
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				System.out.println("����ֵ�ǿա�������������������������������");
				SoapObject result = (SoapObject) envelope.bodyIn;

				// System.out.println(result.toString());

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}

	public static String GGFBSave(String sZT, String ilx, String sZW,
			String sJSR, String sJSRMC, int iGrpID, String usrid,
			String username) {

		String methodName = "GGFBSave";
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		soapObject.addProperty("sZT", sZT);
		soapObject.addProperty("ilx", ilx);
		soapObject.addProperty("sZW", sZW);
		soapObject.addProperty("sJSR", sJSR);
		soapObject.addProperty("sJSRMC", sJSRMC);
		soapObject.addProperty("iGrpID", iGrpID);
		// soapObject.addProperty("otherText",otherText);
		soapObject.addProperty("usrid", usrid);
		soapObject.addProperty("username", username);

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			System.out.println("jinrule ...............06");
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				System.out.println("����ֵ�ǿա�������������������������������");
				SoapObject result = (SoapObject) envelope.bodyIn;

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}

	public static String QDSave(String jd, String wd, String address,
			String img, String name, String bz, String userid, String bmid) {

		String methodName = "NQD";
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		soapObject.addProperty("jd", jd);
		soapObject.addProperty("wd", wd);
		soapObject.addProperty("address", address);
		soapObject.addProperty("img", img);
		soapObject.addProperty("name", name);
		soapObject.addProperty("bz", bz);
		soapObject.addProperty("userid", userid);
		soapObject.addProperty("bmid", bmid);
		Log.d("yin", "NQD:" + soapObject);
		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			System.out.println("jinrule ...............06");
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				System.out.println("����ֵ�ǿա�������������������������������");
				SoapObject result = (SoapObject) envelope.bodyIn;

				// System.out.println(result.toString());

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}

	public static String AQZGTZSave(int ZGTZID, int iGCID, int sZGDW,
			String sJCBW, String sBH, String dJDRQ, String dZGRQ, String sZGNR,
			String sQFR, String userid, String sOperate) {

		String methodName = "AQZGTZSave";
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		soapObject.addProperty("iGCID", iGCID);
		soapObject.addProperty("sZGDW", sZGDW);
		soapObject.addProperty("sJCBW", sJCBW);
		soapObject.addProperty("sBH", sBH);
		soapObject.addProperty("dJDRQ", dJDRQ);
		soapObject.addProperty("dZGRQ", dZGRQ);
		soapObject.addProperty("sZGNR", sZGNR);
		soapObject.addProperty("sQFR", sQFR);
		soapObject.addProperty("userid", userid);

		soapObject.addProperty("id", ZGTZID);
		soapObject.addProperty("sOperate", sOperate);
		soapObject.addProperty("iGRPID", 0);
		soapObject.addProperty("iJDJCID", 0);
		soapObject.addProperty("cFSSZ", "N");

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			System.out.println("jinrule ...............06");
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				System.out.println("����ֵ�ǿա�������������������������������");
				SoapObject result = (SoapObject) envelope.bodyIn;

				// System.out.println(result.toString());

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}

	public static String everycanforStrzdxm2(String name1, String name2, String name3, String name4, String name5,
			String name6, String name7, String name8, String name9, String name10, String name11, String name12,
			String name13, String name14, String name15, String name16, String name17, String name18, String name19,
			String name20, String name21, String name22, String name23, String name24, String name25, String name26,
			String name27, String name28, String name29,String name30,String name31, String value1, String value2, String value3, String value4,
			String value5, String value6, String value7, String value8, String value9, String value10, String value11,
			String value12, String value13, String value14, String value15, String value16, String value17,
			String value18, String value19, String value20, String value21, String value22, String value23,
			String value24, String value25, String value26, String value27, String value28, String value29,
			String value30, String value31,
			String method) {
		String methodName = method;
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		if (!name1.equals("")) {
			soapObject.addProperty(name1, value1);
		}
		if (!name2.equals("")) {
			soapObject.addProperty(name2, value2);
		}
		if (!name3.equals("")) {
			soapObject.addProperty(name3, value3);
		}
		if (!name4.equals("")) {
			soapObject.addProperty(name4, value4);
		}
		if (!name5.equals("")) {
			soapObject.addProperty(name5, value5);
		}
		if (!name6.equals("")) {
			soapObject.addProperty(name6, value6);
		}
		if (!name6.equals("")) {
			soapObject.addProperty(name7, value7);
		}
		if (!name8.equals("")) {
			soapObject.addProperty(name8, value8);
		}
		if (!name9.equals("")) {
			soapObject.addProperty(name9, value9);
		}
		if (!name10.equals("")) {
			soapObject.addProperty(name10, value10);
		}
		if (!name11.equals("")) {
			soapObject.addProperty(name11, value11);
		}
		if (!name12.equals("")) {
			soapObject.addProperty(name12, value12);
		}
		if (!name13.equals("")) {
			soapObject.addProperty(name13, value13);
		}
		if (!name14.equals("")) {
			soapObject.addProperty(name14, value14);
		}
		if (!name15.equals("")) {
			soapObject.addProperty(name15, value15);
		}
		if (!name16.equals("")) {
			soapObject.addProperty(name16, value16);
		}
		if (!name17.equals("")) {
			soapObject.addProperty(name17, value17);
		}
		if (!name18.equals("")) {
			soapObject.addProperty(name18, value18);
		}
		if (!name19.equals("")) {
			soapObject.addProperty(name19, value19);
		}
		if (!name20.equals("")) {
			soapObject.addProperty(name20, value20);
		}
		if (!name21.equals("")) {
			soapObject.addProperty(name21, value21);
		}
		if (!name22.equals("")) {
			soapObject.addProperty(name22, value22);
		}
		if (!name23.equals("")) {
			soapObject.addProperty(name23, value23);
		}
		if (!name24.equals("")) {
			soapObject.addProperty(name24, value24);
		}
		if (!name25.equals("")) {
			soapObject.addProperty(name25, value25);
		}
		if (!name26.equals("")) {
			soapObject.addProperty(name26, value26);
		}
		if (!name27.equals("")) {
			soapObject.addProperty(name27, value27);
		}
		if (!name28.equals("")) {
			soapObject.addProperty(name28, value28);
		}
		if (!name29.equals("")) {
			soapObject.addProperty(name29, value29);
		}
		if (!name30.equals("")) {
			soapObject.addProperty(name30, value30);
		}
		if (!name31.equals("")) {
			soapObject.addProperty(name31, value31);
		}
		
		Log.d("WebServiceUtil", method + "��" + soapObject);
		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				SoapObject result = (SoapObject) envelope.bodyIn;
				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}
	
	
	
	// ���������Ե��õķ���(name1��name2,name3�����ӵ����Բ���������Ϊ""ʱ�����ӵ�����ֵ��)
	public static String everycanforStr2(String name1, String name2,
			String name3, String name4, String name5, String name6,
			String value1, String value2, String value3, String value4,
			String value5, int value6, String method) {

		String methodName = method;
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		if (!name1.equals("")) {
			soapObject.addProperty(name1, value1);
		}
		if (!name2.equals("")) {
			soapObject.addProperty(name2, value2);
		}
		if (!name3.equals("")) {
			soapObject.addProperty(name3, value3);
		}
		if (!name4.equals("")) {
			soapObject.addProperty(name4, value4);
		}
		if (!name5.equals("")) {
			soapObject.addProperty(name5, value5);
		}
		if (!name6.equals("")) {
			soapObject.addProperty(name6, value6);
		}

		Log.d("yin", method + "��" + soapObject);

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				SoapObject result = (SoapObject) envelope.bodyIn;

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		// Log.d("yin","����ֵ�ǿ����");
		return null;
	}

	public static String ASaveCalendar(String Id, String txtJSRMC,
			String Subject, String userid, String Location, String Description,
			String IsAllDayEvent, String IsDXTXEvent, String colorvalue,
			String timelist, String stpartdate, String etpartdate,
			String stparttime, String etparttime, String timelist1,
			String timelist2, String timelist3) {

		String methodName = "ASaveCalendar";
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		soapObject.addProperty("Id", Id);
		soapObject.addProperty("txtJSRMC", txtJSRMC);
		soapObject.addProperty("Subject", Subject);
		soapObject.addProperty("userid", userid);
		soapObject.addProperty("Location", Location);
		soapObject.addProperty("Description", Description);
		soapObject.addProperty("IsAllDayEvent", IsAllDayEvent);
		soapObject.addProperty("IsDXTXEvent", IsDXTXEvent);
		soapObject.addProperty("colorvalue", colorvalue);
		soapObject.addProperty("timelist", timelist);
		soapObject.addProperty("stpartdate", stpartdate);
		soapObject.addProperty("etpartdate", etpartdate);
		soapObject.addProperty("stparttime", stparttime);
		soapObject.addProperty("etparttime", etparttime);
		soapObject.addProperty("timelist1", timelist1);
		soapObject.addProperty("timelist2", timelist2);
		soapObject.addProperty("timelist3", timelist3);

		Log.d("yin", methodName + "��" + soapObject);

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				SoapObject result = (SoapObject) envelope.bodyIn;

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		// Log.d("yin","����ֵ�ǿ����");
		return null;
	}

	public static String GZRZ_Add(int id, String zt, String rq, String gs,
			String nr, String Operate, String userid, String username,
			String bmmc) {

		String methodName = "GZRZSave";
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		soapObject.addProperty("id", id);
		soapObject.addProperty("zt", zt);
		soapObject.addProperty("rq", rq);
		soapObject.addProperty("gs", gs);
		soapObject.addProperty("nr", nr);
		soapObject.addProperty("Operate", Operate);
		soapObject.addProperty("userid", userid);
		soapObject.addProperty("username", username);
		soapObject.addProperty("bmmc", bmmc);

		Log.d("yin", methodName + "��" + soapObject);

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				SoapObject result = (SoapObject) envelope.bodyIn;

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		// Log.d("yin","����ֵ�ǿ����");
		return null;
	}

	public static String everycanforStr4(String name1, String name2,
			String name3, String name4, String name5, String name6,
			String value1, String value2, String value3, int value4,
			int value5, int value6, String method) {

		String methodName = method;
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		if (!name1.equals("")) {
			soapObject.addProperty(name1, value1);
		}
		if (!name2.equals("")) {
			soapObject.addProperty(name2, value2);
		}
		if (!name3.equals("")) {
			soapObject.addProperty(name3, value3);
		}
		if (!name4.equals("")) {
			soapObject.addProperty(name4, value4);
		}
		if (!name5.equals("")) {
			soapObject.addProperty(name5, value5);
		}
		if (!name6.equals("")) {
			soapObject.addProperty(name6, value6);
		}
		Log.d("yin", methodName + "�����£�" + soapObject);
		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				SoapObject result = (SoapObject) envelope.bodyIn;

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		// Log.d("yin","����ֵ�ǿ����");
		return null;
	}

	public static String everycanforStr3(String name1, String name2,
			String name3, String name4, String name5, String name6,
			String name7, String value1, String value2, String value3,
			String value4, String value5, int value6, String value7,
			String method) {

		String methodName = method;
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		if (!name1.equals("")) {
			soapObject.addProperty(name1, value1);
		}
		if (!name2.equals("")) {
			soapObject.addProperty(name2, value2);
		}
		if (!name3.equals("")) {
			soapObject.addProperty(name3, value3);
		}
		if (!name4.equals("")) {
			soapObject.addProperty(name4, value4);
		}
		if (!name5.equals("")) {
			soapObject.addProperty(name5, value5);
		}
		if (!name6.equals("")) {
			soapObject.addProperty(name6, value6);
		}
		if (!name7.equals("")) {
			soapObject.addProperty(name7, value7);
		}

		envelope.bodyOut = soapObject;
		Log.d("yin", "����Ƭjinrule ...............05");
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			Log.d("yin", "����Ƭjinrule ...............06");
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				Log.d("yin", "����ֵ�ǿա�������������������������������");
				SoapObject result = (SoapObject) envelope.bodyIn;
				// Log.d("yin",result.toString());

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			// Log.d("yin","����ֵ�ǿ�IOException");
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			// Log.d("yin","����ֵ�ǿ�XmlPullParserException");
			e.printStackTrace();
			return null;
		}
		// Log.d("yin","����ֵ�ǿ����");
		return null;
	}

	public static String getweather(String theCityName) {
		String methodName = "getWeatherbyCityName";
		HttpTransportSE ht = new HttpTransportSE(
				"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx");
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject("http://WebXml.com.cn/",
				methodName);
		soapObject.addProperty("theCityName", theCityName);
		Log.d("yin3", "��ȡ����soapObject��" + soapObject);
		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			Log.d("yin", "getweather��������");
			ht.call("http://WebXml.com.cn/" + methodName, envelope);
			Log.d("yin", "getweather��������");
			if (envelope.getResponse() != null) {
				Log.d("yin", "getweather�з���ֵ��");
				SoapObject result = (SoapObject) envelope.bodyIn;
				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			Log.d("yin", "getweatherIOException");
			return null;
		} catch (XmlPullParserException e) {
			Log.d("yin", "getweatherXmlPullParserException");
			return null;
		}
		return null;
	}
	public static String everycanforStrzdxm3(String name1, String name2, String name3, String name4, String name5,
			String name6, String name7, String name8, String name9, String name10, String name11, String name12,
			String name13, String name14, String name15, String name16, String name17, String name18, String name19,
			String name20, String name21, String name22, String name23, String name24, String name25, String name26,
			String name27, String name28, String name29,String name30,String name31,String name32,String name33,String name34
			,String name35,String name36,String name37,String name38,String name39,String name40,String name41,String name42
			,String name43,String name44,String name45,String name46,String name47,String name48,String name49,String name50,String name51,String name52,String name53,
			String value1, String value2, String value3, String value4,String value5, String value6, String value7, String value8, String value9,
			String value10, String value11,String value12, String value13, String value14, String value15, String value16, String value17,
			String value18, String value19, String value20, String value21, String value22, String value23,String value24, String value25, 
			String value26, String value27, String value28, String value29,String value30, String value31, String value32, String value33, 
			String value34, String value35, String value36, String value37, String value38, String value39, String value40, String value41, 
			String value42, String value43, String value44, String value45, String value46, String value47, String value48, String value49, 
			String value50, String value51,String value52,String value53,String method) {
		String methodName = method;
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		if (!name1.equals("")) {
			soapObject.addProperty(name1, value1);
		}
		if (!name2.equals("")) {
			soapObject.addProperty(name2, value2);
		}
		if (!name3.equals("")) {
			soapObject.addProperty(name3, value3);
		}
		if (!name4.equals("")) {
			soapObject.addProperty(name4, value4);
		}
		if (!name5.equals("")) {
			soapObject.addProperty(name5, value5);
		}
		if (!name6.equals("")) {
			soapObject.addProperty(name6, value6);
		}
		if (!name6.equals("")) {
			soapObject.addProperty(name7, value7);
		}
		if (!name8.equals("")) {
			soapObject.addProperty(name8, value8);
		}
		if (!name9.equals("")) {
			soapObject.addProperty(name9, value9);
		}
		if (!name10.equals("")) {
			soapObject.addProperty(name10, value10);
		}
		if (!name11.equals("")) {
			soapObject.addProperty(name11, value11);
		}
		if (!name12.equals("")) {
			soapObject.addProperty(name12, value12);
		}
		if (!name13.equals("")) {
			soapObject.addProperty(name13, value13);
		}
		if (!name14.equals("")) {
			soapObject.addProperty(name14, value14);
		}
		if (!name15.equals("")) {
			soapObject.addProperty(name15, value15);
		}
		if (!name16.equals("")) {
			soapObject.addProperty(name16, value16);
		}
		if (!name17.equals("")) {
			soapObject.addProperty(name17, value17);
		}
		if (!name18.equals("")) {
			soapObject.addProperty(name18, value18);
		}
		if (!name19.equals("")) {
			soapObject.addProperty(name19, value19);
		}
		if (!name20.equals("")) {
			soapObject.addProperty(name20, value20);
		}
		if (!name21.equals("")) {
			soapObject.addProperty(name21, value21);
		}
		if (!name22.equals("")) {
			soapObject.addProperty(name22, value22);
		}
		if (!name23.equals("")) {
			soapObject.addProperty(name23, value23);
		}
		if (!name24.equals("")) {
			soapObject.addProperty(name24, value24);
		}
		if (!name25.equals("")) {
			soapObject.addProperty(name25, value25);
		}
		if (!name26.equals("")) {
			soapObject.addProperty(name26, value26);
		}
		if (!name27.equals("")) {
			soapObject.addProperty(name27, value27);
		}
		if (!name28.equals("")) {
			soapObject.addProperty(name28, value28);
		}
		if (!name29.equals("")) {
			soapObject.addProperty(name29, value29);
		}
		if (!name30.equals("")) {
			soapObject.addProperty(name30, value30);
		}
		if (!name31.equals("")) {
			soapObject.addProperty(name31, value31);
		}
		if (!name32.equals("")) {
			soapObject.addProperty(name32, value32);
		}
		if (!name33.equals("")) {
			soapObject.addProperty(name33, value33);
		}
		if (!name34.equals("")) {
			soapObject.addProperty(name34, value34);
		}
		if (!name35.equals("")) {
			soapObject.addProperty(name35, value35);
		}
		if (!name36.equals("")) {
			soapObject.addProperty(name36, value36);
		}
		if (!name37.equals("")) {
			soapObject.addProperty(name37, value37);
		}
		if (!name38.equals("")) {
			soapObject.addProperty(name38, value38);
		}
		if (!name39.equals("")) {
			soapObject.addProperty(name39, value39);
		}
		if (!name40.equals("")) {
			soapObject.addProperty(name41, value41);
		}
		if (!name42.equals("")) {
			soapObject.addProperty(name42, value42);
		}
		if (!name43.equals("")) {
			soapObject.addProperty(name43, value43);
		}
		if (!name44.equals("")) {
			soapObject.addProperty(name44, value44);
		}
		if (!name45.equals("")) {
			soapObject.addProperty(name45, value45);
		}
		if (!name46.equals("")) {
			soapObject.addProperty(name46, value46);
		}
		if (!name47.equals("")) {
			soapObject.addProperty(name47, value47);
		}
		if (!name48.equals("")) {
			soapObject.addProperty(name48, value48);
		}
		if (!name49.equals("")) {
			soapObject.addProperty(name49, value49);
		}
		if (!name50.equals("")) {
			soapObject.addProperty(name50, value50);
		}
		if (!name51.equals("")) {
			soapObject.addProperty(name51, value51);
		}
		if (!name52.equals("")) {
			soapObject.addProperty(name52, value52);
		}if (!name52.equals("")) {
			soapObject.addProperty(name53, value53);
		}
		
		Log.d("WebServiceUtil", method + "��" + soapObject);
		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				SoapObject result = (SoapObject) envelope.bodyIn;
				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}
	
	public static String everycanforStrxmgl(String name1, String name2, String name3, String name4, String name5,
			String name6, String name7, String value1, String value2, String value3, String value4, String value5,
			String value6, int value7, String method) {

		String methodName = method;
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		if (!name1.equals("")) {
			soapObject.addProperty(name1, value1);
		}
		if (!name2.equals("")) {
			soapObject.addProperty(name2, value2);
		}
		if (!name3.equals("")) {
			soapObject.addProperty(name3, value3);
		}
		if (!name4.equals("")) {
			soapObject.addProperty(name4, value4);
		}
		if (!name5.equals("")) {
			soapObject.addProperty(name5, value5);
		}
		if (!name6.equals("")) {
			soapObject.addProperty(name6, value6);
		}
		if (!name7.equals("")) {
			soapObject.addProperty(name7, value7);
		}

		Log.d("WebServiceUtil", method + "��" + soapObject);

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				SoapObject result = (SoapObject) envelope.bodyIn;

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		// Log.d("yin","����ֵ�ǿ����");
		return null;
	}
	
	public static String everycanforStrxmgl1(String name1, String name2, String name3, String name4, String name5,
			String name6, String name7, String name8, String name9, String name10, String value1, String value2, String value3, String value4, String value5,
			String value6, int value7,String value8,String value9,String value10, String method) {

		String methodName = method;
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		if (!name1.equals("")) {
			soapObject.addProperty(name1, value1);
		}
		if (!name2.equals("")) {
			soapObject.addProperty(name2, value2);
		}
		if (!name3.equals("")) {
			soapObject.addProperty(name3, value3);
		}
		if (!name4.equals("")) {
			soapObject.addProperty(name4, value4);
		}
		if (!name5.equals("")) {
			soapObject.addProperty(name5, value5);
		}
		if (!name6.equals("")) {
			soapObject.addProperty(name6, value6);
		}
		if (!name7.equals("")) {
			soapObject.addProperty(name7, value7);
		}
		if (!name8.equals("")) {
			soapObject.addProperty(name8, value8);
		}if (!name9.equals("")) {
			soapObject.addProperty(name9, value9);
		}if (!name10.equals("")) {
			soapObject.addProperty(name10, value10);
		}
		Log.d("WebServiceUtil", method + "��" + soapObject);

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				SoapObject result = (SoapObject) envelope.bodyIn;

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		// Log.d("yin","����ֵ�ǿ����");
		return null;
	}
	public static String ZFXX_PL(int post_id,String content,int ztreply_id, String userid) {

		String methodName = "post_comment_create";
		HttpTransportSE ht = new HttpTransportSE(SERVICE_URL);
		ht.debug = true;
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);
		SoapObject soapObject = new SoapObject(SERVICE_NS, methodName);

		soapObject.addProperty("post_id", post_id);
		soapObject.addProperty("content", content);
		soapObject.addProperty("ztreply_id", ztreply_id);
		soapObject.addProperty("userid", userid);

		Log.d("yin", methodName + "��" + soapObject);

		envelope.bodyOut = soapObject;
		envelope.dotNet = true;
		envelope.encodingStyle = "UTF-8";
		try {
			ht.call(SERVICE_NS + methodName, envelope);
			if (envelope.getResponse() != null) {
				SoapObject result = (SoapObject) envelope.bodyIn;

				return result.getProperty(0) + "";
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		// Log.d("yin","����ֵ�ǿ����");
		return null;
	}
	
	
}
