package cn.buaa.adapter;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.weixin_friendcircle.ActionItem;
import com.example.weixin_friendcircle.TitlePopup;
import com.example.weixin_friendcircle.Util;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.woeasy.DZFNew.ImagePagerActivity;
import com.woeasy.DZFNew.InfoRYXX;
import com.woeasy.DZFNew.InfoZFXX;
import com.woeasy.DZFNew.InfoZFXX2;
import com.woeasy.DZFNew.MyGridAdapter;
import com.woeasy.DZFNew.NoScrollGridView;
import com.woeasy.DZFNew.R;
import com.woeasy.DZFNew.ZFXX_PL;
import com.woeasy.model.DZF;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import cn.buaa.util.WebServiceUtil;

@SuppressLint("InflateParams")
public class DZFAdapter2 extends BaseAdapter {
	private Context context; // ����������
	private List<DZF> listItems; // ��Ʒ��Ϣ����
	private LayoutInflater listContainer; // ��ͼ����
	private int f;
	private String json;
	private String spname;
	private TitlePopup titlePopup;

	public final class ListItemView { // �Զ���ؼ�����
		/* public ImageView image; */
		public TextView text01;
		public TextView text02;
		public TextView text03;
		public TextView text04;
		public TextView text05;
		public TextView text06;
		public TextView text07;
		public TextView text08;
		public NoScrollGridView detail;
		public NoScrollGridView detail1;
		private ImageView imageView1;

		private ImageView btn1;
	}

	public DZFAdapter2(Context context, List<DZF> listItems) {
		this.context = context;
		listContainer = LayoutInflater.from(context); // ������ͼ����������������
		this.listItems = listItems;

	}

	@Override
	public int getCount() {
		if (listItems == null) {
			return 0;
		} else {
			return listItems.size();
		}
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	public void setmes(List<DZF> listItems) {
		this.listItems = listItems;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final int x = position;
		ListItemView listItemView = null;
		if (convertView == null) {
			listItemView = new ListItemView();
			convertView = listContainer.inflate(R.layout.dzfxx_adapter3, null);

			// ��ȡ�ؼ�����
			listItemView.text01 = (TextView) convertView.findViewById(R.id.text1);
			listItemView.text02 = (TextView) convertView.findViewById(R.id.text1_1);
			listItemView.text03 = (TextView) convertView.findViewById(R.id.text2);
			listItemView.text04 = (TextView) convertView.findViewById(R.id.text4_2);
			listItemView.text05 = (TextView) convertView.findViewById(R.id.text5_1);
			listItemView.text06 = (TextView) convertView.findViewById(R.id.text4);
			listItemView.text07 = (TextView) convertView.findViewById(R.id.text4_6);
			listItemView.text08 = (TextView) convertView.findViewById(R.id.text4_8);
			listItemView.detail = (NoScrollGridView) convertView.findViewById(R.id.gridView);
			listItemView.detail1 = (NoScrollGridView) convertView.findViewById(R.id.gridView1);
			listItemView.imageView1 = (ImageView) convertView.findViewById(R.id.imageView1);
			// ���ÿؼ�����convertView
			convertView.setTag(listItemView);
		} else {
			listItemView = (ListItemView) convertView.getTag();
		}

		
		// ��΢��
		titlePopup = new TitlePopup(context, Util.dip2px(context, 165), Util.dip2px(context, 40));
		titlePopup.addAction(new ActionItem(context, "��", R.drawable.circle_praise));
		titlePopup.addAction(new ActionItem(context, "����", R.drawable.circle_comment));
		// listItemView.text08.setText(listItems.get(position).getAdviseDo());

		if (listItems.get(position).getAdviseDo().equals("")) {
			listItemView.text08.setText("��");
		} else {
			listItemView.text08.setText(listItems.get(position).getAdviseDo());
		}



		
		
		
		
		
		
		listItemView.text01.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				DZF bp = new DZF();
				bp = listItems.get(x);
				Intent intent = new Intent();
				intent.setClass(context, InfoZFXX2.class);
				Bundle bundle = new Bundle();
				bundle.putSerializable("DZF", bp);
				intent.putExtras(bundle);
				context.startActivity(intent);

			}
		});
		listItemView.text07.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				DZF bp = new DZF();
				bp = listItems.get(x);
				Intent intent = new Intent();
				intent.setClass(context, InfoZFXX2.class);
				Bundle bundle = new Bundle();
				bundle.putSerializable("DZF", bp);
				intent.putExtras(bundle);
				context.startActivity(intent);

			}
		});
		listItemView.text08.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				DZF bp = new DZF();
				bp = listItems.get(x);
				Intent intent = new Intent();
				intent.setClass(context, InfoZFXX2.class);
				Bundle bundle = new Bundle();
				bundle.putSerializable("DZF", bp);
				intent.putExtras(bundle);
				context.startActivity(intent);

			}
		});
		return convertView;
	}

	private void imageBrower(int position, String[] urls) {
		Intent intent = new Intent(context, ImagePagerActivity.class);
		// ͼƬurl,Ϊ����ʾ����ʹ�ó�����һ������ݿ��л������л�ȡ
		intent.putExtra(ImagePagerActivity.EXTRA_IMAGE_URLS, urls);
		intent.putExtra(ImagePagerActivity.EXTRA_IMAGE_INDEX, position);
		context.startActivity(intent);
	}

}
