package cn.buaa.adapter;

import java.util.List;

import com.woeasy.DZFNew.R;
import com.woeasy.model.TZ;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class TZAdapter extends BaseAdapter {
	private Context context; // ����������
	private List<TZ> listItems; // ��Ʒ��Ϣ����
	private LayoutInflater listContainer; // ��ͼ����

	public final class ListItemView { // �Զ���ؼ�����
		public ImageView image;
		public TextView text01;
		public TextView text02;
		public TextView text03;
		public TextView text04;
	}

	public TZAdapter(Context context, List<TZ> listItems) {
		this.context = context;
		listContainer = LayoutInflater.from(context); // ������ͼ����������������
		this.listItems = listItems;
	}

	@Override
	public int getCount() {
		return listItems.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}
	
	public void setmes(List<TZ> listItems) {
		this.listItems = listItems;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ListItemView listItemView = null;
		if (convertView == null) {
			listItemView = new ListItemView();
			convertView = listContainer.inflate(R.layout.dzgg, null);
			// ��ȡ�ؼ�����
			listItemView.image = (ImageView) convertView
					.findViewById(R.id.imageItem);
			listItemView.text01 = (TextView) convertView
					.findViewById(R.id.text01);
			listItemView.text02 = (TextView) convertView
					.findViewById(R.id.text02);
			listItemView.text03 = (TextView) convertView
					.findViewById(R.id.text03);
			listItemView.text04 = (TextView) convertView
					.findViewById(R.id.text04);
			// ���ÿؼ�����convertView
			convertView.setTag(listItemView);
		} else {
			listItemView = (ListItemView) convertView.getTag();
		}
		
		
		
		
		listItemView.text01.setText(listItems.get(position).getXWGL_BT());
	//	listItemView.text02.setText(listItems.get(position).getXWGL_ModifierName());
	//	listItemView.text03.setText("�����ˣ�"+listItems.get(position).getXWGL_CreaterName());
		listItemView.text04.setText("����ʱ�䣺"+listItems.get(position).getXWGL_FWRQ().substring(0, listItems.get(position).getXWGL_FWRQ().length()-5));

		return  convertView;
	}


}
