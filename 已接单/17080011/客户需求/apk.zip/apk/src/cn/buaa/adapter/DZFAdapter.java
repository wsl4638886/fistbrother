package cn.buaa.adapter;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.weixin_friendcircle.ActionItem;
import com.example.weixin_friendcircle.TitlePopup;
import com.example.weixin_friendcircle.Util;
import com.nostra13.universalimageloader.core.assist.LoadedFrom;
import com.woeasy.DZFNew.ImagePagerActivity;
import com.woeasy.DZFNew.InfoRYXX;
import com.woeasy.DZFNew.InfoZFXX;
import com.woeasy.DZFNew.MainActivity2;
import com.woeasy.DZFNew.MyGridAdapter;
import com.woeasy.DZFNew.NoScrollGridView;
import com.woeasy.DZFNew.R;
import com.woeasy.DZFNew.R.id;
import com.woeasy.DZFNew.ZFXX2;
import com.woeasy.DZFNew.ZFXX_PL;
import com.woeasy.model.DZF;
import com.woeasy.model.ROWS;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import cn.buaa.util.WebServiceUtil;

public class DZFAdapter extends BaseAdapter {
	private Context context; // ����������
	private List<DZF> listItems; // ��Ʒ��Ϣ����
	private DZF ap;
	private LayoutInflater listContainer; // ��ͼ����
	private int f;
	private String json;
	private TitlePopup titlePopup;
	public final class ListItemView { // �Զ���ؼ�����
		/*public ImageView image;*/
		public TextView text01;
		public TextView text02;
		public TextView text03;
		public TextView text04;
		public TextView text05;
		public TextView text06;
		public TextView text07;
		public TextView plmz;
		public TextView plnr;
		public TextView dz;
		
		public NoScrollGridView detail;
		private ImageView btn1;
	}
	public DZFAdapter(Context context, List<DZF> listItems) {
		this.context = context;
		listContainer = LayoutInflater.from(context); // ������ͼ����������������
		this.listItems = listItems;
		
		
	}
	
	@Override
	public int getCount() {
		if (listItems==null) {
			return 0;
		}else {
			return listItems.size();
		}
	}
	@Override
	public Object getItem(int position) {
		return null;
	}
	public void setmes(List<DZF> listItems) {
		this.listItems = listItems;
	}
	@Override
	public long getItemId(int position) {
		return 0;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final int x=position;
		
		ListItemView listItemView = null;
		
		if (convertView == null) {
			listItemView = new ListItemView();
			convertView = listContainer.inflate(R.layout.dzfxx_adapter, null);
			// ��ȡ�ؼ�����
			listItemView.text01 = (TextView) convertView.findViewById(R.id.text1);
			listItemView.text02 = (TextView) convertView.findViewById(R.id.text1_1);
			listItemView.text03 = (TextView) convertView.findViewById(R.id.text2);
			listItemView.text04 = (TextView) convertView.findViewById(R.id.text3);
			listItemView.text05 = (TextView) convertView.findViewById(R.id.text4);
			listItemView.text06 = (TextView) convertView.findViewById(R.id.text4_2);
			listItemView.text07 = (TextView) convertView.findViewById(R.id.text5_1);
			listItemView.detail = (NoScrollGridView) convertView.findViewById(R.id.gridView);
			listItemView.btn1 = (ImageView) convertView.findViewById(R.id.button1);
			
			
			// ���ÿؼ�����convertView
			convertView.setTag(listItemView);
		} else {
			listItemView = (ListItemView) convertView.getTag();
		}
		//��΢��
		titlePopup = new TitlePopup(context, Util.dip2px(context, 165), Util.dip2px(context, 40));
		titlePopup.addAction(new ActionItem(context, "��", R.drawable.circle_praise));
		titlePopup.addAction(new ActionItem(context, "����",R.drawable.circle_comment));
		
		listItemView.text01.setText(listItems.get(position).getProName());
		listItemView.text02.setVisibility(View.GONE);;
		listItemView.text03.setText(listItems.get(position).getYearND());
		listItemView.text04.setText(listItems.get(position).getYearYF());
		listItemView.text05.setText(listItems.get(position).getProSchedule());
		listItemView.text07.setText(listItems.get(position).getMobileTel());
	//	listItemView.pl.setText(listItems.get(position).getContent()+"\n");
		/*listItemView.plmz.setText(listItems.get(position).getName());
		listItemView.plnr.setText(listItems.get(position).getContent());*/
		
		if (listItems.get(position).getStime().equals("")) {
			listItemView.text06.setText(listItems.get(position).getStime());
		}else {
			listItemView.text06.setText(listItems.get(position).getStime().substring(0, listItems.get(position).getStime().length()-3));

		}
		/*
		final String plmz[]=listItems.get(position).getName().split(",");
		final String plnr[]=listItems.get(position).getContent().split(",");
		if(listItems.get(position).getName().length()!=0){
			String string = "";
			for(int i=0;i<plmz.length;i++){
				string=string+plmz[i]+":"+plnr[i]+"\n";
				//System.out.println("aaaaaaa"+);
				
			}
			listItemView.plmz.setText(string);
		}*/
	
		
		//	listItemView.text06.setText(listItems.get(position).getStime());
		final String TP_urls[]=listItems.get(position).getSJWSFJ_FullName().split(",");
		
		if(listItems.get(position).getSJWSFJ_FullName().length()!=0)
		for(int i=0;i<TP_urls.length;i++)
		TP_urls[i]="http://218.92.212.198:4888/FJuploadfiles/"+TP_urls[i];
		
		//Log.d("dddddd :", TP_urls[i]);
		if(TP_urls.length>0&&!TP_urls[0].equals("")){
    		listItemView.detail.setVisibility(View.VISIBLE);
			listItemView.detail.setAdapter(new MyGridAdapter(TP_urls, context));
			listItemView.detail.setOnItemClickListener(new AdapterView.OnItemClickListener() {
					@Override
					public void onItemClick(AdapterView<?> parent,
							View view, int position, long id) {
						imageBrower(position, TP_urls);

					}
				});
    	}else {
			listItemView.detail.setVisibility(View.GONE);
		}
		
		convertView.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				 DZF bp = new DZF();
			     bp = listItems.get(x);
			     Intent intent = new Intent();
				 intent.setClass(context, InfoZFXX.class);
				 Bundle bundle = new Bundle();
				 bundle.putSerializable("DZF", bp);
				 intent.putExtras(bundle);
				 context.startActivity(intent);
				
			}
		});
		
		listItemView.btn1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				
				titlePopup.setAnimationStyle(R.style.cricleBottomAnimation);
				titlePopup.show(v);
			}
		});
		
		
		
		
		
		
		
		
		
		
		
		
		
/*	listItemView.im1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				
				 DZF bp = new DZF();
			     bp = listItems.get(x);
			     Intent intent = new Intent();
				 intent.setClass(context, ZFXX_PL.class);
				 Bundle bundle = new Bundle();
				 bundle.putSerializable("DZF", bp);
				 intent.putExtras(bundle);
				 context.startActivity(intent);
			}
		});
		
		
		listItemView.im2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				
				new Thread(new Runnable() {
					@Override
					public void run() {
						
						json = WebServiceUtil.everycanforStr4("UserID", "post_id", "","", "","", 
								"zhouhui", listItems.get(x).getId(),"",0,0,0,"post_like_add");
						Log.d("json1111111111", json);
						
						Message message = new Message();
						message.what = 1;
						handler.sendMessage(message);
					}
				}).start();
				
			}
});
		*/
		
		
		
		
		
		
		
		return  convertView;
	}
	private void imageBrower(int position, String[] urls) {

			if (urls[position].contains(".mp4")) {

			final Uri a =Uri.parse(""+urls[position]); 
			Intent intent = new Intent();
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.setAction(android.content.Intent.ACTION_VIEW);
			intent.setData(a);
			// intent.setData(a);  
			System.out.println("abcdefg:"+a);
			context.startActivity(intent);
			} else {
			Intent intent = new Intent(context, ImagePagerActivity.class);
			// ͼƬurl,Ϊ����ʾ����ʹ�ó�����һ������ݿ��л������л�ȡ
			intent.putExtra(ImagePagerActivity.EXTRA_IMAGE_URLS, urls);
			intent.putExtra(ImagePagerActivity.EXTRA_IMAGE_INDEX, position);
			context.startActivity(intent);
			}
			}
	

}
