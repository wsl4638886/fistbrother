package cn.buaa.adapter;

import java.util.List;

import com.woeasy.DZFNew.R;
import com.woeasy.model.ROWS;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ROWSAdapter extends BaseAdapter {
	private Context context; // ����������
	private List<ROWS> listItems; // ��Ʒ��Ϣ����
	private LayoutInflater listContainer; // ��ͼ����

	public final class ListItemView { // �Զ���ؼ�����
		public ImageView image;
		public TextView text01;
		public TextView text02;
		public TextView text03;
		public TextView text04;
		public TextView text05;
	}

	public ROWSAdapter(Context context, List<ROWS> listItems) {
		this.context = context;
		listContainer = LayoutInflater.from(context); // ������ͼ����������������
		this.listItems = listItems;
	}

	@Override
	public int getCount() {
		return listItems.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}
	
	public void setmes(List<ROWS> listItems) {
		this.listItems = listItems;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ListItemView listItemView = null;
		if (convertView == null) {
			listItemView = new ListItemView();
			convertView = listContainer.inflate(R.layout.ryxx_adapter, null);
			// ��ȡ�ؼ�����
			listItemView.image = (ImageView) convertView
					.findViewById(R.id.im1);
			listItemView.text01 = (TextView) convertView
					.findViewById(R.id.text1);
			listItemView.text02 = (TextView) convertView
					.findViewById(R.id.text1_1);
			listItemView.text03 = (TextView) convertView
					.findViewById(R.id.text2);
			listItemView.text04 = (TextView) convertView
					.findViewById(R.id.text4);
			listItemView.text05 = (TextView) convertView
					.findViewById(R.id.text3);
			// ���ÿؼ�����convertView
			convertView.setTag(listItemView);
		} else {
			listItemView = (ListItemView) convertView.getTag();
		}
		
		
		listItemView.text01.setText(listItems.get(position).getProName());
     	listItemView.text02.setText(listItems.get(position).getUnitName1());
    	listItemView.text03.setText(listItems.get(position).getReceiptCode());
    	listItemView.text05.setText(listItems.get(position).getProDivideOther());
    	listItemView.text04.setText(listItems.get(position).getLocationNumber());
//     	listItemView.text05.setText(listItems.get(position).getUnitName1());
//		listItemView.text03.setText("��Ͷ��(��Ԫ):"+listItems.get(position).getBuildInfonew_WFInst()+"    ���:"+listItems.get(position).getInvestmentYear());
//		listItemView.text04.setText("�ʱ�䣺"+listItems.get(position).getWhsj());


		return  convertView;
	}

}
