package com.woeasy.DZFNew;



import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.woeasy.DZFNew.PullDownView.OnPullDownListener;
import com.woeasy.model.DZF;
import com.woeasy.model.ROWS;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import cn.buaa.adapter.DZFAdapter;
import cn.buaa.adapter.ROWSAdapter;
import cn.buaa.util.NetHelper;
import cn.buaa.util.WebServiceUtil;

public class ZFXX_list extends Activity  implements OnPullDownListener,OnItemClickListener{
	private ListView listview;
	private PullDownView mPullDownView;
	private DZFAdapter listViewAdapter;
	private List<DZF> listItems = new ArrayList<DZF>();
	private String json, json2, json3,jsoncan,flag2,xmcx,strseq,json4,json5,record;
	private String spname,str1;
	private int pageindex = 1;
	private ROWS ap;
	private int proseq;
	private Button zfxx;
	private boolean iswebbing=false;
	protected static final int ADD_ADPATER = 1;
	protected static final int ADD_DZGG = 1;
	private static final int WHAT_DID_LOAD_DATA = 0;
	private static final int WHAT_DID_REFRESH = 1;
	private static final int WHAT_DID_MORE = 2;
	public static ZFXX_list listact;
	private  TextView zs;
	private Handler handler = new Handler() {
		@SuppressWarnings("unchecked")
		@Override
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case WHAT_DID_LOAD_DATA: {
				setData(listItems);
				// setGGData();
				mPullDownView.notifyDidLoad();
				zs.setText("����:"+record+"��  ");
				break;
			}
			case WHAT_DID_REFRESH: {
				listItems.clear();
				listItems=(List<DZF>)msg.obj;
				listViewAdapter.setmes((List<DZF>) msg.obj);
				listViewAdapter.notifyDataSetChanged();
				mPullDownView.notifyDidRefresh();
				zs.setText("����:"+record+"��  ");
				break;
			}

			case WHAT_DID_MORE: {
				listViewAdapter.setmes(listItems);
				listViewAdapter.notifyDataSetChanged();
				mPullDownView.notifyDidMore();
				zs.setText("����:"+record+"��  ");
				break;
			}
			}
		}
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dzfxx_list);
		listact = this;
		spname = getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE+Context.MODE_WORLD_WRITEABLE).getString("spname", "");
		Intent intent = this.getIntent(); 
	     ap=(ROWS) intent.getSerializableExtra("ROWS");
	     proseq=ap.getSeq();
	     getInfo();
	     mPullDownView = (PullDownView) findViewById(R.id.rwlistview);
			mPullDownView.setOnPullDownListener(this);
			listview = mPullDownView.getListView();
			//����ˢ��
			listViewAdapter = new DZFAdapter(this, listItems);
			listview.setAdapter(listViewAdapter);
			listview.setOnItemClickListener(this);
			mPullDownView.enableAutoFetchMore(false, 1);
			//��������
			mPullDownView.enableAutoFetchMore(true, 1);
			 zfxx=(Button) findViewById(R.id.zf);
				zs=  (TextView)findViewById(R.id.zs);
			 zfxx.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						Intent intent = new Intent();
						intent.setClass(ZFXX_list.this, ZFXX_XJ.class);
						Bundle bundle = new Bundle();
						bundle.putSerializable("ROWS", ap);
						intent.putExtras(bundle);
						startActivity(intent);
						
					}
				});
	}
	protected void setData(List<DZF> list2) {
		listViewAdapter = new DZFAdapter(this, listItems);
		listview.setAdapter(listViewAdapter);

	}
	
	private void getInfo() {
		boolean havenet = NetHelper.IsHaveInternet(ZFXX_list.this);
		if (havenet) {
			new Thread() {
				public void run() {
					JSONObject jsonObj;
					JSONObject jsonObj2;
					JSONObject jsonObj3;
					JSONObject jsonObj4;
					JSONObject jsonObj5;
					JSONArray jsonObjs = null;
					JSONArray jsonObjs2 = null;
					JSONArray jsonObjs3 = null;
					JSONArray jsonObjs4 = null;
					JSONArray jsonObjs5 = null;
	json = WebServiceUtil.everycanforStr4("userid", "", "", "", "proseq", "pageindex",
											spname, "", "",0,proseq, pageindex, "ZDXMJDGetList1");
					// json=json.replace("[{\"pmodel\":", "[");
					Log.d("����Դ��", json);
					if (json != null && !json.equals("0")) {
						 JSONTokener jsonTokener = new JSONTokener(json);
						try {
							jsonObjs = new JSONArray(json);
						} catch (JSONException e1) {
							e1.printStackTrace();
						}
						try {
							JSONObject xm = (JSONObject) jsonTokener.nextValue();
							jsonObjs = xm.getJSONArray("rows");
							String aa[]=json.split(",");
							aa[2]=aa[2].replace("\"records\":", "");
							record=aa[2];
							for (int i = 0; i < jsonObjs.length(); i++) {
								jsonObj = (JSONObject) jsonObjs.opt(i);
								if (jsonObj.getString("pmodel") != null)
								json2 = jsonObj.getString("pmodel");
								Log.d("yuan2", json2);
								json3 = jsonObj.getString("tp");
								json4=jsonObj.getString("commentlist");
								json5=jsonObj.getString("likelist");
								
								json2 = json2.replace("{", "[{");
								json2 = json2.replace("}", "}]");
								jsonObjs2 = new JSONArray(json2);
								
								json3 = json3.replace("[", "{\"tp\":[");
								json3 = json3.replace("]", "]}");
								Log.d("yuan3", json3);
								
								json4 = json4.replace("[", "{\"commentlist\":[");
								json4 = json4.replace("]", "]}");
								Log.d("yuan4", json4);
								
								
								DZF rz = new DZF();
								for (int j = 0; j < jsonObjs2.length(); j++) {
									jsonObj2 = (JSONObject) jsonObjs2.opt(j);
									rz.setId(jsonObj2.getString("id"));
									Log.d("yuan++++", jsonObj2.getString("id"));
									
									rz.setProSeq(jsonObj2.getString("proSeq"));
									rz.setProName(jsonObj2.getString("proName"));
									rz.setYearND(jsonObj2.getString("yearND"));
									rz.setYearYF(jsonObj2.getString("yearYF"));
									rz.setYearPlanFundSum(jsonObj2.getString("yearPlanFundSum"));
									rz.setTotalInvestFromBegin(jsonObj2.getString("totalInvestFromBegin"));
									rz.setMonthInvest(jsonObj2.getString("monthInvest"));
									rz.setLastInvestThisYear(jsonObj2.getString("lastInvestThisYear"));
									rz.setZjsyLastyearInvestPercent(jsonObj2.getString("zjsyLastyearInvestPercent"));
									rz.setFinishInvestThisYear(jsonObj2.getString("finishInvestThisYear"));
									rz.setZjsyThisyearInvestPercent(jsonObj2.getString("zjsyThisyearInvestPercent"));
									rz.setBuildStep(jsonObj2.getString("buildStep"));
									rz.setApproSeq(jsonObj2.getString("approSeq"));
									rz.setPreceiptCode(jsonObj2.getString("preceiptCode"));
									rz.setBeginDatestr(jsonObj2.getString("beginDatestr"));
									rz.setOverDate(jsonObj2.getString("overDate"));
									rz.setDeferReason(jsonObj2.getString("deferReason"));
									rz.setProSchedule(jsonObj2.getString("proSchedule"));
									rz.setExistProblem(jsonObj2.getString("existProblem"));
									rz.setAdviseDo(jsonObj2.getString("adviseDo"));
									rz.setChangeCondition(jsonObj2.getString("changeCondition"));
									rz.setProLinkMan(jsonObj2.getString("proLinkMan"));
									rz.setOfficeTel(jsonObj2.getString("officeTel"));
									rz.setMobileTel(jsonObj2.getString("mobileTel"));
									rz.setQqNumber(jsonObj2.getString("qqNumber"));
									rz.setFax(jsonObj2.getString("fax"));
									rz.setPmMonthScheduleBase_WFID(jsonObj2.getString("pmMonthScheduleBase_WFID"));									
									rz.setPmMonthScheduleBase_WFInst(jsonObj2.getString("pmMonthScheduleBase_WFInst"));
									rz.setPmMonthScheduleBase_WPID(jsonObj2.getString("pmMonthScheduleBase_WPID"));
									str1=jsonObj2.getString("pmMonthScheduleBase_WPID");
									rz.setPmMonthScheduleBase_Awaiter(jsonObj2.getString("pmMonthScheduleBase_Awaiter"));
									rz.setPmMonthScheduleBase_Handler(jsonObj2.getString("pmMonthScheduleBase_Handler"));
									rz.setStime(jsonObj2.getString("stime"));
									rz.setEtime(jsonObj2.getString("etime"));
									
									JSONTokener jsonTokener2 = new JSONTokener(json3);
									JSONObject xm2 = (JSONObject) jsonTokener2.nextValue();
									jsonObjs3 = xm2.getJSONArray("tp");
									String SJWSFJ_GRPID = "";
									String SJWSFJ_XH = "";
									String SJWSFJ_FileName = "";
									String SJWSFJ_FileType = "";
									String SJWSFJ_FilePath = "";
									String SJWSFJ_WHRID = "";
									String SJWSFJ_WHR = "";
									String SJWSFJ_WHSJ = "";
									String SJWSFJ_FullName = "";
									String SJWSFJ_WJJ = "";
									String SJWSFJ_DID = "";
									String SJWSFJ_XID = "";
									for (int k = 0; k < jsonObjs3.length(); k++) {
										jsonObj3 = (JSONObject) jsonObjs3.opt(k);
										if (SJWSFJ_GRPID != "")
											SJWSFJ_GRPID = SJWSFJ_GRPID + ",";
										SJWSFJ_GRPID = SJWSFJ_GRPID + jsonObj3.getString("SJWSFJ_GRPID");
										if (SJWSFJ_XH != "")
											SJWSFJ_XH = SJWSFJ_XH + ",";
										SJWSFJ_XH = SJWSFJ_XH + jsonObj3.getString("SJWSFJ_XH");
										if (SJWSFJ_FileName != "")
											SJWSFJ_FileName = SJWSFJ_FileName + ",";
										SJWSFJ_FileName = SJWSFJ_FileName + jsonObj3.getString("SJWSFJ_FileName");
										if (SJWSFJ_FileType != "")
											SJWSFJ_FileType = SJWSFJ_FileType + ",";
										SJWSFJ_FileType = SJWSFJ_FileType + jsonObj3.getString("SJWSFJ_FileType");
										if (SJWSFJ_FilePath != "")
											SJWSFJ_FilePath = SJWSFJ_FilePath + ",";
										SJWSFJ_FilePath = SJWSFJ_FilePath + jsonObj3.getString("SJWSFJ_FilePath");
										if (SJWSFJ_WHRID != "")
											SJWSFJ_WHRID = SJWSFJ_WHRID + ",";
										SJWSFJ_WHRID = SJWSFJ_WHRID + jsonObj3.getString("SJWSFJ_WHRID");
										if (SJWSFJ_WHR != "")
											SJWSFJ_WHR = SJWSFJ_WHR + ",";
										SJWSFJ_WHR = SJWSFJ_WHR + jsonObj3.getString("SJWSFJ_WHR");
										if (SJWSFJ_WHSJ != "")
											SJWSFJ_WHSJ = SJWSFJ_WHSJ + ",";
										SJWSFJ_WHSJ = SJWSFJ_WHSJ + jsonObj3.getString("SJWSFJ_WHSJ");
										if (SJWSFJ_FullName != "")
											SJWSFJ_FullName = SJWSFJ_FullName + ",";
										SJWSFJ_FullName = SJWSFJ_FullName + jsonObj3.getString("SJWSFJ_FullName");
										if (SJWSFJ_WJJ != "")
											SJWSFJ_WJJ = SJWSFJ_WJJ + ",";
										SJWSFJ_WJJ = SJWSFJ_WJJ + jsonObj3.getString("SJWSFJ_WJJ");
										if (SJWSFJ_DID != "")
											SJWSFJ_DID = SJWSFJ_DID + ",";
										SJWSFJ_DID = SJWSFJ_DID + jsonObj3.getString("SJWSFJ_DID");
										if (SJWSFJ_XID != "")
											SJWSFJ_XID = SJWSFJ_XID + ",";
										SJWSFJ_XID = SJWSFJ_XID + jsonObj3.getString("SJWSFJ_XID");

									}
									
									rz.setSJWSFJ_GRPID(SJWSFJ_GRPID);
									rz.setSJWSFJ_XH(SJWSFJ_XH);
									rz.setSJWSFJ_FileName(SJWSFJ_FileName);
									rz.setSJWSFJ_FileType(SJWSFJ_FileType);
									rz.setSJWSFJ_FilePath(SJWSFJ_FilePath);
									rz.setSJWSFJ_WHRID(SJWSFJ_WHRID);
									rz.setSJWSFJ_WHR(SJWSFJ_WHR);
									rz.setSJWSFJ_WHSJ(SJWSFJ_WHSJ);
									rz.setSJWSFJ_WHSJ(SJWSFJ_WHSJ);
									rz.setSJWSFJ_FullName(SJWSFJ_FullName);
									rz.setSJWSFJ_WJJ(SJWSFJ_WJJ);
									rz.setSJWSFJ_DID(SJWSFJ_DID);
									rz.setSJWSFJ_XID(SJWSFJ_XID);
									Log.d("yuanw", rz.getSJWSFJ_FullName());
									Log.d("yuanw1", rz.getSJWSFJ_XH());
									
									/*JSONTokener jsonTokener3 = new JSONTokener(json4);
									JSONObject xm3 = (JSONObject) jsonTokener3.nextValue();
									jsonObjs4 = xm3.getJSONArray("commentlist");
									
									String reply_id = "";
									String create_user = "";
									String attach_ids = "";
									String attachments = "";
									String create_time = "";
									String content = "";
									String name = "";
									for (int m = 0; m < jsonObjs4.length(); m++) {
										jsonObj4 = (JSONObject) jsonObjs4.opt(m);
										if (reply_id != "")
											reply_id = reply_id + ",";
										reply_id = reply_id + jsonObj4.getString("reply_id");
										if (create_user != "")
											create_user = create_user + ",";
										create_user = create_user + jsonObj4.getString("create_user");
										if (attach_ids != "")
											attach_ids = attach_ids + ",";
										attach_ids = attach_ids + jsonObj4.getString("attach_ids");
										if (attachments != "")
											attachments = attachments + ",";
										attachments = attachments + jsonObj4.getString("attachments");
										if (create_time != "")
											create_time = create_time + ",";
										create_time = create_time + jsonObj4.getString("create_time");
										if (content != "")
											content = content + ",";
										content = content + jsonObj4.getString("content");
										if (name != "")
											name = name + ",";
										name = name + jsonObj4.getString("name");
										
									}		
									rz.setReply_id(reply_id);
									rz.setCreate_user(create_user);
									rz.setAttach_ids(attach_ids);
									rz.setAttachments(attachments);
									rz.setCreate_time(create_time);
									rz.setContent(content);
									rz.setName(name);
									Log.d("yuansssss", rz.getContent());
									*/
									
									listItems.add(rz);
								}
							
							}
						} catch (Exception e) {
						}
						
						Message msg = new Message();
						msg.what = WHAT_DID_LOAD_DATA;
						handler.sendMessage(msg);
					}

				}
			}.start();
		} else {
			new AlertDialog.Builder(ZFXX_list.this)
			.setMessage("���������������ã�")
			.setTitle("����������")
			.setPositiveButton("ȷ��",new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog,
								int which) {
						}

					}).show();

}

	}
	
	
	@Override
	public void onRefresh() {
		pageindex=1;
		boolean havenet = NetHelper.IsHaveInternet(ZFXX_list.this);
		if (havenet) {
			new Thread() {
				public void run() {
					JSONObject jsonObj;
					JSONObject jsonObj2;
					JSONObject jsonObj3;
					JSONArray jsonObjs = null;
					JSONArray jsonObjs2 = null;
					JSONArray jsonObjs3 = null;
					List<DZF> list = new ArrayList<DZF>();
	json = WebServiceUtil.everycanforStr4("userid", "", "", "", "proseq", "pageindex",
											spname, "", "",0,proseq, pageindex, "ZDXMJDGetList1");
					// json=json.replace("[{\"pmodel\":", "[");
					Log.d("����Դ��", json);
					if (json != null && !json.equals("0")) {
						 JSONTokener jsonTokener = new JSONTokener(json);
						try {
							jsonObjs = new JSONArray(json);
						} catch (JSONException e1) {
							e1.printStackTrace();
						}
						try {
							JSONObject xm = (JSONObject) jsonTokener.nextValue();
							jsonObjs = xm.getJSONArray("rows");
							String aa[]=json.split(",");
							aa[2]=aa[2].replace("\"records\":", "");
							record=aa[2];
							for (int i = 0; i < jsonObjs.length(); i++) {
								jsonObj = (JSONObject) jsonObjs.opt(i);
								if (jsonObj.getString("pmodel") != null)
								json2 = jsonObj.getString("pmodel");
								Log.d("yuan2", json2);
								json3 = jsonObj.getString("tp");
								json4=jsonObj.getString("commentlist");
								json5=jsonObj.getString("likelist");
								
								json2 = json2.replace("{", "[{");
								json2 = json2.replace("}", "}]");
								jsonObjs2 = new JSONArray(json2);
								
								json3 = json3.replace("[", "{\"tp\":[");
								json3 = json3.replace("]", "]}");
								Log.d("yuan3", json3);
								
								
								
								DZF rz = new DZF();
								for (int j = 0; j < jsonObjs2.length(); j++) {
									jsonObj2 = (JSONObject) jsonObjs2.opt(j);
									rz.setId(jsonObj2.getString("id"));
									Log.d("yuan++++", jsonObj2.getString("id"));
									
									rz.setProSeq(jsonObj2.getString("proSeq"));
									rz.setProName(jsonObj2.getString("proName"));
									rz.setYearND(jsonObj2.getString("yearND"));
									rz.setYearYF(jsonObj2.getString("yearYF"));
									rz.setYearPlanFundSum(jsonObj2.getString("yearPlanFundSum"));
									rz.setTotalInvestFromBegin(jsonObj2.getString("totalInvestFromBegin"));
									rz.setMonthInvest(jsonObj2.getString("monthInvest"));
									rz.setLastInvestThisYear(jsonObj2.getString("lastInvestThisYear"));
									rz.setZjsyLastyearInvestPercent(jsonObj2.getString("zjsyLastyearInvestPercent"));
									rz.setFinishInvestThisYear(jsonObj2.getString("finishInvestThisYear"));
									rz.setZjsyThisyearInvestPercent(jsonObj2.getString("zjsyThisyearInvestPercent"));
									rz.setBuildStep(jsonObj2.getString("buildStep"));
									rz.setApproSeq(jsonObj2.getString("approSeq"));
									rz.setPreceiptCode(jsonObj2.getString("preceiptCode"));
									rz.setBeginDatestr(jsonObj2.getString("beginDatestr"));
									rz.setOverDate(jsonObj2.getString("overDate"));
									rz.setDeferReason(jsonObj2.getString("deferReason"));
									rz.setProSchedule(jsonObj2.getString("proSchedule"));
									rz.setExistProblem(jsonObj2.getString("existProblem"));
									rz.setAdviseDo(jsonObj2.getString("adviseDo"));
									rz.setChangeCondition(jsonObj2.getString("changeCondition"));
									rz.setProLinkMan(jsonObj2.getString("proLinkMan"));
									rz.setOfficeTel(jsonObj2.getString("officeTel"));
									rz.setMobileTel(jsonObj2.getString("mobileTel"));
									rz.setQqNumber(jsonObj2.getString("qqNumber"));
									rz.setFax(jsonObj2.getString("fax"));
									rz.setPmMonthScheduleBase_WFID(jsonObj2.getString("pmMonthScheduleBase_WFID"));									
									rz.setPmMonthScheduleBase_WFInst(jsonObj2.getString("pmMonthScheduleBase_WFInst"));
									rz.setPmMonthScheduleBase_WPID(jsonObj2.getString("pmMonthScheduleBase_WPID"));
									str1=jsonObj2.getString("pmMonthScheduleBase_WPID");
									rz.setPmMonthScheduleBase_Awaiter(jsonObj2.getString("pmMonthScheduleBase_Awaiter"));
									rz.setPmMonthScheduleBase_Handler(jsonObj2.getString("pmMonthScheduleBase_Handler"));
									rz.setStime(jsonObj2.getString("stime"));
									rz.setEtime(jsonObj2.getString("etime"));
									
									JSONTokener jsonTokener2 = new JSONTokener(json3);
									JSONObject xm2 = (JSONObject) jsonTokener2.nextValue();
									jsonObjs3 = xm2.getJSONArray("tp");
									String SJWSFJ_GRPID = "";
									String SJWSFJ_XH = "";
									String SJWSFJ_FileName = "";
									String SJWSFJ_FileType = "";
									String SJWSFJ_FilePath = "";
									String SJWSFJ_WHRID = "";
									String SJWSFJ_WHR = "";
									String SJWSFJ_WHSJ = "";
									String SJWSFJ_FullName = "";
									String SJWSFJ_WJJ = "";
									String SJWSFJ_DID = "";
									String SJWSFJ_XID = "";
									for (int k = 0; k < jsonObjs3.length(); k++) {
										jsonObj3 = (JSONObject) jsonObjs3.opt(k);
										if (SJWSFJ_GRPID != "")
											SJWSFJ_GRPID = SJWSFJ_GRPID + ",";
										SJWSFJ_GRPID = SJWSFJ_GRPID + jsonObj3.getString("SJWSFJ_GRPID");
										if (SJWSFJ_XH != "")
											SJWSFJ_XH = SJWSFJ_XH + ",";
										SJWSFJ_XH = SJWSFJ_XH + jsonObj3.getString("SJWSFJ_XH");
										if (SJWSFJ_FileName != "")
											SJWSFJ_FileName = SJWSFJ_FileName + ",";
										SJWSFJ_FileName = SJWSFJ_FileName + jsonObj3.getString("SJWSFJ_FileName");
										if (SJWSFJ_FileType != "")
											SJWSFJ_FileType = SJWSFJ_FileType + ",";
										SJWSFJ_FileType = SJWSFJ_FileType + jsonObj3.getString("SJWSFJ_FileType");
										if (SJWSFJ_FilePath != "")
											SJWSFJ_FilePath = SJWSFJ_FilePath + ",";
										SJWSFJ_FilePath = SJWSFJ_FilePath + jsonObj3.getString("SJWSFJ_FilePath");
										if (SJWSFJ_WHRID != "")
											SJWSFJ_WHRID = SJWSFJ_WHRID + ",";
										SJWSFJ_WHRID = SJWSFJ_WHRID + jsonObj3.getString("SJWSFJ_WHRID");
										if (SJWSFJ_WHR != "")
											SJWSFJ_WHR = SJWSFJ_WHR + ",";
										SJWSFJ_WHR = SJWSFJ_WHR + jsonObj3.getString("SJWSFJ_WHR");
										if (SJWSFJ_WHSJ != "")
											SJWSFJ_WHSJ = SJWSFJ_WHSJ + ",";
										SJWSFJ_WHSJ = SJWSFJ_WHSJ + jsonObj3.getString("SJWSFJ_WHSJ");
										if (SJWSFJ_FullName != "")
											SJWSFJ_FullName = SJWSFJ_FullName + ",";
										SJWSFJ_FullName = SJWSFJ_FullName + jsonObj3.getString("SJWSFJ_FullName");
										if (SJWSFJ_WJJ != "")
											SJWSFJ_WJJ = SJWSFJ_WJJ + ",";
										SJWSFJ_WJJ = SJWSFJ_WJJ + jsonObj3.getString("SJWSFJ_WJJ");
										if (SJWSFJ_DID != "")
											SJWSFJ_DID = SJWSFJ_DID + ",";
										SJWSFJ_DID = SJWSFJ_DID + jsonObj3.getString("SJWSFJ_DID");
										if (SJWSFJ_XID != "")
											SJWSFJ_XID = SJWSFJ_XID + ",";
										SJWSFJ_XID = SJWSFJ_XID + jsonObj3.getString("SJWSFJ_XID");

									}
									
									rz.setSJWSFJ_GRPID(SJWSFJ_GRPID);
									rz.setSJWSFJ_XH(SJWSFJ_XH);
									rz.setSJWSFJ_FileName(SJWSFJ_FileName);
									rz.setSJWSFJ_FileType(SJWSFJ_FileType);
									rz.setSJWSFJ_FilePath(SJWSFJ_FilePath);
									rz.setSJWSFJ_WHRID(SJWSFJ_WHRID);
									rz.setSJWSFJ_WHR(SJWSFJ_WHR);
									rz.setSJWSFJ_WHSJ(SJWSFJ_WHSJ);
									rz.setSJWSFJ_WHSJ(SJWSFJ_WHSJ);
									rz.setSJWSFJ_FullName(SJWSFJ_FullName);
									rz.setSJWSFJ_WJJ(SJWSFJ_WJJ);
									rz.setSJWSFJ_DID(SJWSFJ_DID);
									rz.setSJWSFJ_XID(SJWSFJ_XID);
									Log.d("yuanw", rz.getSJWSFJ_FullName());
									Log.d("yuanw1", rz.getSJWSFJ_XH());
									list.add(rz);
								}
							
							}
						} catch (Exception e) {
						}
						
						Message msg = new Message();
						msg.what = WHAT_DID_REFRESH;
						msg.obj = list;
						handler.sendMessage(msg);
					}

				}
			}.start();
		} else {
			new AlertDialog.Builder(ZFXX_list.this)
			.setMessage("���������������ã�")
			.setTitle("����������")
			.setPositiveButton("ȷ��",new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog,
								int which) {
						}

					}).show();

}
	}
	
	
	@Override
	public void onMore() {
		pageindex++;
		boolean havenet = NetHelper.IsHaveInternet(ZFXX_list.this);
		if (havenet) {
			new Thread() {
				public void run() {
					JSONObject jsonObj;
					JSONObject jsonObj2;
					JSONObject jsonObj3;
					JSONArray jsonObjs = null;
					JSONArray jsonObjs2 = null;
					JSONArray jsonObjs3 = null;
	json = WebServiceUtil.everycanforStr4("userid", "", "", "", "proseq", "pageindex",
											spname, "", "",0,proseq, pageindex, "ZDXMJDGetList1");
					// json=json.replace("[{\"pmodel\":", "[");
					Log.d("����Դ��", json);
					if (json != null && !json.equals("0")) {
						 JSONTokener jsonTokener = new JSONTokener(json);
						try {
							jsonObjs = new JSONArray(json);
						} catch (JSONException e1) {
							e1.printStackTrace();
						}
						try {
							JSONObject xm = (JSONObject) jsonTokener.nextValue();
							jsonObjs = xm.getJSONArray("rows");
							for (int i = 0; i < jsonObjs.length(); i++) {
								jsonObj = (JSONObject) jsonObjs.opt(i);
								if (jsonObj.getString("pmodel") != null)
								json2 = jsonObj.getString("pmodel");
								Log.d("yuan2", json2);
								json3 = jsonObj.getString("tp");
								json4=jsonObj.getString("commentlist");
								json5=jsonObj.getString("likelist");
								
								json2 = json2.replace("{", "[{");
								json2 = json2.replace("}", "}]");
								jsonObjs2 = new JSONArray(json2);
								
								json3 = json3.replace("[", "{\"tp\":[");
								json3 = json3.replace("]", "]}");
								Log.d("yuan3", json3);
								
								
								
								DZF rz = new DZF();
								String aa[]=json.split(",");
								aa[2]=aa[2].replace("\"records\":", "");
								record=aa[2];
								for (int j = 0; j < jsonObjs2.length(); j++) {
									jsonObj2 = (JSONObject) jsonObjs2.opt(j);
									rz.setId(jsonObj2.getString("id"));
									Log.d("yuan++++", jsonObj2.getString("id"));
									
									rz.setProSeq(jsonObj2.getString("proSeq"));
									rz.setProName(jsonObj2.getString("proName"));
									rz.setYearND(jsonObj2.getString("yearND"));
									rz.setYearYF(jsonObj2.getString("yearYF"));
									rz.setYearPlanFundSum(jsonObj2.getString("yearPlanFundSum"));
									rz.setTotalInvestFromBegin(jsonObj2.getString("totalInvestFromBegin"));
									rz.setMonthInvest(jsonObj2.getString("monthInvest"));
									rz.setLastInvestThisYear(jsonObj2.getString("lastInvestThisYear"));
									rz.setZjsyLastyearInvestPercent(jsonObj2.getString("zjsyLastyearInvestPercent"));
									rz.setFinishInvestThisYear(jsonObj2.getString("finishInvestThisYear"));
									rz.setZjsyThisyearInvestPercent(jsonObj2.getString("zjsyThisyearInvestPercent"));
									rz.setBuildStep(jsonObj2.getString("buildStep"));
									rz.setApproSeq(jsonObj2.getString("approSeq"));
									rz.setPreceiptCode(jsonObj2.getString("preceiptCode"));
									rz.setBeginDatestr(jsonObj2.getString("beginDatestr"));
									rz.setOverDate(jsonObj2.getString("overDate"));
									rz.setDeferReason(jsonObj2.getString("deferReason"));
									rz.setProSchedule(jsonObj2.getString("proSchedule"));
									rz.setExistProblem(jsonObj2.getString("existProblem"));
									rz.setAdviseDo(jsonObj2.getString("adviseDo"));
									rz.setChangeCondition(jsonObj2.getString("changeCondition"));
									rz.setProLinkMan(jsonObj2.getString("proLinkMan"));
									rz.setOfficeTel(jsonObj2.getString("officeTel"));
									rz.setMobileTel(jsonObj2.getString("mobileTel"));
									rz.setQqNumber(jsonObj2.getString("qqNumber"));
									rz.setFax(jsonObj2.getString("fax"));
									rz.setPmMonthScheduleBase_WFID(jsonObj2.getString("pmMonthScheduleBase_WFID"));									
									rz.setPmMonthScheduleBase_WFInst(jsonObj2.getString("pmMonthScheduleBase_WFInst"));
									rz.setPmMonthScheduleBase_WPID(jsonObj2.getString("pmMonthScheduleBase_WPID"));
									str1=jsonObj2.getString("pmMonthScheduleBase_WPID");
									rz.setPmMonthScheduleBase_Awaiter(jsonObj2.getString("pmMonthScheduleBase_Awaiter"));
									rz.setPmMonthScheduleBase_Handler(jsonObj2.getString("pmMonthScheduleBase_Handler"));
									rz.setStime(jsonObj2.getString("stime"));
									rz.setEtime(jsonObj2.getString("etime"));
									
									JSONTokener jsonTokener2 = new JSONTokener(json3);
									JSONObject xm2 = (JSONObject) jsonTokener2.nextValue();
									jsonObjs3 = xm2.getJSONArray("tp");
									String SJWSFJ_GRPID = "";
									String SJWSFJ_XH = "";
									String SJWSFJ_FileName = "";
									String SJWSFJ_FileType = "";
									String SJWSFJ_FilePath = "";
									String SJWSFJ_WHRID = "";
									String SJWSFJ_WHR = "";
									String SJWSFJ_WHSJ = "";
									String SJWSFJ_FullName = "";
									String SJWSFJ_WJJ = "";
									String SJWSFJ_DID = "";
									String SJWSFJ_XID = "";
									for (int k = 0; k < jsonObjs3.length(); k++) {
										jsonObj3 = (JSONObject) jsonObjs3.opt(k);
										if (SJWSFJ_GRPID != "")
											SJWSFJ_GRPID = SJWSFJ_GRPID + ",";
										SJWSFJ_GRPID = SJWSFJ_GRPID + jsonObj3.getString("SJWSFJ_GRPID");
										if (SJWSFJ_XH != "")
											SJWSFJ_XH = SJWSFJ_XH + ",";
										SJWSFJ_XH = SJWSFJ_XH + jsonObj3.getString("SJWSFJ_XH");
										if (SJWSFJ_FileName != "")
											SJWSFJ_FileName = SJWSFJ_FileName + ",";
										SJWSFJ_FileName = SJWSFJ_FileName + jsonObj3.getString("SJWSFJ_FileName");
										if (SJWSFJ_FileType != "")
											SJWSFJ_FileType = SJWSFJ_FileType + ",";
										SJWSFJ_FileType = SJWSFJ_FileType + jsonObj3.getString("SJWSFJ_FileType");
										if (SJWSFJ_FilePath != "")
											SJWSFJ_FilePath = SJWSFJ_FilePath + ",";
										SJWSFJ_FilePath = SJWSFJ_FilePath + jsonObj3.getString("SJWSFJ_FilePath");
										if (SJWSFJ_WHRID != "")
											SJWSFJ_WHRID = SJWSFJ_WHRID + ",";
										SJWSFJ_WHRID = SJWSFJ_WHRID + jsonObj3.getString("SJWSFJ_WHRID");
										if (SJWSFJ_WHR != "")
											SJWSFJ_WHR = SJWSFJ_WHR + ",";
										SJWSFJ_WHR = SJWSFJ_WHR + jsonObj3.getString("SJWSFJ_WHR");
										if (SJWSFJ_WHSJ != "")
											SJWSFJ_WHSJ = SJWSFJ_WHSJ + ",";
										SJWSFJ_WHSJ = SJWSFJ_WHSJ + jsonObj3.getString("SJWSFJ_WHSJ");
										if (SJWSFJ_FullName != "")
											SJWSFJ_FullName = SJWSFJ_FullName + ",";
										SJWSFJ_FullName = SJWSFJ_FullName + jsonObj3.getString("SJWSFJ_FullName");
										if (SJWSFJ_WJJ != "")
											SJWSFJ_WJJ = SJWSFJ_WJJ + ",";
										SJWSFJ_WJJ = SJWSFJ_WJJ + jsonObj3.getString("SJWSFJ_WJJ");
										if (SJWSFJ_DID != "")
											SJWSFJ_DID = SJWSFJ_DID + ",";
										SJWSFJ_DID = SJWSFJ_DID + jsonObj3.getString("SJWSFJ_DID");
										if (SJWSFJ_XID != "")
											SJWSFJ_XID = SJWSFJ_XID + ",";
										SJWSFJ_XID = SJWSFJ_XID + jsonObj3.getString("SJWSFJ_XID");

									}
									
									rz.setSJWSFJ_GRPID(SJWSFJ_GRPID);
									rz.setSJWSFJ_XH(SJWSFJ_XH);
									rz.setSJWSFJ_FileName(SJWSFJ_FileName);
									rz.setSJWSFJ_FileType(SJWSFJ_FileType);
									rz.setSJWSFJ_FilePath(SJWSFJ_FilePath);
									rz.setSJWSFJ_WHRID(SJWSFJ_WHRID);
									rz.setSJWSFJ_WHR(SJWSFJ_WHR);
									rz.setSJWSFJ_WHSJ(SJWSFJ_WHSJ);
									rz.setSJWSFJ_WHSJ(SJWSFJ_WHSJ);
									rz.setSJWSFJ_FullName(SJWSFJ_FullName);
									rz.setSJWSFJ_WJJ(SJWSFJ_WJJ);
									rz.setSJWSFJ_DID(SJWSFJ_DID);
									rz.setSJWSFJ_XID(SJWSFJ_XID);
									Log.d("yuanw", rz.getSJWSFJ_FullName());
									Log.d("yuanw1", rz.getSJWSFJ_XH());
									listItems.add(rz);
								}
							
							}
						} catch (Exception e) {
						}
						
						Message msg = new Message();
						msg.what = WHAT_DID_MORE;
						handler.sendMessage(msg);
					}

				}
			}.start();
		} else {
			new AlertDialog.Builder(ZFXX_list.this)
			.setMessage("���������������ã�")
			.setTitle("����������")
			.setPositiveButton("ȷ��",new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog,
								int which) {
						}

					}).show();

}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		// TODO Auto-generated method stub
		
	}

	

	
	
	/**
	 * ����
	 */
	public void btn_back(View v){
		this.finish();
	}
	

}
