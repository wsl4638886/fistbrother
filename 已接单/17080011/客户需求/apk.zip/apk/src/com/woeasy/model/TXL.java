package com.woeasy.model;

import java.io.Serializable;

public class TXL implements Serializable{
	private int ID;
	private int FID;
	private String BGSHM;
	private String FL;
	private String ZFHS;
	private String SSBM;
	
	
	
	
	public String getZFHS() {
		return ZFHS;
	}
	public void setZFHS(String zFHS) {
		ZFHS = zFHS;
	}
	public String getSSBM() {
		return SSBM;
	}
	public void setSSBM(String sSBM) {
		SSBM = sSBM;
	}
	public int getFID() {
		return FID;
	}
	public void setFID(int fID) {
		FID = fID;
	}
	private String MC;
	private String SJHM;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getMC() {
		return MC;
	}
	public void setMC(String mC) {
		MC = mC;
	}
	public String getSJHM() {
		return SJHM;
	}
	public void setSJHM(String sJHM) {
		SJHM = sJHM;
	}
	public String getBGSHM() {
		return BGSHM;
	}
	public void setBGSHM(String bGSHM) {
		BGSHM = bGSHM;
	}
	public String getFL() {
		return FL;
	}
	public void setFL(String fL) {
		FL = fL;
	}

	
}
