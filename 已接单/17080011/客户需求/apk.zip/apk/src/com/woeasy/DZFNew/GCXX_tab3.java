package com.woeasy.DZFNew;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.woeasy.model.ROWS;

import cn.buaa.adapter.MyAdapter;
import cn.buaa.util.CommonUtil;
import cn.buaa.util.ImageAdapter;
import cn.buaa.util.MyGallery;
import cn.buaa.util.VideoFrameImageLoader;
import cn.buaa.util.WebServiceUtil;
import cn.takephoto.view.PullToRefreshLayout;
import cn.takephoto.view.PullToRefreshLayout.OnRefreshListener;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.RelativeLayout.LayoutParams;

@SuppressLint("HandlerLeak")
public class GCXX_tab3 extends Activity implements OnRefreshListener, OnItemClickListener {
	private DisplayMetrics dm;
	// private ProgressBar xctk_ProgressBar;
	private VideoFrameImageLoader mVideoFrameImageLoader;
	private String json;
	private GridView gridview = null;
	private MyAdapter adapter;
	private PullToRefreshLayout pullToRefreshLayout;
	private ArrayList<String> caches = new ArrayList<String>();
	private List<String> urls = new ArrayList<String>();
	private int p = 0;
	private int pageindex = 0;
	private ROWS gcxx;
	private boolean isLoadMore;
	private Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			// xctk_ProgressBar.setVisibility(View.GONE);
			if (msg.what == 1) {

				if (isLoadMore) {
					pullToRefreshLayout.loadmoreFinish(PullToRefreshLayout.SUCCEED);
				} else {
					pullToRefreshLayout.refreshFinish(PullToRefreshLayout.SUCCEED);
				}

				adapter.notifyDataSetChanged();
			} else if (msg.what == -1) {

				if (isLoadMore) {
					pullToRefreshLayout.loadmoreFinish(PullToRefreshLayout.FAIL);
				} else {
					pullToRefreshLayout.refreshFinish(PullToRefreshLayout.FAIL);
				}

			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xctk);

		gcxx = (ROWS) this.getIntent().getSerializableExtra("ROWS");
		dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		mVideoFrameImageLoader = new VideoFrameImageLoader(this);

		gridview = (GridView) findViewById(R.id.gridView);
		gridview.setOnItemClickListener(this);
		adapter = new MyAdapter(this, urls, mVideoFrameImageLoader, dm.widthPixels);
		gridview.setAdapter(adapter);
		pullToRefreshLayout = (PullToRefreshLayout) findViewById(R.id.refresh_view);
		pullToRefreshLayout.setOnRefreshListener(this);

		getinformation();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		mVideoFrameImageLoader.cancelTask();
	}

	private void getinformation() {
		new Thread() {
			@Override
			public void run() {
				try {
					JSONObject jsonObj;
					JSONArray jsonObjs = null;
					json = WebServiceUtil.everycanforStr2("", "", "", "", "", "pageindex", "", "", "", "", "",
							pageindex, "GetZFTPList");
					json = json.replace("[", "{\"tp\":[");
					json = json.replace("]", "]}");
					Log.d("ͼƬ���ݣ�", json);

					if (json != null && !json.equals("0")) {

						JSONTokener jsonTokener = new JSONTokener(json);
						JSONObject xm = (JSONObject) jsonTokener.nextValue();
						jsonObjs = xm.getJSONArray("tp");
						String ID = "";
						String hz = "";
						String zfnr = "";
						String jdid = "";
						String zfsj = "";
						String zfr = "";
						String tpfile = "";

						for (int k = 0; k < jsonObjs.length(); k++) {
							jsonObj = (JSONObject) jsonObjs.opt(k);
							tpfile = jsonObj.getString("tpfile");

							String url = WebServiceUtil.getURL2() + "FJuploadfiles/" + tpfile;

							urls.add(url);

							if (!url.toLowerCase().endsWith(".mp4")) {
								caches.add(CommonUtil.getRootFilePath() + "com.geniuseoe2012/files/"
										+ String.valueOf(url).hashCode());
							}
						}

						Message message = new Message();
						message.what = 1;
						handler.sendMessage(message);

					}
				} catch (Exception e1) {
					e1.printStackTrace();
					Message message = new Message();
					message.what = -1;
					handler.sendMessage(message);
				}
			}

		}.start();
	}

	private void showPic_hun() {
		LinearLayout layoutz = new LinearLayout(this);
		layoutz.setOrientation(LinearLayout.VERTICAL);
		MyGallery myGallery = new MyGallery(this);
		myGallery.setLayoutParams(new LayoutParams(dm.widthPixels, dm.widthPixels));
		ArrayList<byte[]> tmpDishImages = new ArrayList<byte[]>();

		byte[] a = null;
		tmpDishImages.add(a);
		tmpDishImages.add(a);
		tmpDishImages.add(a);
		tmpDishImages.add(a);
		tmpDishImages.add(a);
		tmpDishImages.add(a);
		ImageAdapter imageAdapter = new ImageAdapter(this, tmpDishImages);
		imageAdapter.createReflectedImages();
		myGallery.setAdapter(imageAdapter);
		layoutz.addView(myGallery);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, 1, 1, "�б���ͼ");
		menu.add(0, 2, 2, "ժҪ��ͼ");
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == 1) {
			return true;
		} else if (item.getItemId() == 2) {
			showPic_hun();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		String url = urls.get(arg2);

		if (url.toLowerCase().endsWith(".mp4")) {
			Intent intent = new Intent(GCXX_tab3.this, VideoActivity.class);
			intent.putExtra("url", url);
			startActivity(intent);
		} else {

			String filename = String.valueOf(url.hashCode());
			String idString = CommonUtil.getRootFilePath() + "com.geniuseoe2012/files/" + filename;

			int position = 0;
			for (int i = 0; i < caches.size(); i++) {
				if (idString.equals(caches.get(i))) {
					position = i;
					break;
				}
			}

			Intent intent = new Intent(GCXX_tab3.this, MultiTouch.class);
			intent.putExtra("id", idString);
			intent.putStringArrayListExtra("list", caches);
			intent.putExtra("position", position);
			startActivity(intent);
		}
	}

	@Override
	public void onRefresh(PullToRefreshLayout pullToRefreshLayout) {
		// TODO Auto-generated method stub
		isLoadMore = false;
		urls.clear();
		adapter.notifyDataSetChanged();
		pageindex = 0;
		getinformation();

	}

	@Override
	public void onLoadMore(PullToRefreshLayout pullToRefreshLayout) {
		// TODO Auto-generated method stub
		isLoadMore = true;
		pageindex++;
		getinformation();

	}

}
