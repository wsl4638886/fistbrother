package com.woeasy.DZFNew;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import cn.buaa.util.FileUtils;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

@SuppressLint({ "Registered", "SdCardPath" })
@TargetApi(Build.VERSION_CODES.GINGERBREAD)
public class CameraActivity2 extends Activity implements SurfaceHolder.Callback{
	private SurfaceView surfaceView1;
	private SurfaceHolder surfaceHolder;
	private TextView timer;
	private Button button1;
	private Button button2;
	private Button button3;
	//private Button button4;
	private MediaRecorder mRecorder;
	private String mVideoFilename;
	private Camera camera;
	private byte[] datecc=null;
	private String path="";
	private Intent intent;
	private boolean Record=true;
	private boolean Recording=false;
	private int hour = 0;
	private int minute = 0;
	private int second = 0;
	private int width;
	private int height;
	
	private boolean change=false;
	
	private Handler handler = new Handler(new Handler.Callback() {
		@Override
		public boolean handleMessage(Message msg) {
			if (msg.what==1) {
				if (change) {
					button1.setBackgroundResource(R.drawable.record1);
					change=false;
				}/*else {
					button1.setBackgroundResource(R.drawable.record2);
					change=true;
				}*/
				
			}
			
			return false;
		}
	});
	private Runnable task = new Runnable() {
		public void run() {
			if (Recording) {
				handler.postDelayed(this, 1000);
				second++;
				if (second >= 60) {
					minute++;
					second = second % 60;
				}
				if (minute >= 60) {
					hour++;
					minute = minute % 60;
				}
				timer.setText(format(hour) + ":" + format(minute) + ":"
						+ format(second));
				if (Integer.parseInt(format(second))>14&&mRecorder!=null) {
					mRecorder.stop();
		        	releaseMediaRecorder();
		        	Recording=false;
		        	hour = 0;
					minute = 0;
					second = 0;
		        	button1.setBackgroundResource(R.drawable.record2);
		        	intent.putExtra("path3",mVideoFilename);
					setResult(RESULT_OK,intent); 
		            finish();
				}
			}
		}
	};
	public String format(int i) {
		String s = i + "";
		if (s.length() == 1) {
			s = "0" + s;
		}
		return s;
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			intent.putExtra("path3",mVideoFilename);
			setResult(RESULT_OK,intent); 
            finish();	
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.camera_take2);
		intent=this.getIntent();
		//Bundle bundle=intent.getExtras();
		//path=bundle.getString("path");
		initView();
		setClick();
	}

	private void setClick() {
		/*button4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				if (Record) {
					Record=false;
					button1.setBackgroundResource(R.drawable.camera);
					
				}else {
					Record=true;
					button1.setBackgroundResource(R.drawable.record2);
				}
			}
		});*/
		
		button1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				if (Record) {
					if (Recording) {
						if (mRecorder != null) {
				        	mRecorder.stop();
				        	releaseMediaRecorder();
				        	Recording=false;
				        	hour = 0;
							minute = 0;
							second = 0;
				        	button1.setBackgroundResource(R.drawable.record2);
				        	intent.putExtra("path3",mVideoFilename);
							setResult(RESULT_OK,intent); 
				            finish();
				        }
					}else {
						mRecorder = new MediaRecorder();
						try {
							camera.unlock();
							mRecorder.setCamera(camera);
						} catch (Exception e) {
							e.printStackTrace();
						}
				        mRecorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
				        mRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);
				        CamcorderProfile mProfile = CamcorderProfile.get(CamcorderProfile.QUALITY_QVGA);
				        mRecorder.setProfile(mProfile);
				        mRecorder.setMaxDuration(1200000);
				        //mRecorder.setVideoSize(width,height);
				        FileUtils.creatSDDir("woyeapp/Video");
				        mVideoFilename=Environment.getExternalStorageDirectory().toString()+"/woyeapp/video" + System.currentTimeMillis() + ".mp4";
				        mRecorder.setOutputFile(mVideoFilename);
				        mRecorder.setVideoSize(640,480);
				        //mRecorder.setVideoSize(1920,1080);
				        //mRecorder.setVideoFrameRate(15);//视频帧数
				        try {
				        	
				        	mRecorder.prepare();
				            timer.setVisibility(View.VISIBLE);
							handler.postDelayed(task, 1000);
				        	
							mRecorder.start();
							Recording=true;
							button1.setBackgroundResource(R.drawable.record1);
							new Thread(){
								@Override
								public void run() {
									while (Recording) {
										try {
											Thread.sleep(1000);
										} catch (Exception e) {
											
										}
										Message message=new Message();
										message.what=1;
										handler.sendMessage(message);
									}
									
									super.run();
								}
				        		
				        	}.start();
						} catch (IllegalStateException e) {
							e.printStackTrace();
							releaseMediaRecorder();
							camera.lock();
						}catch (IOException e) {
				            throw new RuntimeException(e);
				        }
					}
				}else {
					timer.setVisibility(View.GONE);
					camera.autoFocus(mAutoFocusCallback);
					button1.setVisibility(View.GONE);
				}
				
			}
		});
		
		button2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				datecc=null;
				if (camera!=null) {
					camera.startPreview();
					button2.setVisibility(View.GONE);
					button3.setVisibility(View.GONE);
					button1.setVisibility(View.VISIBLE);
				}
			}
		});
		
		button3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FileOutputStream outSteam=null;
				FileOutputStream outSteam2=null;
	            try{
	                outSteam=new FileOutputStream(path);
	                outSteam2=new FileOutputStream(path);
	                outSteam.write(datecc);
	                outSteam2.write(datecc);
	                outSteam.close();
	                outSteam2.close();
	                datecc=null;
	                
	                
	            	}catch(FileNotFoundException e)
		            {
		            	e.printStackTrace();
		            } 	catch (IOException e) {
		                e.printStackTrace();
		            }
	            setResult(RESULT_OK,intent); 
	            finish();
			}
		});
	}
	private void releaseMediaRecorder(){
    	if (mRecorder != null) {
            cleanupEmptyFile();
            mRecorder.reset();
            mRecorder.release();
            mRecorder = null;
        }
    }
	private void cleanupEmptyFile() {
        if (mVideoFilename != null) {
            File f = new File(mVideoFilename);
            if (f.length() == 0 && f.delete()) {
                mVideoFilename = null;
            }
        }
    }
	@SuppressWarnings("deprecation")
	private void initView() {
		surfaceView1=(SurfaceView)findViewById(R.id.camera_take_surfaceView1);
		button1=(Button)findViewById(R.id.camera_take_button1);
		button2=(Button)findViewById(R.id.camera_take_button2);
		button3=(Button)findViewById(R.id.camera_take_button3);
		/*button4=(Button)findViewById(R.id.camera_take_button4);*/
		timer=(TextView)findViewById(R.id.camera_take_timer);
		
		button2.setVisibility(View.GONE);
		button3.setVisibility(View.GONE);
		
		surfaceHolder=surfaceView1.getHolder();
		//surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		surfaceHolder.setKeepScreenOn(true);
        surfaceHolder.setFixedSize(1920,1088); 
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        surfaceHolder.addCallback(this);
	}

	@Override
	public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
		
	}

	@SuppressWarnings("deprecation")
	@Override
	public void surfaceCreated(SurfaceHolder arg0) {
		camera=Camera.open();
		try {
			Camera.Parameters parameters=camera.getParameters();
			parameters.getPictureSize();
			camera.setDisplayOrientation(90);
			parameters.setPictureFormat(PixelFormat.JPEG);
			parameters.setRotation(90);
			//parameters.setPictureSize(1920,1088);
			String a= parameters.get("picture-size-values");
			Log.d("yin",a);
			String []aa=a.split(",");
			width=0;
			height=0;
			for(int i=0;i<aa.length;i++){
				String []bb= aa[i].split("x");
				if (Integer.parseInt(bb[0])>300&&Integer.parseInt(bb[0])<400) {
					if (Integer.parseInt(bb[0])>width) {
						width=Integer.parseInt(bb[0]);
						height=Integer.parseInt(bb[1]);
					}
				}
			}
			if (width==0) {
				String []bb= aa[aa.length-1].split("x");
				width=Integer.parseInt(bb[0]);
				height=Integer.parseInt(bb[1]);
			}
			parameters.setPictureSize(width, height);
			parameters.setPreviewSize(width, height);
			//camera.setParameters(parameters);
			camera.setPreviewDisplay(surfaceHolder);
			camera.startPreview();
		} catch (IOException e) {
			e.printStackTrace();
			camera.release();
			camera=null;
		}
		
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {
		if (camera!=null) {
			camera.stopPreview();
		}
		camera.release();
		camera=null;
	}

	
	AutoFocusCallback mAutoFocusCallback= new AutoFocusCallback(){
		 
		@Override
		public void onAutoFocus(boolean success, Camera camera) {
			if(success){
				camera.takePicture(shutterCallback, null, jpegCallback);
			}else{
			}
		}
	};
	
	 private ShutterCallback shutterCallback = new ShutterCallback()  
	  {  
	    public void onShutter()  
	    {  
	    }  
	  };
	
	 private PictureCallback jpegCallback = new PictureCallback()  
	  { 
	    public void onPictureTaken(byte[] _data, Camera _camera) 
	    { 
	    	datecc=_data;
	    	button2.setVisibility(View.VISIBLE);
	    	button3.setVisibility(View.VISIBLE);
	    	
	    } 
	  };
}
