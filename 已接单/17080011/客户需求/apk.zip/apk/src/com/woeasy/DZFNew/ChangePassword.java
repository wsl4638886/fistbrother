package com.woeasy.DZFNew;



import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ChangePassword extends Activity{

	private RelativeLayout R1,R2,R3;
	private TextView text4;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.changepassword);
		findView();
		setClick();
		setInfo();
		
	}

	private void setInfo() {
		try {
			String app_versionName=this.getPackageManager().getPackageInfo(getResources().getString(R.string.package_name), 0).versionName;
			text4.setText(app_versionName);
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}		
		
		
	}

	
	
	private void setClick() {
		R1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent();
	            intent.setClass(ChangePassword.this,ChangePassword2.class);
	            startActivity(intent);
				
			}
		});
		
		R2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent();
	            intent.setClass(ChangePassword.this,Login.class);
	            startActivity(intent);
	            ChangePassword.this.finish();
	            if(MainActivity2.instance!=null){
	            	MainActivity2.instance.finish();//�ر�Main ���Activity
	        	}
				
			}
		});
		
		R3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent();
	            intent.setClass(ChangePassword.this,ChangePassword3.class);
	            startActivity(intent);
			}
		});
	}

	private void findView() {
		R1=(RelativeLayout)findViewById(R.id.R1);
		R2=(RelativeLayout)findViewById(R.id.R2);
		R3=(RelativeLayout)findViewById(R.id.R3);
		text4=(TextView)findViewById(R.id.text4);
	}

	public void btn_back(View v){
		this.finish();
	}
	
}
