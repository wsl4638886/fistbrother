package com.woeasy.model;

import java.io.Serializable;

public class DZF implements Serializable {
	public String id;
	private String investTotal;
	

	private String proSeq;
	private String proName;
	private String yearND;
	private String yearYF;
	private String yearPlanFundSum;
	private String totalInvestFromBegin;
	private String monthInvest;
	private String lastInvestThisYear;
	private String zjsyLastyearInvestPercent;
	private String finishInvestThisYear;
	private String zjsyThisyearInvestPercent;
	private String buildStep;
	private String approSeq;
	private String preceiptCode;
	private String beginDatestr;
	private String overDate;
	private String deferReason;
	private String proSchedule;
	private String existProblem;
	private String adviseDo;
	private String changeCondition;
	private String proLinkMan;
	private String officeTel;
	private String mobileTel;
	private String qqNumber;
	private String fax;
	private String pmMonthScheduleBase_WFID;
	private String pmMonthScheduleBase_WFInst;
	private String pmMonthScheduleBase_WPID;
	private String pmMonthScheduleBase_Awaiter;
	private String pmMonthScheduleBase_Handler;

	private String SJWSFJ_GRPID;
	private String SJWSFJ_XH;
	private String SJWSFJ_FileName;
	private String SJWSFJ_FileType;
	private String SJWSFJ_FilePath;
	private String SJWSFJ_WHRID;
	private String SJWSFJ_WHR;
	private String SJWSFJ_WHSJ;
	private String SJWSFJ_FullName;
	private String SJWSFJ_WJJ;
	private String SJWSFJ_DID;
	private String SJWSFJ_XID;
	
	private String stime;
	private String etime;

	
	private String headIcon;
	private String reply_id;
	private String create_user;
	private String attach_ids;
	private String attachments;
	private String create_time;
	private String content;
	private String name;
	
	private String name1;
	
	
	
	
	
	
	
	
	public String getName1() {
		return name1;
	}

	public void setName1(String name1) {
		this.name1 = name1;
	}

	public String getHeadIcon() {
		return headIcon;
	}

	public void setHeadIcon(String headIcon) {
		this.headIcon = headIcon;
	}

	public String getReply_id() {
		return reply_id;
	}

	public void setReply_id(String reply_id) {
		this.reply_id = reply_id;
	}

	public String getCreate_user() {
		return create_user;
	}

	public void setCreate_user(String create_user) {
		this.create_user = create_user;
	}

	public String getAttach_ids() {
		return attach_ids;
	}

	public void setAttach_ids(String attach_ids) {
		this.attach_ids = attach_ids;
	}

	public String getAttachments() {
		return attachments;
	}

	public void setAttachments(String attachments) {
		this.attachments = attachments;
	}

	public String getCreate_time() {
		return create_time;
	}

	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInvestTotal() {
		return investTotal;
	}

	public void setInvestTotal(String investTotal) {
		this.investTotal = investTotal;
	}
	
	public String getStime() {
		return stime;
	}

	public void setStime(String stime) {
		this.stime = stime;
	}

	public String getEtime() {
		return etime;
	}

	public void setEtime(String etime) {
		this.etime = etime;
	}

	public String getSJWSFJ_GRPID() {
		return SJWSFJ_GRPID;
	}

	public void setSJWSFJ_GRPID(String sJWSFJ_GRPID) {
		SJWSFJ_GRPID = sJWSFJ_GRPID;
	}

	public String getSJWSFJ_XH() {
		return SJWSFJ_XH;
	}

	public void setSJWSFJ_XH(String sJWSFJ_XH) {
		SJWSFJ_XH = sJWSFJ_XH;
	}

	public String getSJWSFJ_FileName() {
		return SJWSFJ_FileName;
	}

	public void setSJWSFJ_FileName(String sJWSFJ_FileName) {
		SJWSFJ_FileName = sJWSFJ_FileName;
	}

	public String getSJWSFJ_FileType() {
		return SJWSFJ_FileType;
	}

	public void setSJWSFJ_FileType(String sJWSFJ_FileType) {
		SJWSFJ_FileType = sJWSFJ_FileType;
	}

	public String getSJWSFJ_FilePath() {
		return SJWSFJ_FilePath;
	}

	public void setSJWSFJ_FilePath(String sJWSFJ_FilePath) {
		SJWSFJ_FilePath = sJWSFJ_FilePath;
	}

	public String getSJWSFJ_WHRID() {
		return SJWSFJ_WHRID;
	}

	public void setSJWSFJ_WHRID(String sJWSFJ_WHRID) {
		SJWSFJ_WHRID = sJWSFJ_WHRID;
	}

	public String getSJWSFJ_WHR() {
		return SJWSFJ_WHR;
	}

	public void setSJWSFJ_WHR(String sJWSFJ_WHR) {
		SJWSFJ_WHR = sJWSFJ_WHR;
	}

	public String getSJWSFJ_WHSJ() {
		return SJWSFJ_WHSJ;
	}

	public void setSJWSFJ_WHSJ(String sJWSFJ_WHSJ) {
		SJWSFJ_WHSJ = sJWSFJ_WHSJ;
	}

	public String getSJWSFJ_FullName() {
		return SJWSFJ_FullName;
	}

	public void setSJWSFJ_FullName(String sJWSFJ_FullName) {
		SJWSFJ_FullName = sJWSFJ_FullName;
	}

	public String getSJWSFJ_WJJ() {
		return SJWSFJ_WJJ;
	}

	public void setSJWSFJ_WJJ(String sJWSFJ_WJJ) {
		SJWSFJ_WJJ = sJWSFJ_WJJ;
	}

	public String getSJWSFJ_DID() {
		return SJWSFJ_DID;
	}

	public void setSJWSFJ_DID(String sJWSFJ_DID) {
		SJWSFJ_DID = sJWSFJ_DID;
	}

	public String getSJWSFJ_XID() {
		return SJWSFJ_XID;
	}

	public void setSJWSFJ_XID(String sJWSFJ_XID) {
		SJWSFJ_XID = sJWSFJ_XID;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProSeq() {
		return proSeq;
	}

	public void setProSeq(String proSeq) {
		this.proSeq = proSeq;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getYearND() {
		return yearND;
	}

	public void setYearND(String yearND) {
		this.yearND = yearND;
	}

	public String getYearYF() {
		return yearYF;
	}

	public void setYearYF(String yearYF) {
		this.yearYF = yearYF;
	}

	public String getYearPlanFundSum() {
		return yearPlanFundSum;
	}

	public void setYearPlanFundSum(String yearPlanFundSum) {
		this.yearPlanFundSum = yearPlanFundSum;
	}

	public String getTotalInvestFromBegin() {
		return totalInvestFromBegin;
	}

	public void setTotalInvestFromBegin(String totalInvestFromBegin) {
		this.totalInvestFromBegin = totalInvestFromBegin;
	}

	public String getMonthInvest() {
		return monthInvest;
	}

	public void setMonthInvest(String monthInvest) {
		this.monthInvest = monthInvest;
	}

	public String getLastInvestThisYear() {
		return lastInvestThisYear;
	}

	public void setLastInvestThisYear(String lastInvestThisYear) {
		this.lastInvestThisYear = lastInvestThisYear;
	}

	public String getZjsyLastyearInvestPercent() {
		return zjsyLastyearInvestPercent;
	}

	public void setZjsyLastyearInvestPercent(String zjsyLastyearInvestPercent) {
		this.zjsyLastyearInvestPercent = zjsyLastyearInvestPercent;
	}

	public String getFinishInvestThisYear() {
		return finishInvestThisYear;
	}

	public void setFinishInvestThisYear(String finishInvestThisYear) {
		this.finishInvestThisYear = finishInvestThisYear;
	}

	public String getZjsyThisyearInvestPercent() {
		return zjsyThisyearInvestPercent;
	}

	public void setZjsyThisyearInvestPercent(String zjsyThisyearInvestPercent) {
		this.zjsyThisyearInvestPercent = zjsyThisyearInvestPercent;
	}

	public String getBuildStep() {
		return buildStep;
	}

	public void setBuildStep(String buildStep) {
		this.buildStep = buildStep;
	}

	public String getApproSeq() {
		return approSeq;
	}

	public void setApproSeq(String approSeq) {
		this.approSeq = approSeq;
	}

	public String getPreceiptCode() {
		return preceiptCode;
	}

	public void setPreceiptCode(String preceiptCode) {
		this.preceiptCode = preceiptCode;
	}

	public String getBeginDatestr() {
		return beginDatestr;
	}

	public void setBeginDatestr(String beginDatestr) {
		this.beginDatestr = beginDatestr;
	}

	public String getOverDate() {
		return overDate;
	}

	public void setOverDate(String overDate) {
		this.overDate = overDate;
	}

	public String getDeferReason() {
		return deferReason;
	}

	public void setDeferReason(String deferReason) {
		this.deferReason = deferReason;
	}

	public String getProSchedule() {
		return proSchedule;
	}

	public void setProSchedule(String proSchedule) {
		this.proSchedule = proSchedule;
	}

	public String getExistProblem() {
		return existProblem;
	}

	public void setExistProblem(String existProblem) {
		this.existProblem = existProblem;
	}

	public String getAdviseDo() {
		return adviseDo;
	}

	public void setAdviseDo(String adviseDo) {
		this.adviseDo = adviseDo;
	}

	public String getChangeCondition() {
		return changeCondition;
	}

	public void setChangeCondition(String changeCondition) {
		this.changeCondition = changeCondition;
	}

	public String getProLinkMan() {
		return proLinkMan;
	}

	public void setProLinkMan(String proLinkMan) {
		this.proLinkMan = proLinkMan;
	}

	public String getOfficeTel() {
		return officeTel;
	}

	public void setOfficeTel(String officeTel) {
		this.officeTel = officeTel;
	}

	public String getMobileTel() {
		return mobileTel;
	}

	public void setMobileTel(String mobileTel) {
		this.mobileTel = mobileTel;
	}

	public String getQqNumber() {
		return qqNumber;
	}

	public void setQqNumber(String qqNumber) {
		this.qqNumber = qqNumber;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getPmMonthScheduleBase_WFID() {
		return pmMonthScheduleBase_WFID;
	}

	public void setPmMonthScheduleBase_WFID(String pmMonthScheduleBase_WFID) {
		this.pmMonthScheduleBase_WFID = pmMonthScheduleBase_WFID;
	}

	public String getPmMonthScheduleBase_WFInst() {
		return pmMonthScheduleBase_WFInst;
	}

	public void setPmMonthScheduleBase_WFInst(String pmMonthScheduleBase_WFInst) {
		this.pmMonthScheduleBase_WFInst = pmMonthScheduleBase_WFInst;
	}

	public String getPmMonthScheduleBase_WPID() {
		return pmMonthScheduleBase_WPID;
	}

	public void setPmMonthScheduleBase_WPID(String pmMonthScheduleBase_WPID) {
		this.pmMonthScheduleBase_WPID = pmMonthScheduleBase_WPID;
	}

	public String getPmMonthScheduleBase_Awaiter() {
		return pmMonthScheduleBase_Awaiter;
	}

	public void setPmMonthScheduleBase_Awaiter(String pmMonthScheduleBase_Awaiter) {
		this.pmMonthScheduleBase_Awaiter = pmMonthScheduleBase_Awaiter;
	}

	public String getPmMonthScheduleBase_Handler() {
		return pmMonthScheduleBase_Handler;
	}

	public void setPmMonthScheduleBase_Handler(String pmMonthScheduleBase_Handler) {
		this.pmMonthScheduleBase_Handler = pmMonthScheduleBase_Handler;
	}

}
