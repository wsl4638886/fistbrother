package com.woeasy.model;

import java.io.Serializable;

public class ROWS implements Serializable {

	private String prodq;
	private String address;
	private String proName;
	private String locationNumber;
	private String receiptCode;
	private String proDivideOther;
	private String landTotalArea;
	private String BY3;
	private String investTotal;
	private String yearWorkPlan;
	private String proProfessionChild;
	private String BY2;
	private String landNum;
	private String unitName2 ;
	private String beginDate;
	private String imageProcess;
	private String economicBenefit;
	private String background;
	private String JD;
	private String WD;
	private String unitName1;
	private String BuildContent;
	private String yearND;
	private String yearYF;
	private int seq;
	private String proSeq;
	private String cityFund;
	private String  proProfession;
	
	
	
	
	public String getProProfession() {
		return proProfession;
	}
	public void setProProfession(String proProfession) {
		this.proProfession = proProfession;
	}
	public String getCityFund() {
		return cityFund;
	}
	public void setCityFund(String cityFund) {
		this.cityFund = cityFund;
	}
	public String getProSeq() {
		return proSeq;
	}
	public void setProSeq(String proSeq) {
		this.proSeq = proSeq;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getYearND() {
		return yearND;
	}
	public void setYearND(String yearND) {
		this.yearND = yearND;
	}
	public String getYearYF() {
		return yearYF;
	}
	public void setYearYF(String yearYF) {
		this.yearYF = yearYF;
	}
	public String getBuildContent() {
		return BuildContent;
	}
	public void setBuildContent(String buildContent) {
		BuildContent = buildContent;
	}
	public String getUnitName1() {
		return unitName1;
	}
	public void setUnitName1(String unitName1) {
		this.unitName1 = unitName1;
	}
	public String getProdq() {
		return prodq;
	}
	public void setProdq(String prodq) {
		this.prodq = prodq;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public String getLocationNumber() {
		return locationNumber;
	}
	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}
	public String getReceiptCode() {
		return receiptCode;
	}
	public void setReceiptCode(String receiptCode) {
		this.receiptCode = receiptCode;
	}
	public String getProDivideOther() {
		return proDivideOther;
	}
	public void setProDivideOther(String proDivideOther) {
		this.proDivideOther = proDivideOther;
	}
	public String getLandTotalArea() {
		return landTotalArea;
	}
	public void setLandTotalArea(String landTotalArea) {
		this.landTotalArea = landTotalArea;
	}
	public String getBY3() {
		return BY3;
	}
	public void setBY3(String bY3) {
		BY3 = bY3;
	}
	public String getInvestTotal() {
		return investTotal;
	}
	public void setInvestTotal(String investTotal) {
		this.investTotal = investTotal;
	}
	public String getYearWorkPlan() {
		return yearWorkPlan;
	}
	public void setYearWorkPlan(String yearWorkPlan) {
		this.yearWorkPlan = yearWorkPlan;
	}
	public String getProProfessionChild() {
		return proProfessionChild;
	}
	public void setProProfessionChild(String proProfessionChild) {
		this.proProfessionChild = proProfessionChild;
	}
	public String getBY2() {
		return BY2;
	}
	public void setBY2(String bY2) {
		BY2 = bY2;
	}
	public String getLandNum() {
		return landNum;
	}
	public void setLandNum(String landNum) {
		this.landNum = landNum;
	}
	public String getUnitName2() {
		return unitName2;
	}
	public void setUnitName2(String unitName2) {
		this.unitName2 = unitName2;
	}
	public String getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}
	public String getImageProcess() {
		return imageProcess;
	}
	public void setImageProcess(String imageProcess) {
		this.imageProcess = imageProcess;
	}
	public String getEconomicBenefit() {
		return economicBenefit;
	}
	public void setEconomicBenefit(String economicBenefit) {
		this.economicBenefit = economicBenefit;
	}
	public String getBackground() {
		return background;
	}
	public void setBackground(String background) {
		this.background = background;
	}
	public String getJD() {
		return JD;
	}
	public void setJD(String jD) {
		JD = jD;
	}
	public String getWD() {
		return WD;
	}
	public void setWD(String wD) {
		WD = wD;
	}

	
	
}
