package com.woeasy.model;

import java.io.Serializable;

public class MyBean implements Serializable {
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAvator() {
		return avator;
	}
	public void setAvator(String avator) {
		this.avator = avator;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String[] getUrls() {
		return urls;
	}
	public void setUrls(String[] urls) {
		this.urls = urls;
	}
	public int id;
	public String avator;
	public String name;
	public String content;
	public String time;
	public String[] urls;
	public int iZLID;
    public String sGCMC;
    public String sZLBH;
    public String sZLMC;
   
    public String sZLZT;
    public String sDCLR;
    public String dMaxSJ;
    public String dMinSJ;
    public String sJSDW;
    public String sXMJL;
    public String sSGDW;
    public String sZJLGCS;
    public String sJLDW;
    public String sJDY;
    public String sWPID;
    public int sFJS;
    public String sWFInst;
    public String sWFID;
    public String WJM;
    public String sWHR;
    public String sWHRTX;
    public String step;
	public String m_GetLog;
	public String iMBID;
    
    public String getiMBID() {
		return iMBID;
	}
	public void setiMBID(String iMBID) {
		this.iMBID = iMBID;
	}
	public String getWorkFlowInfoList() {
		return WorkFlowInfoList;
	}
	public void setWorkFlowInfoList(String workFlowInfoList) {
		WorkFlowInfoList = workFlowInfoList;
	}
	public String WorkFlowInfoList;
    
	public int getiZLID() {
		return iZLID;
	}
	public void setiZLID(int iZLID) {
		this.iZLID = iZLID;
	}
	public String getsGCMC() {
		return sGCMC;
	}
	public void setsGCMC(String sGCMC) {
		this.sGCMC = sGCMC;
	}
	public String getsZLBH() {
		return sZLBH;
	}
	public void setsZLBH(String sZLBH) {
		this.sZLBH = sZLBH;
	}
	public String getsZLMC() {
		return sZLMC;
	}
	public void setsZLMC(String sZLMC) {
		this.sZLMC = sZLMC;
	}
	public String getsZLZT() {
		return sZLZT;
	}
	public void setsZLZT(String sZLZT) {
		this.sZLZT = sZLZT;
	}
	public String getsDCLR() {
		return sDCLR;
	}
	public void setsDCLR(String sDCLR) {
		this.sDCLR = sDCLR;
	}
	public String getdMaxSJ() {
		return dMaxSJ;
	}
	public void setdMaxSJ(String dMaxSJ) {
		this.dMaxSJ = dMaxSJ;
	}
	public String getdMinSJ() {
		return dMinSJ;
	}
	public void setdMinSJ(String dMinSJ) {
		this.dMinSJ = dMinSJ;
	}
	public String getsJSDW() {
		return sJSDW;
	}
	public void setsJSDW(String sJSDW) {
		this.sJSDW = sJSDW;
	}
	public String getsXMJL() {
		return sXMJL;
	}
	public void setsXMJL(String sXMJL) {
		this.sXMJL = sXMJL;
	}
	public String getsSGDW() {
		return sSGDW;
	}
	public void setsSGDW(String sSGDW) {
		this.sSGDW = sSGDW;
	}
	public String getsZJLGCS() {
		return sZJLGCS;
	}
	public void setsZJLGCS(String sZJLGCS) {
		this.sZJLGCS = sZJLGCS;
	}
	public String getsJLDW() {
		return sJLDW;
	}
	public void setsJLDW(String sJLDW) {
		this.sJLDW = sJLDW;
	}
	public String getsJDY() {
		return sJDY;
	}
	public void setsJDY(String sJDY) {
		this.sJDY = sJDY;
	}
	public String getsWPID() {
		return sWPID;
	}
	public void setsWPID(String sWPID) {
		this.sWPID = sWPID;
	}
	public int getsFJS() {
		return sFJS;
	}
	public void setsFJS(int sFJS) {
		this.sFJS = sFJS;
	}
	public String getsWFInst() {
		return sWFInst;
	}
	public void setsWFInst(String sWFInst) {
		this.sWFInst = sWFInst;
	}
	public String getsWFID() {
		return sWFID;
	}
	public void setsWFID(String sWFID) {
		this.sWFID = sWFID;
	}
	public String getWJM() {
		return WJM;
	}
	public void setWJM(String wJM) {
		WJM = wJM;
	}
	public String getsWHR() {
		return sWHR;
	}
	public void setsWHR(String sWHR) {
		this.sWHR = sWHR;
	}
	public String getsWHRTX() {
		return sWHRTX;
	}
	public void setsWHRTX(String sWHRTX) {
		this.sWHRTX = sWHRTX;
	}
	public String getStep() {
		return step;
	}
	public void setStep(String step) {
		this.step = step;
	}
	public String getM_GetLog() {
		return m_GetLog;
	}
	public void setM_GetLog(String m_GetLog) {
		this.m_GetLog = m_GetLog;
	}
}
