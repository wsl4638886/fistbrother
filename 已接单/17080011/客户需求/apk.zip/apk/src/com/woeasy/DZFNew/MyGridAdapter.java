package com.woeasy.DZFNew;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.ThumbnailUtils;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import cn.buaa.util.PicUtils;

import com.nostra13.universalimageloader.core.ImageLoader;

public class MyGridAdapter extends BaseAdapter {
	private String[] files;
	private Context context;
	private LayoutInflater mLayoutInflater;

	public MyGridAdapter(String[] files, Context context) {
		this.files = files;
		mLayoutInflater = LayoutInflater.from(context);
		this.context=context;
	}

	@Override
	public int getCount() {
		int cou=files.length;
		if(cou>6){cou=6;}
		return files == null ? 0 : cou;
	}

	@Override
	public String getItem(int position) {
		return files[position];
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		MyGridViewHolder viewHolder;
		if (convertView == null) {
			viewHolder = new MyGridViewHolder();
			convertView = mLayoutInflater.inflate(R.layout.gridview_item,
					parent, false);
			viewHolder.imageView = (ImageView) convertView
					.findViewById(R.id.album_image);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (MyGridViewHolder) convertView.getTag();
		}
		String url = getItem(position);

		
		if(url.contains(".mp4")){
			url=url.replace("file://", "");
			System.out.println("daye:"+url);
			Bitmap photo = BitmapFactory.decodeResource(context.getResources(), R.drawable.play);
			System.out.println("daaaa:"+photo);
			viewHolder.imageView.setImageBitmap(PicUtils.createBitmap(getVideoThumbnail(url,250,250,MediaStore.Images.Thumbnails.MICRO_KIND), photo));
			viewHolder.imageView.setImageResource( R.drawable.sp);
		}else{
			ImageLoader.getInstance().displayImage(url, viewHolder.imageView);
			
		}
		

		return convertView;
	}



	private Bitmap getVideoThumbnail(String videoPath, int width, int height, int kind) {  
       	Bitmap bitmap = null;  
        bitmap = ThumbnailUtils.createVideoThumbnail(videoPath, kind);  
        bitmap = ThumbnailUtils.extractThumbnail(bitmap, width, height,ThumbnailUtils.OPTIONS_RECYCLE_INPUT);  
        return bitmap;  
	} 
	
	private static class MyGridViewHolder {
		ImageView imageView;
	}
}
