package com.woeasy.DZFNew;

import cn.buaa.util.WebServiceUtil;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.RelativeLayout;

@SuppressLint({ "HandlerLeak", "WorldReadableFiles", "WorldWriteableFiles" })
public class ChangePassword2 extends Activity{

	private RelativeLayout R2;
	private EditText E1,E2,E3;
	private String spname,spword,json;
	private boolean iswebbing=false;
	
	private Handler handler=new Handler(){

		@SuppressWarnings("deprecation")
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			
			if (msg.what==1) {
				iswebbing=false;
				if (json.equals("0")||json==null) {
					new AlertDialog.Builder(ChangePassword2.this)
					.setTitle("�����޸�ʧ�ܣ�").setPositiveButton("ȷ��", null)
					.create().show();
				}else {
					SharedPreferences sharedPreferences=getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE+Context.MODE_WORLD_WRITEABLE);
					SharedPreferences.Editor editor=sharedPreferences.edit();
					editor.putString("spword", spword);
					editor.commit();
					
					new AlertDialog.Builder(ChangePassword2.this)
					.setTitle("�����޸ĳɹ���").setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface arg0, int arg1) {
								finish();
							}
						})
					.create().show();
				}
			}
			
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.changepassword2);
		findView();
		setClick();
		setInfo();
		
	}

	private void setInfo() {
		
		
	}

	
	
	private void setClick() {
		
		R2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				if(!E1.getText().toString().equals("")&&!E2.getText().toString().equals("")&&!E3.getText().toString().equals("")){
					if(E1.getText().toString().equals(E2.getText().toString())){
						
						if(E3.getText().toString().equals(spword)){
							if (!iswebbing) {
								iswebbing=true;
							
								new Thread(){
									@Override
									public void run() {
										json=WebServiceUtil.everycanforStr4("sUserID","sOldPWD","sNewPWD", "", "", "", spname, spword,E2.getText().toString(), 0, 0, 0,"ChangePWD");
										Log.d("yin","ChangePWD��"+json);
										Message message=new Message();
							    		message.what=1;
							    		handler.sendMessage(message);
										
									}
								}.start();
							}
						}else{
							new AlertDialog.Builder(ChangePassword2.this)
							.setTitle("�����ԭ���벻��ȷ��").setPositiveButton("ȷ��", null)
							.create().show();
						}
						
						
					}else{
						new AlertDialog.Builder(ChangePassword2.this)
						.setTitle("������������벻һ����").setPositiveButton("ȷ��", null)
						.create().show();
					}
					
				}else{
					new AlertDialog.Builder(ChangePassword2.this)
					.setTitle("ԭ����������벻��Ϊ�գ�").setPositiveButton("ȷ��", null)
					.create().show();
				}
				
				
				
				
			}
		});
	}

	@SuppressWarnings("deprecation")
	private void findView() {
		E1=(EditText)findViewById(R.id.E1);
		E2=(EditText)findViewById(R.id.E2);
		E3=(EditText)findViewById(R.id.E3);
		R2=(RelativeLayout)findViewById(R.id.R2);
		
		spname=getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE+Context.MODE_WORLD_WRITEABLE).getString("spname","");
		spword=getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE+Context.MODE_WORLD_WRITEABLE).getString("spword","");
	}

	public void btn_back(View v){
		this.finish();
	}
	
}
