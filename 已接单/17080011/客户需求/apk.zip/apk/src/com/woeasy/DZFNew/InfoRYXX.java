package com.woeasy.DZFNew;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;
import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.LocationSource;
import com.amap.api.maps.model.Marker;
import com.amap.api.services.core.LatLonPoint;
import com.amap.api.services.geocoder.GeocodeResult;
import com.amap.api.services.geocoder.GeocodeSearch.OnGeocodeSearchListener;
import com.amap.api.services.geocoder.RegeocodeResult;
import com.woeasy.model.ROWS;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.buaa.util.NetHelper;
import cn.buaa.util.WebServiceUtil;

public class InfoRYXX extends Activity implements AMapLocationListener, LocationSource ,OnGeocodeSearchListener{
	private TextView info_text1,info_text2,info_text3,info_text4,info_text5,info_text6,info_text7,info_text8,info_text9,
	info_text10,info_text11,info_text12,info_text13,info_text14,info_text15,info_text16,info_text17,info_text18,
	info_text19,info_text20,info_text21,info_text22,info_text23;
	private ROWS email;
	private Button zfxx;
	private String json;
	private boolean iswebbing = false;
	private boolean hasup = false;
	private OnLocationChangedListener mListener;
	private double geoLat;
	private double geoLng;
	private int id;
	private Button b1,b2,b3;
	private String JD,WD;
	private int f=1;
	 private AMapLocationClient mLocationClient = null;
	private AMap aMap = null;
	private String addressName;
	private Marker regeoMarker;
	private LatLonPoint latLonPoint;
	private String wz;
	private int flag=0,flag1=1;
	private LinearLayout info_tab1;
	private LinearLayout info_tab2;
	private LinearLayout info_tab3;
	private LinearLayout info_tab4;
	private Button bt2;
	private Button bj;
	private ProgressDialog progressDialog;
	public static InfoRYXX listact;
	
	public AMapLocationClientOption mLocationOption = null;
	private Handler handler = new Handler(){
		  public void handleMessage(Message msg){
		      super.handleMessage(msg);
		      if (msg.what == 1) {
					progressDialog.dismiss();
					if(json!=null&&json.equals("1")){
						if (RY_list.listact != null) {
							RY_list.listact.onRefresh();
							finish();
						}
						
						
					}
				}else  if(msg.what == 2){
		    	  Toast.makeText(InfoRYXX.this, "����ɹ�", 3000).show();
		    	  info_text21.setText("0");
		    	  info_text22.setText("0");
					b2.setText("���µ���λ��");
					f=1;
					
				}else if(msg.what ==3){
					info_text21.setText(JD);
					info_text22.setText(WD);
				Toast.makeText(InfoRYXX.this, "���³ɹ�", 3000).show();
					b2.setText("�������λ��");
					f=0;
					
				}
		  }
	  };
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.inforyxx);
		
		findview();
	//	initLocal();
	}

public void findview(){
	 
	 zfxx=(Button) findViewById(R.id.zf);
	 Intent intent = this.getIntent(); 
	  email=(ROWS) intent.getSerializableExtra("ROWS");
	  id=email.getSeq();
	  String  sr=email.getCityFund();
	System.out.print("cesssssss"+sr);
	bj=(Button) findViewById(R.id.bj);
	bj.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(InfoRYXX.this, RY_BJ.class);
			Bundle bundle = new Bundle();
			bundle.putSerializable("ROWS", email);
			intent.putExtras(bundle);
			startActivity(intent);
			finish();
		}
	});
	
	 b2=(Button) findViewById(R.id.button1);	 
	 bt2=(Button)findViewById(R.id.bt2);
	 b2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				//Toast.makeText(getActivity(), wz, Toast.LENGTH_SHORT).show();
				
				if(f==0){
				boolean havenet = NetHelper.IsHaveInternet(InfoRYXX.this);
				if (havenet) {
					new Thread() {
						@Override
						public void run() {						
							json = WebServiceUtil.everycanforStr2("jd", "wd", "", "", "", "id", "0.0000", "0.0000", "", "", "", email.getSeq(), "UpdateXMJWD");
							Log.d("���λ��", json);
							if (json!=null) {
								Message msg = new Message();
								msg.what = 2;
								handler.sendMessage(msg);
							}
						}
					}.start();

				} else {
					new AlertDialog.Builder(InfoRYXX.this)
							.setMessage("���������������ã�")
							.setTitle("����������")
							.setPositiveButton("ȷ��",
									new DialogInterface.OnClickListener() {
										@Override
										public void onClick(DialogInterface dialog,
												int which) {
										}
									}).show();
				}
				
			   }else if(f==1){
				   boolean havenet = NetHelper.IsHaveInternet(InfoRYXX.this);
				   
					if (havenet) {
						new Thread() {
							@Override
						public void run() {						
							json = WebServiceUtil.everycanforStr2("jd", "wd","", "", "","id",JD,WD, "","", "", email.getSeq(),"UpdateXMJWD");
							Log.d("�ϴ�λ��", json);
							if (json!=null) {
							Message msg = new Message();
							msg.what = 3;
							handler.sendMessage(msg);
								}

							}
						}.start();

					} else {
						new AlertDialog.Builder(InfoRYXX.this)
						.setMessage("���������������ã�")
						.setTitle("����������")
						.setPositiveButton("ȷ��",
						new DialogInterface.OnClickListener() {
											@Override
						public void onClick(DialogInterface dialog,
								int which) {
						}
					}).show();
					}
					
				   }
			 }
		});
	 
	 
		bt2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				
				new AlertDialog.Builder(InfoRYXX.this).setMessage("ȷ��ɾ���˾�����Ϣ��")
				.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface arg0, int arg1) {}})
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {						
					@Override
					public void onClick(DialogInterface dialog, int which) {
						progressDialog=ProgressDialog.show(InfoRYXX.this,"����ɾ��������","���Ե�...");
						new Thread(new Runnable() {
							@Override
							public void run() {
								
								json = WebServiceUtil.everycanforStr("","","","id","","","", id,"deleteJMXX");
								Message message = new Message();
								message.what = 1;
								handler.sendMessage(message);
						        
							}
						}).start();
					}

				 }).show();
				
				
			}
		});
	 
		 
			info_text1=(TextView) findViewById(R.id.info_text1);
			info_text2=(TextView) findViewById(R.id.info_text2);
			info_text3=(TextView) findViewById(R.id.info_text3);
			info_text4=(TextView) findViewById(R.id.info_text4);
			info_text5=(TextView) findViewById(R.id.info_text5);
			info_text6=(TextView) findViewById(R.id.info_text6);
			info_text7=(TextView) findViewById(R.id.info_text7);
			info_text8=(TextView) findViewById(R.id.info_text8);
			info_text9=(TextView) findViewById(R.id.info_text9);
			info_text10=(TextView) findViewById(R.id.info_text10);
			info_text11=(TextView) findViewById(R.id.info_text11);
			info_text12=(TextView) findViewById(R.id.info_text12);
			info_text13=(TextView) findViewById(R.id.info_text13);
			info_text14=(TextView) findViewById(R.id.info_text14);
			info_text15=(TextView) findViewById(R.id.info_text15);
			info_text16=(TextView) findViewById(R.id.info_text16);
			info_text17=(TextView) findViewById(R.id.info_text17);
			info_text18=(TextView) findViewById(R.id.info_text18);
			info_text19=(TextView) findViewById(R.id.info_text19);
			info_text20=(TextView) findViewById(R.id.info_text20);
			info_text21=(TextView) findViewById(R.id.info_text21);
			info_text22=(TextView) findViewById(R.id.info_text22);
			info_text23=(TextView) findViewById(R.id.info_text23);
			info_tab1 =(LinearLayout)findViewById(R.id.info_tab1);
		    info_tab2 =(LinearLayout)findViewById(R.id.info_tab2);
		    info_tab3 =(LinearLayout)findViewById(R.id.info_tab3);
				
		    info_tab1.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View arg0) {
						Intent intent = new Intent();
						intent.setClass(InfoRYXX.this, ZFXX_list.class);
						Bundle bundle = new Bundle();
						bundle.putSerializable("ROWS", email);
						intent.putExtras(bundle);
						startActivity(intent);
						
					}
			   });
		    info_tab2.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					Intent intent = new Intent();
					intent.setClass(InfoRYXX.this, ZFTP.class);
					Bundle bundle = new Bundle();
					bundle.putSerializable("ROWS", email);
					intent.putExtras(bundle);
					startActivity(intent);
					
				}
		   });
			 
			  info_text1.setText(email.getProdq());
			  info_text2.setText(email.getAddress());
			  info_text3.setText(email.getProName());
			  info_text4.setText(email.getLocationNumber());
			  info_text5.setText(email.getUnitName1());
			  info_text6.setText(email.getReceiptCode()); 
			  info_text7.setText(email.getProDivideOther());  
			  info_text8.setText(email.getLandTotalArea());
			  info_text9.setText(email.getCityFund()+"��Ԫ");
			  info_text10.setText(email.getInvestTotal()+"��Ԫ");  
			  info_text11.setText(email.getYearWorkPlan());
			  info_text12.setText(email.getBuildContent());  
			  info_text13.setText(email.getProProfessionChild());  
			  info_text14.setText(email.getBY2());  
			  info_text15.setText(email.getLandNum());  
			  info_text16.setText(email.getUnitName2 ());  
			  info_text17.setText(email.getBeginDate());  
			  info_text18.setText(email.getImageProcess());  
			  info_text19.setText(email.getEconomicBenefit());  
			  info_text20.setText(email.getBackground());  
			  info_text21.setText(email.getJD());  
			  info_text22.setText(email.getWD());  
			  info_text23.setText(email.getProProfession());  
			      
			 id=email.getSeq();
			 /**
			  * �½�
			  */
			zfxx.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Intent intent = new Intent();
					intent.setClass(InfoRYXX.this, ZFXX_XJ.class);
					Bundle bundle = new Bundle();
					bundle.putSerializable("ROWS", email);
					intent.putExtras(bundle);
					startActivity(intent);
					
				}
			});
	}

















		@Override
		public void onGeocodeSearched(GeocodeResult arg0, int arg1) {
			// TODO Auto-generated method stub
		}
		@Override
		public void onRegeocodeSearched(RegeocodeResult result, int rCode) {
			if (rCode == 1000) {
				if (result != null && result.getRegeocodeAddress() != null
					&& result.getRegeocodeAddress().getFormatAddress() != null) {
					addressName = result.getRegeocodeAddress().getFormatAddress()+ "����";
			/*		aMap.animateCamera(CameraUpdateFactory.newLatLngZoom(AMapUtil.convertToLatLng(latLonPoint), 15));
					regeoMarker.setPosition(AMapUtil.convertToLatLng(latLonPoint));*/
				//	ToastUtil.show(getActivity(), addressName);
					//location.setText(addressName);
					
				} else {
				//	ToastUtil.show(getActivity(), "�Բ���û��������������ݣ�");
				}
			} else {
				//ToastUtil.showerror(getActivity(), rCode);
			}
			
		}
		
		private void initLocal() {
			 //��ʼ����λ
	       mLocationClient = new AMapLocationClient(InfoRYXX.this);
	       //���ö�λ�ص�����
	       mLocationClient.setLocationListener(this);
	       //��ʼ����λ����
	       mLocationOption = new AMapLocationClientOption();
	       //���ö�λģʽΪHight_Accuracy�߾���ģʽ��Battery_SavingΪ�͹���ģʽ��Device_Sensors�ǽ��豸ģʽ
	       mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);
	       //�����Ƿ񷵻ص�ַ��Ϣ��Ĭ�Ϸ��ص�ַ��Ϣ��
	       mLocationOption.setNeedAddress(true);
	       //�����Ƿ�ֻ��λһ��,Ĭ��Ϊfalse
	       mLocationOption.setOnceLocation(false);//����Ϊ��ζ�λ
	       //�����Ƿ�ǿ��ˢ��WIFI��Ĭ��Ϊǿ��ˢ��
	       mLocationOption.setWifiActiveScan(true);
	       //�����Ƿ�����ģ��λ��,Ĭ��Ϊfalse��������ģ��λ��
	       mLocationOption.setMockEnable(false);
	       //���ö�λ���,��λ����,Ĭ��Ϊ2000ms
	       mLocationOption.setInterval(2000);
	       //����λ�ͻ��˶������ö�λ����
	       mLocationClient.setLocationOption(mLocationOption);
	       //������λ
	       mLocationClient.startLocation();		
		}
		@Override
		public void activate(OnLocationChangedListener arg0) {
			// TODO Auto-generated method stub
		}
		@Override
		public void deactivate() {
			// TODO Auto-generated method stub
		}
		@Override
		public void onLocationChanged(AMapLocation aMapLocation) {
			 if (aMapLocation != null) {
		            if (aMapLocation.getErrorCode() == 0) {
		                //��λ�ɹ��ص���Ϣ�����������Ϣ
		                aMapLocation.getLocationType();//��ȡ��ǰ��λ�����Դ�������綨λ���������ٷ���λ���ͱ�
		                JD=String.valueOf(aMapLocation.getLongitude());//��ȡ����
		                WD=String.valueOf(aMapLocation.getLatitude());//��ȡγ��
		                aMapLocation.getAccuracy();//��ȡ������Ϣ
		                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		                Date date = new Date(aMapLocation.getTime());
		                df.format(date);//��λʱ��
		                aMapLocation.getAddress();//��ַ�����option������isNeedAddressΪfalse����û�д˽�������綨λ����л��е�ַ��Ϣ��GPS��λ�����ص�ַ��Ϣ��
		                aMapLocation.getCountry();//������Ϣ
		                aMapLocation.getProvince();//ʡ��Ϣ
		                aMapLocation.getCity();//������Ϣ
		                aMapLocation.getDistrict();//������Ϣ
		                aMapLocation.getStreet();//�ֵ���Ϣ
		                aMapLocation.getStreetNum();//�ֵ����ƺ���Ϣ
		                wz=aMapLocation.getProvince()+aMapLocation.getCity()+aMapLocation.getDistrict()+aMapLocation.getStreet()+aMapLocation.getStreetNum();
		                aMapLocation.getCityCode();//���б���
		                aMapLocation.getAdCode();//��������
		                if(flag==0){
		    				flag=1;
		    				//Toast.makeText(getActivity(), "��λ�ɹ�", Toast.LENGTH_SHORT).show();
		    				}
		            } else {
		                //��ʾ������ϢErrCode�Ǵ����룬errInfo�Ǵ�����Ϣ��������������
		                Log.e("AmapError", "location Error, ErrCode:"
		                        + aMapLocation.getErrorCode() + ", errInfo:"
		                        + aMapLocation.getErrorInfo());
		               // Toast.makeText(getApplicationContext(), "��λʧ��", Toast.LENGTH_LONG).show();
		            }
		        }
			
		}
			
		
		
				
		
		}
