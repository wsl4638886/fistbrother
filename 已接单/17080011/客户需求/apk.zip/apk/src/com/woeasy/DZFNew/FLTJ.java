package com.woeasy.DZFNew;



import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebSettings.ZoomDensity;

public class FLTJ extends Activity {
	private WebView webview; 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fltj);
		webview = (WebView) findViewById(R.id.webview);
		webview.getSettings().setJavaScriptEnabled(true);//����js 
		webview.getSettings().setBlockNetworkImage(false);//���ͼƬ����ʾ 
		webview.getSettings().setDefaultTextEncodingName("utf-8");		
		webview.getSettings().setBuiltInZoomControls(true);
		webview.getSettings().setSupportZoom(true);
		webview.getSettings().setDefaultZoom(ZoomDensity.CLOSE);
		webview.getSettings().setUseWideViewPort(true);
		webview.getSettings().setLoadWithOverviewMode(true);
		webview.getSettings().setJavaScriptEnabled(true);
		webview.loadUrl("file:///android_asset/ZlglInfo_pic.htm");
		webview.setInitialScale(45);

		webview.getSettings().setLayoutAlgorithm(LayoutAlgorithm.NARROW_COLUMNS);
		webview.setWebViewClient(new WebViewClient(){
		    @Override
		    public boolean shouldOverrideUrlLoading(WebView view, String url) {
		        view.loadUrl(url);
		        return true;
		        }
		});
		webview.loadUrl("http://218.92.212.198:4888/Framework/ZDXM/YYXMFX");
	}


}
