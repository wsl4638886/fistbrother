package com.woeasy.model;

import java.io.Serializable;

public class WPbean implements Serializable {
    public String WPID;
    public String getIsCountersign() {
		return IsCountersign;
	}
	public void setIsCountersign(String isCountersign) {
		IsCountersign = isCountersign;
	}
	public String IsCountersign;
    public String getWPID() {
		return WPID;
	}
	public void setWPID(String wPID) {
		WPID = wPID;
	}
	public String getWPName() {
		return WPName;
	}
	public void setWPName(String wPName) {
		WPName = wPName;
	}
	public String WPName;
	
	public String WPMRSPR;
	public String WPMRSP;
	public String getWPMRSPR() {
		return WPMRSPR;
	}
	public void setWPMRSPR(String wPMRSPR) {
		WPMRSPR = wPMRSPR;
	}
	public String getWPMRSP() {
		return WPMRSP;
	}
	public void setWPMRSP(String wPMRSP) {
		WPMRSP = wPMRSP;
	}
}
