package com.woeasy.DZFNew;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyStore.PrivateKeyEntry;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.pgyersdk.javabean.AppBean;
import com.pgyersdk.update.PgyUpdateManager;
import com.pgyersdk.update.UpdateManagerListener;

import cn.buaa.util.NetHelper;
import cn.buaa.util.WebServiceUtil;
import cn.jpush.android.api.JPushInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint({ "WorldWriteableFiles", "WorldReadableFiles", "HandlerLeak" })
public class Login extends Activity {
	private EditText mUser; // �ʺű༭��
	private EditText mPassword; // ����༭��
	private TextView main_verInfo;
	private RelativeLayout Login_R;
	private String spname;
	private String spword;
	private SharedPreferences sharedPreferences;
	private String json;
	private Message message;
	private ProgressDialog progressDialog;
	private int app_versionCode=-1;
	private String app_versionName = "";
	private String remark;
	private File file01;
	private CheckBox login_check;
	private String uxm,udw,uxb,usr,udh,uzw,usfz,udwdz,ubmid;
	private  String role;
	private boolean actclose=false;
	
	private Button youk;
	private Handler handler=new Handler(){

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			
			if (msg.what==1) {
				progressDialog.dismiss();
				
				if (json.equals("0")||json==null) {
					new AlertDialog.Builder(Login.this)
					.setIcon(getResources().getDrawable(R.drawable.login_error_icon))
					.setTitle("��¼ʧ��")
					.setMessage("�ʺŻ������벻��ȷ\n������������룡")
					.create().show();
				}else if (role.equals("1")) {
					saveSharedPreferences();					
					Intent intent = new Intent();
		            intent.setClass(Login.this,MainActivity2.class);
		            startActivity(intent);
		            actclose=true;
		            finish();
				}else {
					saveSharedPreferences();
					Intent intent = new Intent();
		            intent.setClass(Login.this,MainActivity3.class);
		            startActivity(intent);
		            Toast.makeText(getApplicationContext(), "��¼�ɹ�", Toast.LENGTH_SHORT).show();
		            JPushInterface.setAliasAndTags(getApplicationContext(),spname,null,null);
		            finish();
		            
		            
		            //startActivity(new Intent(Login.this, GPSNaviActivity.class));
		            
				}
			}else if (msg.what==2) {
				remark=remark.replaceAll("&","\n");
				new AlertDialog.Builder(Login.this).setMessage(remark).setTitle("�����°汾")
				.setNegativeButton("ȡ��",new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {}})
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {						
					@Override
					public void onClick(DialogInterface dialog, int which) {
						progressDialog=ProgressDialog.show(Login.this,"���������°汾","���Ե�...");
						new Thread(){
							@Override
							public void run() {
								try {
					    			file01=getFileFromServer(getResources().getString(R.string.apk_url));
					    		} catch (Exception e) {
					    			e.printStackTrace();
					    		}
								message=new Message();
						    	message.what=3;
						    	handler.sendMessage(message);
							}
						}.start();
						}
				}).show();
				
			}else if (msg.what==3) {
				progressDialog.dismiss();
				if (file01!=null) {
    				Intent intent = new Intent();    
    		        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);    
    		        intent.setAction(android.content.Intent.ACTION_VIEW);    
    		        Uri uri = Uri.fromFile(file01);  
    		        intent.setDataAndType(uri,"application/vnd.android.package-archive"); 
    		        startActivity(intent);
				}
			}
			
			
			
		}
	};
	
	@Override
	protected void onStart() {
		super.onStart();
		loadSharedPreferences();
	}
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        
        getVerInfo();
        findView();
		checkUpdate();
	//	setInfo();
        setClick();
        makedir();
        
    }

    private void makedir() {
		File dir = new File(Environment.getExternalStorageDirectory()+"/"+"woyeapp/firstshow1"); 
        if (!dir.exists()) {
        	dir.mkdirs();
        }
	}
    
    private void setInfo() {
    	main_verInfo.setText(app_versionName);
	}

	private void setClick() {
        Login_R.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE); 
				imm.hideSoftInputFromWindow(mUser.getWindowToken(), 0); 
				return false;
			}
		});
        
        Login_R.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE); 
				imm.hideSoftInputFromWindow(mUser.getWindowToken(), 0); 
				return false;
			}
		});
	}

	private void findView() {
    	 mUser = (EditText)findViewById(R.id.login_user_edit);
         mPassword = (EditText)findViewById(R.id.login_passwd_edit);
         Login_R = (RelativeLayout)findViewById(R.id.Login_R);
         login_check=(CheckBox)findViewById(R.id.login_check);
         main_verInfo=(TextView)findViewById(R.id.main_verInfo);
         login_check.setChecked(true);
         youk=(Button) findViewById(R.id.youk);
       /*  youk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent intent=new Intent();
				intent.setClass(Login.this, YOUKE.class);//RY_list
				startActivity(intent);
				
			}
		});*/
	}

	public File getFileFromServer(String path) throws Exception{                 
		if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){  
			URL url = new URL(path);                        
			HttpURLConnection conn = (HttpURLConnection) url.openConnection(); 
			if (conn.getResponseCode() == 200) {                                 
				InputStream is = conn.getInputStream();                                 
				File file = new File(Environment.getExternalStorageDirectory(), getResources().getString(R.string.apk_Location)); 
				FileOutputStream fos = new FileOutputStream(file);               
				BufferedInputStream bis = new BufferedInputStream(is);       
				byte[] buffer = new byte[1024];                             
				int len;                                
				while((len =bis.read(buffer))!=-1){                         
					fos.write(buffer, 0, len);                           
					}                               
				fos.close();                                 
				bis.close();                                 
				is.close();                                
				return file;                        
				}else{                                 
					return null;                       
				}                 
			}                 
		else{                        
			return null;                
			}        
		}
    
    private void getVerInfo(){
		try {
			app_versionCode=this.getPackageManager().getPackageInfo(getResources().getString(R.string.package_name), 0).versionCode;
			app_versionName=this.getPackageManager().getPackageInfo(getResources().getString(R.string.package_name), 0).versionName;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
	}
    
    private void checkUpdate(){
    	PgyUpdateManager.register(Login.this,
    			   new UpdateManagerListener() {

    			      @Override
    			      public void onUpdateAvailable(final String result) {

    			        // ���°汾��Ϣ��װ��AppBean��
    			        final AppBean appBean = getAppBeanFromString(result);
    			        new AlertDialog.Builder(Login.this)
    			            .setTitle("�����°汾")
    			            .setMessage(appBean.getReleaseNote())
    			            .setNegativeButton(
    			                    "ȷ��",
    			                    new DialogInterface.OnClickListener() {

    			                        @Override
    			                        public void onClick(
    			                                DialogInterface dialog,
    			                                int which) {
    			                            startDownloadTask(
    			                            		Login.this,
    			                                    appBean.getDownloadURL());
    			                        }
    			                    }).show();
    			      }

    			      @Override
    			      public void onNoUpdateAvailable() {
    			      }
    			   });

	}
    
    public void login_mainweixin(View v) {
    	
    	boolean havenet=NetHelper.IsHaveInternet(Login.this);
		if (havenet) {
    	
	    	spname=mUser.getText().toString().toLowerCase().trim();
	    	spword=mPassword.getText().toString().toLowerCase().trim();
	    	if("".equals(spname) || "".equals(spword))   //�ж� �ʺź�����
	        {
	        	new AlertDialog.Builder(Login.this)
				.setIcon(getResources().getDrawable(R.drawable.login_error_icon))
				.setTitle("��¼����")
				.setMessage("�û����������벻��Ϊ��\n��������ٵ�¼��")
				.create().show();
	        }else {
	        	
	        	progressDialog=ProgressDialog.show(Login.this,"���ڵ�¼��","���Ե�...");
				new Thread(){
					@Override
					public void run() {
						json=WebServiceUtil.everycanforStr2("username","password","","","","", spname, spword,"", "", "", 0, "NewIsUser");
						Log.d("yin","IsUser��"+json);
						if (json!=null&&!json.equals("0")) {
							JSONTokener jsonTokener=new JSONTokener(json);
							try {
								
								JSONObject person= (JSONObject) jsonTokener.nextValue();
								uxm=person.getString("uxm");
								udw=person.getString("udw");
								uxb=person.getString("uxb");
								usr=person.getString("usr");
								udh=person.getString("udh");
								uzw=person.getString("uzw");
								usfz=person.getString("usfz");
								udwdz=person.getString("udwdz");
								ubmid=person.getString("ubmid");
								role=person.getString("role");
								//uszp=person.getString("uszp");
								
					        }catch (JSONException e) {
					                        e.printStackTrace();
					        }
						}
						
						message=new Message();
			    		message.what=1;
			    		handler.sendMessage(message);
					}
					
				}.start();
	        	
			}
	    	
		}else {
			new AlertDialog.Builder(Login.this).setMessage("��ǰ���粻����,�����������ã�").setTitle("����������")
			.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {						
				@Override
				public void onClick(DialogInterface dialog, int which) {}}).show();

		}
	    	
			
				
    	
    	
    	
    	/*if("admin".equals(mUser.getText().toString()) && "admin".equals(mPassword.getText().toString()))   //�ж� �ʺź�����
        {
             Intent intent = new Intent();
             intent.setClass(Login.this,MainWeixin.class);
             startActivity(intent);
             Toast.makeText(getApplicationContext(), "��¼�ɹ�", Toast.LENGTH_SHORT).show();
          }
        else if("".equals(mUser.getText().toString()) || "".equals(mPassword.getText().toString()))   //�ж� �ʺź�����
        {
        	new AlertDialog.Builder(Login.this)
			.setIcon(getResources().getDrawable(R.drawable.login_error_icon))
			.setTitle("��¼����")
			.setMessage("�û����������벻��Ϊ�գ�\n��������ٵ�¼��")
			.create().show();
         }
        else{
           
        	new AlertDialog.Builder(Login.this)
			.setIcon(getResources().getDrawable(R.drawable.login_error_icon))
			.setTitle("��¼ʧ��")
			.setMessage("΢���ʺŻ������벻��ȷ��\n������������룡")
			.create().show();
        }*/
    	
    	//��¼��ť
    	/*
      	Intent intent = new Intent();
		intent.setClass(Login.this,Whatsnew.class);
		startActivity(intent);
		Toast.makeText(getApplicationContext(), "��¼�ɹ�", Toast.LENGTH_SHORT).show();
		this.finish();*/
      }  
    public void login_back(View v) {     //������ ���ذ�ť
      	this.finish();
      }  
    public void login_pw(View v) {     //�������밴ť
    	Uri uri = Uri.parse("http://3g.qq.com"); 
    	Intent intent = new Intent(Intent.ACTION_VIEW, uri); 
    	startActivity(intent);
    }  
    
    @SuppressWarnings("deprecation")
	protected void saveSharedPreferences() {
    	
		sharedPreferences=getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE+Context.MODE_WORLD_WRITEABLE);
		SharedPreferences.Editor editor=sharedPreferences.edit();
		editor.putString("spname", spname);
		editor.putString("spword", spword);
		editor.putString("json", json);
		editor.putString("uxm", uxm);
		editor.putString("udw", udw);
		editor.putString("uxb", uxb);
		editor.putString("usr", usr);
		editor.putString("udh", udh);
		editor.putString("uzw", uzw);
		editor.putString("usfz", usfz);
		editor.putString("udwdz", udwdz);
		editor.putString("ubmid", ubmid);
		editor.putString("role", role);
		//editor.putString("uszp", uszp);
		if(login_check.isChecked()){
    		editor.putString("check","1");
    	}else{
    		editor.putString("check","0");
    	}
		editor.commit();
		
	}
    
    @SuppressWarnings("deprecation")
	private void loadSharedPreferences() {
		
		sharedPreferences=getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE+Context.MODE_WORLD_WRITEABLE);
		spname=sharedPreferences.getString("spname","");
		spword=sharedPreferences.getString("spword", "");
		uxm=sharedPreferences.getString("uxm","");
		udw=sharedPreferences.getString("udw", "");
		uxb=sharedPreferences.getString("uxb","");
		usr=sharedPreferences.getString("usr", "");
		udh=sharedPreferences.getString("udh","");
		uzw=sharedPreferences.getString("uzw", "");
		usfz=sharedPreferences.getString("usfz", "");
		udwdz=sharedPreferences.getString("udwdz", "");
		//uszp=sharedPreferences.getString("uszp", "");
		
		if(sharedPreferences.getString("check", "").equals("1")){
			mUser.setText(spname);
		}
		
		mPassword.setText(spword);
		
		JPushInterface.setAliasAndTags(getApplicationContext(),spname,null,null);
		
	}
    //JPush ����
    protected void onResume(){  
        super.onResume();  
        JPushInterface.onResume(this);  
    }  
    @Override  
    protected void onPause(){  
        super.onPause();  
        JPushInterface.onPause(this);  
    } 
    
}
