package com.woeasy.DZFNew;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import com.woeasy.DZFNew.PullDownView.OnPullDownListener;
import com.woeasy.model.ROWS;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import cn.buaa.adapter.ROWSAdapter;
import cn.buaa.util.NetHelper;
import cn.buaa.util.WebServiceUtil;
import android.widget.AdapterView.OnItemClickListener;

@SuppressLint({ "HandlerLeak", "InflateParams" })
public class RY_list2 extends Activity implements OnPullDownListener,OnItemClickListener{
	
	private ListView listview;
	private PullDownView mPullDownView;
	private ROWSAdapter listViewAdapter;
	private List<ROWS> listItems = new ArrayList<ROWS>();
	private String json;
	private String spname;
	private String wantto="����Ԫ";
	private String proName="",prodq="",search="",yearnd = "", proProfession = "";
	private int pageindex = 1;
	private Button serch;
	private boolean iswebbing=false;
	private String searchstr="";
	private TextView title;
	private String searchname="";
	private String methodString;
	private Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12,b13, bqb;
	protected static final int ADD_ADPATER = 1;
	protected static final int ADD_DZGG = 1;
	private static final int WHAT_DID_LOAD_DATA = 0;
	private static final int WHAT_DID_REFRESH = 1;
	private static final int WHAT_DID_MORE = 2;
	private static final String CENTER = null;
	private Button xj;
	public static RY_list2 listact;
	private LinearLayout nyc,xxc,ydc,bcc,hjc,thjjkfq,xyjjq,hbkjc,yljd,wfjd,xfjd,dyjd,wxjd,b_zu;
	private Button b1_1, b2_1, b3_1, b4_1, b5_1, b6_1, b7_1, b8_1, b9_1, b10_1, b11_1, b12_1,b13_1,
	b14_1,b15_1,b16_1,b17_1,b18_1,b19_1,b20_1,b21_1,b22_1,b23_1,b24_1,b25_1,bqb2;
	private Button b1_2, b2_2, b3_2, b4_2, b5_2, b6_2, b7_2, b8_2, b9_2, b10_2, b11_2, b12_2,b13_2,
	b14_2,b15_2,b16_2,b17_2,b18_2,b19_2,b20_2,b21_2,b22_2,b23_2,b24_2,bqb3;
	private Button b1_3, b2_3, b3_3, b4_3, b5_3, b6_3, b7_3, b8_3, b9_3, b10_3, b11_3, b12_3,b13_3,
	b14_3,bqb4;
	private Button b1_4, b2_4, b3_4, b4_4, b5_4, b6_4, b7_4, b8_4, b9_4, b10_4, b11_4, b12_4,b13_4,bqb5;
	private Button b1_5, b2_5, b3_5, b4_5, b5_5, b6_5, b7_5, b8_5, b9_5, b10_5, b11_5,bqb6;
	private Button b1_6, b2_6, b3_6, b4_6, b5_6, b6_6, b7_6, b8_6,bqb7;
	private Button b1_7, b2_7, b3_7, b4_7, b5_7, b6_7, b7_7, b8_7, b9_7, b10_7, b11_7, b12_7,bqb8;
	private Button b1_8, b2_8, b3_8, b4_8, b5_8, b6_8,bqb9;
	private Button b1_9, b2_9, b3_9, b4_9, b5_9, b6_9, b7_9, b8_9, b9_9, b10_9, b11_9, b12_9,b13_9,
	b14_9,bqb10;
	private Button b1_10, b2_10, b3_10, b4_10, b5_10, b6_10, b7_10, b8_10, b9_10, b10_10, b11_10, b12_10,b13_10,
	b14_10,bqb11;
	private Button b1_11, b2_11, b3_11, b4_11, b5_11, b6_11, b7_11, b8_11, b9_11, b10_11, b11_11, b12_11,b13_11,
	b14_11,b15_11,bqb12;
	private Button b1_12, b2_12, b3_12, b4_12, b5_12, b6_12, b7_12, b8_12,bqb13;
	private Button b1_13, b2_13, b3_13, b4_13, b5_13, b6_13, b7_13, b8_13, b9_13, b10_13, b11_13, bqb14;
	private Button b1_z, b2_z, b3_z, b4_z, b5_z, b6_z, b7_z, b8_z, b9_z, b10_z, b11_z, b12_z,b13_z,
	b14_z,b15_z,b16_z,b17_z,b18_z,bqb15;
	private AlertDialog dlg;
	
	private LinearLayout xingyangjjq;
	private Handler handler = new Handler() {
		@SuppressWarnings("unchecked")
		@Override
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case WHAT_DID_LOAD_DATA: {
				setData();
				// setGGData();
				mPullDownView.notifyDidLoad();
				break;
			}
			case WHAT_DID_REFRESH: {
				listItems.clear();
				listItems=(List<ROWS>)msg.obj;
				listViewAdapter.setmes((List<ROWS>) msg.obj);
				listViewAdapter.notifyDataSetChanged();
				mPullDownView.notifyDidRefresh();
				break;
			}

			case WHAT_DID_MORE: {
				listViewAdapter.setmes(listItems);
				listViewAdapter.notifyDataSetChanged();
				mPullDownView.notifyDidMore();
				break;
			}
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ryxx_list);
		listact = this;
		spname = getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE+Context.MODE_WORLD_WRITEABLE).getString("spname", "");
		
		getInfo();
	
		mPullDownView = (PullDownView) findViewById(R.id.rwlistview);
		mPullDownView.setOnPullDownListener(this);
		listview = mPullDownView.getListView();
		//����ˢ��
		listViewAdapter = new ROWSAdapter(this, listItems);
		listview.setAdapter(listViewAdapter);
		listview.setOnItemClickListener(this);
		mPullDownView.enableAutoFetchMore(false, 1);
		//��������
		mPullDownView.enableAutoFetchMore(true, 1);
		findview();
		findzu();
		OnClick();
		nyz();
		xxz();
		ydz();
		bcz();
		hjz();
		thjjkfq();
		xyjjq();
		hbkjc();
		yljd();
		xfjd();
		wfjd();
		dyjd();
		wxjd();
		zu();
		xj.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(RY_list2.this, RY_XJ.class);
			
				startActivity(intent);
				
			}
		});
		
		serch.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				 LayoutInflater myinflater = LayoutInflater.from(RY_list2.this);
			     final View mydialogview = myinflater.inflate(R.layout.searchzd, null);
			     dlg = new AlertDialog.Builder(RY_list2.this,AlertDialog.THEME_HOLO_LIGHT)
			    	      .setTitle("��������Ӧ����")
			    	      .setView(mydialogview)//����һ��ʵ���˺���Դ�ļ��е�mylogindialog�Ĺ���
			    	      .setPositiveButton("����", new DialogInterface.OnClickListener() {				    	            
			    	            @Override
			    	            public void onClick(DialogInterface arg0, int arg1) {				    	            	
			    	            	Spinner sp1=(Spinner)mydialogview.findViewById(R.id.province_spinner);
			    	            	Spinner sp2=(Spinner)mydialogview.findViewById(R.id.city_spinner);
			    	            	Spinner sp3=(Spinner)mydialogview.findViewById(R.id.county_spinner);
			    	            	proName=sp1.getSelectedItem().toString();
			    	            	if(proName.equals("ȫ��"))
			    	            		proName="";
			    	            	prodq=sp2.getSelectedItem().toString();
			    	            	if(prodq.equals("ȫ��"))
			    	            		prodq="";			    	      
			    	            	proProfession=sp3.getSelectedItem().toString();
			    	            	if(proProfession.equals("ȫ��"))
			    	            		proProfession="";			    	            	
			    	            	onRefresh();
			    	              }
			    	        })
			    	        .setNeutralButton("ȡ��", new DialogInterface.OnClickListener(){

			    	            @Override
			    	            public void onClick(DialogInterface arg0, int arg1) {
			    	            }
			    	            
			    	        })
			    	        .create();
			     Window window = dlg.getWindow();
	             window.setGravity(Gravity.CENTER);  //�˴���������dialog��ʾ��λ��
	             window.setWindowAnimations(R.style.anstyle);  
			     dlg.show();
			}
		});
		getInfo();
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	private void setData() {
		listViewAdapter = new ROWSAdapter(this, listItems);
		listview.setAdapter(listViewAdapter);
	}
	
	private void findzu(){
		bqb15=(Button) findViewById(R.id.qb15);
		 b1_z=(Button) findViewById(R.id.yizu);
		 b2_z=(Button) findViewById(R.id.erzu);
		 b3_z=(Button) findViewById(R.id.sanzu);
		 b4_z=(Button) findViewById(R.id.sizu);
		 b5_z=(Button) findViewById(R.id.wuzu);
		 b6_z=(Button) findViewById(R.id.liuzu);
		 b7_z=(Button) findViewById(R.id.qizu);
		 b8_z=(Button) findViewById(R.id.bazu);
		 b9_z=(Button) findViewById(R.id.jiuzu);
		 b10_z=(Button) findViewById(R.id.shizu);
		 b11_z=(Button) findViewById(R.id.shiyizu);
		 b12_z=(Button) findViewById(R.id.shierzu);
		 b13_z=(Button) findViewById(R.id.shisanzu);
		 b14_z=(Button) findViewById(R.id.shisizu);
		 b15_z=(Button) findViewById(R.id.shiwuzu);
		 b16_z=(Button) findViewById(R.id.shiliuzu);
		 b17_z=(Button) findViewById(R.id.shiqizu);
		 b18_z=(Button) findViewById(R.id.shibazu);
		 serch=(Button) findViewById(R.id.serch);	
		 xingyangjjq=(LinearLayout) findViewById(R.id.xingyangjjq);
	}
	
	private void findview(){
		b1 = (Button)findViewById(R.id.one);
		b2 = (Button) findViewById(R.id.two);
		b3 = (Button) findViewById(R.id.three);
		b4 = (Button) findViewById(R.id.four);
		b5 = (Button)findViewById(R.id.five);
		b6 = (Button) findViewById(R.id.six);
		b7 = (Button) findViewById(R.id.seven);
		b8 = (Button) findViewById(R.id.eight);
		b9 = (Button) findViewById(R.id.nine);
		b10 = (Button) findViewById(R.id.ten);
		b11 = (Button) findViewById(R.id.eleven);
		b12 = (Button) findViewById(R.id.twelve);
		b13 = (Button) findViewById(R.id.thirteen);
		bqb = (Button) findViewById(R.id.qb);
		xj=(Button) findViewById(R.id.xj);
		
		nyc=(LinearLayout) findViewById(R.id.nyc);
		xxc=(LinearLayout) findViewById(R.id.xxc);
		ydc=(LinearLayout) findViewById(R.id.ydc);
		bcc=(LinearLayout) findViewById(R.id.bcc);
		hjc=(LinearLayout) findViewById(R.id.hjc);
		thjjkfq=(LinearLayout) findViewById(R.id.thjjkfq);
		xyjjq=(LinearLayout) findViewById(R.id.xyjjq);
		hbkjc=(LinearLayout) findViewById(R.id.hbkjc);
		yljd=(LinearLayout) findViewById(R.id.yljd);
		xfjd=(LinearLayout) findViewById(R.id.xfjd);
		wfjd=(LinearLayout) findViewById(R.id.wfjd);
		dyjd=(LinearLayout) findViewById(R.id.dyjd);
		wxjd=(LinearLayout) findViewById(R.id.wxjd);
			
		//������
		bqb2=(Button) findViewById(R.id.qb2);
		 b1_1=(Button) findViewById(R.id.n_xy);
		 b2_1=(Button) findViewById(R.id.n_mh);
		 b3_1=(Button) findViewById(R.id.n_tz);
		 b4_1=(Button) findViewById(R.id.n_qd);
		 b5_1=(Button) findViewById(R.id.n_cj);
		 b6_1=(Button) findViewById(R.id.n_gy);
		 b7_1=(Button) findViewById(R.id.n_fx);
		 b8_1=(Button) findViewById(R.id.n_zr);
		 b9_1=(Button) findViewById(R.id.n_zd);
		 b10_1=(Button) findViewById(R.id.n_lm);
		 b11_1=(Button) findViewById(R.id.n_tj);
		 b12_1=(Button) findViewById(R.id.n_sj);
		 b13_1=(Button) findViewById(R.id.n_yw);
		 b14_1=(Button) findViewById(R.id.n_xr);
		 b15_1=(Button) findViewById(R.id.n_ct);
		 b16_1=(Button) findViewById(R.id.n_rk);
		 b17_1=(Button) findViewById(R.id.n_yz);
		 b18_1=(Button) findViewById(R.id.n_yq);
		 b19_1=(Button) findViewById(R.id.n_ln);
		 b20_1=(Button) findViewById(R.id.n_lim);
		 b21_1=(Button) findViewById(R.id.n_cb);
		 b22_1=(Button) findViewById(R.id.n_dt);
		 b23_1=(Button) findViewById(R.id.n_gc);
		 b24_1=(Button) findViewById(R.id.n_sg);
		 b25_1=(Button) findViewById(R.id.n_yd);
		 //������
		 bqb3=(Button) findViewById(R.id.qb3);
		 b1_2=(Button) findViewById(R.id.x_ct);
		 b2_2=(Button) findViewById(R.id.x_fm);
		 b3_2=(Button) findViewById(R.id.x_gl);
		 b4_2=(Button) findViewById(R.id.x_gh);
		 b5_2=(Button) findViewById(R.id.x_hd);
		 b6_2=(Button) findViewById(R.id.x_lm);
		 b7_2=(Button) findViewById(R.id.x_nj);
		 b8_2=(Button) findViewById(R.id.x_qy);
		 b9_2=(Button) findViewById(R.id.x_sl);
		 b10_2=(Button) findViewById(R.id.x_sz);
		 b11_2=(Button) findViewById(R.id.x_sh);
		 b12_2=(Button) findViewById(R.id.x_sn);
		 b13_2=(Button) findViewById(R.id.x_tx);
		 b14_2=(Button) findViewById(R.id.x_g);
		 b15_2=(Button) findViewById(R.id.x_xy);
		 b16_2=(Button) findViewById(R.id.x_xj);
		 b17_2=(Button) findViewById(R.id.x_xjj);
		 b18_2=(Button) findViewById(R.id.x_xn);
		 b19_2=(Button) findViewById(R.id.x_xiny);
		 b20_2=(Button) findViewById(R.id.x_yx);
		 b21_2=(Button) findViewById(R.id.x_cc);
		 b22_2=(Button) findViewById(R.id.x_zn);
		 b23_2=(Button) findViewById(R.id.x_zx);
		 b24_2=(Button) findViewById(R.id.x_zb);
	  //�ζ���
		 bqb4=(Button) findViewById(R.id.qb4);
		 b1_3=(Button) findViewById(R.id.guiy);
		 b2_3=(Button) findViewById(R.id.liz);
		 b3_3=(Button) findViewById(R.id.meim);
		 b4_3=(Button) findViewById(R.id.dongn);
		 b5_3=(Button) findViewById(R.id.zhaof);
		 b6_3=(Button) findViewById(R.id.shengj);
		 b7_3=(Button) findViewById(R.id.shuy);
		 b8_3=(Button) findViewById(R.id.wug);
		 b9_3=(Button) findViewById(R.id.xingchong);
		 b10_3=(Button) findViewById(R.id.xingjian);
		 b11_3=(Button) findViewById(R.id.yangy);
		 b12_3=(Button) findViewById(R.id.zhengy);
		 b13_3=(Button) findViewById(R.id.zhongd);
		 b14_3=(Button) findViewById(R.id.nyyq);
		 //�����
		 bqb5=(Button) findViewById(R.id.qb5);
		 b1_4=(Button) findViewById(R.id.b_bc);
		 b2_4=(Button) findViewById(R.id.b_fm);
		 b3_4=(Button) findViewById(R.id.b_bl);
		 b4_4=(Button) findViewById(R.id.b_jc);
		 b5_4=(Button) findViewById(R.id.b_xt);
		 b6_4=(Button) findViewById(R.id.b_ml);
		 b7_4=(Button) findViewById(R.id.b_xy);
		 b8_4=(Button) findViewById(R.id.b_xc);
		 b9_4=(Button) findViewById(R.id.b_xq);
		 b10_4=(Button) findViewById(R.id.b_dt);
		 b11_4=(Button) findViewById(R.id.b_sg);
		 b12_4=(Button) findViewById(R.id.b_jg);
		 b13_4=(Button) findViewById(R.id.b_mq);
		 //�Ƽ���
		 bqb6=(Button) findViewById(R.id.qb6);
		 b1_5=(Button) findViewById(R.id.h_xingj);
		 b2_5=(Button) findViewById(R.id.h_xingt);
		 b3_5=(Button) findViewById(R.id.h_huangj);
		 b4_5=(Button) findViewById(R.id.h_xingz);
		 b5_5=(Button) findViewById(R.id.h_hand);
		 b6_5=(Button) findViewById(R.id.h_yangj);
		 b7_5=(Button) findViewById(R.id.h_huangq);
		 b8_5=(Button) findViewById(R.id.h_zhin);
		 b9_5=(Button) findViewById(R.id.h_xingn);
		 b10_5=(Button) findViewById(R.id.h_xygj);
		 b11_5=(Button) findViewById(R.id.h_tgs);
		 //ͤ�����ÿ�����
		 bqb7=(Button) findViewById(R.id.qb7);
		 b1_6=(Button) findViewById(R.id.grsq);
		 b2_6=(Button) findViewById(R.id.xmsq);
		 b3_6=(Button) findViewById(R.id.fksq);
		 b4_6=(Button) findViewById(R.id.blsq);
		 b5_6=(Button) findViewById(R.id.nlsq);
		 b6_6=(Button) findViewById(R.id.nysq);
		 b7_6=(Button) findViewById(R.id.xfsq);
		 b8_6=(Button) findViewById(R.id.swc);
		 //���󾭼���
		 bqb8=(Button) findViewById(R.id.qb8);
		 b1_7=(Button) findViewById(R.id.yuanhe);
		 b2_7=(Button) findViewById(R.id.sanying);
		 b3_7=(Button) findViewById(R.id.longqiao);
		 b4_7=(Button) findViewById(R.id.yuangzhuang);
		 b5_7=(Button) findViewById(R.id.yuyang);
		 b6_7=(Button) findViewById(R.id.yanwan);
		 b7_7=(Button) findViewById(R.id.beiza);
		 b8_7=(Button) findViewById(R.id.xysq);
		 b9_7=(Button) findViewById(R.id.xianfsqu);
		 b10_7=(Button) findViewById(R.id.tjgsq);
		 b11_7=(Button) findViewById(R.id.cbsq);
		 b12_7=(Button) findViewById(R.id.ydsq);
		 //�����Ƽ���
		 bqb9=(Button) findViewById(R.id.qb9);
		 b1_8=(Button) findViewById(R.id.xingming);
		 b2_8=(Button) findViewById(R.id.shaoling);
		 b3_8=(Button) findViewById(R.id.qingfeng);
		 b4_8=(Button) findViewById(R.id.minglian);
		 b5_8=(Button) findViewById(R.id.fengyan);
		 b6_8=(Button) findViewById(R.id.xinggang);
		 //ع���ֵ�
		 bqb10=(Button) findViewById(R.id.qb10);
		 b1_9=(Button) findViewById(R.id.huangcheng);
		 b2_9=(Button) findViewById(R.id.yangzhongsq);
		 b3_9=(Button) findViewById(R.id.xurisq);
		 b4_9=(Button) findViewById(R.id.xianqsq);
		 b5_9=(Button) findViewById(R.id.tantusq);
		 b6_9=(Button) findViewById(R.id.qiaodsq);
		 b7_9=(Button) findViewById(R.id.hailsq);
		 b8_9=(Button) findViewById(R.id.gongdsq);
		 b9_9=(Button) findViewById(R.id.dassq);
		 b10_9=(Button) findViewById(R.id.bashsq);
		 b11_9=(Button) findViewById(R.id.yangxsq);
		 b12_9=(Button) findViewById(R.id.haicsq);
		 b13_9=(Button) findViewById(R.id.donggsq);
		 b14_9=(Button) findViewById(R.id.linjsq);
		 //�ȷ�ֵ�
		 bqb11=(Button) findViewById(R.id.qb11);
		 b1_10=(Button) findViewById(R.id.donghe);
		 b2_10=(Button) findViewById(R.id.chengx);
		 b3_10=(Button) findViewById(R.id.jiangsq);
		 b4_10=(Button) findViewById(R.id.xianfsq);
		 b5_10=(Button) findViewById(R.id.jusq);
		 b6_10=(Button) findViewById(R.id.xflsq);
		 b7_10=(Button) findViewById(R.id.lhsq);
		 b8_10=(Button) findViewById(R.id.bclsq);
		 b9_10=(Button) findViewById(R.id.dclsq);
		 b10_10=(Button) findViewById(R.id.jianxsq);
		 b11_10=(Button) findViewById(R.id.xinjsq);
		 b12_10=(Button) findViewById(R.id.yuhsq);
		 b13_10=(Button) findViewById(R.id.jiangksq);
		 b14_10=(Button) findViewById(R.id.shengysq);
		 //�ķ�ֵ�
		 bqb12=(Button) findViewById(R.id.qb12);
		 b1_11=(Button) findViewById(R.id.shuangyuan);
		 b2_11=(Button) findViewById(R.id.changba);
		 b3_11=(Button) findViewById(R.id.sanyuansq);
		 b4_11=(Button) findViewById(R.id.jiefqsq);
		 b5_11=(Button) findViewById(R.id.nuxsq);
		 b6_11=(Button) findViewById(R.id.zhongxsq);
		 b7_11=(Button) findViewById(R.id.yingbin);
		 b8_11=(Button) findViewById(R.id.banqsq);
		 b9_11=(Button) findViewById(R.id.yanmlsq);
		 b10_11=(Button) findViewById(R.id.yanhsq);
		 b11_11=(Button) findViewById(R.id.xiyuansq);
		 b12_11=(Button) findViewById(R.id.dawsq);
		 b13_11=(Button) findViewById(R.id.wenqsq);
		 b14_11=(Button) findViewById(R.id.zhaoysq);
		 b15_11=(Button) findViewById(R.id.shuangylsq);
		 //����ֵ�
		 bqb13=(Button) findViewById(R.id.qb13);
		 b1_12=(Button) findViewById(R.id.daynag);
		 b2_12=(Button) findViewById(R.id.daxing);
		 b3_12=(Button) findViewById(R.id.dssq);
		 b4_12=(Button) findViewById(R.id.haiysq);
		 b5_12=(Button) findViewById(R.id.tongysq);
		 b6_12=(Button) findViewById(R.id.yanns);
		 b7_12=(Button) findViewById(R.id.yuecsq);
		 b8_12=(Button) findViewById(R.id.ylsq);
		 //���ǽֵ�
		 bqb14=(Button) findViewById(R.id.qb14);
		 b1_13=(Button) findViewById(R.id.wuxingc);
		 b2_13=(Button) findViewById(R.id.yahsq);
		 b3_13=(Button) findViewById(R.id.chengdsq);
		 b4_13=(Button) findViewById(R.id.dzxcsq);
		 b5_13=(Button) findViewById(R.id.xtsq);
		 b6_13=(Button) findViewById(R.id.yqsq);
		 b7_13=(Button) findViewById(R.id.xinghsq);
		 b8_13=(Button) findViewById(R.id.fnsq);
		 b9_13=(Button) findViewById(R.id.qingksq);
		 b10_13=(Button) findViewById(R.id.yannasq);
		 b11_13=(Button) findViewById(R.id.yuanbsq);
		 
		 b_zu=(LinearLayout) findViewById(R.id.zhu);
	}
	
	private void OnClick() {

		b1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "������";
				onRefresh();
				b1.setTextColor(Color.rgb(255, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));
				nyc.setVisibility(View.VISIBLE);
				xxc.setVisibility(View.GONE);
				ydc.setVisibility(View.GONE);
				bcc.setVisibility(View.GONE);
				hjc.setVisibility(View.GONE);
				thjjkfq.setVisibility(View.GONE);
				xyjjq.setVisibility(View.GONE);
				hbkjc.setVisibility(View.GONE);
				yljd.setVisibility(View.GONE);
				xfjd.setVisibility(View.GONE);
				wfjd.setVisibility(View.GONE);
				dyjd.setVisibility(View.GONE);
				wxjd.setVisibility(View.GONE);
				
			}
		});
		
		b2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "������";
				onRefresh();

				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(255, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));
				xxc.setVisibility(View.VISIBLE);
				nyc.setVisibility(View.GONE);
				ydc.setVisibility(View.GONE);
				bcc.setVisibility(View.GONE);
				hjc.setVisibility(View.GONE);
				thjjkfq.setVisibility(View.GONE);
				xyjjq.setVisibility(View.GONE);
				hbkjc.setVisibility(View.GONE);
				yljd.setVisibility(View.GONE);
				xfjd.setVisibility(View.GONE);
				wfjd.setVisibility(View.GONE);
				dyjd.setVisibility(View.GONE);
				wxjd.setVisibility(View.GONE);
			}
		});
		
		b3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "�ζ���";
				onRefresh();
				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(255, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));

				ydc.setVisibility(View.VISIBLE);
				xxc.setVisibility(View.GONE);
				nyc.setVisibility(View.GONE);
				bcc.setVisibility(View.GONE);
				hjc.setVisibility(View.GONE);
				thjjkfq.setVisibility(View.GONE);
				xyjjq.setVisibility(View.GONE);
				hbkjc.setVisibility(View.GONE);
				yljd.setVisibility(View.GONE);
				xfjd.setVisibility(View.GONE);
				wfjd.setVisibility(View.GONE);
				dyjd.setVisibility(View.GONE);
				wxjd.setVisibility(View.GONE);
			}
		});
		b4.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "�����";
				onRefresh();
				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(255, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));

				bcc.setVisibility(View.VISIBLE);
				ydc.setVisibility(View.GONE);
				xxc.setVisibility(View.GONE);
				nyc.setVisibility(View.GONE);
				hjc.setVisibility(View.GONE);
				thjjkfq.setVisibility(View.GONE);
				xyjjq.setVisibility(View.GONE);
				hbkjc.setVisibility(View.GONE);
				yljd.setVisibility(View.GONE);
				xfjd.setVisibility(View.GONE);
				wfjd.setVisibility(View.GONE);
				dyjd.setVisibility(View.GONE);
				wxjd.setVisibility(View.GONE);
			}
		});
		b5.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "�Ƽ���";
				onRefresh();
				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(255, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));

				hjc.setVisibility(View.VISIBLE);
				bcc.setVisibility(View.GONE);
				ydc.setVisibility(View.GONE);
				xxc.setVisibility(View.GONE);
				nyc.setVisibility(View.GONE);
				thjjkfq.setVisibility(View.GONE);
				xyjjq.setVisibility(View.GONE);
				hbkjc.setVisibility(View.GONE);
				yljd.setVisibility(View.GONE);
				xfjd.setVisibility(View.GONE);
				wfjd.setVisibility(View.GONE);
				dyjd.setVisibility(View.GONE);
				wxjd.setVisibility(View.GONE);
			}
		});
		b6.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "���ÿ�����";
				onRefresh();
				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(255, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));

				thjjkfq.setVisibility(View.VISIBLE);
				hjc.setVisibility(View.GONE);
				bcc.setVisibility(View.GONE);
				ydc.setVisibility(View.GONE);
				xxc.setVisibility(View.GONE);
				nyc.setVisibility(View.GONE);
				xyjjq.setVisibility(View.GONE);
				hbkjc.setVisibility(View.GONE);
				yljd.setVisibility(View.GONE);
				xfjd.setVisibility(View.GONE);
				wfjd.setVisibility(View.GONE);
				dyjd.setVisibility(View.GONE);
				wxjd.setVisibility(View.GONE);
			}
		});
		b7.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "���󾭼ÿ�����";
				onRefresh();
				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(255, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));

				xyjjq.setVisibility(View.VISIBLE);
				thjjkfq.setVisibility(View.GONE);
				hjc.setVisibility(View.GONE);
				bcc.setVisibility(View.GONE);
				ydc.setVisibility(View.GONE);
				xxc.setVisibility(View.GONE);
				nyc.setVisibility(View.GONE);
				hbkjc.setVisibility(View.GONE);
				yljd.setVisibility(View.GONE);
				xfjd.setVisibility(View.GONE);
				wfjd.setVisibility(View.GONE);
				dyjd.setVisibility(View.GONE);
				wxjd.setVisibility(View.GONE);
			}
		});
		b8.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "�����Ƽ���";
				onRefresh();
				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(255, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));

				hbkjc.setVisibility(View.VISIBLE);
				xyjjq.setVisibility(View.GONE);
				thjjkfq.setVisibility(View.GONE);
				hjc.setVisibility(View.GONE);
				bcc.setVisibility(View.GONE);
				ydc.setVisibility(View.GONE);
				xxc.setVisibility(View.GONE);
				nyc.setVisibility(View.GONE);
				yljd.setVisibility(View.GONE);
				xfjd.setVisibility(View.GONE);
				wfjd.setVisibility(View.GONE);
				dyjd.setVisibility(View.GONE);
				wxjd.setVisibility(View.GONE);
			}
		});
		b9.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "ع���ֵ�";
				onRefresh();
				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(255, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));
				
				yljd.setVisibility(View.VISIBLE);
				hbkjc.setVisibility(View.GONE);
				xyjjq.setVisibility(View.GONE);
				thjjkfq.setVisibility(View.GONE);
				hjc.setVisibility(View.GONE);
				bcc.setVisibility(View.GONE);
				ydc.setVisibility(View.GONE);
				xxc.setVisibility(View.GONE);
				nyc.setVisibility(View.GONE);
				xfjd.setVisibility(View.GONE);
				wfjd.setVisibility(View.GONE);
				dyjd.setVisibility(View.GONE);
				wxjd.setVisibility(View.GONE);

			}
		});
		b10.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "�ȷ�ֵ�";
				onRefresh();
				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(255, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));

				xfjd.setVisibility(View.VISIBLE);
				yljd.setVisibility(View.GONE);
				hbkjc.setVisibility(View.GONE);
				xyjjq.setVisibility(View.GONE);
				thjjkfq.setVisibility(View.GONE);
				hjc.setVisibility(View.GONE);
				bcc.setVisibility(View.GONE);
				ydc.setVisibility(View.GONE);
				xxc.setVisibility(View.GONE);
				nyc.setVisibility(View.GONE);
				wfjd.setVisibility(View.GONE);
				dyjd.setVisibility(View.GONE);
				wxjd.setVisibility(View.GONE);
			}
		});
		b11.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "�ķ�ֵ�";
				onRefresh();
				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(255, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));
				
				wfjd.setVisibility(View.VISIBLE);
				xfjd.setVisibility(View.GONE);
				yljd.setVisibility(View.GONE);
				hbkjc.setVisibility(View.GONE);
				xyjjq.setVisibility(View.GONE);
				thjjkfq.setVisibility(View.GONE);
				hjc.setVisibility(View.GONE);
				bcc.setVisibility(View.GONE);
				ydc.setVisibility(View.GONE);
				xxc.setVisibility(View.GONE);
				nyc.setVisibility(View.GONE);
				dyjd.setVisibility(View.GONE);
				wxjd.setVisibility(View.GONE);

			}
		});
		b12.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "����ֵ�";
				onRefresh();
				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(255, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));

				wxjd.setVisibility(View.VISIBLE);
				dyjd.setVisibility(View.GONE);
				wfjd.setVisibility(View.GONE);
				xfjd.setVisibility(View.GONE);
				yljd.setVisibility(View.GONE);
				hbkjc.setVisibility(View.GONE);
				xyjjq.setVisibility(View.GONE);
				thjjkfq.setVisibility(View.GONE);
				hjc.setVisibility(View.GONE);
				bcc.setVisibility(View.GONE);
				ydc.setVisibility(View.GONE);
				xxc.setVisibility(View.GONE);
				nyc.setVisibility(View.GONE);
			
			}
		});

		b13.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "���ǽֵ�";
				onRefresh();
				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(255, 0, 0));
				bqb.setTextColor(Color.rgb(0, 0, 0));

				dyjd.setVisibility(View.VISIBLE);
				wfjd.setVisibility(View.GONE);
				xfjd.setVisibility(View.GONE);
				yljd.setVisibility(View.GONE);
				hbkjc.setVisibility(View.GONE);
				xyjjq.setVisibility(View.GONE);
				thjjkfq.setVisibility(View.GONE);
				hjc.setVisibility(View.GONE);
				bcc.setVisibility(View.GONE);
				ydc.setVisibility(View.GONE);
				xxc.setVisibility(View.GONE);
				nyc.setVisibility(View.GONE);
				wxjd.setVisibility(View.GONE);
			}
		});
		bqb.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				prodq = "";
				onRefresh();
				b1.setTextColor(Color.rgb(0, 0, 0));
				b2.setTextColor(Color.rgb(0, 0, 0));
				b3.setTextColor(Color.rgb(0, 0, 0));
				b4.setTextColor(Color.rgb(0, 0, 0));
				b5.setTextColor(Color.rgb(0, 0, 0));
				b6.setTextColor(Color.rgb(0, 0, 0));
				b7.setTextColor(Color.rgb(0, 0, 0));
				b8.setTextColor(Color.rgb(0, 0, 0));
				b9.setTextColor(Color.rgb(0, 0, 0));
				b10.setTextColor(Color.rgb(0, 0, 0));
				b11.setTextColor(Color.rgb(0, 0, 0));
				b12.setTextColor(Color.rgb(0, 0, 0));
				b13.setTextColor(Color.rgb(0, 0, 0));
				bqb.setTextColor(Color.rgb(255, 0, 0));

			}
		});


	}
	
	private void getInfo(){
		boolean havenet = NetHelper.IsHaveInternet(RY_list2.this);
		if (havenet) {
			new Thread() {
				@Override
				public void run() {
					spname = getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE+Context.MODE_WORLD_WRITEABLE).getString("spname", "");
					
					json = WebServiceUtil.everycanforStrxmgl("proName", "wantto", "prodq", "yearnd", "proProfession",
							"userid", "pageindex", proName, methodString, prodq, yearnd, proProfession, spname, pageindex,
							"ZDXMGetList2");
					Log.d("��Ա��Ϣ", json);

					JSONArray jsonObjs;
					JSONObject jsonObj;
					JSONTokener jsonTokener = new JSONTokener(json);
					try {

						JSONObject person = (JSONObject) jsonTokener.nextValue();
						jsonObjs = person.getJSONArray("rows");
						
						for (int i = 0; i < jsonObjs.length(); i++) {
							ROWS rows = new ROWS();
							jsonObj = (JSONObject) jsonObjs.opt(i);

							rows.setSeq(jsonObj.getInt("seq"));
							
							if (jsonObj.getString("prodq") != null) {
								rows.setProdq(jsonObj.getString("prodq"));
							} else {
								rows.setProdq("");
							}
						
							if (jsonObj.getString("address") != null) {
								rows.setAddress(jsonObj.getString("address"));
							} else {
								rows.setAddress("");
							}
							if (jsonObj.getString("proName") != null) {
								rows.setProName(jsonObj.getString("proName"));
							} else {
								rows.setProName("");
							}
							if (jsonObj.getString("locationNumber") != null) {
								rows.setLocationNumber(jsonObj.getString("locationNumber"));
							} else {
								rows.setLocationNumber("");
							}
							if (jsonObj.getString("unitName1") != null) {
								rows.setUnitName1(jsonObj.getString("unitName1"));
							} else {
								rows.setUnitName1("");
							}
							if (jsonObj.getString("receiptCode") != null) {
								rows.setReceiptCode(jsonObj.getString("receiptCode"));
							} else {
								rows.setReceiptCode("");
							}
							if (jsonObj.getString("proDivideOther") != null) {
								rows.setProDivideOther(jsonObj.getString("proDivideOther"));
							} else {
								rows.setProDivideOther("");
							}
							if (jsonObj.getString("landTotalArea") != null) {
								rows.setLandTotalArea(jsonObj.getString("landTotalArea"));
							} else {
								rows.setLandTotalArea("");
							}
							if (jsonObj.getString("BY3") != null) {
								rows.setBY3(jsonObj.getString("BY3"));
							} else {
								rows.setBY3("");
							}
							if (jsonObj.getString("investTotal") != null) {
								rows.setInvestTotal(jsonObj.getString("investTotal"));
							} else {
								rows.setInvestTotal("");
							}
							if (jsonObj.getString("yearWorkPlan") != null) {
								rows.setYearWorkPlan(jsonObj.getString("yearWorkPlan"));
							} else {
								rows.setYearWorkPlan("");
							}
							if (jsonObj.getString("buildContent") != null) {
								rows.setBuildContent(jsonObj.getString("buildContent"));
							} else {
								rows.setBuildContent("");
							}
							if (jsonObj.getString("proProfessionChild") != null) {
								rows.setProProfessionChild(jsonObj.getString("proProfessionChild"));
							} else {
								rows.setProProfessionChild("");
							}
							if (jsonObj.getString("BY2") != null) {
								rows.setBY2(jsonObj.getString("BY2"));
							} else {
								rows.setBY2("");
							}
							if (jsonObj.getString("landNum") != null) {
								rows.setLandNum(jsonObj.getString("landNum"));
							} else {
								rows.setLandNum("");
							}
							if (jsonObj.getString("unitName2") != null) {
								rows.setUnitName2 (jsonObj.getString("unitName2"));
							} else {
								rows.setUnitName2 ("");
							}
							
							if (jsonObj.getString("beginDate") != null) {
								rows.setBeginDate (jsonObj.getString("beginDate"));
							} else {
								rows.setBeginDate ("");
							}
							if (jsonObj.getString("imageProcess") != null) {
								rows.setImageProcess (jsonObj.getString("imageProcess"));
							} else {
								rows.setImageProcess ("");
							}
							if (jsonObj.getString("economicBenefit") != null) {
								rows.setEconomicBenefit (jsonObj.getString("economicBenefit"));
							} else {
								rows.setEconomicBenefit("");
							}
							
							if (jsonObj.getString("background") != null) {
								rows.setBackground (jsonObj.getString("background"));
							} else {
								rows.setBackground("");
							}
							
						
							
							
							if (jsonObj.getString("JD") != null) {
								rows.setJD (jsonObj.getString("JD"));
							} else {
								rows.setJD("");
							}
							if (jsonObj.getString("WD") != null) {
								rows.setWD (jsonObj.getString("WD"));
							} else {
								rows.setWD("");
							}
							
						listItems.add(rows);
						}

						Message msg = new Message();
						msg.what = WHAT_DID_LOAD_DATA;
						handler.sendMessage(msg);
					} catch (JSONException e) {
						e.printStackTrace();
					}

				}
			}.start();

		} else {
			new AlertDialog.Builder(RY_list2.this)
					.setMessage("���������������ã�")
					.setTitle("����������")
					.setPositiveButton("ȷ��",new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
								}

							}).show();

		}
		
		
		
		
		
		
		
		
		
	}
	
	private void nyz(){

		b1_1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_1.setTextColor(Color.rgb(255, 0, 0));
				b2_1.setTextColor(Color.rgb(0, 0, 0));
				b3_1.setTextColor(Color.rgb(0, 0, 0));
				b4_1.setTextColor(Color.rgb(0, 0, 0));
				b5_1.setTextColor(Color.rgb(0, 0, 0));
				b6_1.setTextColor(Color.rgb(0, 0, 0));
				b7_1.setTextColor(Color.rgb(0, 0, 0));
				b8_1.setTextColor(Color.rgb(0, 0, 0));
				b9_1.setTextColor(Color.rgb(0, 0, 0));
				b10_1.setTextColor(Color.rgb(0, 0, 0));
				b11_1.setTextColor(Color.rgb(0, 0, 0));
				b12_1.setTextColor(Color.rgb(0, 0, 0));
				b13_1.setTextColor(Color.rgb(0, 0, 0));
				b14_1.setTextColor(Color.rgb(0, 0, 0));
				b15_1.setTextColor(Color.rgb(0, 0, 0));
				b16_1.setTextColor(Color.rgb(0, 0, 0));
				b17_1.setTextColor(Color.rgb(0, 0, 0));
				b18_1.setTextColor(Color.rgb(0, 0, 0));
				b19_1.setTextColor(Color.rgb(0, 0, 0));
				b20_1.setTextColor(Color.rgb(0, 0, 0));
				b21_1.setTextColor(Color.rgb(0, 0, 0));
				b22_1.setTextColor(Color.rgb(0, 0, 0));
				b23_1.setTextColor(Color.rgb(0, 0, 0));
				b24_1.setTextColor(Color.rgb(0, 0, 0));
				b25_1.setTextColor(Color.rgb(0, 0, 0));
				bqb2.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
				
			}
		});
			b2_1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�񺽴�";
				onRefresh();
				b2_1.setTextColor(Color.rgb(255, 0, 0));
				b1_1.setTextColor(Color.rgb(0, 0, 0));
				b3_1.setTextColor(Color.rgb(0, 0, 0));
				b4_1.setTextColor(Color.rgb(0, 0, 0));
				b5_1.setTextColor(Color.rgb(0, 0, 0));
				b6_1.setTextColor(Color.rgb(0, 0, 0));
				b7_1.setTextColor(Color.rgb(0, 0, 0));
				b8_1.setTextColor(Color.rgb(0, 0, 0));
				b9_1.setTextColor(Color.rgb(0, 0, 0));
				b10_1.setTextColor(Color.rgb(0, 0, 0));
				b11_1.setTextColor(Color.rgb(0, 0, 0));
				b12_1.setTextColor(Color.rgb(0, 0, 0));
				b13_1.setTextColor(Color.rgb(0, 0, 0));
				b14_1.setTextColor(Color.rgb(0, 0, 0));
				b15_1.setTextColor(Color.rgb(0, 0, 0));
				b16_1.setTextColor(Color.rgb(0, 0, 0));
				b17_1.setTextColor(Color.rgb(0, 0, 0));
				b18_1.setTextColor(Color.rgb(0, 0, 0));
				b19_1.setTextColor(Color.rgb(0, 0, 0));
				b20_1.setTextColor(Color.rgb(0, 0, 0));
				b21_1.setTextColor(Color.rgb(0, 0, 0));
				b22_1.setTextColor(Color.rgb(0, 0, 0));
				b23_1.setTextColor(Color.rgb(0, 0, 0));
				b24_1.setTextColor(Color.rgb(0, 0, 0));
				b25_1.setTextColor(Color.rgb(0, 0, 0));
				bqb2.setTextColor(Color.rgb(0, 0, 0));
				
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
			
			b3_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "ͷ���";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(255, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));

					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					b10_z.setVisibility(View.VISIBLE);
					b11_z.setVisibility(View.VISIBLE);
					b12_z.setVisibility(View.VISIBLE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
					
				}
			});
		
			b4_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "��մ�";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(255, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));

					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					
					b9_z.setVisibility(View.GONE);
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b5_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "�¾���";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(255, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			
			b6_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "��԰��";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(255, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					b10_z.setVisibility(View.VISIBLE);
					b11_z.setVisibility(View.VISIBLE);
					b12_z.setVisibility(View.VISIBLE);
					b13_z.setVisibility(View.VISIBLE);
					
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b7_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "�����";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(255, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					b10_z.setVisibility(View.VISIBLE);
					b11_z.setVisibility(View.VISIBLE);
					b12_z.setVisibility(View.VISIBLE);
					b13_z.setVisibility(View.VISIBLE);
					b14_z.setVisibility(View.VISIBLE);
					b15_z.setVisibility(View.VISIBLE);
					b16_z.setVisibility(View.VISIBLE);
					b17_z.setVisibility(View.VISIBLE);
					
				}
			});
			b8_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "��Ȼ��";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(255, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b9_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "������";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(255, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b10_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "������";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(255, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					b10_z.setVisibility(View.VISIBLE);
					b11_z.setVisibility(View.VISIBLE);
					b12_z.setVisibility(View.VISIBLE);
					
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b11_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "̶���";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(255, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					
					b9_z.setVisibility(View.GONE);
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b12_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "�����";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(255, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					
					b8_z.setVisibility(View.GONE);
					b9_z.setVisibility(View.GONE);
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
					
				}
			});
			b13_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "�����";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(255, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE);
					b10_z.setVisibility(View.VISIBLE);
					b11_z.setVisibility(View.VISIBLE);
					b12_z.setVisibility(View.VISIBLE);
					
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b14_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "��¡��";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(255, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					b10_z.setVisibility(View.VISIBLE);
					b11_z.setVisibility(View.VISIBLE);
					b12_z.setVisibility(View.VISIBLE);
					b13_z.setVisibility(View.VISIBLE);
					
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b15_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "���ô�";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(255, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b16_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "Ի����";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(255, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));

					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b17_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "���д�";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(255, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));

					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					
					b9_z.setVisibility(View.GONE);
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b18_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "�����";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(255, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					
					b7_z.setVisibility(View.GONE);
					b8_z.setVisibility(View.GONE);
					b9_z.setVisibility(View.GONE);
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b19_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "�����";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(255, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b20_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "�����";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(255, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					b10_z.setVisibility(View.VISIBLE);
					b11_z.setVisibility(View.VISIBLE);
					
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b21_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "��Ӵ�";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(255, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					b10_z.setVisibility(View.VISIBLE);
					
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b22_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "���Ŵ�";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(255, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					
					b6_z.setVisibility(View.GONE);
					b7_z.setVisibility(View.GONE);
					b8_z.setVisibility(View.GONE);
					b9_z.setVisibility(View.GONE);
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b23_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "�߲���";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(255, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					
					b6_z.setVisibility(View.GONE);
					b7_z.setVisibility(View.GONE);
					b8_z.setVisibility(View.GONE);
					b9_z.setVisibility(View.GONE);
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b24_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "����";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(255, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					
					b6_z.setVisibility(View.GONE);
					b7_z.setVisibility(View.GONE);
					b8_z.setVisibility(View.GONE);
					b9_z.setVisibility(View.GONE);
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			b25_1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "�ζ���";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(255, 0, 0));
					bqb2.setTextColor(Color.rgb(0, 0, 0));
					
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.GONE);
					b7_z.setVisibility(View.GONE);
					b8_z.setVisibility(View.GONE);
					b9_z.setVisibility(View.GONE);
					b10_z.setVisibility(View.GONE);
					b11_z.setVisibility(View.GONE);
					b12_z.setVisibility(View.GONE);
					b13_z.setVisibility(View.GONE);
					b14_z.setVisibility(View.GONE);
					b15_z.setVisibility(View.GONE);
					b16_z.setVisibility(View.GONE);
					b17_z.setVisibility(View.GONE);
				}
			});
			bqb2.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					proProfession = "";
					onRefresh();
					b2_1.setTextColor(Color.rgb(0, 0, 0));
					b1_1.setTextColor(Color.rgb(0, 0, 0));
					b3_1.setTextColor(Color.rgb(0, 0, 0));
					b4_1.setTextColor(Color.rgb(0, 0, 0));
					b5_1.setTextColor(Color.rgb(0, 0, 0));
					b6_1.setTextColor(Color.rgb(0, 0, 0));
					b7_1.setTextColor(Color.rgb(0, 0, 0));
					b8_1.setTextColor(Color.rgb(0, 0, 0));
					b9_1.setTextColor(Color.rgb(0, 0, 0));
					b10_1.setTextColor(Color.rgb(0, 0, 0));
					b11_1.setTextColor(Color.rgb(0, 0, 0));
					b12_1.setTextColor(Color.rgb(0, 0, 0));
					b13_1.setTextColor(Color.rgb(0, 0, 0));
					b14_1.setTextColor(Color.rgb(0, 0, 0));
					b15_1.setTextColor(Color.rgb(0, 0, 0));
					b16_1.setTextColor(Color.rgb(0, 0, 0));
					b17_1.setTextColor(Color.rgb(0, 0, 0));
					b18_1.setTextColor(Color.rgb(0, 0, 0));
					b19_1.setTextColor(Color.rgb(0, 0, 0));
					b20_1.setTextColor(Color.rgb(0, 0, 0));
					b21_1.setTextColor(Color.rgb(0, 0, 0));
					b22_1.setTextColor(Color.rgb(0, 0, 0));
					b23_1.setTextColor(Color.rgb(0, 0, 0));
					b24_1.setTextColor(Color.rgb(0, 0, 0));
					b25_1.setTextColor(Color.rgb(0, 0, 0));
					bqb2.setTextColor(Color.rgb(255, 0, 0));
					
					b1_z.setVisibility(View.VISIBLE);
					b2_z.setVisibility(View.VISIBLE);
					b3_z.setVisibility(View.VISIBLE);
					b4_z.setVisibility(View.VISIBLE);
					b5_z.setVisibility(View.VISIBLE);
					b6_z.setVisibility(View.VISIBLE);
					b7_z.setVisibility(View.VISIBLE);
					b8_z.setVisibility(View.VISIBLE);
					b9_z.setVisibility(View.VISIBLE );
					b10_z.setVisibility(View.VISIBLE);
					b11_z.setVisibility(View.VISIBLE);
					b12_z.setVisibility(View.VISIBLE);
					b13_z.setVisibility(View.VISIBLE);
					b14_z.setVisibility(View.VISIBLE);
					b15_z.setVisibility(View.VISIBLE);
					b16_z.setVisibility(View.VISIBLE);
					b17_z.setVisibility(View.VISIBLE);

					
					
				}
			});
			
			
			
			
			
			
			
			
			
			
			
			
	}
	
	private void xxz(){
		b1_2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				proProfession = "��̨��";
				onRefresh();
				b1_2.setTextColor(Color.rgb(255, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				b18_z.setVisibility(View.GONE);
			}
		});
		b2_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(255, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.VISIBLE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
				
			}
		});
		b3_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��¶��";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(255, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b4_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�źӴ�";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(255, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b5_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�鶫��";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(255, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b6_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���˴�";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(255, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b7_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�߽ܴ�";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(255, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.VISIBLE);
				b16_z.setVisibility(View.VISIBLE);
				b17_z.setVisibility(View.VISIBLE);
				
			}
		});
		b8_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "ǰӪ��";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(255, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b9_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(255, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.VISIBLE);
				b16_z.setVisibility(View.VISIBLE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b10_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(255, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b11_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "ʯ����";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(255, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.VISIBLE);
				b16_z.setVisibility(View.VISIBLE);
				b17_z.setVisibility(View.VISIBLE);
				b18_z.setVisibility(View.VISIBLE);
				
			}
		});
		b12_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "˫�Ҵ�";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(255, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.VISIBLE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b13_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "ͬ�Ĵ�";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(255, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b14_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(255, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.GONE);
				b5_z.setVisibility(View.GONE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b15_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�³���";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(255, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b16_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�½���";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(255, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b17_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�½��";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(255, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b18_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���Ͼ�";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(255, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b19_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(255, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b20_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(255, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b21_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(255, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);

			}
		});
		b22_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���Ͼ�";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(255, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b23_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(255, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b24_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�򱱾�";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(255, 0, 0));
				bqb3.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.VISIBLE);
				b16_z.setVisibility(View.VISIBLE);
				b17_z.setVisibility(View.GONE);
			}
		});
		
		bqb3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "";
				onRefresh();
				b1_2.setTextColor(Color.rgb(0, 0, 0));
				b2_2.setTextColor(Color.rgb(0, 0, 0));
				b3_2.setTextColor(Color.rgb(0, 0, 0));
				b4_2.setTextColor(Color.rgb(0, 0, 0));
				b5_2.setTextColor(Color.rgb(0, 0, 0));
				b6_2.setTextColor(Color.rgb(0, 0, 0));
				b7_2.setTextColor(Color.rgb(0, 0, 0));
				b8_2.setTextColor(Color.rgb(0, 0, 0));
				b9_2.setTextColor(Color.rgb(0, 0, 0));
				b10_2.setTextColor(Color.rgb(0, 0, 0));
				b11_2.setTextColor(Color.rgb(0, 0, 0));
				b12_2.setTextColor(Color.rgb(0, 0, 0));
				b13_2.setTextColor(Color.rgb(0, 0, 0));
				b14_2.setTextColor(Color.rgb(0, 0, 0));
				b15_2.setTextColor(Color.rgb(0, 0, 0));
				b16_2.setTextColor(Color.rgb(0, 0, 0));
				b17_2.setTextColor(Color.rgb(0, 0, 0));
				b18_2.setTextColor(Color.rgb(0, 0, 0));
				b19_2.setTextColor(Color.rgb(0, 0, 0));
				b20_2.setTextColor(Color.rgb(0, 0, 0));
				b21_2.setTextColor(Color.rgb(0, 0, 0));
				b22_2.setTextColor(Color.rgb(0, 0, 0));
				b23_2.setTextColor(Color.rgb(0, 0, 0));
				b24_2.setTextColor(Color.rgb(0, 0, 0));
				bqb3.setTextColor(Color.rgb(255, 0, 0));

				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.VISIBLE);
				b16_z.setVisibility(View.VISIBLE);
				b17_z.setVisibility(View.VISIBLE);
			}
		});
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	private void ydz(){
		b1_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��Ӣ��";
				onRefresh();
				b1_3.setTextColor(Color.rgb(255, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		
		b2_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(255, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b3_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(255, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);

			}
		});
		b4_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���ϴ�";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(255, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b5_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�׷��";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(255, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b6_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(255, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b7_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(255, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b8_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��۴�";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(255, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b9_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�³��";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(255, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b10_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�½���";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(255, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);


			}
		});
		b11_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(255, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b12_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(255, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);


			}
		});
		b13_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�ж���";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(255, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b14_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "ũҵ԰��";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(255, 0, 0));
				bqb4.setTextColor(Color.rgb(0, 0, 0));

				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		bqb4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "";
				onRefresh();
				b1_3.setTextColor(Color.rgb(0, 0, 0));
				b2_3.setTextColor(Color.rgb(0, 0, 0));
				b3_3.setTextColor(Color.rgb(0, 0, 0));
				b4_3.setTextColor(Color.rgb(0, 0, 0));
				b5_3.setTextColor(Color.rgb(0, 0, 0));
				b6_3.setTextColor(Color.rgb(0, 0, 0));
				b7_3.setTextColor(Color.rgb(0, 0, 0));
				b8_3.setTextColor(Color.rgb(0, 0, 0));
				b9_3.setTextColor(Color.rgb(0, 0, 0));
				b10_3.setTextColor(Color.rgb(0, 0, 0));
				b11_3.setTextColor(Color.rgb(0, 0, 0));
				b12_3.setTextColor(Color.rgb(0, 0, 0));
				b13_3.setTextColor(Color.rgb(0, 0, 0));
				b14_3.setTextColor(Color.rgb(0, 0, 0));
				bqb4.setTextColor(Color.rgb(255, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.VISIBLE);
				b16_z.setVisibility(View.VISIBLE);
				b17_z.setVisibility(View.VISIBLE);
			}
		});
		
		
		
		
		
		
	}
	
	private void bcz(){
		b1_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��־�";
				onRefresh();
				b1_4.setTextColor(Color.rgb(255, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);

			}
		});
		
		b2_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(255, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b3_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(255, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b4_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��´�";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(255, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b5_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���Ŵ�";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(255, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);

			}
		});
		b6_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(255, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b7_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "˼Դ��";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(255, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);

			}
		});
		b8_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�³´�";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(255, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);

			}
		});
		b9_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���Ŵ�";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(255, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.GONE);
				b5_z.setVisibility(View.GONE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b10_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(255, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.GONE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b11_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "˫�۴�";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(255, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);

			}
		});
		b12_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�繵��";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(255, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b13_4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��Ȩ��";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(255, 0, 0));
				bqb5.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);

				
			}
		});
		bqb5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "";
				onRefresh();
				b1_4.setTextColor(Color.rgb(0, 0, 0));
				b2_4.setTextColor(Color.rgb(0, 0, 0));
				b3_4.setTextColor(Color.rgb(0, 0, 0));
				b4_4.setTextColor(Color.rgb(0, 0, 0));
				b5_4.setTextColor(Color.rgb(0, 0, 0));
				b6_4.setTextColor(Color.rgb(0, 0, 0));
				b7_4.setTextColor(Color.rgb(0, 0, 0));
				b8_4.setTextColor(Color.rgb(0, 0, 0));
				b9_4.setTextColor(Color.rgb(0, 0, 0));
				b10_4.setTextColor(Color.rgb(0, 0, 0));
				b11_4.setTextColor(Color.rgb(0, 0, 0));
				b12_4.setTextColor(Color.rgb(0, 0, 0));
				b13_4.setTextColor(Color.rgb(0, 0, 0));
				bqb5.setTextColor(Color.rgb(255, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.VISIBLE);
				b16_z.setVisibility(View.VISIBLE);
				b17_z.setVisibility(View.VISIBLE);
			}
		});
		
		
		
		
	}
	
	private void hjz(){
		b1_5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�½־�";
				onRefresh();
				b1_5.setTextColor(Color.rgb(255, 0, 0));
				b2_5.setTextColor(Color.rgb(0, 0, 0));
				b3_5.setTextColor(Color.rgb(0, 0, 0));
				b4_5.setTextColor(Color.rgb(0, 0, 0));
				b5_5.setTextColor(Color.rgb(0, 0, 0));
				b6_5.setTextColor(Color.rgb(0, 0, 0));
				b7_5.setTextColor(Color.rgb(0, 0, 0));
				b8_5.setTextColor(Color.rgb(0, 0, 0));
				b9_5.setTextColor(Color.rgb(0, 0, 0));
				b10_5.setTextColor(Color.rgb(0, 0, 0));
				b11_5.setTextColor(Color.rgb(0, 0, 0));
				bqb6.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b2_5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��ͬ��";
				onRefresh();
				b1_5.setTextColor(Color.rgb(0, 0, 0));
				b2_5.setTextColor(Color.rgb(255, 0, 0));
				b3_5.setTextColor(Color.rgb(0, 0, 0));
				b4_5.setTextColor(Color.rgb(0, 0, 0));
				b5_5.setTextColor(Color.rgb(0, 0, 0));
				b6_5.setTextColor(Color.rgb(0, 0, 0));
				b7_5.setTextColor(Color.rgb(0, 0, 0));
				b8_5.setTextColor(Color.rgb(0, 0, 0));
				b9_5.setTextColor(Color.rgb(0, 0, 0));
				b10_5.setTextColor(Color.rgb(0, 0, 0));
				b11_5.setTextColor(Color.rgb(0, 0, 0));
				bqb6.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b3_5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�Ƽ��";
				onRefresh();
				b1_5.setTextColor(Color.rgb(0, 0, 0));
				b2_5.setTextColor(Color.rgb(0, 0, 0));
				b3_5.setTextColor(Color.rgb(255, 0, 0));
				b4_5.setTextColor(Color.rgb(0, 0, 0));
				b5_5.setTextColor(Color.rgb(0, 0, 0));
				b6_5.setTextColor(Color.rgb(0, 0, 0));
				b7_5.setTextColor(Color.rgb(0, 0, 0));
				b8_5.setTextColor(Color.rgb(0, 0, 0));
				b9_5.setTextColor(Color.rgb(0, 0, 0));
				b10_5.setTextColor(Color.rgb(0, 0, 0));
				b11_5.setTextColor(Color.rgb(0, 0, 0));
				bqb6.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b4_5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��բ��";
				onRefresh();
				b1_5.setTextColor(Color.rgb(0, 0, 0));
				b2_5.setTextColor(Color.rgb(0, 0, 0));
				b3_5.setTextColor(Color.rgb(0, 0, 0));
				b4_5.setTextColor(Color.rgb(255, 0, 0));
				b5_5.setTextColor(Color.rgb(0, 0, 0));
				b6_5.setTextColor(Color.rgb(0, 0, 0));
				b7_5.setTextColor(Color.rgb(0, 0, 0));
				b8_5.setTextColor(Color.rgb(0, 0, 0));
				b9_5.setTextColor(Color.rgb(0, 0, 0));
				b10_5.setTextColor(Color.rgb(0, 0, 0));
				b11_5.setTextColor(Color.rgb(0, 0, 0));
				bqb6.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b5_5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_5.setTextColor(Color.rgb(0, 0, 0));
				b2_5.setTextColor(Color.rgb(0, 0, 0));
				b3_5.setTextColor(Color.rgb(0, 0, 0));
				b4_5.setTextColor(Color.rgb(0, 0, 0));
				b5_5.setTextColor(Color.rgb(255, 0, 0));
				b6_5.setTextColor(Color.rgb(0, 0, 0));
				b7_5.setTextColor(Color.rgb(0, 0, 0));
				b8_5.setTextColor(Color.rgb(0, 0, 0));
				b9_5.setTextColor(Color.rgb(0, 0, 0));
				b10_5.setTextColor(Color.rgb(0, 0, 0));
				b11_5.setTextColor(Color.rgb(0, 0, 0));
				bqb6.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b6_5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "����";
				onRefresh();
				b1_5.setTextColor(Color.rgb(0, 0, 0));
				b2_5.setTextColor(Color.rgb(0, 0, 0));
				b3_5.setTextColor(Color.rgb(0, 0, 0));
				b4_5.setTextColor(Color.rgb(0, 0, 0));
				b5_5.setTextColor(Color.rgb(0, 0, 0));
				b6_5.setTextColor(Color.rgb(255, 0, 0));
				b7_5.setTextColor(Color.rgb(0, 0, 0));
				b8_5.setTextColor(Color.rgb(0, 0, 0));
				b9_5.setTextColor(Color.rgb(0, 0, 0));
				b10_5.setTextColor(Color.rgb(0, 0, 0));
				b11_5.setTextColor(Color.rgb(0, 0, 0));
				bqb6.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b7_5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_5.setTextColor(Color.rgb(0, 0, 0));
				b2_5.setTextColor(Color.rgb(0, 0, 0));
				b3_5.setTextColor(Color.rgb(0, 0, 0));
				b4_5.setTextColor(Color.rgb(0, 0, 0));
				b5_5.setTextColor(Color.rgb(0, 0, 0));
				b6_5.setTextColor(Color.rgb(0, 0, 0));
				b7_5.setTextColor(Color.rgb(255, 0, 0));
				b8_5.setTextColor(Color.rgb(0, 0, 0));
				b9_5.setTextColor(Color.rgb(0, 0, 0));
				b10_5.setTextColor(Color.rgb(0, 0, 0));
				b11_5.setTextColor(Color.rgb(0, 0, 0));
				bqb6.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);

				
			}
		});
		b8_5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "ָ�ϴ�";
				onRefresh();
				b1_5.setTextColor(Color.rgb(0, 0, 0));
				b2_5.setTextColor(Color.rgb(0, 0, 0));
				b3_5.setTextColor(Color.rgb(0, 0, 0));
				b4_5.setTextColor(Color.rgb(0, 0, 0));
				b5_5.setTextColor(Color.rgb(0, 0, 0));
				b6_5.setTextColor(Color.rgb(0, 0, 0));
				b7_5.setTextColor(Color.rgb(0, 0, 0));
				b8_5.setTextColor(Color.rgb(255, 0, 0));
				b9_5.setTextColor(Color.rgb(0, 0, 0));
				b10_5.setTextColor(Color.rgb(0, 0, 0));
				b11_5.setTextColor(Color.rgb(0, 0, 0));
				bqb6.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b9_5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��ũ��";
				onRefresh();
				b1_5.setTextColor(Color.rgb(0, 0, 0));
				b2_5.setTextColor(Color.rgb(0, 0, 0));
				b3_5.setTextColor(Color.rgb(0, 0, 0));
				b4_5.setTextColor(Color.rgb(0, 0, 0));
				b5_5.setTextColor(Color.rgb(0, 0, 0));
				b6_5.setTextColor(Color.rgb(0, 0, 0));
				b7_5.setTextColor(Color.rgb(0, 0, 0));
				b8_5.setTextColor(Color.rgb(0, 0, 0));
				b9_5.setTextColor(Color.rgb(255, 0, 0));
				b10_5.setTextColor(Color.rgb(0, 0, 0));
				b11_5.setTextColor(Color.rgb(0, 0, 0));
				bqb6.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b10_5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "����۾�";
				onRefresh();
				b1_5.setTextColor(Color.rgb(0, 0, 0));
				b2_5.setTextColor(Color.rgb(0, 0, 0));
				b3_5.setTextColor(Color.rgb(0, 0, 0));
				b4_5.setTextColor(Color.rgb(0, 0, 0));
				b5_5.setTextColor(Color.rgb(0, 0, 0));
				b6_5.setTextColor(Color.rgb(0, 0, 0));
				b7_5.setTextColor(Color.rgb(0, 0, 0));
				b8_5.setTextColor(Color.rgb(0, 0, 0));
				b9_5.setTextColor(Color.rgb(0, 0, 0));
				b10_5.setTextColor(Color.rgb(255, 0, 0));
				b11_5.setTextColor(Color.rgb(0, 0, 0));
				bqb6.setTextColor(Color.rgb(0, 0, 0));
				
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b11_5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��̲��˾";
				onRefresh();
				b1_5.setTextColor(Color.rgb(0, 0, 0));
				b2_5.setTextColor(Color.rgb(0, 0, 0));
				b3_5.setTextColor(Color.rgb(0, 0, 0));
				b4_5.setTextColor(Color.rgb(0, 0, 0));
				b5_5.setTextColor(Color.rgb(0, 0, 0));
				b6_5.setTextColor(Color.rgb(0, 0, 0));
				b7_5.setTextColor(Color.rgb(0, 0, 0));
				b8_5.setTextColor(Color.rgb(0, 0, 0));
				b9_5.setTextColor(Color.rgb(0, 0, 0));
				b10_5.setTextColor(Color.rgb(0, 0, 0));
				b11_5.setTextColor(Color.rgb(255, 0, 0));
				bqb6.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		bqb6.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "";
				onRefresh();
				b1_5.setTextColor(Color.rgb(0, 0, 0));
				b2_5.setTextColor(Color.rgb(0, 0, 0));
				b3_5.setTextColor(Color.rgb(0, 0, 0));
				b4_5.setTextColor(Color.rgb(0, 0, 0));
				b5_5.setTextColor(Color.rgb(0, 0, 0));
				b6_5.setTextColor(Color.rgb(0, 0, 0));
				b7_5.setTextColor(Color.rgb(0, 0, 0));
				b8_5.setTextColor(Color.rgb(0, 0, 0));
				b9_5.setTextColor(Color.rgb(0, 0, 0));
				b10_5.setTextColor(Color.rgb(0, 0, 0));
				b11_5.setTextColor(Color.rgb(0, 0, 0));
				bqb6.setTextColor(Color.rgb(255, 0, 0));
				

				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.VISIBLE);
				b16_z.setVisibility(View.VISIBLE);
				b17_z.setVisibility(View.VISIBLE);
			}
		});
		
		
		
		
		
		
		
		
	}
	
	private void thjjkfq(){
		b1_6.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_6.setTextColor(Color.rgb(255, 0, 0));
				b2_6.setTextColor(Color.rgb(0, 0, 0));
				b3_6.setTextColor(Color.rgb(0, 0, 0));
				b4_6.setTextColor(Color.rgb(0, 0, 0));
				b5_6.setTextColor(Color.rgb(0, 0, 0));
				b6_6.setTextColor(Color.rgb(0, 0, 0));
				b7_6.setTextColor(Color.rgb(0, 0, 0));
				b8_6.setTextColor(Color.rgb(0, 0, 0));
				bqb7.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b2_6.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_6.setTextColor(Color.rgb(0, 0, 0));
				b2_6.setTextColor(Color.rgb(255, 0, 0));
				b3_6.setTextColor(Color.rgb(0, 0, 0));
				b4_6.setTextColor(Color.rgb(0, 0, 0));
				b5_6.setTextColor(Color.rgb(0, 0, 0));
				b6_6.setTextColor(Color.rgb(0, 0, 0));
				b7_6.setTextColor(Color.rgb(0, 0, 0));
				b8_6.setTextColor(Color.rgb(0, 0, 0));
				bqb7.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);

			}
		});
		b3_6.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_6.setTextColor(Color.rgb(0, 0, 0));
				b2_6.setTextColor(Color.rgb(0, 0, 0));
				b3_6.setTextColor(Color.rgb(255, 0, 0));
				b4_6.setTextColor(Color.rgb(0, 0, 0));
				b5_6.setTextColor(Color.rgb(0, 0, 0));
				b6_6.setTextColor(Color.rgb(0, 0, 0));
				b7_6.setTextColor(Color.rgb(0, 0, 0));
				b8_6.setTextColor(Color.rgb(0, 0, 0));
				bqb7.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b4_6.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_6.setTextColor(Color.rgb(0, 0, 0));
				b2_6.setTextColor(Color.rgb(0, 0, 0));
				b3_6.setTextColor(Color.rgb(0, 0, 0));
				b4_6.setTextColor(Color.rgb(255, 0, 0));
				b5_6.setTextColor(Color.rgb(0, 0, 0));
				b6_6.setTextColor(Color.rgb(0, 0, 0));
				b7_6.setTextColor(Color.rgb(0, 0, 0));
				b8_6.setTextColor(Color.rgb(0, 0, 0));
				bqb7.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
			}
		});
		b5_6.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_6.setTextColor(Color.rgb(0, 0, 0));
				b2_6.setTextColor(Color.rgb(0, 0, 0));
				b3_6.setTextColor(Color.rgb(0, 0, 0));
				b4_6.setTextColor(Color.rgb(0, 0, 0));
				b5_6.setTextColor(Color.rgb(255, 0, 0));
				b6_6.setTextColor(Color.rgb(0, 0, 0));
				b7_6.setTextColor(Color.rgb(0, 0, 0));
				b8_6.setTextColor(Color.rgb(0, 0, 0));
				bqb7.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b6_6.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��ӳ����";
				onRefresh();
				b1_6.setTextColor(Color.rgb(0, 0, 0));
				b2_6.setTextColor(Color.rgb(0, 0, 0));
				b3_6.setTextColor(Color.rgb(0, 0, 0));
				b4_6.setTextColor(Color.rgb(0, 0, 0));
				b5_6.setTextColor(Color.rgb(0, 0, 0));
				b6_6.setTextColor(Color.rgb(255, 0, 0));
				b7_6.setTextColor(Color.rgb(0, 0, 0));
				b8_6.setTextColor(Color.rgb(0, 0, 0));
				bqb7.setTextColor(Color.rgb(0, 0, 0));

				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);
				
			}
		});
		b7_6.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�·�����";
				onRefresh();
				b1_6.setTextColor(Color.rgb(0, 0, 0));
				b2_6.setTextColor(Color.rgb(0, 0, 0));
				b3_6.setTextColor(Color.rgb(0, 0, 0));
				b4_6.setTextColor(Color.rgb(0, 0, 0));
				b5_6.setTextColor(Color.rgb(0, 0, 0));
				b6_6.setTextColor(Color.rgb(0, 0, 0));
				b7_6.setTextColor(Color.rgb(255, 0, 0));
				b8_6.setTextColor(Color.rgb(0, 0, 0));
				bqb7.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);

				
			}
		});
		b8_6.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���ݴ�";
				onRefresh();
				b1_6.setTextColor(Color.rgb(0, 0, 0));
				b2_6.setTextColor(Color.rgb(0, 0, 0));
				b3_6.setTextColor(Color.rgb(0, 0, 0));
				b4_6.setTextColor(Color.rgb(0, 0, 0));
				b5_6.setTextColor(Color.rgb(0, 0, 0));
				b6_6.setTextColor(Color.rgb(0, 0, 0));
				b7_6.setTextColor(Color.rgb(0, 0, 0));
				b8_6.setTextColor(Color.rgb(255, 0, 0));
				bqb7.setTextColor(Color.rgb(0, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.GONE);
				b7_z.setVisibility(View.GONE);
				b8_z.setVisibility(View.GONE);
				b9_z.setVisibility(View.GONE);
				b10_z.setVisibility(View.GONE);
				b11_z.setVisibility(View.GONE);
				b12_z.setVisibility(View.GONE);
				b13_z.setVisibility(View.GONE);
				b14_z.setVisibility(View.GONE);
				b15_z.setVisibility(View.GONE);
				b16_z.setVisibility(View.GONE);
				b17_z.setVisibility(View.GONE);

			}
		});
		bqb7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "";
				onRefresh();
				b1_6.setTextColor(Color.rgb(0, 0, 0));
				b2_6.setTextColor(Color.rgb(0, 0, 0));
				b3_6.setTextColor(Color.rgb(0, 0, 0));
				b4_6.setTextColor(Color.rgb(0, 0, 0));
				b5_6.setTextColor(Color.rgb(0, 0, 0));
				b6_6.setTextColor(Color.rgb(0, 0, 0));
				b7_6.setTextColor(Color.rgb(0, 0, 0));
				b8_6.setTextColor(Color.rgb(0, 0, 0));
				bqb7.setTextColor(Color.rgb(255, 0, 0));
				b1_z.setVisibility(View.VISIBLE);
				b2_z.setVisibility(View.VISIBLE);
				b3_z.setVisibility(View.VISIBLE);
				b4_z.setVisibility(View.VISIBLE);
				b5_z.setVisibility(View.VISIBLE);
				b6_z.setVisibility(View.VISIBLE);
				b7_z.setVisibility(View.VISIBLE);
				b8_z.setVisibility(View.VISIBLE);
				b9_z.setVisibility(View.VISIBLE );
				b10_z.setVisibility(View.VISIBLE);
				b11_z.setVisibility(View.VISIBLE);
				b12_z.setVisibility(View.VISIBLE);
				b13_z.setVisibility(View.VISIBLE);
				b14_z.setVisibility(View.VISIBLE);
				b15_z.setVisibility(View.VISIBLE);
				b16_z.setVisibility(View.VISIBLE);
				b17_z.setVisibility(View.VISIBLE);
			}
		});
		
		
		
		
		
	}
	
	private void xyjjq(){
		b1_7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "Ԭ�Ӵ�";
				onRefresh();
				b1_7.setTextColor(Color.rgb(255, 0, 0));
				b2_7.setTextColor(Color.rgb(0, 0, 0));
				b3_7.setTextColor(Color.rgb(0, 0, 0));
				b4_7.setTextColor(Color.rgb(0, 0, 0));
				b5_7.setTextColor(Color.rgb(0, 0, 0));
				b6_7.setTextColor(Color.rgb(0, 0, 0));
				b7_7.setTextColor(Color.rgb(0, 0, 0));
				b8_7.setTextColor(Color.rgb(0, 0, 0));
				b9_7.setTextColor(Color.rgb(0, 0, 0));
				b10_7.setTextColor(Color.rgb(0, 0, 0));
				b11_7.setTextColor(Color.rgb(0, 0, 0));
				b12_7.setTextColor(Color.rgb(0, 0, 0));
				bqb8.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b2_7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��Ӣ��";
				onRefresh();
				b1_7.setTextColor(Color.rgb(0, 0, 0));
				b2_7.setTextColor(Color.rgb(255, 0, 0));
				b3_7.setTextColor(Color.rgb(0, 0, 0));
				b4_7.setTextColor(Color.rgb(0, 0, 0));
				b5_7.setTextColor(Color.rgb(0, 0, 0));
				b6_7.setTextColor(Color.rgb(0, 0, 0));
				b7_7.setTextColor(Color.rgb(0, 0, 0));
				b8_7.setTextColor(Color.rgb(0, 0, 0));
				b9_7.setTextColor(Color.rgb(0, 0, 0));
				b10_7.setTextColor(Color.rgb(0, 0, 0));
				b11_7.setTextColor(Color.rgb(0, 0, 0));
				b12_7.setTextColor(Color.rgb(0, 0, 0));
				bqb8.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b3_7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���Ŵ�";
				onRefresh();
				b1_7.setTextColor(Color.rgb(0, 0, 0));
				b2_7.setTextColor(Color.rgb(0, 0, 0));
				b3_7.setTextColor(Color.rgb(255, 0, 0));
				b4_7.setTextColor(Color.rgb(0, 0, 0));
				b5_7.setTextColor(Color.rgb(0, 0, 0));
				b6_7.setTextColor(Color.rgb(0, 0, 0));
				b7_7.setTextColor(Color.rgb(0, 0, 0));
				b8_7.setTextColor(Color.rgb(0, 0, 0));
				b9_7.setTextColor(Color.rgb(0, 0, 0));
				b10_7.setTextColor(Color.rgb(0, 0, 0));
				b11_7.setTextColor(Color.rgb(0, 0, 0));
				b12_7.setTextColor(Color.rgb(0, 0, 0));
				bqb8.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b4_7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "Ԭׯ��";
				onRefresh();
				b1_7.setTextColor(Color.rgb(0, 0, 0));
				b2_7.setTextColor(Color.rgb(0, 0, 0));
				b3_7.setTextColor(Color.rgb(0, 0, 0));
				b4_7.setTextColor(Color.rgb(255, 0, 0));
				b5_7.setTextColor(Color.rgb(0, 0, 0));
				b6_7.setTextColor(Color.rgb(0, 0, 0));
				b7_7.setTextColor(Color.rgb(0, 0, 0));
				b8_7.setTextColor(Color.rgb(0, 0, 0));
				b9_7.setTextColor(Color.rgb(0, 0, 0));
				b10_7.setTextColor(Color.rgb(0, 0, 0));
				b11_7.setTextColor(Color.rgb(0, 0, 0));
				b12_7.setTextColor(Color.rgb(0, 0, 0));
				bqb8.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b5_7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_7.setTextColor(Color.rgb(0, 0, 0));
				b2_7.setTextColor(Color.rgb(0, 0, 0));
				b3_7.setTextColor(Color.rgb(0, 0, 0));
				b4_7.setTextColor(Color.rgb(0, 0, 0));
				b5_7.setTextColor(Color.rgb(255, 0, 0));
				b6_7.setTextColor(Color.rgb(0, 0, 0));
				b7_7.setTextColor(Color.rgb(0, 0, 0));
				b8_7.setTextColor(Color.rgb(0, 0, 0));
				b9_7.setTextColor(Color.rgb(0, 0, 0));
				b10_7.setTextColor(Color.rgb(0, 0, 0));
				b11_7.setTextColor(Color.rgb(0, 0, 0));
				b12_7.setTextColor(Color.rgb(0, 0, 0));
				bqb8.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b6_7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_7.setTextColor(Color.rgb(0, 0, 0));
				b2_7.setTextColor(Color.rgb(0, 0, 0));
				b3_7.setTextColor(Color.rgb(0, 0, 0));
				b4_7.setTextColor(Color.rgb(0, 0, 0));
				b5_7.setTextColor(Color.rgb(0, 0, 0));
				b6_7.setTextColor(Color.rgb(255, 0, 0));
				b7_7.setTextColor(Color.rgb(0, 0, 0));
				b8_7.setTextColor(Color.rgb(0, 0, 0));
				b9_7.setTextColor(Color.rgb(0, 0, 0));
				b10_7.setTextColor(Color.rgb(0, 0, 0));
				b11_7.setTextColor(Color.rgb(0, 0, 0));
				b12_7.setTextColor(Color.rgb(0, 0, 0));
				bqb8.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b7_7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��բ��";
				onRefresh();
				b1_7.setTextColor(Color.rgb(0, 0, 0));
				b2_7.setTextColor(Color.rgb(0, 0, 0));
				b3_7.setTextColor(Color.rgb(0, 0, 0));
				b4_7.setTextColor(Color.rgb(0, 0, 0));
				b5_7.setTextColor(Color.rgb(0, 0, 0));
				b6_7.setTextColor(Color.rgb(0, 0, 0));
				b7_7.setTextColor(Color.rgb(255, 0, 0));
				b8_7.setTextColor(Color.rgb(0, 0, 0));
				b9_7.setTextColor(Color.rgb(0, 0, 0));
				b10_7.setTextColor(Color.rgb(0, 0, 0));
				b11_7.setTextColor(Color.rgb(0, 0, 0));
				b12_7.setTextColor(Color.rgb(0, 0, 0));
				bqb8.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b8_7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_7.setTextColor(Color.rgb(0, 0, 0));
				b2_7.setTextColor(Color.rgb(0, 0, 0));
				b3_7.setTextColor(Color.rgb(0, 0, 0));
				b4_7.setTextColor(Color.rgb(0, 0, 0));
				b5_7.setTextColor(Color.rgb(0, 0, 0));
				b6_7.setTextColor(Color.rgb(0, 0, 0));
				b7_7.setTextColor(Color.rgb(0, 0, 0));
				b8_7.setTextColor(Color.rgb(255, 0, 0));
				b9_7.setTextColor(Color.rgb(0, 0, 0));
				b10_7.setTextColor(Color.rgb(0, 0, 0));
				b11_7.setTextColor(Color.rgb(0, 0, 0));
				b12_7.setTextColor(Color.rgb(0, 0, 0));
				bqb8.setTextColor(Color.rgb(0, 0, 0));

				b_zu.setVisibility(View.GONE);
				xingyangjjq.setVisibility(View.VISIBLE);
			}
		});
		b9_7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�·�����";
				onRefresh();
				b1_7.setTextColor(Color.rgb(0, 0, 0));
				b2_7.setTextColor(Color.rgb(0, 0, 0));
				b3_7.setTextColor(Color.rgb(0, 0, 0));
				b4_7.setTextColor(Color.rgb(0, 0, 0));
				b5_7.setTextColor(Color.rgb(0, 0, 0));
				b6_7.setTextColor(Color.rgb(0, 0, 0));
				b7_7.setTextColor(Color.rgb(0, 0, 0));
				b8_7.setTextColor(Color.rgb(0, 0, 0));
				b9_7.setTextColor(Color.rgb(255, 0, 0));
				b10_7.setTextColor(Color.rgb(0, 0, 0));
				b11_7.setTextColor(Color.rgb(0, 0, 0));
				b12_7.setTextColor(Color.rgb(0, 0, 0));
				bqb8.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b10_7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "ͯ�ҹ�����";
				onRefresh();
				b1_7.setTextColor(Color.rgb(0, 0, 0));
				b2_7.setTextColor(Color.rgb(0, 0, 0));
				b3_7.setTextColor(Color.rgb(0, 0, 0));
				b4_7.setTextColor(Color.rgb(0, 0, 0));
				b5_7.setTextColor(Color.rgb(0, 0, 0));
				b6_7.setTextColor(Color.rgb(0, 0, 0));
				b7_7.setTextColor(Color.rgb(0, 0, 0));
				b8_7.setTextColor(Color.rgb(0, 0, 0));
				b9_7.setTextColor(Color.rgb(0, 0, 0));
				b10_7.setTextColor(Color.rgb(255, 0, 0));
				b11_7.setTextColor(Color.rgb(0, 0, 0));
				b12_7.setTextColor(Color.rgb(0, 0, 0));
				bqb8.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b11_7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�Ǳ�����";
				onRefresh();
				b1_7.setTextColor(Color.rgb(0, 0, 0));
				b2_7.setTextColor(Color.rgb(0, 0, 0));
				b3_7.setTextColor(Color.rgb(0, 0, 0));
				b4_7.setTextColor(Color.rgb(0, 0, 0));
				b5_7.setTextColor(Color.rgb(0, 0, 0));
				b6_7.setTextColor(Color.rgb(0, 0, 0));
				b7_7.setTextColor(Color.rgb(0, 0, 0));
				b8_7.setTextColor(Color.rgb(0, 0, 0));
				b9_7.setTextColor(Color.rgb(0, 0, 0));
				b10_7.setTextColor(Color.rgb(0, 0, 0));
				b11_7.setTextColor(Color.rgb(255, 0, 0));
				b12_7.setTextColor(Color.rgb(0, 0, 0));
				bqb8.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b12_7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�ε�����";
				onRefresh();
				b1_7.setTextColor(Color.rgb(0, 0, 0));
				b2_7.setTextColor(Color.rgb(0, 0, 0));
				b3_7.setTextColor(Color.rgb(0, 0, 0));
				b4_7.setTextColor(Color.rgb(0, 0, 0));
				b5_7.setTextColor(Color.rgb(0, 0, 0));
				b6_7.setTextColor(Color.rgb(0, 0, 0));
				b7_7.setTextColor(Color.rgb(0, 0, 0));
				b8_7.setTextColor(Color.rgb(0, 0, 0));
				b9_7.setTextColor(Color.rgb(0, 0, 0));
				b10_7.setTextColor(Color.rgb(0, 0, 0));
				b11_7.setTextColor(Color.rgb(0, 0, 0));
				b12_7.setTextColor(Color.rgb(255, 0, 0));
				bqb8.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		bqb8.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "";
				onRefresh();
				b1_7.setTextColor(Color.rgb(0, 0, 0));
				b2_7.setTextColor(Color.rgb(0, 0, 0));
				b3_7.setTextColor(Color.rgb(0, 0, 0));
				b4_7.setTextColor(Color.rgb(0, 0, 0));
				b5_7.setTextColor(Color.rgb(0, 0, 0));
				b6_7.setTextColor(Color.rgb(0, 0, 0));
				b7_7.setTextColor(Color.rgb(0, 0, 0));
				b8_7.setTextColor(Color.rgb(0, 0, 0));
				b9_7.setTextColor(Color.rgb(0, 0, 0));
				b10_7.setTextColor(Color.rgb(0, 0, 0));
				b11_7.setTextColor(Color.rgb(0, 0, 0));
				b12_7.setTextColor(Color.rgb(0, 0, 0));
				bqb8.setTextColor(Color.rgb(255, 0, 0));
			}
		});
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	private void hbkjc(){
		b1_8.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_8.setTextColor(Color.rgb(255, 0, 0));
				b2_8.setTextColor(Color.rgb(0, 0, 0));
				b3_8.setTextColor(Color.rgb(0, 0, 0));
				b4_8.setTextColor(Color.rgb(0, 0, 0));
				b5_8.setTextColor(Color.rgb(0, 0, 0));
				b6_8.setTextColor(Color.rgb(0, 0, 0));
				bqb9.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b2_8.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���ִ�";
				onRefresh();
				b1_8.setTextColor(Color.rgb(0, 0, 0));
				b2_8.setTextColor(Color.rgb(255, 0, 0));
				b3_8.setTextColor(Color.rgb(0, 0, 0));
				b4_8.setTextColor(Color.rgb(0, 0, 0));
				b5_8.setTextColor(Color.rgb(0, 0, 0));
				b6_8.setTextColor(Color.rgb(0, 0, 0));
				bqb9.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b3_8.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "����";
				onRefresh();
				b1_8.setTextColor(Color.rgb(0, 0, 0));
				b2_8.setTextColor(Color.rgb(0, 0, 0));
				b3_8.setTextColor(Color.rgb(255, 0, 0));
				b4_8.setTextColor(Color.rgb(0, 0, 0));
				b5_8.setTextColor(Color.rgb(0, 0, 0));
				b6_8.setTextColor(Color.rgb(0, 0, 0));
				bqb9.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b4_8.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_8.setTextColor(Color.rgb(0, 0, 0));
				b2_8.setTextColor(Color.rgb(0, 0, 0));
				b3_8.setTextColor(Color.rgb(0, 0, 0));
				b4_8.setTextColor(Color.rgb(255, 0, 0));
				b5_8.setTextColor(Color.rgb(0, 0, 0));
				b6_8.setTextColor(Color.rgb(0, 0, 0));
				bqb9.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b5_8.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_8.setTextColor(Color.rgb(0, 0, 0));
				b2_8.setTextColor(Color.rgb(0, 0, 0));
				b3_8.setTextColor(Color.rgb(0, 0, 0));
				b4_8.setTextColor(Color.rgb(0, 0, 0));
				b5_8.setTextColor(Color.rgb(255, 0, 0));
				b6_8.setTextColor(Color.rgb(0, 0, 0));
				bqb9.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b6_8.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�¸۴�";
				onRefresh();
				b1_8.setTextColor(Color.rgb(0, 0, 0));
				b2_8.setTextColor(Color.rgb(0, 0, 0));
				b3_8.setTextColor(Color.rgb(0, 0, 0));
				b4_8.setTextColor(Color.rgb(0, 0, 0));
				b5_8.setTextColor(Color.rgb(0, 0, 0));
				b6_8.setTextColor(Color.rgb(255, 0, 0));
				bqb9.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		bqb9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "";
				onRefresh();
				b1_8.setTextColor(Color.rgb(0, 0, 0));
				b2_8.setTextColor(Color.rgb(0, 0, 0));
				b3_8.setTextColor(Color.rgb(0, 0, 0));
				b4_8.setTextColor(Color.rgb(0, 0, 0));
				b5_8.setTextColor(Color.rgb(0, 0, 0));
				b6_8.setTextColor(Color.rgb(0, 0, 0));
				bqb9.setTextColor(Color.rgb(255, 0, 0));
			}
		});
	}
	
	private void yljd(){
		b1_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���Ǵ�";
				onRefresh();
				b1_9.setTextColor(Color.rgb(255, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b2_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(255, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b3_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(255, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b4_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��ǰ·����";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(255, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b5_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "̲Ϳ����";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(255, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b6_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�Ŷ�����";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(255, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b7_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "����·����";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(255, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b8_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���籱������";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(255, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b9_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��ʥ����";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(255, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b10_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��ʮ������";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(255, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b11_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(255, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b12_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(255, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b13_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(255, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b14_9.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���������";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(255, 0, 0));
				bqb10.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		bqb10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "";
				onRefresh();
				b1_9.setTextColor(Color.rgb(0, 0, 0));
				b2_9.setTextColor(Color.rgb(0, 0, 0));
				b3_9.setTextColor(Color.rgb(0, 0, 0));
				b4_9.setTextColor(Color.rgb(0, 0, 0));
				b5_9.setTextColor(Color.rgb(0, 0, 0));
				b6_9.setTextColor(Color.rgb(0, 0, 0));
				b7_9.setTextColor(Color.rgb(0, 0, 0));
				b8_9.setTextColor(Color.rgb(0, 0, 0));
				b9_9.setTextColor(Color.rgb(0, 0, 0));
				b10_9.setTextColor(Color.rgb(0, 0, 0));
				b11_9.setTextColor(Color.rgb(0, 0, 0));
				b12_9.setTextColor(Color.rgb(0, 0, 0));
				b13_9.setTextColor(Color.rgb(0, 0, 0));
				b14_9.setTextColor(Color.rgb(0, 0, 0));
				bqb10.setTextColor(Color.rgb(255, 0, 0));
			}
		});
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	private void xfjd(){
		b1_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���Ӵ�";
				onRefresh();
				b1_10.setTextColor(Color.rgb(255, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b2_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "������";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(255, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b3_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(255, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b4_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�ȷ�����";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(255, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b5_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�糡·����";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(255, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b6_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�Ҹ�·����";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(255, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b7_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "����·����";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(255, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b8_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "����·����";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(255, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b9_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "����·����";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(255, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b10_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(255, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b11_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�½�����";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(255, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b12_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "Խ��·����";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(255, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b13_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "����·����";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(255, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b14_10.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��Զ·����";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(255, 0, 0));
				bqb11.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		bqb11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "";
				onRefresh();
				b1_10.setTextColor(Color.rgb(0, 0, 0));
				b2_10.setTextColor(Color.rgb(0, 0, 0));
				b3_10.setTextColor(Color.rgb(0, 0, 0));
				b4_10.setTextColor(Color.rgb(0, 0, 0));
				b5_10.setTextColor(Color.rgb(0, 0, 0));
				b6_10.setTextColor(Color.rgb(0, 0, 0));
				b7_10.setTextColor(Color.rgb(0, 0, 0));
				b8_10.setTextColor(Color.rgb(0, 0, 0));
				b9_10.setTextColor(Color.rgb(0, 0, 0));
				b10_10.setTextColor(Color.rgb(0, 0, 0));
				b11_10.setTextColor(Color.rgb(0, 0, 0));
				b12_10.setTextColor(Color.rgb(0, 0, 0));
				b13_10.setTextColor(Color.rgb(0, 0, 0));
				b14_10.setTextColor(Color.rgb(0, 0, 0));
				bqb11.setTextColor(Color.rgb(255, 0, 0));
			}
		});
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	private void wfjd(){
		b1_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "˫Ԫ��";
				onRefresh();
				b1_11.setTextColor(Color.rgb(255, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b2_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���Ӵ�";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(255, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b3_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��Ԫ������";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(255, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b4_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���������";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(255, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b5_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��ѧ����";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(255, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b6_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(255, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b7_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "ӭ��������";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(255, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b8_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(255, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b9_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "����·����";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(255, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b10_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�غ�����";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(255, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b11_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��Է����";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(255, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b12_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(255, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b13_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(255, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b14_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(255, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b15_11.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "˫Ԫ·����";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(255, 0, 0));
				bqb12.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		bqb12.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = " ";
				onRefresh();
				b1_11.setTextColor(Color.rgb(0, 0, 0));
				b2_11.setTextColor(Color.rgb(0, 0, 0));
				b3_11.setTextColor(Color.rgb(0, 0, 0));
				b4_11.setTextColor(Color.rgb(0, 0, 0));
				b5_11.setTextColor(Color.rgb(0, 0, 0));
				b6_11.setTextColor(Color.rgb(0, 0, 0));
				b7_11.setTextColor(Color.rgb(0, 0, 0));
				b8_11.setTextColor(Color.rgb(0, 0, 0));
				b9_11.setTextColor(Color.rgb(0, 0, 0));
				b10_11.setTextColor(Color.rgb(0, 0, 0));
				b11_11.setTextColor(Color.rgb(0, 0, 0));
				b12_11.setTextColor(Color.rgb(0, 0, 0));
				b13_11.setTextColor(Color.rgb(0, 0, 0));
				b14_11.setTextColor(Color.rgb(0, 0, 0));
				b15_11.setTextColor(Color.rgb(0, 0, 0));
				bqb12.setTextColor(Color.rgb(255, 0, 0));
			}
		});
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	private void dyjd(){
		b1_12.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����";
				onRefresh();
				b1_12.setTextColor(Color.rgb(255, 0, 0));
				b2_12.setTextColor(Color.rgb(0, 0, 0));
				b3_12.setTextColor(Color.rgb(0, 0, 0));
				b4_12.setTextColor(Color.rgb(0, 0, 0));
				b5_12.setTextColor(Color.rgb(0, 0, 0));
				b6_12.setTextColor(Color.rgb(0, 0, 0));
				b7_12.setTextColor(Color.rgb(0, 0, 0));
				b8_12.setTextColor(Color.rgb(0, 0, 0));
				bqb13.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b2_12.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���Ǵ�";
				onRefresh();
				b1_12.setTextColor(Color.rgb(0, 0, 0));
				b2_12.setTextColor(Color.rgb(255, 0, 0));
				b3_12.setTextColor(Color.rgb(0, 0, 0));
				b4_12.setTextColor(Color.rgb(0, 0, 0));
				b5_12.setTextColor(Color.rgb(0, 0, 0));
				b6_12.setTextColor(Color.rgb(0, 0, 0));
				b7_12.setTextColor(Color.rgb(0, 0, 0));
				b8_12.setTextColor(Color.rgb(0, 0, 0));
				bqb13.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b3_12.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�����´�����";
				onRefresh();
				b1_12.setTextColor(Color.rgb(0, 0, 0));
				b2_12.setTextColor(Color.rgb(0, 0, 0));
				b3_12.setTextColor(Color.rgb(255, 0, 0));
				b4_12.setTextColor(Color.rgb(0, 0, 0));
				b5_12.setTextColor(Color.rgb(0, 0, 0));
				b6_12.setTextColor(Color.rgb(0, 0, 0));
				b7_12.setTextColor(Color.rgb(0, 0, 0));
				b8_12.setTextColor(Color.rgb(0, 0, 0));
				bqb13.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b4_12.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_12.setTextColor(Color.rgb(0, 0, 0));
				b2_12.setTextColor(Color.rgb(0, 0, 0));
				b3_12.setTextColor(Color.rgb(0, 0, 0));
				b4_12.setTextColor(Color.rgb(255, 0, 0));
				b5_12.setTextColor(Color.rgb(0, 0, 0));
				b6_12.setTextColor(Color.rgb(0, 0, 0));
				b7_12.setTextColor(Color.rgb(0, 0, 0));
				b8_12.setTextColor(Color.rgb(0, 0, 0));
				bqb13.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b5_12.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "ͨ�ܱ�������";
				onRefresh();
				b1_12.setTextColor(Color.rgb(0, 0, 0));
				b2_12.setTextColor(Color.rgb(0, 0, 0));
				b3_12.setTextColor(Color.rgb(0, 0, 0));
				b4_12.setTextColor(Color.rgb(0, 0, 0));
				b5_12.setTextColor(Color.rgb(255, 0, 0));
				b6_12.setTextColor(Color.rgb(0, 0, 0));
				b7_12.setTextColor(Color.rgb(0, 0, 0));
				b8_12.setTextColor(Color.rgb(0, 0, 0));
				bqb13.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b6_12.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�κ�����";
				onRefresh();
				b1_12.setTextColor(Color.rgb(0, 0, 0));
				b2_12.setTextColor(Color.rgb(0, 0, 0));
				b3_12.setTextColor(Color.rgb(0, 0, 0));
				b4_12.setTextColor(Color.rgb(0, 0, 0));
				b5_12.setTextColor(Color.rgb(0, 0, 0));
				b6_12.setTextColor(Color.rgb(255, 0, 0));
				b7_12.setTextColor(Color.rgb(0, 0, 0));
				b8_12.setTextColor(Color.rgb(0, 0, 0));
				bqb13.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b7_12.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_12.setTextColor(Color.rgb(0, 0, 0));
				b2_12.setTextColor(Color.rgb(0, 0, 0));
				b3_12.setTextColor(Color.rgb(0, 0, 0));
				b4_12.setTextColor(Color.rgb(0, 0, 0));
				b5_12.setTextColor(Color.rgb(0, 0, 0));
				b6_12.setTextColor(Color.rgb(0, 0, 0));
				b7_12.setTextColor(Color.rgb(255, 0, 0));
				b8_12.setTextColor(Color.rgb(0, 0, 0));
				bqb13.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b8_12.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "ع����԰����";
				onRefresh();
				b1_12.setTextColor(Color.rgb(0, 0, 0));
				b2_12.setTextColor(Color.rgb(0, 0, 0));
				b3_12.setTextColor(Color.rgb(0, 0, 0));
				b4_12.setTextColor(Color.rgb(0, 0, 0));
				b5_12.setTextColor(Color.rgb(0, 0, 0));
				b6_12.setTextColor(Color.rgb(0, 0, 0));
				b7_12.setTextColor(Color.rgb(0, 0, 0));
				b8_12.setTextColor(Color.rgb(255, 0, 0));
				bqb13.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		bqb13.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = " ";
				onRefresh();
				b1_12.setTextColor(Color.rgb(0, 0, 0));
				b2_12.setTextColor(Color.rgb(0, 0, 0));
				b3_12.setTextColor(Color.rgb(0, 0, 0));
				b4_12.setTextColor(Color.rgb(0, 0, 0));
				b5_12.setTextColor(Color.rgb(0, 0, 0));
				b6_12.setTextColor(Color.rgb(0, 0, 0));
				b7_12.setTextColor(Color.rgb(0, 0, 0));
				b8_12.setTextColor(Color.rgb(0, 0, 0));
				bqb13.setTextColor(Color.rgb(255, 0, 0));
			}
		});
		
		
		
		
		
		
		
	}
	
	private void wxjd(){
		b1_13.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "���Ǵ�";
				onRefresh();
				b1_13.setTextColor(Color.rgb(255, 0, 0));
				b2_13.setTextColor(Color.rgb(0, 0, 0));
				b3_13.setTextColor(Color.rgb(0, 0, 0));
				b4_13.setTextColor(Color.rgb(0, 0, 0));
				b5_13.setTextColor(Color.rgb(0, 0, 0));
				b6_13.setTextColor(Color.rgb(0, 0, 0));
				b7_13.setTextColor(Color.rgb(0, 0, 0));
				b8_13.setTextColor(Color.rgb(0, 0, 0));
				b9_13.setTextColor(Color.rgb(0, 0, 0));
				b10_13.setTextColor(Color.rgb(0, 0, 0));
				b11_13.setTextColor(Color.rgb(0, 0, 0));
				bqb14.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b2_13.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�ź�����";
				onRefresh();
				b1_13.setTextColor(Color.rgb(0, 0, 0));
				b2_13.setTextColor(Color.rgb(255, 0, 0));
				b3_13.setTextColor(Color.rgb(0, 0, 0));
				b4_13.setTextColor(Color.rgb(0, 0, 0));
				b5_13.setTextColor(Color.rgb(0, 0, 0));
				b6_13.setTextColor(Color.rgb(0, 0, 0));
				b7_13.setTextColor(Color.rgb(0, 0, 0));
				b8_13.setTextColor(Color.rgb(0, 0, 0));
				b9_13.setTextColor(Color.rgb(0, 0, 0));
				b10_13.setTextColor(Color.rgb(0, 0, 0));
				b11_13.setTextColor(Color.rgb(0, 0, 0));
				bqb14.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b3_13.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�Ƕ�����";
				onRefresh();
				b1_13.setTextColor(Color.rgb(0, 0, 0));
				b2_13.setTextColor(Color.rgb(0, 0, 0));
				b3_13.setTextColor(Color.rgb(255, 0, 0));
				b4_13.setTextColor(Color.rgb(0, 0, 0));
				b5_13.setTextColor(Color.rgb(0, 0, 0));
				b6_13.setTextColor(Color.rgb(0, 0, 0));
				b7_13.setTextColor(Color.rgb(0, 0, 0));
				b8_13.setTextColor(Color.rgb(0, 0, 0));
				b9_13.setTextColor(Color.rgb(0, 0, 0));
				b10_13.setTextColor(Color.rgb(0, 0, 0));
				b11_13.setTextColor(Color.rgb(0, 0, 0));
				bqb14.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b4_13.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��բ�´�����";
				onRefresh();
				b1_13.setTextColor(Color.rgb(0, 0, 0));
				b2_13.setTextColor(Color.rgb(0, 0, 0));
				b3_13.setTextColor(Color.rgb(0, 0, 0));
				b4_13.setTextColor(Color.rgb(255, 0, 0));
				b5_13.setTextColor(Color.rgb(0, 0, 0));
				b6_13.setTextColor(Color.rgb(0, 0, 0));
				b7_13.setTextColor(Color.rgb(0, 0, 0));
				b8_13.setTextColor(Color.rgb(0, 0, 0));
				b9_13.setTextColor(Color.rgb(0, 0, 0));
				b10_13.setTextColor(Color.rgb(0, 0, 0));
				b11_13.setTextColor(Color.rgb(0, 0, 0));
				bqb14.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b5_13.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_13.setTextColor(Color.rgb(0, 0, 0));
				b2_13.setTextColor(Color.rgb(0, 0, 0));
				b3_13.setTextColor(Color.rgb(0, 0, 0));
				b4_13.setTextColor(Color.rgb(0, 0, 0));
				b5_13.setTextColor(Color.rgb(255, 0, 0));
				b6_13.setTextColor(Color.rgb(0, 0, 0));
				b7_13.setTextColor(Color.rgb(0, 0, 0));
				b8_13.setTextColor(Color.rgb(0, 0, 0));
				b9_13.setTextColor(Color.rgb(0, 0, 0));
				b10_13.setTextColor(Color.rgb(0, 0, 0));
				b11_13.setTextColor(Color.rgb(0, 0, 0));
				bqb14.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b6_13.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "ӡ������";
				onRefresh();
				b1_13.setTextColor(Color.rgb(0, 0, 0));
				b2_13.setTextColor(Color.rgb(0, 0, 0));
				b3_13.setTextColor(Color.rgb(0, 0, 0));
				b4_13.setTextColor(Color.rgb(0, 0, 0));
				b5_13.setTextColor(Color.rgb(0, 0, 0));
				b6_13.setTextColor(Color.rgb(255, 0, 0));
				b7_13.setTextColor(Color.rgb(0, 0, 0));
				b8_13.setTextColor(Color.rgb(0, 0, 0));
				b9_13.setTextColor(Color.rgb(0, 0, 0));
				b10_13.setTextColor(Color.rgb(0, 0, 0));
				b11_13.setTextColor(Color.rgb(0, 0, 0));
				bqb14.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b7_13.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�º�����";
				onRefresh();
				b1_13.setTextColor(Color.rgb(0, 0, 0));
				b2_13.setTextColor(Color.rgb(0, 0, 0));
				b3_13.setTextColor(Color.rgb(0, 0, 0));
				b4_13.setTextColor(Color.rgb(0, 0, 0));
				b5_13.setTextColor(Color.rgb(0, 0, 0));
				b6_13.setTextColor(Color.rgb(0, 0, 0));
				b7_13.setTextColor(Color.rgb(255, 0, 0));
				b8_13.setTextColor(Color.rgb(0, 0, 0));
				b9_13.setTextColor(Color.rgb(0, 0, 0));
				b10_13.setTextColor(Color.rgb(0, 0, 0));
				b11_13.setTextColor(Color.rgb(0, 0, 0));
				bqb14.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b8_13.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_13.setTextColor(Color.rgb(0, 0, 0));
				b2_13.setTextColor(Color.rgb(0, 0, 0));
				b3_13.setTextColor(Color.rgb(0, 0, 0));
				b4_13.setTextColor(Color.rgb(0, 0, 0));
				b5_13.setTextColor(Color.rgb(0, 0, 0));
				b6_13.setTextColor(Color.rgb(0, 0, 0));
				b7_13.setTextColor(Color.rgb(0, 0, 0));
				b8_13.setTextColor(Color.rgb(255, 0, 0));
				b9_13.setTextColor(Color.rgb(0, 0, 0));
				b10_13.setTextColor(Color.rgb(0, 0, 0));
				b11_13.setTextColor(Color.rgb(0, 0, 0));
				bqb14.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b9_13.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "�쿵����";
				onRefresh();
				b1_13.setTextColor(Color.rgb(0, 0, 0));
				b2_13.setTextColor(Color.rgb(0, 0, 0));
				b3_13.setTextColor(Color.rgb(0, 0, 0));
				b4_13.setTextColor(Color.rgb(0, 0, 0));
				b5_13.setTextColor(Color.rgb(0, 0, 0));
				b6_13.setTextColor(Color.rgb(0, 0, 0));
				b7_13.setTextColor(Color.rgb(0, 0, 0));
				b8_13.setTextColor(Color.rgb(0, 0, 0));
				b9_13.setTextColor(Color.rgb(255, 0, 0));
				b10_13.setTextColor(Color.rgb(0, 0, 0));
				b11_13.setTextColor(Color.rgb(0, 0, 0));
				bqb14.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b10_13.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "��������";
				onRefresh();
				b1_13.setTextColor(Color.rgb(0, 0, 0));
				b2_13.setTextColor(Color.rgb(0, 0, 0));
				b3_13.setTextColor(Color.rgb(0, 0, 0));
				b4_13.setTextColor(Color.rgb(0, 0, 0));
				b5_13.setTextColor(Color.rgb(0, 0, 0));
				b6_13.setTextColor(Color.rgb(0, 0, 0));
				b7_13.setTextColor(Color.rgb(0, 0, 0));
				b8_13.setTextColor(Color.rgb(0, 0, 0));
				b9_13.setTextColor(Color.rgb(0, 0, 0));
				b10_13.setTextColor(Color.rgb(255, 0, 0));
				b11_13.setTextColor(Color.rgb(0, 0, 0));
				bqb14.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b11_13.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = "Է������";
				onRefresh();
				b1_13.setTextColor(Color.rgb(0, 0, 0));
				b2_13.setTextColor(Color.rgb(0, 0, 0));
				b3_13.setTextColor(Color.rgb(0, 0, 0));
				b4_13.setTextColor(Color.rgb(0, 0, 0));
				b5_13.setTextColor(Color.rgb(0, 0, 0));
				b6_13.setTextColor(Color.rgb(0, 0, 0));
				b7_13.setTextColor(Color.rgb(0, 0, 0));
				b8_13.setTextColor(Color.rgb(0, 0, 0));
				b9_13.setTextColor(Color.rgb(0, 0, 0));
				b10_13.setTextColor(Color.rgb(0, 0, 0));
				b11_13.setTextColor(Color.rgb(255, 0, 0));
				bqb14.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		bqb14.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				proProfession = " ";
				onRefresh();
				b1_13.setTextColor(Color.rgb(0, 0, 0));
				b2_13.setTextColor(Color.rgb(0, 0, 0));
				b3_13.setTextColor(Color.rgb(0, 0, 0));
				b4_13.setTextColor(Color.rgb(0, 0, 0));
				b5_13.setTextColor(Color.rgb(0, 0, 0));
				b6_13.setTextColor(Color.rgb(0, 0, 0));
				b7_13.setTextColor(Color.rgb(0, 0, 0));
				b8_13.setTextColor(Color.rgb(0, 0, 0));
				b9_13.setTextColor(Color.rgb(0, 0, 0));
				b10_13.setTextColor(Color.rgb(0, 0, 0));
				b11_13.setTextColor(Color.rgb(0, 0, 0));
				bqb14.setTextColor(Color.rgb(255, 0, 0));
			}
		});
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	private void zu(){
		b1_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "һ��";
				onRefresh();
				b1_z.setTextColor(Color.rgb(255, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b2_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(255, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b3_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(255, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b4_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(255, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b5_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(255, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b6_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(255, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b7_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(255, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b8_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(255, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b9_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(255, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b10_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "ʮ��";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(255, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b11_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "ʮһ��";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(255, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b12_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "ʮ����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(255, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b13_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "ʮ����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(255, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b14_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "ʮ����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(255, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b15_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "ʮ����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(255, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b16_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "ʮ����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(255, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b17_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "ʮ����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(255, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		b18_z.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "ʮ����";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(255, 0, 0));
				bqb15.setTextColor(Color.rgb(0, 0, 0));
			}
		});
		bqb15.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				yearnd = "";
				onRefresh();
				b1_z.setTextColor(Color.rgb(0, 0, 0));
				b2_z.setTextColor(Color.rgb(0, 0, 0));
				b3_z.setTextColor(Color.rgb(0, 0, 0));
				b4_z.setTextColor(Color.rgb(0, 0, 0));
				b5_z.setTextColor(Color.rgb(0, 0, 0));
				b6_z.setTextColor(Color.rgb(0, 0, 0));
				b7_z.setTextColor(Color.rgb(0, 0, 0));
				b8_z.setTextColor(Color.rgb(0, 0, 0));
				b9_z.setTextColor(Color.rgb(0, 0, 0));
				b10_z.setTextColor(Color.rgb(0, 0, 0));
				b11_z.setTextColor(Color.rgb(0, 0, 0));
				b12_z.setTextColor(Color.rgb(0, 0, 0));
				b13_z.setTextColor(Color.rgb(0, 0, 0));
				b14_z.setTextColor(Color.rgb(0, 0, 0));
				b15_z.setTextColor(Color.rgb(0, 0, 0));
				b16_z.setTextColor(Color.rgb(0, 0, 0));
				b17_z.setTextColor(Color.rgb(0, 0, 0));
				b18_z.setTextColor(Color.rgb(0, 0, 0));
				bqb15.setTextColor(Color.rgb(255, 0, 0));
			}
		});
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//��ת
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		ROWS email = new ROWS();
		email = listItems.get(arg2);
		Intent intent = new Intent();
		intent.setClass(RY_list2.this, InfoRYXX.class);
		Bundle bundle = new Bundle();
		bundle.putSerializable("ROWS", email);
		intent.putExtras(bundle);
		startActivity(intent);
		
	}
	
	//����
	@Override
	public void onRefresh() {
		pageindex = 1;
		new Thread(new Runnable() {

			@Override
			public void run() {
				json = WebServiceUtil.everycanforStrxmgl("proName", "wantto", "prodq", "yearnd", "proProfession",
						"userid", "pageindex", proName, methodString, prodq, yearnd, proProfession, spname, pageindex,
						"ZDXMGetList2");
				JSONArray jsonObjs;
				JSONObject jsonObj;
				JSONTokener jsonTokener = new JSONTokener(json);
				
				try {
					
					JSONObject person = (JSONObject) jsonTokener.nextValue();
					jsonObjs = person.getJSONArray("rows");
					List<ROWS>list=new ArrayList<ROWS>();
					for (int i = 0; i < jsonObjs.length(); i++) {
						ROWS rows=new ROWS();
						jsonObj = (JSONObject) jsonObjs.opt(i);

					
						
						rows.setSeq(jsonObj.getInt("seq"));
						if (jsonObj.getString("prodq") != null) {
							rows.setProdq(jsonObj.getString("prodq"));
						} else {
							rows.setProdq("");
						}
					
						if (jsonObj.getString("address") != null) {
							rows.setAddress(jsonObj.getString("address"));
						} else {
							rows.setAddress("");
						}
						if (jsonObj.getString("proName") != null) {
							rows.setProName(jsonObj.getString("proName"));
						} else {
							rows.setProName("");
						}
						if (jsonObj.getString("locationNumber") != null) {
							rows.setLocationNumber(jsonObj.getString("locationNumber"));
						} else {
							rows.setLocationNumber("");
						}
						if (jsonObj.getString("unitName1") != null) {
							rows.setUnitName1(jsonObj.getString("unitName1"));
						} else {
							rows.setUnitName1("");
						}
						if (jsonObj.getString("receiptCode") != null) {
							rows.setReceiptCode(jsonObj.getString("receiptCode"));
						} else {
							rows.setReceiptCode("");
						}
						if (jsonObj.getString("proDivideOther") != null) {
							rows.setProDivideOther(jsonObj.getString("proDivideOther"));
						} else {
							rows.setProDivideOther("");
						}
						if (jsonObj.getString("landTotalArea") != null) {
							rows.setLandTotalArea(jsonObj.getString("landTotalArea"));
						} else {
							rows.setLandTotalArea("");
						}
						if (jsonObj.getString("BY3") != null) {
							rows.setBY3(jsonObj.getString("BY3"));
						} else {
							rows.setBY3("");
						}
						if (jsonObj.getString("investTotal") != null) {
							rows.setInvestTotal(jsonObj.getString("investTotal"));
						} else {
							rows.setInvestTotal("");
						}
						if (jsonObj.getString("yearWorkPlan") != null) {
							rows.setYearWorkPlan(jsonObj.getString("yearWorkPlan"));
						} else {
							rows.setYearWorkPlan("");
						}
						if (jsonObj.getString("buildContent") != null) {
							rows.setBuildContent(jsonObj.getString("buildContent"));
						} else {
							rows.setBuildContent("");
						}
						if (jsonObj.getString("proProfessionChild") != null) {
							rows.setProProfessionChild(jsonObj.getString("proProfessionChild"));
						} else {
							rows.setProProfessionChild("");
						}
						if (jsonObj.getString("BY2") != null) {
							rows.setBY2(jsonObj.getString("BY2"));
						} else {
							rows.setBY2("");
						}
						if (jsonObj.getString("landNum") != null) {
							rows.setLandNum(jsonObj.getString("landNum"));
						} else {
							rows.setLandNum("");
						}
						if (jsonObj.getString("unitName2") != null) {
							rows.setUnitName2 (jsonObj.getString("unitName2"));
						} else {
							rows.setUnitName2 ("");
						}
						
						if (jsonObj.getString("beginDate") != null) {
							rows.setBeginDate (jsonObj.getString("beginDate"));
						} else {
							rows.setBeginDate ("");
						}
						if (jsonObj.getString("imageProcess") != null) {
							rows.setImageProcess (jsonObj.getString("imageProcess"));
						} else {
							rows.setImageProcess ("");
						}
						if (jsonObj.getString("economicBenefit") != null) {
							rows.setEconomicBenefit (jsonObj.getString("economicBenefit"));
						} else {
							rows.setEconomicBenefit("");
						}
						
						if (jsonObj.getString("background") != null) {
							rows.setBackground (jsonObj.getString("background"));
						} else {
							rows.setBackground("");
						}
						if (jsonObj.getString("JD") != null) {
							rows.setJD (jsonObj.getString("JD"));
						} else {
							rows.setJD("");
						}
						if (jsonObj.getString("WD") != null) {
							rows.setWD (jsonObj.getString("WD"));
						} else {
							rows.setWD("");
						}
						
						list.add(rows);
					}
					Message msg = new Message();
					msg.what = WHAT_DID_REFRESH;
					msg.obj = list;
					handler.sendMessage(msg);
					
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
			
		}).start();
		
	}
	//ˢ��
	@Override
	public void onMore() {
		pageindex++;
		new Thread(new Runnable() {

			@Override
			public void run() {
				json = WebServiceUtil.everycanforStrxmgl("proName", "wantto", "prodq", "yearnd", "proProfession",
						"userid", "pageindex", proName, methodString, prodq, yearnd, proProfession, spname, pageindex,
						"ZDXMGetList2");
				JSONArray jsonObjs;
				JSONObject jsonObj;
				JSONTokener jsonTokener = new JSONTokener(json);
				
				
				try {
				
					JSONObject person = (JSONObject) jsonTokener.nextValue();
					jsonObjs = person.getJSONArray("rows");
					for (int i = 0; i < jsonObjs.length(); i++) {
						ROWS rows=new ROWS();
						jsonObj = (JSONObject) jsonObjs.opt(i);
						rows.setSeq(jsonObj.getInt("seq"));
						if (jsonObj.getString("prodq") != null) {
							rows.setProdq(jsonObj.getString("prodq"));
						} else {
							rows.setProdq("");
						}
					
						if (jsonObj.getString("address") != null) {
							rows.setAddress(jsonObj.getString("address"));
						} else {
							rows.setAddress("");
						}
						if (jsonObj.getString("proName") != null) {
							rows.setProName(jsonObj.getString("proName"));
						} else {
							rows.setProName("");
						}
						if (jsonObj.getString("locationNumber") != null) {
							rows.setLocationNumber(jsonObj.getString("locationNumber"));
						} else {
							rows.setLocationNumber("");
						}
						if (jsonObj.getString("unitName1") != null) {
							rows.setUnitName1(jsonObj.getString("unitName1"));
						} else {
							rows.setUnitName1("");
						}
						if (jsonObj.getString("receiptCode") != null) {
							rows.setReceiptCode(jsonObj.getString("receiptCode"));
						} else {
							rows.setReceiptCode("");
						}
						if (jsonObj.getString("proDivideOther") != null) {
							rows.setProDivideOther(jsonObj.getString("proDivideOther"));
						} else {
							rows.setProDivideOther("");
						}
						if (jsonObj.getString("landTotalArea") != null) {
							rows.setLandTotalArea(jsonObj.getString("landTotalArea"));
						} else {
							rows.setLandTotalArea("");
						}
						if (jsonObj.getString("BY3") != null) {
							rows.setBY3(jsonObj.getString("BY3"));
						} else {
							rows.setBY3("");
						}
						if (jsonObj.getString("investTotal") != null) {
							rows.setInvestTotal(jsonObj.getString("investTotal"));
						} else {
							rows.setInvestTotal("");
						}
						if (jsonObj.getString("yearWorkPlan") != null) {
							rows.setYearWorkPlan(jsonObj.getString("yearWorkPlan"));
						} else {
							rows.setYearWorkPlan("");
						}
						if (jsonObj.getString("buildContent") != null) {
							rows.setBuildContent(jsonObj.getString("buildContent"));
						} else {
							rows.setBuildContent("");
						}
						if (jsonObj.getString("proProfessionChild") != null) {
							rows.setProProfessionChild(jsonObj.getString("proProfessionChild"));
						} else {
							rows.setProProfessionChild("");
						}
						if (jsonObj.getString("BY2") != null) {
							rows.setBY2(jsonObj.getString("BY2"));
						} else {
							rows.setBY2("");
						}
						if (jsonObj.getString("landNum") != null) {
							rows.setLandNum(jsonObj.getString("landNum"));
						} else {
							rows.setLandNum("");
						}
						if (jsonObj.getString("unitName2") != null) {
							rows.setUnitName2 (jsonObj.getString("unitName2"));
						} else {
							rows.setUnitName2 ("");
						}
						
						if (jsonObj.getString("beginDate") != null) {
							rows.setBeginDate (jsonObj.getString("beginDate"));
						} else {
							rows.setBeginDate ("");
						}
						if (jsonObj.getString("imageProcess") != null) {
							rows.setImageProcess (jsonObj.getString("imageProcess"));
						} else {
							rows.setImageProcess ("");
						}
						if (jsonObj.getString("economicBenefit") != null) {
							rows.setEconomicBenefit (jsonObj.getString("economicBenefit"));
						} else {
							rows.setEconomicBenefit("");
						}
						
						if (jsonObj.getString("background") != null) {
							rows.setBackground (jsonObj.getString("background"));
						} else {
							rows.setBackground("");
						}
						if (jsonObj.getString("JD") != null) {
							rows.setJD (jsonObj.getString("JD"));
						} else {
							rows.setJD("");
						}
						if (jsonObj.getString("WD") != null) {
							rows.setWD (jsonObj.getString("WD"));
						} else {
							rows.setWD("");
						}
						listItems.add(rows);
					}
					Message msg = new Message();
					msg.what = WHAT_DID_MORE;
					handler.sendMessage(msg);
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
			
		}).start();
		
	} 


}
