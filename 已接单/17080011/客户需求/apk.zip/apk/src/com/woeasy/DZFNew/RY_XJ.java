package com.woeasy.DZFNew;






import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;
import cn.buaa.util.NetHelper;
import cn.buaa.util.WebServiceUtil;

@SuppressLint("ShowToast")
public class RY_XJ extends Activity {
	private Spinner province_spinner;
	private Spinner city_spinner;
	private Spinner county_spinner;
	private Integer provinceId, cityId;
	private EditText display;
	private String strProvince, strCity, strCounty;
	private String method = "updateXMXX";
	private String wantTo="����Ԫ";
	private Button up;
	private boolean webbing = false;
	private String json,officeTel;
	private ProgressDialog progressDialog;
	private String uxm,spname;
	private String value1,value2,value3,value4,value5,value6,value7,value8,value9,value10,
			   value11,value12,value13,value14,value15,value16,value17,value18,value19,value20,
            value21,value22,value23,value24,value25,value26,value27,value28,value29,value30,
            value31,value32,value33,value34,value35,value36,value37,value38,value39,value40,
            value41,value42,value43,value44,value45,value46,value47,value48,value49,value50,value51,value52,value53;
	private EditText e1,e2,e3,e4,e5,e6,e7,e8,e9,e10,e11,e12,e13,e14,e15,e16,e17,e18;
	private Handler handler = new Handler() {
		@SuppressWarnings("unchecked")
		@Override
		public void handleMessage(android.os.Message msg) {

			if (msg.what == 1) {
			//uppic();
				RY_XJ.this.finish();
				Toast.makeText(RY_XJ.this, "�½��ɹ�", Toast.LENGTH_SHORT).show();
			} else if (msg.what == 2) {
				progressDialog.dismiss();
				Toast.makeText(RY_XJ.this, "�½��ɹ�", Toast.LENGTH_SHORT).show();
				RY_XJ.this.finish();
			/*	if(json!=null){
					if (ZFXX_list.listact != null) {
						ZFXX_list.listact.onRefresh();
						ZFXX_XJ.this.finish();
					}
					
					
				}*/
			} else if (msg.what == 3) {

			}

		}
	};
	
	private int[] city = {
			R.array.qxz_province_item,
			R.array.nyz_province_item, R.array.xxz_province_item, 
			R.array.ydz_province_item, R.array.bcz_province_item, 
			R.array.hjz_province_item, R.array.thjjkfq_province_item, 
			R.array.xyjjq_province_item, R.array.hbkjc_province_item, 
			R.array.yljd_province_item, R.array.xfjd_province_item, 
			R.array.wfjd_province_item, R.array.dyjd_province_item, 
			R.array.wxjd_province_item, 
			
			};
	private int[] countyOfXZ = {
			R.array.xz_item, 
			
	};
	
	//������
	private int[] countyOfNYZ = 
			{R.array.qxz_item, R.array.xinyangcun_item, 
			R.array.minghangcun_item, R.array.touzaocun_item, 
			R.array.qingduncun_item, R.array.chenjincun_item, 
			R.array.guyuancun_item, R.array.fangxiangcun_city_item, 
			R.array.zirancun_item, R.array.zhengdongcun_city_item, 
			R.array.longmiaocun_city_item, R.array.tanjiancun_city_item,
			R.array.sanjianju_city_item,R.array.yangwancun_city_item,
			R.array.xinglongcun_city_item,R.array.caitangcun_city_item,
			R.array.rikangcun_city_item,R.array.yanzhongcun_city_item,
			R.array.yueqingcun_city_item,R.array.longliancun_city_item,
			R.array.limingcun_city_item,R.array.caibacun_city_item,
			R.array.dongtuancun_city_item,R.array.gaochanju_city_item,
			R.array.shuguangju_city_item,R.array.yandongju_city_item,
			};
	//������
	private int[] countyOfXXZ = 
			{R.array.qxz_item,R.array.chentaicun_city_item, R.array.fangmincun_city_item,
			R.array.ganlucun_city_item, R.array.guhecun_city_item, 
			R.array.hongd_city_item, R.array.lianm_city_item, 
			R.array.nij_city_item, R.array.qiany_city_item, 
			R.array.sanl_city_item, R.array.sanz_city_item, 
			R.array.shih_city_item,R.array.shuangl_city_item,
			R.array.tongx_city_item,R.array.xgj_city_item,
			R.array.xingy_city_item,R.array.xingj_city_item,
			R.array.xingjie_city_item,R.array.xnj_city_item,
			R.array.xingyong_city_item,R.array.yongx_city_item,
			R.array.changc_item,R.array.znj_item,
			R.array.zxj_item,R.array.zbj_item
			};
	//�ζ���
	private int[] countyOfYDZ = 
			{R.array.qxz_item,R.array.gyc_city_item, R.array.lzj_city_item, 
			R.array.mmc_city_item, R.array.dnc_city_item, R.array.zfc_city_item,
			R.array.sjc_city_item, R.array.syc_city_item,
			R.array.wgc_city_item, R.array.xcc_city_item, 
			R.array.xjc_city_item, R.array.yyc_city_item, 
			R.array.zyc_city_item,
			R.array.zdc_city_item,
			R.array.zyc_city_item
			};
	//�����
	private int[] countyOfBCZ = 
			{R.array.qxz_item,R.array.bcj_city_item, R.array.fmj_city_item, 
			R.array.blc_city_item, R.array.jcc_city_item, R.array.xtc_city_item, 
			R.array.mlc_city_item, R.array.siyuanc_city_item,
			R.array.xincc_city_item, R.array.xinqiaoc_city_item, R.array.dtc_city_item, 
			R.array.sgc_city_item, R.array.jgc_city_item, R.array.mqc_city_item,
			};
	//�Ƽ���
	private int[] countyOfHJZ = 
		   {R.array.qxz_item,R.array.xjj_city_item, R.array.xtj_city_item,
			R.array.hjj_city_item, R.array.xzc_city_item, R.array.hdc_city_item, 
			R.array.yjc_city_item, R.array.hcc_city_item, R.array.znc_city_item,
			R.array.xnc_city_item,R.array.xygj_city_item,R.array.jtgs_city_item
			};
	//ͤ�����ÿ�����
	private int[] countyOfTHJJKFQ = 
		   {R.array.qxz_item,R.array.grsq_city_item, R.array.xmsq_city_item,
			R.array.fksq_city_item, R.array.blsq_city_item,
			R.array.nlsq_city_item, R.array.nysq_city_item, 
			R.array.xfsq_city_item, R.array.swc_city_item,
		
			};
	//���󾭼���
	private int[] countyOfXYJJQ = 
	       {R.array.qxz_item,R.array.yhc_city_item, R.array.sanyccity_item, 
			R.array.lqc_city_item, R.array.yzc_city_item, 
			R.array.yuyangc_city_item, R.array.ywc_city_item,
			R.array.bzc_city_item, R.array.xysq_item, 
			R.array.xinfsq_city_item, R.array.tjgsq_city_item, 
			R.array.cbsq_city_item, R.array.ydsq_city_item, 
			};
	//�����Ƽ���
	private int[] countyOfHBKJC = 
			{R.array.qxz_item,R.array.xingmc_city_item, R.array.slc_city_item,
			R.array.qfc_city_item, R.array.mianlc_city_item, 
			R.array.fyc_city_item, R.array.xgc_city_item, 
			};
	
	//ع���ֵ�
	private int[] countyOfYLJD = 
			{R.array.qxz_item,R.array.huancc_city_item, R.array.yzsq_city_item, 
			R.array.xrsq_city_item, R.array.xqlsq_city_item, 
			R.array.ttsq_city_item, R.array.qtsq_city_item, 
			R.array.hllsq_city_item, R.array.gdbcsq_city_item, 
			R.array.dssq_city_item, R.array.bsjsq_city_item, 
			R.array.yxsq_city_item, R.array.hcsq_city_item, 
			R.array.dgsq_city_item, R.array.ljqsq_city_item, 
			};
	//�ȷ�ֵ�
	private int[] countyOfXFJD = 
			{R.array.qxz_item,R.array.dhc_city_item, 
			R.array.cxc_city_item, R.array.jdsq_city_item, 
			R.array.xianfsq_city_item, R.array.jclsq_city_item,
			R.array.xflsq_city_item, R.array.lhlsq_city_item, R.array.bclsq_city_item,
			R.array.dclsq_city_item,R.array.jxsq_city_item,
			R.array.xinjiansq_city_item,R.array.yhlsq_city_item,
			R.array.jklsq_city_item,R.array.sylsq_city_item
			};
	//�ķ�ֵ�
	private int[] countyOfWFJD = 
			{R.array.qxz_item,R.array.shuangyc_city_item, R.array.cbc_city_item, 
			R.array.syxsq_city_item, R.array.jfqsq_city_item, R.array.rxsq_city_item, 
			R.array.zxsq_city_item, R.array.ybsq_city_item, R.array.bqsq_city_item, 
			R.array.ymlsq_city_item, R.array.yhsq_city_item, 
			R.array.xysq_city_item,R.array.dqsq_city_item,
			R.array.wqsq_city_item,R.array.zysq_city_item,R.array.shuangylsq_city_item
			};
	//����ֵ�
	private int[] countyOfDYJD = 
			{R.array.qxz_item,R.array.dyc_city_item, R.array.dxc_city_item, 
			R.array.dsxcsq_city_item, R.array.hysq_city_item,
			R.array.tybcsq_city_item, R.array.yanhsq_city_item, 
			R.array.ycsq_city_item, R.array.ylgysq_city_item
			};
	//���ǽֵ�
	private int[] countyOfWXJD = 
			{R.array.qxz_item,R.array.wxc_city_item, R.array.yahsq_city_item,
			R.array.cdsq_city_item, R.array.xzxcsq_city_item, 
			R.array.xtsq_city_item, R.array.yqsq_city_item, 
			R.array.xhsq_city_item, R.array.fnsq_city_item,
			R.array.qksq_city_item, R.array.ynsq_city_item, 
			R.array.yuanbsq_city_item
			};
	
	private ArrayAdapter<CharSequence> province_adapter;
	private ArrayAdapter<CharSequence> city_adapter;
	private ArrayAdapter<CharSequence> county_adapter;
	
	public void findView(){
		spname = getSharedPreferences("ydjtLogin",
				Context.MODE_WORLD_READABLE + Context.MODE_WORLD_WRITEABLE)
				.getString("spname", "");
		uxm = getSharedPreferences("ydjtLogin",
				Context.MODE_WORLD_READABLE + Context.MODE_WORLD_WRITEABLE)
				.getString("uxm", "");
		up=(Button) findViewById(R.id.up);
		e1=(EditText) findViewById(R.id.Ed1);
		e2=(EditText) findViewById(R.id.Ed2);
		e3=(EditText) findViewById(R.id.Ed3);
		e4=(EditText) findViewById(R.id.Ed4);
		e5=(EditText) findViewById(R.id.Ed5);
		e6=(EditText) findViewById(R.id.Ed6);
		e7=(EditText) findViewById(R.id.Ed7);
		e8=(EditText) findViewById(R.id.Ed8);
		e9=(EditText) findViewById(R.id.Ed9);
		e10=(EditText) findViewById(R.id.Ed10);
		e11=(EditText) findViewById(R.id.Ed11);
		e12=(EditText) findViewById(R.id.Ed12);
		e13=(EditText) findViewById(R.id.Ed13);
		e14=(EditText) findViewById(R.id.Ed14);
		e15=(EditText) findViewById(R.id.Ed15);
		e16=(EditText) findViewById(R.id.Ed16);
		e17=(EditText) findViewById(R.id.Ed17);
		e18=(EditText) findViewById(R.id.Ed18);
		value5 = e1.getText().toString();
		value7 = e2.getText().toString();
		value44 = e3.getText().toString();
		value19 = e4.getText().toString();
		value11 = e5.getText().toString();
		value34 = e6.getText().toString();
		value17 = e7.getText().toString();
		value13 = e8.getText().toString();
		value15 = e9.getText().toString();
		value35 = e10.getText().toString();
		value21 = e11.getText().toString();
		value33 = e12.getText().toString();
		
		value45 = e14.getText().toString().trim();
		value14 = e15.getText().toString().trim();
		value22 = e16.getText().toString().trim();
		value23 = e17.getText().toString().trim();
		value20 = e18.getText().toString().trim();
		
	}
	
	private  void setOnclick(){
	
		
		
		up.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
			if (strProvince.equals("��ѡ����(�ֵ���������)")) {
					Toast.makeText(RY_XJ.this,"��ѡ����(�ֵ���������)��",3000).show();
				}else if (strCity.equals("��ѡ��")) {
					Toast.makeText(RY_XJ.this,"��ѡ���(����)��",3000).show();
				}else if (strCounty.equals("��ѡ��")) {
					Toast.makeText(RY_XJ.this,"��ѡ����(С��)��",3000).show();
				}else if (e1.getText().toString().equals("")) {
					Toast.makeText(RY_XJ.this,"����д������",3000).show();
				}else if (e2.getText().toString().equals("")) {
					Toast.makeText(RY_XJ.this,"����д��ͥ�˿�����",3000).show();
				}else if (e3.getText().toString().equals("")) {
					Toast.makeText(RY_XJ.this,"����д��ͥסַ��",3000).show();
				}else if (e4.getText().toString().equals("")) {
					Toast.makeText(RY_XJ.this,"����д��ϵ�绰��",3000).show();
				}else if (e5.getText().toString().equals("")) {
					Toast.makeText(RY_XJ.this,"����дũ����������ͥ��",3000).show();
				}else if (e6.getText().toString().equals("")) {
					Toast.makeText(RY_XJ.this,"����д��ͥ�����룡",3000).show();
				}else if (e7.getText().toString().equals("")) {
					Toast.makeText(RY_XJ.this,"����д��ũ�����룡",3000).show();
				}else if (e8.getText().toString().equals("")) {
					Toast.makeText(RY_XJ.this,"����д�а���������",3000).show();
				}
				
				
				
				
				else{
					findView();
				}
				

			}
		});
		
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ryxx_xj);
		//����activityʱ���Զ�����������
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		  loadSpinner();  
		  findView();
		  setOnclick();
	}
	private void loadSpinner(){
		province_spinner = (Spinner) findViewById(R.id.province_spinner);
		province_spinner.setPrompt("��ѡ����");
		province_adapter = ArrayAdapter.createFromResource(this, R.array.province_item, android.R.layout.simple_spinner_item);
		province_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    	province_spinner.setAdapter(province_adapter);
    	//select(province_spinner, province_adapter, R.array.province_item);
    	
    	province_spinner.setOnItemSelectedListener(new OnItemSelectedListener() {	
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3){					
				provinceId = province_spinner.getSelectedItemPosition();
				//��
				strProvince = province_spinner.getSelectedItem().toString();
				city_spinner = (Spinner) findViewById(R.id.city_spinner);
				if(true){	
					Log.v("test", "province: "+province_spinner.getSelectedItem().toString()+provinceId.toString());
					county_spinner = (Spinner) findViewById(R.id.county_spinner);
					city_spinner = (Spinner) findViewById(R.id.city_spinner);
					city_spinner.setPrompt("��ѡ���");
					select(city_spinner, city_adapter, city[provinceId]);
					city_spinner.setOnItemSelectedListener(new OnItemSelectedListener(){

						@Override
						public void onItemSelected(AdapterView<?> arg0,
							View arg1, int arg2, long arg3) {
							cityId = city_spinner.getSelectedItemPosition();
							//��
							strCity = city_spinner.getSelectedItem().toString();
							Log.v("test", "city: "+city_spinner.getSelectedItem().toString()+cityId.toString());
							if(true)	{
								county_spinner = (Spinner) findViewById(R.id.county_spinner);
								county_spinner.setPrompt("��ѡ����");
								switch (provinceId) {
							
								case 0:
									select(county_spinner, county_adapter, countyOfXZ[cityId]);
									break;
								case 1:
									select(county_spinner, county_adapter, countyOfNYZ[cityId]);
									break;
								case 2:
									select(county_spinner, county_adapter, countyOfXXZ[cityId]);
									break;
								case 3:
									select(county_spinner, county_adapter, countyOfYDZ[cityId]);
									break;
								case 4:
									select(county_spinner, county_adapter, countyOfBCZ[cityId]);
									break;
								case 5:
									select(county_spinner, county_adapter, countyOfHJZ[cityId]);
									break;
								case 6:
									select(county_spinner, county_adapter, countyOfTHJJKFQ[cityId]);
									break;
								case 7:
									select(county_spinner, county_adapter, countyOfXYJJQ[cityId]);
									break;
								case 8:
									select(county_spinner, county_adapter, countyOfHBKJC[cityId]);
									break;
								case 9:
									select(county_spinner, county_adapter, countyOfYLJD[cityId]);
									break;
								case 10:
									select(county_spinner, county_adapter, countyOfXFJD[cityId]);
									break;
								case 11:
									select(county_spinner, county_adapter, countyOfWFJD[cityId]);
									break;
								case 12:
									select(county_spinner, county_adapter, countyOfDYJD[cityId]);
									break;
								case 13:
									select(county_spinner, county_adapter, countyOfWXJD[cityId]);
									break;
								
				
								default:
									break;
								}
								
								county_spinner.setOnItemSelectedListener(new OnItemSelectedListener() 
								{

									@Override
									public void onItemSelected(
											AdapterView<?> arg0, View arg1,
											int arg2, long arg3) {
										//��
										strCounty = county_spinner.getSelectedItem().toString();//��
									//	display.setText(strProvince+"-"+strCity+"-"+strCounty);
									}

									@Override
									public void onNothingSelected(
											AdapterView<?> arg0) {
										
										
									}
									
								});
							}
						}

						@Override
						public void onNothingSelected(AdapterView<?> arg0) {
							// TODO Auto-generated method stub
							
						}

					});							
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				
			}
		});
		
	}
	
	
	
	private void select(Spinner spin, ArrayAdapter<CharSequence> adapter, int arry)
	{
		adapter = ArrayAdapter.createFromResource(this, arry, android.R.layout.simple_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spin.setAdapter(adapter);
		//spin.setSelection(0,true);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void btn_back(View v){
		this.finish();
	}
}
