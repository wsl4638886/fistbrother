package com.woeasy.DZFNew;



import java.util.ArrayList;
import java.util.List;

import com.woeasy.model.ADInfo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import cn.takephoto.view.CycleViewPager;

public class MainActivity2 extends Activity {
	private ListView listview;
	private String json;
	protected static final int ADD_ADPATER = 1;
	protected static final int ADD_DZGG = 1;
	private static final int WHAT_DID_LOAD_DATA = 0;
	private static final int WHAT_DID_REFRESH = 1;
	private static final int WHAT_DID_MORE = 2;
	private String spname;
	public static MainActivity2 instance = null;
	private List<ADInfo> infos = new ArrayList<ADInfo>();
	private int[] imageUrls={R.drawable.lbn5,R.drawable.lbn5,R.drawable.lbn5,R.drawable.lbn5,R.drawable.lbn5,};
	private List<ImageView> views = new ArrayList<ImageView>();
	private CycleViewPager cycleViewPager;
	private boolean menu_display = false;
	private PopupWindow menuWindow;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_activity2);
		instance = this;
		findview();
		initialize();
	}
	
	
	private void findview(){
		ImageView im1=(ImageView) findViewById(R.id.im1);
		im1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent=new Intent();
				intent.setClass(MainActivity2.this, RY_list.class);//RY_list
				startActivity(intent);
				
			}
		});
		ImageView im2=(ImageView) findViewById(R.id.im2);
		im2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent=new Intent();
				intent.setClass(MainActivity2.this, ZFXX2.class);//ZFXX2
				startActivity(intent);
				
			}
		});
		ImageView im3=(ImageView) findViewById(R.id.im3);
		im3.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent=new Intent();
				intent.setClass(MainActivity2.this, GCXX_tab3.class);//GCXX_tab3
				startActivity(intent);
				
			}
		});
		
		ImageView im4=(ImageView) findViewById(R.id.im4);
		
		ImageView im5=(ImageView) findViewById(R.id.im5);
			
		
		ImageView im6=(ImageView) findViewById(R.id.im6);
		
		ImageView im7=(ImageView) findViewById(R.id.im7);
		ImageView im8=(ImageView) findViewById(R.id.im8);
		ImageView im9=(ImageView) findViewById(R.id.im9);
		
	}
	
	
	
	private void initialize() {
		cycleViewPager = (CycleViewPager) getFragmentManager()
				.findFragmentById(R.id.fragment_cycle_viewpager_content);
		ImageView i1=new ImageView(this);
		i1.setImageResource(imageUrls[imageUrls.length-1]);
		views.add(i1);
		for (int i = 0; i < imageUrls.length; i++) {
			ImageView i2=new ImageView(this);
			i2.setImageResource(imageUrls[i]);
			views.add(i2);
		}
		ImageView i3=new ImageView(this);
		i3.setImageResource(imageUrls[0]);
		views.add(i3);
		// 设置循环，在调用setData方法前调�?
		cycleViewPager.setCycle(true);
		// 在加载数据前设置是否循环
		cycleViewPager.setData(views, infos, null);
		//设置轮播
		cycleViewPager.setWheel(true);
	    // 设置轮播时间，默�?5000ms
		cycleViewPager.setTime(5000);
		//设置圆点指示图标组居中显示，默认靠右
		cycleViewPager.setIndicatorCenter();
	}
}
