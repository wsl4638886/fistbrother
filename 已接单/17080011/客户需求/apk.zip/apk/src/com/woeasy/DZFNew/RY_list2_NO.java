package com.woeasy.DZFNew;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import com.woeasy.DZFNew.PullDownView.OnPullDownListener;
import com.woeasy.model.ROWS;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnCancelListener;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import cn.buaa.adapter.ROWSAdapter;
import cn.buaa.util.NetHelper;
import cn.buaa.util.WebServiceUtil;
import android.widget.AdapterView.OnItemClickListener;

@SuppressLint("HandlerLeak")
public class RY_list2_NO extends Activity implements OnPullDownListener,OnItemClickListener{
	
	private ListView listview;
	private PullDownView mPullDownView;
	private ROWSAdapter listViewAdapter;
	private List<ROWS> listItems = new ArrayList<ROWS>();
	private String json,record;
	private String spname;
	private String wantto="����Ԫ";
	private String proName="",prodq="",search="";
	private int pageindex = 1;
	private Button serch;
	private boolean iswebbing=false;
	private String yearnd = "", proProfession = "";
	private String searchstr="";
	private TextView title;
	private String searchname="";
	private String methodString;
	private Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12,b13, bqb;
	protected static final int ADD_ADPATER = 1;
	protected static final int ADD_DZGG = 1;
	private static final int WHAT_DID_LOAD_DATA = 0;
	private static final int WHAT_DID_REFRESH = 1;
	private static final int WHAT_DID_MORE = 2;
	private Button xj;
	private LinearLayout nyc,xxc,ydc,bcc,hjc,kfq,xykfq,hbkjc,ylc,wfc,xfc,dyc,wxc;
	private  String ubmid,role;
	public static RY_list2_NO listact;
	private  TextView zs;
	private Handler handler = new Handler() {
		@SuppressWarnings("unchecked")
		@Override
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case WHAT_DID_LOAD_DATA: {
				setData();
				// setGGData();
				mPullDownView.notifyDidLoad();
				zs.setText("����:"+record+"��  ");
				break;
			}
			case WHAT_DID_REFRESH: {
				listItems.clear();
				listItems=(List<ROWS>)msg.obj;
				listViewAdapter.setmes((List<ROWS>) msg.obj);
				listViewAdapter.notifyDataSetChanged();
				mPullDownView.notifyDidRefresh();
				zs.setText("����:"+record+"��  ");
				break;
			}

			case WHAT_DID_MORE: {
				listViewAdapter.setmes(listItems);
				listViewAdapter.notifyDataSetChanged();
				mPullDownView.notifyDidMore();
				zs.setText("����:"+record+"��  ");
				break;
			}
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ryxx_list2);
		listact = this;
		spname = getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE+Context.MODE_WORLD_WRITEABLE).getString("spname", "");
		ubmid=getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE + Context.MODE_WORLD_WRITEABLE).getString("ubmid", "");
		role=getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE + Context.MODE_WORLD_WRITEABLE).getString("role", "");
	
		mPullDownView = (PullDownView) findViewById(R.id.rwlistview);
		mPullDownView.setOnPullDownListener(this);
		listview = mPullDownView.getListView();
		//����ˢ��
		listViewAdapter = new ROWSAdapter(this, listItems);
		listview.setAdapter(listViewAdapter);
		listview.setOnItemClickListener(this);
		mPullDownView.enableAutoFetchMore(false, 1);
		//��������
		mPullDownView.enableAutoFetchMore(true, 1);
		findview();
		 serch=(Button)findViewById(R.id.serch);
		xj.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(RY_list2_NO.this, RY_XJ.class);
			
				startActivity(intent);
				
			}
		});
		
		serch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				if (!iswebbing) {
					iswebbing=true;
					final EditText inputServer = new EditText(RY_list2_NO.this);
					
					new AlertDialog.Builder(RY_list2_NO.this,AlertDialog.THEME_DEVICE_DEFAULT_LIGHT).setTitle("����������")//ʹ��Ĭ���豸 ǳɫ����
					.setView(inputServer)
					.setNegativeButton("ȡ��",new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface arg0, int arg1) {
							iswebbing=false;
						}
					}).setOnCancelListener(new OnCancelListener() {
						@Override
						public void onCancel(DialogInterface arg0) {
							iswebbing=false;
						}
					}).setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							
							
							searchstr=inputServer.getText().toString();
							onRefresh();
							iswebbing=false;
							dialog.dismiss();
						}

					}).show();
				}
				
			}
		});
		
	}

	private void setData() {
		listViewAdapter = new ROWSAdapter(this, listItems);
		listview.setAdapter(listViewAdapter);
	}
	
	
	private void findview(){
		xj=(Button) findViewById(R.id.xj);
		zs=  (TextView)findViewById(R.id.zs);
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	//��ת
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		
	}

	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMore() {
		// TODO Auto-generated method stub
		
	}


}
