package com.woeasy.DZFNew;



import com.woeasy.model.TZ;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

@SuppressLint("JavascriptInterface")
public class A2 extends Activity implements DownloadListener{
	private TZ ap;
	private WebView info_text01;
	private String nr;
	private Button fj;
	
	final Handler myHandler = new Handler();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.a1);
		
		TextView t=(TextView) findViewById(R.id.fanhui);
		TextView t2=(TextView) findViewById(R.id.texttitle);
		info_text01 = (WebView)findViewById(R.id.text01);
		fj=(Button) findViewById(R.id.fj);
	/*	fj.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(A2.this, ZlglInfo2.class);
				startActivity(intent);
			}
		});*/
		Intent intent = this.getIntent(); 
		ap=(TZ)intent.getSerializableExtra("info");
	    info_text01.getSettings().setDefaultTextEncodingName("utf-8");		
        info_text01.getSettings().setBuiltInZoomControls(true);
        info_text01.getSettings().setUseWideViewPort(true);
		info_text01.getSettings().setLoadWithOverviewMode(true);
		info_text01.getSettings().setJavaScriptEnabled(true);
		info_text01.loadUrl("file:///android_asset/ZlglInfo_pic.htm");
		info_text01.addJavascriptInterface(new InJavaScriptLocalObj(), "local_obj");
		info_text01.setWebViewClient(new MyWebViewClient());
		info_text01.setInitialScale(45);
		info_text01.getSettings().setLayoutAlgorithm(LayoutAlgorithm.NARROW_COLUMNS);	
		info_text01.getSettings().setUseWideViewPort(true); 
		info_text01.getSettings().setLoadWithOverviewMode(true);
		t2.setText(ap.getXWGL_BT());
		nr="</b>"+ap.getXWGL_ZW();
		info_text01.loadDataWithBaseURL("","<meta name='viewport' content='width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no'>"+nr,"text/html","utf-8",null);
		info_text01.setWebChromeClient(new WebChromeClient());
		//�ر�
		t.setOnClickListener(new OnClickListener() {		
			@Override
			public void onClick(View v) {
				A2.this.finish();
			}
		});
		info_text01.setWebViewClient(new WebViewClient(){ 
	         @Override 
	         public boolean shouldOverrideUrlLoading(WebView view, String url) { 
	  
	          
	          Intent intent= new Intent();        
	          intent.setAction("android.intent.action.VIEW");    
	          Uri content_url = Uri.parse(url);   
	          intent.setData(content_url);  
	          startActivity(intent);
	          return true; 
	         } 
	        });

	}
	
	 final class InJavaScriptLocalObj {
	        public void showSource(String html) {
	        	 myHandler.post(new Runnable() {
	                 @Override
	                 public void run() {
	                	 
	                 }
	             });

	        }
	}
	 
	 final class MyWebViewClient extends WebViewClient{  

	        public boolean shouldOverrideUrlLoading(WebView view, String url) {   

	            view.loadUrl(url);   

	            return true;   

	        }  

	        public void onPageStarted(WebView view, String url, Bitmap favicon) {

	            super.onPageStarted(view, url, favicon);

	        }    

	        public void onPageFinished(WebView view, String url) {

	            view.loadUrl("javascript:window.local_obj.showSource('');");

	            super.onPageFinished(view, url);

	        }

	    }

	  @Override  
      public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype,  
                                  long contentLength) {  
          Uri uri = Uri.parse(url);  
          Intent intent = new Intent(Intent.ACTION_VIEW, uri);  
          startActivity(intent);  
      }  
	 
}
