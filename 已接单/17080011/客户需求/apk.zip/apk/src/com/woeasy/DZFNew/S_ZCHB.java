package com.woeasy.DZFNew;

import java.util.ArrayList;
import java.util.List;
import com.alibaba.fastjson.JSONObject;
import com.woeasy.DZFNew.PullDownView.OnPullDownListener;
import com.woeasy.model.TZ;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import cn.buaa.adapter.TZAdapter;
import cn.buaa.util.NetHelper;
import cn.buaa.util.WebServiceUtil;

public class S_ZCHB extends Activity implements OnPullDownListener, OnItemClickListener{
	  private TZAdapter listViewAdapter;
	  private ListView listview;
	  private PullDownView mPullDownView;
	  private List<TZ> listItems = new ArrayList();
	  private String json;
	  private int pageno = 1;
	  
	  protected static final int ADD_ADPATER = 1;
	  protected static final int ADD_DZGG = 1;
	  private static final int WHAT_DID_LOAD_DATA = 0;
	  private static final int WHAT_DID_MORE = 2;
	  private static final int WHAT_DID_REFRESH = 1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.s_zchb);
		mPullDownView = (PullDownView) findViewById(R.id.rwlistview);
		mPullDownView.setOnPullDownListener(this);
		listview = mPullDownView.getListView();
		getList();
		//����ˢ��
		listViewAdapter = new TZAdapter(this, listItems);
		listview.setAdapter(listViewAdapter);
		listview.setOnItemClickListener(this);
		mPullDownView.enableAutoFetchMore(false, 1);
		//��������
		mPullDownView.enableAutoFetchMore(true, 1);
	}
	private void setData(){
		   listViewAdapter = new TZAdapter(this, listItems);
		    listview.setAdapter(listViewAdapter);
		  }
	 private Handler handler = new Handler(){
		    @SuppressWarnings("unchecked")
			@SuppressLint("HandlerLeak")
			public void handleMessage(Message msg){
		      switch (msg.what){
		      default:
		        return;
		      case 0:
		    	 setData();
		    	mPullDownView.notifyDidLoad();
		        return;
		      case 1:
		    	 listViewAdapter.setmes((List<TZ>)msg.obj);
		    	 listViewAdapter.notifyDataSetChanged();
		    	 mPullDownView.notifyDidRefresh();
		        return;
		      case 2:
		      }
		      listViewAdapter.setmes(listItems);
		      listViewAdapter.notifyDataSetChanged();
		      mPullDownView.notifyDidMore();
		    }
		  };
	
			/**
		  	 * ��ȡ�б�
		  	 */

			private void getList() {
				boolean havenet = NetHelper.IsHaveInternet(S_ZCHB.this);
				if (havenet) {
					new Thread() {
						@Override
						public void run() {
					    	json=WebServiceUtil.everycanforStr2("lx", "", "", "", "", "pageno", "Ҫ�ŷ���", "", "", "", "", pageno, "YWGL");   

							if (json == null || json.equals("0")) {
								listItems = null;
								Message msg = new Message();
								msg.what = WHAT_DID_LOAD_DATA;
								handler.sendMessage(msg);
								return;
							} else {
							    List localList=JSONObject.parseArray(json, TZ.class);  
							    listItems.addAll(localList);
								Message msg = new Message();
								msg.what = WHAT_DID_LOAD_DATA;
								handler.sendMessage(msg);

							}

						}
					}.start();

				} else {
					new AlertDialog.Builder(S_ZCHB.this)
							.setMessage("���������������ã�")
							.setTitle("����������")
							.setPositiveButton("ȷ��",
									new DialogInterface.OnClickListener() {
										@Override
										public void onClick(DialogInterface dialog,
												int which) {
										}

									}).show();

				}
			}
	
	@Override
	public void onRefresh() {
		pageno=1;
	    new Thread(new Runnable(){
		      @SuppressWarnings("unchecked")
			public void run(){
			    json=WebServiceUtil.everycanforStr2("lx", "", "", "", "", "pageno", "Ҫ�ŷ���", "", "", "", "", pageno, "YWGL");   
		        if ((json == null) || (json.equals("0"))) {
		        	listItems = null;
					Message msg = new Message();
					msg.what = WHAT_DID_REFRESH;
					handler.sendMessage(msg);
		          return;
		        }else{
		        List localList = JSONObject.parseArray(json, TZ.class);
		        listItems.clear();
		        listItems.addAll(localList);
		        Message msg = new Message();
				msg.what = WHAT_DID_REFRESH;
				msg.obj = listItems;
				handler.sendMessage(msg);
		      }
		      }
		    }).start();
	}
	

	
	@Override
	public void onMore() {
		pageno++;
		boolean havenet = NetHelper.IsHaveInternet(S_ZCHB.this);
		if (havenet) {
			new Thread() {
				@Override
				public void run() {
			    	json=WebServiceUtil.everycanforStr2("lx", "", "", "", "", "pageno", "Ҫ�ŷ���", "", "", "", "", pageno, "YWGL");   

					if (json==null||json.equals("0")) {
						Message msg = new Message();
						msg.what = WHAT_DID_MORE;
						handler.sendMessage(msg);
						return;
					} else {
						List localList = JSONObject.parseArray(json, TZ.class);
						listItems.addAll(localList);
						Message msg = new Message();
						msg.what = WHAT_DID_MORE;
						handler.sendMessage(msg);

					}

				}
			}.start();

		} else {
			new AlertDialog.Builder(S_ZCHB.this)
					.setMessage("���������������ã�")
					.setTitle("����������")
					.setPositiveButton("ȷ��",
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
								}

							}).show();

		}

	}
	/**
	 * 
	 * ҳ����ת
	 */
	
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		new TZ();
	    TZ localGZRZ = (TZ)this.listItems.get(arg2);
	    Intent intent = new Intent();
	    intent.setClass(this, A1.class);
	    Bundle localBundle = new Bundle();
	    localBundle.putSerializable("info", localGZRZ);
	    intent.putExtras(localBundle);
	    startActivity(intent);
		
	}

}
