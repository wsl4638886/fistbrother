package com.woeasy.DZFNew;







import com.woeasy.model.DZF;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import cn.buaa.util.WebServiceUtil;

@SuppressLint("ShowToast")
public class ZFXX_PL extends Activity {
	private EditText Et1;
	private Button save;
	private String json,spname;
	private ProgressDialog progressDialog;
	private int id;
	private DZF email;
	private Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);

			if (msg.what == 1) {
				progressDialog.dismiss();
				if(json!=null){
					if (ZFXX_list.listact != null) {
						ZFXX_list.listact.onRefresh();
					}
					
					
					finish();
				}
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dzf_pl);
		spname = getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE+Context.MODE_WORLD_WRITEABLE).getString("spname", "");
		findView();
	}

	private void findView() {
		Intent intent = this.getIntent(); 
		email=(DZF) intent.getSerializableExtra("DZF");
		 id=Integer.parseInt(email.getId());
		 System.out.println("caonima::"+id);
		Et1=(EditText)findViewById(R.id.Et1);
		save=(Button)findViewById(R.id.up);
		save.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				if(Et1.getText().toString().equals("")){
					Toast.makeText(ZFXX_PL.this,"����д�������ݣ�",3000).show();
				}else{
					
					progressDialog=ProgressDialog.show(ZFXX_PL.this,"�����ϴ�������","���Ե�...");
					new Thread(new Runnable() {
						@Override
						public void run() {
							
							json = WebServiceUtil.everycanforStr4("UserID", "content", "","", "reply_id","post_id", 
									spname, Et1.getText().toString(),"",0,0,id,"post_comment_create");							Message message = new Message();
							message.what = 1;
							handler.sendMessage(message);
							Toast.makeText(ZFXX_PL.this,"�����ɹ�",3000).show();
						}
					}).start();
					
					
				}
			}
		});
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * ����
	 */
	public void btn_back(View v){
		this.finish();
	}
}
