package com.woeasy.DZFNew;


import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.VideoView;

public class VideoActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_video);

		VideoView videoView = (VideoView) findViewById(R.id.videoView);

		String videoUrl = getIntent().getStringExtra("url");
		videoView.setVideoURI(Uri.parse(videoUrl));

		// ��ʼ������Ƶ
		videoView.start();

		// VideiView�񽹵�
		// videoView.requestFocus();
		
		findViewById(R.id.title_back).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}

}
