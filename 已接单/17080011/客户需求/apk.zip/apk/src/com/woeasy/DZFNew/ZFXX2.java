package com.woeasy.DZFNew;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.example.ponylistviewdemo.NoScrollListView;
import com.example.weixin_friendcircle.ActionItem;
import com.example.weixin_friendcircle.TitlePopup;
import com.example.weixin_friendcircle.Util;
import com.woeasy.DZFNew.PullDownView.OnPullDownListener;
import com.woeasy.model.DZF;
import com.woeasy.model.ROWS;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnCancelListener;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import cn.buaa.adapter.DZFAdapter2;
import cn.buaa.adapter.NoScrollGridAdapter;
import cn.buaa.adapter.DZFAdapter2.ListItemView;
import cn.buaa.util.NetHelper;
import cn.buaa.util.WebServiceUtil;

@SuppressLint({ "WorldWriteableFiles", "WorldReadableFiles" })
@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class ZFXX2 extends Activity implements OnPullDownListener, OnItemClickListener {
	private ListView listview;
	private PullDownView mPullDownView;
	private DZFAdapter2 listViewAdapter;
	private List<DZF> listItems = new ArrayList<DZF>();
	private String json, json2, json3, jsoncan, flag2, xmcx, strseq, record, json4, json5, searchstr = "";
	private String spname, str1,uxm;
	private int pageindex = 1;
	private ROWS ap;
	private int proseq = 0;
	private Button zfxx, serch, login_reback_btn;
	private boolean iswebbing = false;
	protected static final int ADD_ADPATER = 1;
	protected static final int ADD_DZGG = 1;
	private static final int WHAT_DID_LOAD_DATA = 0;
	private static final int WHAT_DID_REFRESH = 1;
	private static final int WHAT_DID_MORE = 2;
	public static ZFXX2 listen;
	private TextView zs;
	private String newid;
	private String comment = ""; // ��¼�Ի����е�����
	private Button commentButton; // ���۰�ť
	private EditText commentEdit; // ���������
	private boolean isReply; // �Ƿ��ǻظ�
	private LinearLayout commentLinear; // ������������Բ���
	private int index_pos;
	private Handler handler = new Handler() {
		@SuppressWarnings("unchecked")
		@Override
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case WHAT_DID_LOAD_DATA: {
				setData();
				// setGGData();
				mPullDownView.notifyDidLoad();
				zs.setText("����:" + record + "��  ");
				break;
			}
			case WHAT_DID_REFRESH: {
				listItems.clear();
				listItems = (List<DZF>) msg.obj;
				listViewAdapter.setmes((List<DZF>) msg.obj);
				listViewAdapter.notifyDataSetChanged();
				mPullDownView.notifyDidRefresh();
				zs.setText("����:" + record + "��  ");
				break;
			}

			case WHAT_DID_MORE: {
				listViewAdapter.setmes(listItems);
				listViewAdapter.notifyDataSetChanged();
				mPullDownView.notifyDidMore();
				zs.setText("����:" + record + "��  ");
				break;
			}
			case 7: {
				ZFXX2.listen.onRefresh();
				
			}
			}
		}

	};

	public String getNewid() {
		return newid;
	}

	public void setNewid(String newid) {
		this.newid = newid;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dzfxx_list2);
		listen = this;
		spname = "zhouhui";
		uxm=getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE + Context.MODE_WORLD_WRITEABLE).getString("uxm", "");
		Intent intent = this.getIntent();
		ap = (ROWS) intent.getSerializableExtra("ROWS");
		getInfo();
		mPullDownView = (PullDownView) findViewById(R.id.rwlistview);
		mPullDownView.setOnPullDownListener(this);
		listview = mPullDownView.getListView();
		// ����ˢ��
		listViewAdapter = new DZFAdapter2(this, listItems);
		listview.setAdapter(listViewAdapter);
		listview.setOnItemClickListener(this);
		mPullDownView.enableAutoFetchMore(false, 1);
		// ��������
		mPullDownView.enableAutoFetchMore(true, 1);
		zfxx = (Button) findViewById(R.id.zf);
		zs = (TextView) findViewById(R.id.zs);
		serch = (Button) findViewById(R.id.serch);
		commentLinear = (LinearLayout) findViewById(R.id.commentLinear);
		commentButton = (Button) findViewById(R.id.commentButton);
		commentEdit = (EditText) findViewById(R.id.commentEdit);
		/**
		 * ����
		 */
		commentButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// Toast.makeText(ZFXX2.this, newid, Toast.LENGTH_LONG);

				new Thread(new Runnable() {
					@Override
					public void run() {
						json = WebServiceUtil.everycanforStr4("UserID", "content", "", "", "reply_id", "post_id",
								spname, commentEdit.getText().toString(), "", 0, 0, Integer.valueOf(newid).intValue(),
								"post_comment_create");
						Message message = new Message();
						message.what = 7;
						handler.sendMessage(message);
					}
				}).start();

				commentEdit.setText("");
				commentLinear.setVisibility(View.GONE);
				onFocusChange(false);

			}
		});

		zfxx.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(ZFXX2.this, ZFXX_XJ.class);
				Bundle bundle = new Bundle();
				bundle.putSerializable("ROWS", ap);
				intent.putExtras(bundle);
				startActivity(intent);

			}
		});

		serch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				if (!iswebbing) {
					iswebbing = true;
					final EditText inputServer = new EditText(ZFXX2.this);

					new AlertDialog.Builder(ZFXX2.this, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT).setTitle("����������")// ʹ��Ĭ���豸
																													// ǳɫ����
							.setView(inputServer).setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface arg0, int arg1) {
									iswebbing = false;
								}
							}).setOnCancelListener(new OnCancelListener() {
								@Override
								public void onCancel(DialogInterface arg0) {
									iswebbing = false;
								}
							}).setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog, int which) {

									searchstr = inputServer.getText().toString();
									onRefresh();
									iswebbing = false;
									dialog.dismiss();
								}

							}).show();
				}

			}
		});

	}

	/**
	 * ��ʾ���������뷨
	 */
	private void onFocusChange(boolean hasFocus) {
		final boolean isFocus = hasFocus;
		(new Handler()).postDelayed(new Runnable() {
			public void run() {
				InputMethodManager imm = (InputMethodManager) commentEdit.getContext()
						.getSystemService(INPUT_METHOD_SERVICE);
				if (isFocus) {
					// ��ʾ���뷨
					imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
				} else {
					// �������뷨
					imm.hideSoftInputFromWindow(commentEdit.getWindowToken(), 0);
				}
			}
		}, 100);
	}

	private void setData() {
		listViewAdapter = new DZFAdapter2(this, listItems);
		listview.setAdapter(listViewAdapter);
	}

	private void getInfo() {
		boolean havenet = NetHelper.IsHaveInternet(ZFXX2.this);
		if (havenet) {
			new Thread() {
				public void run() {
					JSONObject jsonObj;
					JSONObject jsonObj2;
					JSONObject jsonObj3;
					JSONObject jsonObj4;
					JSONObject jsonObj5;
					JSONArray jsonObjs = null;
					JSONArray jsonObjs2 = null;
					JSONArray jsonObjs3 = null;
					JSONArray jsonObjs4 = null;
					JSONArray jsonObjs5 = null;
					json = WebServiceUtil.everycanforStr4("userid", "proName", "sw", "", "proseq", "pageindex", 
							spname,searchstr, "", 0, proseq, pageindex, "ZDXMJDGetList1");
					// json=json.replace("[{\"pmodel\":", "[");
					if (json != null && !json.equals("0")) {
						JSONTokener jsonTokener = new JSONTokener(json);
						try {
							jsonObjs = new JSONArray(json);
						} catch (JSONException e1) {
							e1.printStackTrace();
						}
						try {
							JSONObject xm = (JSONObject) jsonTokener.nextValue();
							jsonObjs = xm.getJSONArray("rows");
							String aa[] = json.split(",");
							aa[2] = aa[2].replace("\"records\":", "");
							record = aa[2];
							for (int i = 0; i < jsonObjs.length(); i++) {
								jsonObj = (JSONObject) jsonObjs.opt(i);
								if (jsonObj.getString("pmodel") != null)
									json2 = jsonObj.getString("pmodel");
								Log.d("yuan2", json2);
								json3 = jsonObj.getString("tp");
								json4 = jsonObj.getString("commentlist");
								json5 = jsonObj.getString("likelist");

								json2 = json2.replace("{", "[{");
								json2 = json2.replace("}", "}]");
								jsonObjs2 = new JSONArray(json2);

								json3 = json3.replace("[", "{\"tp\":[");
								json3 = json3.replace("]", "]}");
								Log.d("yuan3", json3);

								json4 = json4.replace("[", "{\"commentlist\":[");
								json4 = json4.replace("]", "]}");
								Log.d("yuan4", json4);

								json5 = json5.replace("[", "{\"likelist\":[");
								json5 = json5.replace("]", "]}");
								Log.d("yuan5", json5);

								DZF rz = new DZF();
								for (int j = 0; j < jsonObjs2.length(); j++) {
									jsonObj2 = (JSONObject) jsonObjs2.opt(j);
									rz.setId(jsonObj2.getString("id"));
									Log.d("yuan++++", jsonObj2.getString("id"));

									rz.setProSeq(jsonObj2.getString("proSeq"));
									rz.setProName(jsonObj2.getString("proName"));
									rz.setYearND(jsonObj2.getString("yearND"));
									rz.setYearYF(jsonObj2.getString("yearYF"));
									rz.setYearPlanFundSum(jsonObj2.getString("yearPlanFundSum"));
									rz.setTotalInvestFromBegin(jsonObj2.getString("totalInvestFromBegin"));
									rz.setMonthInvest(jsonObj2.getString("monthInvest"));
									rz.setLastInvestThisYear(jsonObj2.getString("lastInvestThisYear"));
									rz.setZjsyLastyearInvestPercent(jsonObj2.getString("zjsyLastyearInvestPercent"));
									rz.setFinishInvestThisYear(jsonObj2.getString("finishInvestThisYear"));
									rz.setZjsyThisyearInvestPercent(jsonObj2.getString("zjsyThisyearInvestPercent"));
									rz.setBuildStep(jsonObj2.getString("buildStep"));
									rz.setApproSeq(jsonObj2.getString("approSeq"));
									rz.setPreceiptCode(jsonObj2.getString("preceiptCode"));
									rz.setBeginDatestr(jsonObj2.getString("beginDatestr"));
									rz.setOverDate(jsonObj2.getString("overDate"));
									rz.setDeferReason(jsonObj2.getString("deferReason"));
									rz.setProSchedule(jsonObj2.getString("proSchedule"));
									rz.setExistProblem(jsonObj2.getString("existProblem"));
									rz.setAdviseDo(jsonObj2.getString("adviseDo"));
									rz.setChangeCondition(jsonObj2.getString("changeCondition"));
									rz.setProLinkMan(jsonObj2.getString("proLinkMan"));
									rz.setOfficeTel(jsonObj2.getString("officeTel"));
									rz.setMobileTel(jsonObj2.getString("mobileTel"));
									rz.setQqNumber(jsonObj2.getString("qqNumber"));
									rz.setFax(jsonObj2.getString("fax"));
									rz.setPmMonthScheduleBase_WFID(jsonObj2.getString("pmMonthScheduleBase_WFID"));
									rz.setPmMonthScheduleBase_WFInst(jsonObj2.getString("pmMonthScheduleBase_WFInst"));
									rz.setPmMonthScheduleBase_WPID(jsonObj2.getString("pmMonthScheduleBase_WPID"));
									str1 = jsonObj2.getString("pmMonthScheduleBase_WPID");
									rz.setPmMonthScheduleBase_Awaiter(
											jsonObj2.getString("pmMonthScheduleBase_Awaiter"));
									rz.setPmMonthScheduleBase_Handler(
											jsonObj2.getString("pmMonthScheduleBase_Handler"));
									rz.setStime(jsonObj2.getString("stime"));
									rz.setEtime(jsonObj2.getString("etime"));

									JSONTokener jsonTokener2 = new JSONTokener(json3);
									JSONObject xm2 = (JSONObject) jsonTokener2.nextValue();
									jsonObjs3 = xm2.getJSONArray("tp");
									String SJWSFJ_GRPID = "";
									String SJWSFJ_XH = "";
									String SJWSFJ_FileName = "";
									String SJWSFJ_FileType = "";
									String SJWSFJ_FilePath = "";
									String SJWSFJ_WHRID = "";
									String SJWSFJ_WHR = "";
									String SJWSFJ_WHSJ = "";
									String SJWSFJ_FullName = "";
									String SJWSFJ_WJJ = "";
									String SJWSFJ_DID = "";
									String SJWSFJ_XID = "";
									for (int k = 0; k < jsonObjs3.length(); k++) {
										jsonObj3 = (JSONObject) jsonObjs3.opt(k);
										if (SJWSFJ_GRPID != "")
											SJWSFJ_GRPID = SJWSFJ_GRPID + ",";
										SJWSFJ_GRPID = SJWSFJ_GRPID + jsonObj3.getString("SJWSFJ_GRPID");
										if (SJWSFJ_XH != "")
											SJWSFJ_XH = SJWSFJ_XH + ",";
										SJWSFJ_XH = SJWSFJ_XH + jsonObj3.getString("SJWSFJ_XH");
										if (SJWSFJ_FileName != "")
											SJWSFJ_FileName = SJWSFJ_FileName + ",";
										SJWSFJ_FileName = SJWSFJ_FileName + jsonObj3.getString("SJWSFJ_FileName");
										if (SJWSFJ_FileType != "")
											SJWSFJ_FileType = SJWSFJ_FileType + ",";
										SJWSFJ_FileType = SJWSFJ_FileType + jsonObj3.getString("SJWSFJ_FileType");
										if (SJWSFJ_FilePath != "")
											SJWSFJ_FilePath = SJWSFJ_FilePath + ",";
										SJWSFJ_FilePath = SJWSFJ_FilePath + jsonObj3.getString("SJWSFJ_FilePath");
										if (SJWSFJ_WHRID != "")
											SJWSFJ_WHRID = SJWSFJ_WHRID + ",";
										SJWSFJ_WHRID = SJWSFJ_WHRID + jsonObj3.getString("SJWSFJ_WHRID");
										if (SJWSFJ_WHR != "")
											SJWSFJ_WHR = SJWSFJ_WHR + ",";
										SJWSFJ_WHR = SJWSFJ_WHR + jsonObj3.getString("SJWSFJ_WHR");
										if (SJWSFJ_WHSJ != "")
											SJWSFJ_WHSJ = SJWSFJ_WHSJ + ",";
										SJWSFJ_WHSJ = SJWSFJ_WHSJ + jsonObj3.getString("SJWSFJ_WHSJ");
										if (SJWSFJ_FullName != "")
											SJWSFJ_FullName = SJWSFJ_FullName + ",";
										SJWSFJ_FullName = SJWSFJ_FullName + jsonObj3.getString("SJWSFJ_FullName");
										if (SJWSFJ_WJJ != "")
											SJWSFJ_WJJ = SJWSFJ_WJJ + ",";
										SJWSFJ_WJJ = SJWSFJ_WJJ + jsonObj3.getString("SJWSFJ_WJJ");
										if (SJWSFJ_DID != "")
											SJWSFJ_DID = SJWSFJ_DID + ",";
										SJWSFJ_DID = SJWSFJ_DID + jsonObj3.getString("SJWSFJ_DID");
										if (SJWSFJ_XID != "")
											SJWSFJ_XID = SJWSFJ_XID + ",";
										SJWSFJ_XID = SJWSFJ_XID + jsonObj3.getString("SJWSFJ_XID");

									}

									rz.setSJWSFJ_GRPID(SJWSFJ_GRPID);
									rz.setSJWSFJ_XH(SJWSFJ_XH);
									rz.setSJWSFJ_FileName(SJWSFJ_FileName);
									rz.setSJWSFJ_FileType(SJWSFJ_FileType);
									rz.setSJWSFJ_FilePath(SJWSFJ_FilePath);
									rz.setSJWSFJ_WHRID(SJWSFJ_WHRID);
									rz.setSJWSFJ_WHR(SJWSFJ_WHR);
									rz.setSJWSFJ_WHSJ(SJWSFJ_WHSJ);
									rz.setSJWSFJ_WHSJ(SJWSFJ_WHSJ);
									rz.setSJWSFJ_FullName(SJWSFJ_FullName);
									rz.setSJWSFJ_WJJ(SJWSFJ_WJJ);
									rz.setSJWSFJ_DID(SJWSFJ_DID);
									rz.setSJWSFJ_XID(SJWSFJ_XID);
									Log.d("yuanw", rz.getSJWSFJ_FullName());
									Log.d("yuanw1", rz.getSJWSFJ_XH());

									JSONTokener jsonTokener3 = new JSONTokener(json4);
									JSONObject xm3 = (JSONObject) jsonTokener3.nextValue();
									jsonObjs4 = xm3.getJSONArray("commentlist");

									String reply_id = "";
									String create_user = "";
									String attach_ids = "";
									String attachments = "";
									String create_time = "";
									String content = "";
									String name = "";
									for (int m = 0; m < jsonObjs4.length(); m++) {
										jsonObj4 = (JSONObject) jsonObjs4.opt(m);
										if (reply_id != "")
											reply_id = reply_id + ",";
										reply_id = reply_id + jsonObj4.getString("reply_id");
										if (create_user != "")
											create_user = create_user + ",";
										create_user = create_user + jsonObj4.getString("create_user");
										if (attach_ids != "")
											attach_ids = attach_ids + ",";
										attach_ids = attach_ids + jsonObj4.getString("attach_ids");
										if (attachments != "")
											attachments = attachments + ",";
										attachments = attachments + jsonObj4.getString("attachments");
										if (create_time != "")
											create_time = create_time + ",";
										create_time = create_time + jsonObj4.getString("create_time");
										if (content != "")
											content = content + ",";
										content = content + jsonObj4.getString("content");
										if (name != "")
											name = name + ",";
										name = name + jsonObj4.getString("name");

									}
									rz.setReply_id(reply_id);
									rz.setCreate_user(create_user);
									rz.setAttach_ids(attach_ids);
									rz.setAttachments(attachments);
									rz.setCreate_time(create_time);
									rz.setContent(content);
									rz.setName(name);
									Log.d("yuansssss", rz.getContent());

									

									JSONTokener jsonTokener4 = new JSONTokener(json5);
									JSONObject xm4 = (JSONObject) jsonTokener4.nextValue();
									jsonObjs5 = xm4.getJSONArray("likelist");
									
								//	String reply_id = "";
									String name1 = "";
									for (int a = 0; a < jsonObjs5.length(); a++) {
										jsonObj5 = (JSONObject) jsonObjs5.opt(a);
										/*if (reply_id != "")
											reply_id = reply_id + ",";
										reply_id = reply_id + jsonObj4.getString("reply_id");*/
										
										if (name1 != "")
											name1 = name1 + ",";
										name1 = name1 + jsonObj5.getString("name");
										
									}		
									rz.setName1(name1);
									Log.d("yuansssss", rz.getName1());
									
									listItems.add(rz);
								}

							}
						} catch (Exception e) {
						}

						Message msg = new Message();
						msg.what = WHAT_DID_LOAD_DATA;
						handler.sendMessage(msg);
					}

				}
			}.start();
		} else {
			new AlertDialog.Builder(ZFXX2.this).setMessage("���������������ã�").setTitle("����������")
					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
						}

					}).show();

		}

	}

	public void onRefresh() {
		pageindex = 1;
		new Thread(new Runnable() {

			@Override
			public void run() {
				JSONObject jsonObj;
				JSONObject jsonObj2;
				JSONObject jsonObj3;
				JSONObject jsonObj4;
				JSONObject jsonObj5;
				JSONArray jsonObjs = null;
				JSONArray jsonObjs2 = null;
				JSONArray jsonObjs3 = null;
				JSONArray jsonObjs4 = null;
				JSONArray jsonObjs5 = null;
				List<DZF> list = new ArrayList<DZF>();
				json = WebServiceUtil.everycanforStr4("userid", "proName", "sw", "", "proseq", "pageindex", spname,
						searchstr, "", 0, proseq, pageindex, "ZDXMJDGetList1");
				// json=json.replace("[{\"pmodel\":", "[");
				Log.d("����Դ��", json);
				if (json != null && !json.equals("0")) {
					JSONTokener jsonTokener = new JSONTokener(json);
					try {
						jsonObjs = new JSONArray(json);
					} catch (JSONException e1) {
						e1.printStackTrace();
					}
					try {
						JSONObject xm = (JSONObject) jsonTokener.nextValue();
						jsonObjs = xm.getJSONArray("rows");
						String aa[] = json.split(",");
						aa[2] = aa[2].replace("\"records\":", "");
						record = aa[2];
						for (int i = 0; i < jsonObjs.length(); i++) {
							jsonObj = (JSONObject) jsonObjs.opt(i);
							if (jsonObj.getString("pmodel") != null)
								json2 = jsonObj.getString("pmodel");
							Log.d("yuan2", json2);
							json3 = jsonObj.getString("tp");
							json4 = jsonObj.getString("commentlist");
							json5 = jsonObj.getString("likelist");

							json2 = json2.replace("{", "[{");
							json2 = json2.replace("}", "}]");
							jsonObjs2 = new JSONArray(json2);

							json3 = json3.replace("[", "{\"tp\":[");
							json3 = json3.replace("]", "]}");
							Log.d("yuan3", json3);

							json4 = json4.replace("[", "{\"commentlist\":[");
							json4 = json4.replace("]", "]}");
							Log.d("yuan4", json4);

							json5 = json5.replace("[", "{\"likelist\":[");
							json5 = json5.replace("]", "]}");
							Log.d("yuan5", json5);

							DZF rz = new DZF();
							for (int j = 0; j < jsonObjs2.length(); j++) {
								jsonObj2 = (JSONObject) jsonObjs2.opt(j);
								rz.setId(jsonObj2.getString("id"));
								Log.d("yuan++++", jsonObj2.getString("id"));

								rz.setProSeq(jsonObj2.getString("proSeq"));
								rz.setProName(jsonObj2.getString("proName"));
								rz.setYearND(jsonObj2.getString("yearND"));
								rz.setYearYF(jsonObj2.getString("yearYF"));
								rz.setYearPlanFundSum(jsonObj2.getString("yearPlanFundSum"));
								rz.setTotalInvestFromBegin(jsonObj2.getString("totalInvestFromBegin"));
								rz.setMonthInvest(jsonObj2.getString("monthInvest"));
								rz.setLastInvestThisYear(jsonObj2.getString("lastInvestThisYear"));
								rz.setZjsyLastyearInvestPercent(jsonObj2.getString("zjsyLastyearInvestPercent"));
								rz.setFinishInvestThisYear(jsonObj2.getString("finishInvestThisYear"));
								rz.setZjsyThisyearInvestPercent(jsonObj2.getString("zjsyThisyearInvestPercent"));
								rz.setBuildStep(jsonObj2.getString("buildStep"));
								rz.setApproSeq(jsonObj2.getString("approSeq"));
								rz.setPreceiptCode(jsonObj2.getString("preceiptCode"));
								rz.setBeginDatestr(jsonObj2.getString("beginDatestr"));
								rz.setOverDate(jsonObj2.getString("overDate"));
								rz.setDeferReason(jsonObj2.getString("deferReason"));
								rz.setProSchedule(jsonObj2.getString("proSchedule"));
								rz.setExistProblem(jsonObj2.getString("existProblem"));
								rz.setAdviseDo(jsonObj2.getString("adviseDo"));
								rz.setChangeCondition(jsonObj2.getString("changeCondition"));
								rz.setProLinkMan(jsonObj2.getString("proLinkMan"));
								rz.setOfficeTel(jsonObj2.getString("officeTel"));
								rz.setMobileTel(jsonObj2.getString("mobileTel"));
								rz.setQqNumber(jsonObj2.getString("qqNumber"));
								rz.setFax(jsonObj2.getString("fax"));
								rz.setPmMonthScheduleBase_WFID(jsonObj2.getString("pmMonthScheduleBase_WFID"));
								rz.setPmMonthScheduleBase_WFInst(jsonObj2.getString("pmMonthScheduleBase_WFInst"));
								rz.setPmMonthScheduleBase_WPID(jsonObj2.getString("pmMonthScheduleBase_WPID"));
								str1 = jsonObj2.getString("pmMonthScheduleBase_WPID");
								rz.setPmMonthScheduleBase_Awaiter(jsonObj2.getString("pmMonthScheduleBase_Awaiter"));
								rz.setPmMonthScheduleBase_Handler(jsonObj2.getString("pmMonthScheduleBase_Handler"));
								rz.setStime(jsonObj2.getString("stime"));
								rz.setEtime(jsonObj2.getString("etime"));

								JSONTokener jsonTokener2 = new JSONTokener(json3);
								JSONObject xm2 = (JSONObject) jsonTokener2.nextValue();
								jsonObjs3 = xm2.getJSONArray("tp");
								String SJWSFJ_GRPID = "";
								String SJWSFJ_XH = "";
								String SJWSFJ_FileName = "";
								String SJWSFJ_FileType = "";
								String SJWSFJ_FilePath = "";
								String SJWSFJ_WHRID = "";
								String SJWSFJ_WHR = "";
								String SJWSFJ_WHSJ = "";
								String SJWSFJ_FullName = "";
								String SJWSFJ_WJJ = "";
								String SJWSFJ_DID = "";
								String SJWSFJ_XID = "";
								for (int k = 0; k < jsonObjs3.length(); k++) {
									jsonObj3 = (JSONObject) jsonObjs3.opt(k);
									if (SJWSFJ_GRPID != "")
										SJWSFJ_GRPID = SJWSFJ_GRPID + ",";
									SJWSFJ_GRPID = SJWSFJ_GRPID + jsonObj3.getString("SJWSFJ_GRPID");
									if (SJWSFJ_XH != "")
										SJWSFJ_XH = SJWSFJ_XH + ",";
									SJWSFJ_XH = SJWSFJ_XH + jsonObj3.getString("SJWSFJ_XH");
									if (SJWSFJ_FileName != "")
										SJWSFJ_FileName = SJWSFJ_FileName + ",";
									SJWSFJ_FileName = SJWSFJ_FileName + jsonObj3.getString("SJWSFJ_FileName");
									if (SJWSFJ_FileType != "")
										SJWSFJ_FileType = SJWSFJ_FileType + ",";
									SJWSFJ_FileType = SJWSFJ_FileType + jsonObj3.getString("SJWSFJ_FileType");
									if (SJWSFJ_FilePath != "")
										SJWSFJ_FilePath = SJWSFJ_FilePath + ",";
									SJWSFJ_FilePath = SJWSFJ_FilePath + jsonObj3.getString("SJWSFJ_FilePath");
									if (SJWSFJ_WHRID != "")
										SJWSFJ_WHRID = SJWSFJ_WHRID + ",";
									SJWSFJ_WHRID = SJWSFJ_WHRID + jsonObj3.getString("SJWSFJ_WHRID");
									if (SJWSFJ_WHR != "")
										SJWSFJ_WHR = SJWSFJ_WHR + ",";
									SJWSFJ_WHR = SJWSFJ_WHR + jsonObj3.getString("SJWSFJ_WHR");
									if (SJWSFJ_WHSJ != "")
										SJWSFJ_WHSJ = SJWSFJ_WHSJ + ",";
									SJWSFJ_WHSJ = SJWSFJ_WHSJ + jsonObj3.getString("SJWSFJ_WHSJ");
									if (SJWSFJ_FullName != "")
										SJWSFJ_FullName = SJWSFJ_FullName + ",";
									SJWSFJ_FullName = SJWSFJ_FullName + jsonObj3.getString("SJWSFJ_FullName");
									if (SJWSFJ_WJJ != "")
										SJWSFJ_WJJ = SJWSFJ_WJJ + ",";
									SJWSFJ_WJJ = SJWSFJ_WJJ + jsonObj3.getString("SJWSFJ_WJJ");
									if (SJWSFJ_DID != "")
										SJWSFJ_DID = SJWSFJ_DID + ",";
									SJWSFJ_DID = SJWSFJ_DID + jsonObj3.getString("SJWSFJ_DID");
									if (SJWSFJ_XID != "")
										SJWSFJ_XID = SJWSFJ_XID + ",";
									SJWSFJ_XID = SJWSFJ_XID + jsonObj3.getString("SJWSFJ_XID");

								}

								rz.setSJWSFJ_GRPID(SJWSFJ_GRPID);
								rz.setSJWSFJ_XH(SJWSFJ_XH);
								rz.setSJWSFJ_FileName(SJWSFJ_FileName);
								rz.setSJWSFJ_FileType(SJWSFJ_FileType);
								rz.setSJWSFJ_FilePath(SJWSFJ_FilePath);
								rz.setSJWSFJ_WHRID(SJWSFJ_WHRID);
								rz.setSJWSFJ_WHR(SJWSFJ_WHR);
								rz.setSJWSFJ_WHSJ(SJWSFJ_WHSJ);
								rz.setSJWSFJ_WHSJ(SJWSFJ_WHSJ);
								rz.setSJWSFJ_FullName(SJWSFJ_FullName);
								rz.setSJWSFJ_WJJ(SJWSFJ_WJJ);
								rz.setSJWSFJ_DID(SJWSFJ_DID);
								rz.setSJWSFJ_XID(SJWSFJ_XID);
								Log.d("yuanw", rz.getSJWSFJ_FullName());
								Log.d("yuanw1", rz.getSJWSFJ_XH());

								JSONTokener jsonTokener3 = new JSONTokener(json4);
								JSONObject xm3 = (JSONObject) jsonTokener3.nextValue();
								jsonObjs4 = xm3.getJSONArray("commentlist");

								String reply_id = "";
								String create_user = "";
								String attach_ids = "";
								String attachments = "";
								String create_time = "";
								String content = "";
								String name = "";
								for (int m = 0; m < jsonObjs4.length(); m++) {
									jsonObj4 = (JSONObject) jsonObjs4.opt(m);
									if (reply_id != "")
										reply_id = reply_id + ",";
									reply_id = reply_id + jsonObj4.getString("reply_id");
									if (create_user != "")
										create_user = create_user + ",";
									create_user = create_user + jsonObj4.getString("create_user");
									if (attach_ids != "")
										attach_ids = attach_ids + ",";
									attach_ids = attach_ids + jsonObj4.getString("attach_ids");
									if (attachments != "")
										attachments = attachments + ",";
									attachments = attachments + jsonObj4.getString("attachments");
									if (create_time != "")
										create_time = create_time + ",";
									create_time = create_time + jsonObj4.getString("create_time");
									if (content != "")
										content = content + ",";
									content = content + jsonObj4.getString("content");
									if (name != "")
										name = name + ",";
									name = name + jsonObj4.getString("name");

								}
								rz.setReply_id(reply_id);
								rz.setCreate_user(create_user);
								rz.setAttach_ids(attach_ids);
								rz.setAttachments(attachments);
								rz.setCreate_time(create_time);
								rz.setContent(content);
								rz.setName(name);
								Log.d("yuansssss", rz.getContent());


								JSONTokener jsonTokener4 = new JSONTokener(json5);
								JSONObject xm4 = (JSONObject) jsonTokener4.nextValue();
								jsonObjs5 = xm4.getJSONArray("likelist");
								
							//	String reply_id = "";
								String name1 = "";
								for (int a = 0; a < jsonObjs5.length(); a++) {
									jsonObj5 = (JSONObject) jsonObjs5.opt(a);
									/*if (reply_id != "")
										reply_id = reply_id + ",";
									reply_id = reply_id + jsonObj4.getString("reply_id");*/
									
									if (name1 != "")
										name1 = name1 + ",";
									name1 = name1 + jsonObj5.getString("name");
									
								}		
								rz.setName1(name1);
								Log.d("yuansssss", rz.getName1());

								list.add(rz);
							}

						}
					} catch (Exception e) {
					}

					Message msg = new Message();
					msg.what = WHAT_DID_REFRESH;
					msg.obj = list;
					handler.sendMessage(msg);
				}

			}
		}).start();

	}

	@Override
	public void onMore() {
		pageindex++;
		boolean havenet = NetHelper.IsHaveInternet(ZFXX2.this);
		if (havenet) {
			new Thread() {
				@Override
				public void run() {
					JSONObject jsonObj;
					JSONObject jsonObj2;
					JSONObject jsonObj3;
					JSONObject jsonObj4;
					JSONObject jsonObj5;
					JSONArray jsonObjs = null;
					JSONArray jsonObjs2 = null;
					JSONArray jsonObjs3 = null;
					JSONArray jsonObjs4 = null;
					JSONArray jsonObjs5 = null;
					json = WebServiceUtil.everycanforStr4("userid", "proName", "sw", "", "proseq", "pageindex", spname,
							searchstr, "", 0, proseq, pageindex, "ZDXMJDGetList1");
					// Log.d("����Դ��", json);
					if (json != null && !json.equals("0")) {
						JSONTokener jsonTokener = new JSONTokener(json);
						try {
							jsonObjs = new JSONArray(json);
						} catch (JSONException e1) {
							e1.printStackTrace();
						}
						try {
							JSONObject xm = (JSONObject) jsonTokener.nextValue();
							jsonObjs = xm.getJSONArray("rows");
							String aa[] = json.split(",");
							aa[2] = aa[2].replace("\"records\":", "");
							record = aa[2];
							for (int i = 0; i < jsonObjs.length(); i++) {
								jsonObj = (JSONObject) jsonObjs.opt(i);
								if (jsonObj.getString("pmodel") != null)
									json2 = jsonObj.getString("pmodel");
								Log.d("yuan2", json2);
								json3 = jsonObj.getString("tp");
								json4 = jsonObj.getString("commentlist");
								json5 = jsonObj.getString("likelist");

								json2 = json2.replace("{", "[{");
								json2 = json2.replace("}", "}]");
								jsonObjs2 = new JSONArray(json2);

								json3 = json3.replace("[", "{\"tp\":[");
								json3 = json3.replace("]", "]}");
								Log.d("yuan3", json3);

								json4 = json4.replace("[", "{\"commentlist\":[");
								json4 = json4.replace("]", "]}");
								Log.d("yuan4", json4);

								json5 = json5.replace("[", "{\"likelist\":[");
								json5 = json5.replace("]", "]}");
								Log.d("yuan5", json5);

								DZF rz = new DZF();
								for (int j = 0; j < jsonObjs2.length(); j++) {
									jsonObj2 = (JSONObject) jsonObjs2.opt(j);
									rz.setId(jsonObj2.getString("id"));
									Log.d("yuan++++", jsonObj2.getString("id"));

									rz.setProSeq(jsonObj2.getString("proSeq"));
									rz.setProName(jsonObj2.getString("proName"));
									rz.setYearND(jsonObj2.getString("yearND"));
									rz.setYearYF(jsonObj2.getString("yearYF"));
									rz.setYearPlanFundSum(jsonObj2.getString("yearPlanFundSum"));
									rz.setTotalInvestFromBegin(jsonObj2.getString("totalInvestFromBegin"));
									rz.setMonthInvest(jsonObj2.getString("monthInvest"));
									rz.setLastInvestThisYear(jsonObj2.getString("lastInvestThisYear"));
									rz.setZjsyLastyearInvestPercent(jsonObj2.getString("zjsyLastyearInvestPercent"));
									rz.setFinishInvestThisYear(jsonObj2.getString("finishInvestThisYear"));
									rz.setZjsyThisyearInvestPercent(jsonObj2.getString("zjsyThisyearInvestPercent"));
									rz.setBuildStep(jsonObj2.getString("buildStep"));
									rz.setApproSeq(jsonObj2.getString("approSeq"));
									rz.setPreceiptCode(jsonObj2.getString("preceiptCode"));
									rz.setBeginDatestr(jsonObj2.getString("beginDatestr"));
									rz.setOverDate(jsonObj2.getString("overDate"));
									rz.setDeferReason(jsonObj2.getString("deferReason"));
									rz.setProSchedule(jsonObj2.getString("proSchedule"));
									rz.setExistProblem(jsonObj2.getString("existProblem"));
									rz.setAdviseDo(jsonObj2.getString("adviseDo"));
									rz.setChangeCondition(jsonObj2.getString("changeCondition"));
									rz.setProLinkMan(jsonObj2.getString("proLinkMan"));
									rz.setOfficeTel(jsonObj2.getString("officeTel"));
									rz.setMobileTel(jsonObj2.getString("mobileTel"));
									rz.setQqNumber(jsonObj2.getString("qqNumber"));
									rz.setFax(jsonObj2.getString("fax"));
									rz.setPmMonthScheduleBase_WFID(jsonObj2.getString("pmMonthScheduleBase_WFID"));
									rz.setPmMonthScheduleBase_WFInst(jsonObj2.getString("pmMonthScheduleBase_WFInst"));
									rz.setPmMonthScheduleBase_WPID(jsonObj2.getString("pmMonthScheduleBase_WPID"));
									str1 = jsonObj2.getString("pmMonthScheduleBase_WPID");
									rz.setPmMonthScheduleBase_Awaiter(
											jsonObj2.getString("pmMonthScheduleBase_Awaiter"));
									rz.setPmMonthScheduleBase_Handler(
											jsonObj2.getString("pmMonthScheduleBase_Handler"));
									rz.setStime(jsonObj2.getString("stime"));
									rz.setEtime(jsonObj2.getString("etime"));

									JSONTokener jsonTokener2 = new JSONTokener(json3);
									JSONObject xm2 = (JSONObject) jsonTokener2.nextValue();
									jsonObjs3 = xm2.getJSONArray("tp");
									String SJWSFJ_GRPID = "";
									String SJWSFJ_XH = "";
									String SJWSFJ_FileName = "";
									String SJWSFJ_FileType = "";
									String SJWSFJ_FilePath = "";
									String SJWSFJ_WHRID = "";
									String SJWSFJ_WHR = "";
									String SJWSFJ_WHSJ = "";
									String SJWSFJ_FullName = "";
									String SJWSFJ_WJJ = "";
									String SJWSFJ_DID = "";
									String SJWSFJ_XID = "";
									for (int k = 0; k < jsonObjs3.length(); k++) {
										jsonObj3 = (JSONObject) jsonObjs3.opt(k);
										if (SJWSFJ_GRPID != "")
											SJWSFJ_GRPID = SJWSFJ_GRPID + ",";
										SJWSFJ_GRPID = SJWSFJ_GRPID + jsonObj3.getString("SJWSFJ_GRPID");
										if (SJWSFJ_XH != "")
											SJWSFJ_XH = SJWSFJ_XH + ",";
										SJWSFJ_XH = SJWSFJ_XH + jsonObj3.getString("SJWSFJ_XH");
										if (SJWSFJ_FileName != "")
											SJWSFJ_FileName = SJWSFJ_FileName + ",";
										SJWSFJ_FileName = SJWSFJ_FileName + jsonObj3.getString("SJWSFJ_FileName");
										if (SJWSFJ_FileType != "")
											SJWSFJ_FileType = SJWSFJ_FileType + ",";
										SJWSFJ_FileType = SJWSFJ_FileType + jsonObj3.getString("SJWSFJ_FileType");
										if (SJWSFJ_FilePath != "")
											SJWSFJ_FilePath = SJWSFJ_FilePath + ",";
										SJWSFJ_FilePath = SJWSFJ_FilePath + jsonObj3.getString("SJWSFJ_FilePath");
										if (SJWSFJ_WHRID != "")
											SJWSFJ_WHRID = SJWSFJ_WHRID + ",";
										SJWSFJ_WHRID = SJWSFJ_WHRID + jsonObj3.getString("SJWSFJ_WHRID");
										if (SJWSFJ_WHR != "")
											SJWSFJ_WHR = SJWSFJ_WHR + ",";
										SJWSFJ_WHR = SJWSFJ_WHR + jsonObj3.getString("SJWSFJ_WHR");
										if (SJWSFJ_WHSJ != "")
											SJWSFJ_WHSJ = SJWSFJ_WHSJ + ",";
										SJWSFJ_WHSJ = SJWSFJ_WHSJ + jsonObj3.getString("SJWSFJ_WHSJ");
										if (SJWSFJ_FullName != "")
											SJWSFJ_FullName = SJWSFJ_FullName + ",";
										SJWSFJ_FullName = SJWSFJ_FullName + jsonObj3.getString("SJWSFJ_FullName");
										if (SJWSFJ_WJJ != "")
											SJWSFJ_WJJ = SJWSFJ_WJJ + ",";
										SJWSFJ_WJJ = SJWSFJ_WJJ + jsonObj3.getString("SJWSFJ_WJJ");
										if (SJWSFJ_DID != "")
											SJWSFJ_DID = SJWSFJ_DID + ",";
										SJWSFJ_DID = SJWSFJ_DID + jsonObj3.getString("SJWSFJ_DID");
										if (SJWSFJ_XID != "")
											SJWSFJ_XID = SJWSFJ_XID + ",";
										SJWSFJ_XID = SJWSFJ_XID + jsonObj3.getString("SJWSFJ_XID");

									}

									rz.setSJWSFJ_GRPID(SJWSFJ_GRPID);
									rz.setSJWSFJ_XH(SJWSFJ_XH);
									rz.setSJWSFJ_FileName(SJWSFJ_FileName);
									rz.setSJWSFJ_FileType(SJWSFJ_FileType);
									rz.setSJWSFJ_FilePath(SJWSFJ_FilePath);
									rz.setSJWSFJ_WHRID(SJWSFJ_WHRID);
									rz.setSJWSFJ_WHR(SJWSFJ_WHR);
									rz.setSJWSFJ_WHSJ(SJWSFJ_WHSJ);
									rz.setSJWSFJ_WHSJ(SJWSFJ_WHSJ);
									rz.setSJWSFJ_FullName(SJWSFJ_FullName);
									rz.setSJWSFJ_WJJ(SJWSFJ_WJJ);
									rz.setSJWSFJ_DID(SJWSFJ_DID);
									rz.setSJWSFJ_XID(SJWSFJ_XID);
									Log.d("yuanw", rz.getSJWSFJ_FullName());
									Log.d("yuanw1", rz.getSJWSFJ_XH());

									JSONTokener jsonTokener3 = new JSONTokener(json4);
									JSONObject xm3 = (JSONObject) jsonTokener3.nextValue();
									jsonObjs4 = xm3.getJSONArray("commentlist");

									String reply_id = "";
									String create_user = "";
									String attach_ids = "";
									String attachments = "";
									String create_time = "";
									String content = "";
									String name = "";
									for (int m = 0; m < jsonObjs4.length(); m++) {
										jsonObj4 = (JSONObject) jsonObjs4.opt(m);
										if (reply_id != "")
											reply_id = reply_id + ",";
										reply_id = reply_id + jsonObj4.getString("reply_id");
										if (create_user != "")
											create_user = create_user + ",";
										create_user = create_user + jsonObj4.getString("create_user");
										if (attach_ids != "")
											attach_ids = attach_ids + ",";
										attach_ids = attach_ids + jsonObj4.getString("attach_ids");
										if (attachments != "")
											attachments = attachments + ",";
										attachments = attachments + jsonObj4.getString("attachments");
										if (create_time != "")
											create_time = create_time + ",";
										create_time = create_time + jsonObj4.getString("create_time");
										if (content != "")
											content = content + ",";
										content = content + jsonObj4.getString("content");
										if (name != "")
											name = name + ",";
										name = name + jsonObj4.getString("name");

									}
									rz.setReply_id(reply_id);
									rz.setCreate_user(create_user);
									rz.setAttach_ids(attach_ids);
									rz.setAttachments(attachments);
									rz.setCreate_time(create_time);
									rz.setContent(content);
									rz.setName(name);
									Log.d("yuansssss", rz.getContent());


									JSONTokener jsonTokener4 = new JSONTokener(json5);
									JSONObject xm4 = (JSONObject) jsonTokener4.nextValue();
									jsonObjs5 = xm4.getJSONArray("likelist");
									
								//	String reply_id = "";
									String name1 = "";
									for (int a = 0; a < jsonObjs5.length(); a++) {
										jsonObj5 = (JSONObject) jsonObjs5.opt(a);
										/*if (reply_id != "")
											reply_id = reply_id + ",";
										reply_id = reply_id + jsonObj4.getString("reply_id");*/
										
										if (name1 != "")
											name1 = name1 + ",";
										name1 = name1 + jsonObj5.getString("name");
										
									}		
									rz.setName1(name1);
									Log.d("yuansssss", rz.getName1());

									listItems.add(rz);
								}

							}
						} catch (Exception e) {
						}

						Message msg = new Message();
						msg.what = WHAT_DID_MORE;
						handler.sendMessage(msg);
					}

				}
			}.start();
		} else {
			new AlertDialog.Builder(ZFXX2.this).setMessage("���������������ã�").setTitle("����������")
					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
						}

					}).show();

		}
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		// TODO Auto-generated method stub

	}

	//����
	public void btn_back(View v) {
		this.finish();
	}

	
	/**
	 * 
	 * ������
	 * 
	 */
	public class DZFAdapter2 extends BaseAdapter {
		private Context context; // ����������
		private List<DZF> listItems; // ��Ʒ��Ϣ����
		private LayoutInflater listContainer; // ��ͼ����
		private int f;
		private String json;
		private String spname;
		private TitlePopup titlePopup;

		public final class ListItemView { // �Զ���ؼ�����
			/* public ImageView image; */
			public TextView text01;
			public TextView text02;
			public TextView text03;
			public TextView text04;
			public TextView text05;
			public TextView text06;
			public TextView text07;
			public TextView text08;
			public TextView text09;
			public TextView text10;
			public TextView plr;
			public TextView nr;
			public RelativeLayout pl;
			public NoScrollGridView detail;
			public NoScrollGridView detail1;
			private ImageView imageView1;
			private ImageView btn1;
			public TextView message_last;
			public TextView message_last1;
			
			NoScrollGridView show_zan;
			ImageView show_msg_zan;
			ImageView show_msg_zan1;
			ImageView show_pinglun;
			ImageView one_image;
			RelativeLayout show_dainzan_buju;
			TextView show_name;
			TextView show_dianzan_msg;
			Button line;
			NoScrollListView replyList; // ���ۻظ��б�
			NoScrollGridView show_image;

		}

		public DZFAdapter2(Context context, List<DZF> listItems) {
			this.context = context;
			listContainer = LayoutInflater.from(context); // ������ͼ����������������
			this.listItems = listItems;

		}

		@Override
		public int getCount() {
			if (listItems == null) {
				return 0;
			} else {
				return listItems.size();
			}
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		public void setmes(List<DZF> listItems) {
			this.listItems = listItems;
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			final int x = position;
			ListItemView listItemView = null;
			if (convertView == null) {
				listItemView = new ListItemView();
				convertView = listContainer.inflate(R.layout.dzfxx_adapter3, null);
				// ��ȡ�ؼ�����
				listItemView.text01 = (TextView) convertView.findViewById(R.id.text1);
				listItemView.text02 = (TextView) convertView.findViewById(R.id.text1_1);
				listItemView.text03 = (TextView) convertView.findViewById(R.id.text2);
				listItemView.text04 = (TextView) convertView.findViewById(R.id.text4_2);
				listItemView.text05 = (TextView) convertView.findViewById(R.id.text5_1);
				listItemView.text06 = (TextView) convertView.findViewById(R.id.text4);
				listItemView.text07 = (TextView) convertView.findViewById(R.id.text4_6);
				listItemView.text08 = (TextView) convertView.findViewById(R.id.text4_8);
				listItemView.detail = (NoScrollGridView) convertView.findViewById(R.id.gridView);
				listItemView.detail1 = (NoScrollGridView) convertView.findViewById(R.id.gridView1);
				listItemView.imageView1 = (ImageView) convertView.findViewById(R.id.imageView1);
				listItemView.show_msg_zan = (ImageView) convertView.findViewById(R.id.show_msg_zan);
				listItemView.show_msg_zan1 = (ImageView) convertView.findViewById(R.id.show_msg_zan1);
				listItemView.text09 = (TextView) convertView.findViewById(R.id.text4_4);
				listItemView.text10 = (TextView) convertView.findViewById(R.id.text5_4);
				listItemView.plr = (TextView) convertView.findViewById(R.id.textView1);
				listItemView.nr = (TextView) convertView.findViewById(R.id.info_text1);
				listItemView.pl = (RelativeLayout) convertView.findViewById(R.id.pl);
				listItemView.show_pinglun = (ImageView) convertView.findViewById(R.id.show_pinglun);
				listItemView.message_last = (TextView) convertView.findViewById(R.id.message_last);
				listItemView.message_last1 = (TextView) convertView.findViewById(R.id.message_last1);
				listItemView.show_dainzan_buju = (RelativeLayout) convertView.findViewById(R.id.show_dainzan_buju);
				
				// ���ÿؼ�����convertView
				convertView.setTag(listItemView);
			} else {
				listItemView = (ListItemView) convertView.getTag();
			}

			// ��΢��
			titlePopup = new TitlePopup(context, Util.dip2px(context, 165), Util.dip2px(context, 40));
			titlePopup.addAction(new ActionItem(context, "��", R.drawable.circle_praise));
			titlePopup.addAction(new ActionItem(context, "����", R.drawable.circle_comment));

			/**
			 * ��ȡֵ
			 */
			
			listItemView.text01.setText(listItems.get(position).getMobileTel());
			listItemView.text02.setText(listItems.get(position).getPmMonthScheduleBase_Handler());
			listItemView.text03.setText(listItems.get(position).getExistProblem());
			listItemView.text04.setText(listItems.get(position).getProName());
			listItemView.text05.setText(listItems.get(position).getQqNumber());
			listItemView.text06.setText(listItems.get(position).getProLinkMan()
			+ listItems.get(position).getBeginDatestr() + listItems.get(position).getOverDate());
			// listItemView.text07.setText(listItems.get(position).getProSchedule());
			// listItemView.text08.setText(listItems.get(position).getAdviseDo());
			
			
			if (listItems.get(position).getName1().equals("") ) {
				listItemView.show_dainzan_buju.setVisibility(View.GONE);
			/*	listItemView.show_msg_zan1.setVisibility(View.GONE);
				listItemView.show_msg_zan.setVisibility(View.VISIBLE);
				listItemView.message_last.setVisibility(View.VISIBLE);
				listItemView.message_last1.setVisibility(View.GONE);*/
				
			}else {
				listItemView.text09.setText(listItems.get(position).getName1());
				listItemView.show_dainzan_buju.setVisibility(View.VISIBLE);
				/*listItemView.show_msg_zan.setVisibility(View.GONE);
				listItemView.show_msg_zan1.setVisibility(View.VISIBLE);
				listItemView.message_last.setVisibility(View.GONE);
				listItemView.message_last1.setVisibility(View.VISIBLE);*/
			}
			
			/*final String dz[] = listItems.get(position).getName1().split(",");
			for (int i = 0; i < dz.length; i++){
				System.out.println("sssssddd:"+dz[i]);
				List lists = Arrays.asList(dz);
			if (lists.contains(uxm)) {
			//	Toast.makeText(getApplicationContext(), dz[i],Toast.LENGTH_SHORT).show();
				listItemView.show_msg_zan.setVisibility(View.GONE);
				listItemView.message_last.setVisibility(View.GONE);
				listItemView.show_msg_zan1.setVisibility(View.VISIBLE);
				listItemView.message_last1.setVisibility(View.VISIBLE);
				
				
				
			}else {
				listItemView.show_msg_zan.setVisibility(View.VISIBLE);
				listItemView.message_last.setVisibility(View.VISIBLE);
				listItemView.show_msg_zan1.setVisibility(View.GONE);
				listItemView.message_last1.setVisibility(View.GONE);
				
			}
			}*/
			
		
	/*********************************************************************************************************/
		
			if (listItems.get(position).getQqNumber().equals("")) {
				listItemView.text05.setText("��");
			} else {
				listItemView.text05.setText(listItems.get(position).getQqNumber());
			}

			if (listItems.get(position).getProSchedule().equals("")) {
				listItemView.text07.setText("��");
			} else {
				listItemView.text07.setText(listItems.get(position).getProSchedule());
			}

			if (listItems.get(position).getAdviseDo().equals("")) {
				listItemView.text08.setText("��");
			} else {
				listItemView.text08.setText(listItems.get(position).getAdviseDo());
			}
			
			
			/**
			 * ��ȡ������
			 */
			final String plr[] = listItems.get(position).getName().split(",");
			final String nr[] = listItems.get(position).getContent().split(",");
			if (listItems.get(position).getName().length() != 0) {
				String string = "";
				for (int i = 0; i < plr.length; i++) {
					string = string + plr[i] + ":" + "\n";
					// System.out.println("aaaaaaa"+plr[i]+":"+nr[i]+"\n");
				}
				listItemView.pl.setVisibility(View.VISIBLE);
				listItemView.plr.setText(string);
			} else {
				listItemView.plr.setText("");
				listItemView.pl.setVisibility(View.GONE);
			}
			
			/**
			 * ��ȡ��������
			 */
			if (listItems.get(position).getContent().length() != 0) {
				String string1 = "";
				for (int j = 0; j < nr.length; j++) {
					string1 = string1 + nr[j] + "\n";
				}
				listItemView.nr.setText(string1);
				listItemView.pl.setVisibility(View.VISIBLE);
			} else {
				listItemView.nr.setText("");
				listItemView.pl.setVisibility(View.GONE);
			}

			/**
			 * ��ȡͼƬ
			 */
			final String TP_urls[] = listItems.get(position).getSJWSFJ_FullName().split(",");
			if (listItems.get(position).getSJWSFJ_FullName().length() != 0)
				for (int i = 0; i < TP_urls.length; i++)
					TP_urls[i] = "http://218.92.212.198:4888/FJuploadfiles/" + TP_urls[i];
			if (TP_urls.length > 0 && !TP_urls[0].equals("")) {
				listItemView.detail.setVisibility(View.VISIBLE);
				listItemView.detail.setAdapter(new MyGridAdapter(TP_urls, context));
				listItemView.detail.setOnItemClickListener(new AdapterView.OnItemClickListener() {
					@Override
					public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
						imageBrower(position, TP_urls);
					}
				});
			} else {
				listItemView.detail.setVisibility(View.GONE);
			}

			/**
			 * ��ȡͷ��
			 */
			String a = listItems.get(position).getPmMonthScheduleBase_Awaiter().replace("http://218.92.212.198:4888","");
			final String TP_urls1[] = a.split(",");
			if (a.equals("/Controls/TXUpload/image/bg_120.gif")) {
				listItemView.detail1.setVisibility(View.GONE);
				listItemView.imageView1.setVisibility(View.VISIBLE);
			} else {
				for (int i = 0; i < TP_urls1.length; i++)
				TP_urls1[i] = "http://218.92.212.198:4888/" + TP_urls1[0];
				listItemView.detail1.setAdapter(new NoScrollGridAdapter(TP_urls1, context));
				listItemView.detail1.setVisibility(View.VISIBLE);
				listItemView.imageView1.setVisibility(View.GONE);
				//�鿴ͷ��
				listItemView.detail1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
					@Override
					public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
						imageBrower(position, TP_urls1);
					}
				});
			}

			/**
			 * ��ת�߷���ϸҳ��
			 */
			listItemView.text06.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					DZF bp = new DZF();
					bp = listItems.get(x);
					Intent intent = new Intent();
					intent.setClass(context, InfoZFXX2.class);
					Bundle bundle = new Bundle();
					bundle.putSerializable("DZF", bp);
					intent.putExtras(bundle);
					context.startActivity(intent);
				}
				
			});
			listItemView.text07.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					DZF bp = new DZF();
					bp = listItems.get(x);
					Intent intent = new Intent();
					intent.setClass(context, InfoZFXX2.class);
					Bundle bundle = new Bundle();
					bundle.putSerializable("DZF", bp);
					intent.putExtras(bundle);
					context.startActivity(intent);
				}
			});
			
			listItemView.text08.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					DZF bp = new DZF();
					bp = listItems.get(x);
					Intent intent = new Intent();
					intent.setClass(context, InfoZFXX2.class);
					Bundle bundle = new Bundle();
					bundle.putSerializable("DZF", bp);
					intent.putExtras(bundle);
					context.startActivity(intent);

				}
			});

			/**
			 * ���޵��ýӿ�
			 */
			spname = "zhouhui";
	//		uxm=getSharedPreferences("ydjtLogin",Context.MODE_WORLD_READABLE + Context.MODE_WORLD_WRITEABLE).getString("uxm", "");
			listItemView.show_msg_zan.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {
					
					new Thread(new Runnable() {
						@Override
						
						public void run() {

						json = WebServiceUtil.everycanforStr4("UserID", "post_id", "", "", "", "", spname,
									listItems.get(x).getId(), "", 0, 0, 0, "post_like_add");
							Log.d("json1111111111", json);

							
							  Message message = new Message(); 
							  message.what =7;
							  handler.sendMessage(message);
							 
						}
					}).start();

				}

			});
			
			/**
			 * ȡ���޵��ýӿ�
			 */
			
			listItemView.show_msg_zan1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					new Thread(new Runnable() {
						@Override
						public void run() {

						json = WebServiceUtil.everycanforStr4("UserID", "post_id", "", "", "", "",
								spname,listItems.get(x).getId(), "", 0, 0, 0, "post_like_del");
							Log.d("json1111111111", json);

							
							  Message message = new Message(); 
							  message.what =7;
							  handler.sendMessage(message);
							 
						}
					}).start();

				}
			});
			
			/**
			 * ���ֵ���
			 */
			listItemView.message_last.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {
					new Thread(new Runnable() {
						@Override
						public void run() {

						json = WebServiceUtil.everycanforStr4("UserID", "post_id", "", "", "", "", spname,
									listItems.get(x).getId(), "", 0, 0, 0, "post_like_add");
							Log.d("json1111111111", json);

							
							  Message message = new Message(); 
							  message.what =7;
							  handler.sendMessage(message);
						}
					}).start();
				}
			});
			
			/**
			 * ����ȡ����
			 */
			
			listItemView.message_last1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					new Thread(new Runnable() {
						@Override
						public void run() {

						json = WebServiceUtil.everycanforStr4("UserID", "post_id", "", "", "", "",
								spname,listItems.get(x).getId(), "", 0, 0, 0, "post_like_del");
							Log.d("json1111111111", json);

							
							  Message message = new Message(); 
							  message.what =7;
							  handler.sendMessage(message);
							 
						}
					}).start();

				}
			});
			
			
			listItemView.pl.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					ZFXX2.listen.setNewid(listItems.get(position).getId());
					index_pos = position;
					isReply = false;
					commentLinear.setVisibility(View.VISIBLE);
					onFocusChange(true);
				}
			});
			
			
			
			
			
			/**
			 * ����
			 */
			listItemView.show_pinglun.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					ZFXX2.listen.setNewid(listItems.get(position).getId());
					index_pos = position;
					isReply = false;
					commentLinear.setVisibility(View.VISIBLE);
					onFocusChange(true);
				}
			});

			
			
			return convertView;

		}

		/**
		 * ��ʾ���������뷨
		 */
		private void onFocusChange(boolean hasFocus) {
			final boolean isFocus = hasFocus;
			(new Handler()).postDelayed(new Runnable() {
				public void run() {
					InputMethodManager imm = (InputMethodManager) commentEdit.getContext()
							.getSystemService(INPUT_METHOD_SERVICE);
					if (isFocus) {
						// ��ʾ���뷨
						imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
					} else {
						// �������뷨
						imm.hideSoftInputFromWindow(commentEdit.getWindowToken(), 0);
					}
				}
			}, 100);
		}

		/**
		 * ��ȡ����ͼƬ
		 */
		private void imageBrower(int position, String[] urls) {
			Intent intent = new Intent(context, ImagePagerActivity.class);
			// ͼƬurl,Ϊ����ʾ����ʹ�ó�����һ������ݿ��л������л�ȡ
			intent.putExtra(ImagePagerActivity.EXTRA_IMAGE_URLS, urls);
			intent.putExtra(ImagePagerActivity.EXTRA_IMAGE_INDEX, position);
			context.startActivity(intent);
		}

	}
}
