package com.woeasy.DZFNew;



import com.woeasy.model.DZF;
import com.woeasy.model.ROWS;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import cn.buaa.util.WebServiceUtil;

public class InfoZFXX extends Activity {
private TextView t1,t2,t3,t4,t5,t6,t7;
private Button bj;
private DZF email;
private String json;
private Button bt2;
private ProgressDialog progressDialog;
public static InfoZFXX listact;
private int id;
private AlertDialog dlg;


private Handler handler = new Handler(){
	  public void handleMessage(Message msg){
	      super.handleMessage(msg);
	      if (msg.what == 1) {
				progressDialog.dismiss();
				if(json!=null&&json.equals("1")){
					if (ZFXX_list.listact != null) {
						ZFXX_list.listact.onRefresh();
						finish();
					}
					
					
				}
			}
	  }
};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dzf__xx);
		findview();
	}

	
	public void findview(){
		Intent intent = this.getIntent(); 
		email=(DZF) intent.getSerializableExtra("DZF");
		Log.d("11111", email.getId());
		 id=Integer.parseInt(email.getId());
		 System.out.println("caonima::"+id);
		t1=(TextView) findViewById(R.id.textView01);
		t2=(TextView) findViewById(R.id.textView02);
		t3=(TextView) findViewById(R.id.textView03);
		t4=(TextView) findViewById(R.id.textView04);
		t5=(TextView) findViewById(R.id.textView05);
		t6=(TextView) findViewById(R.id.textView06);
		t7=(TextView) findViewById(R.id.textView07);
		
		bt2=(Button)findViewById(R.id.bt2);
		bj=(Button) findViewById(R.id.bj);
		bj.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(InfoZFXX.this, ZFXX_BJ.class);
				Bundle bundle = new Bundle();
				bundle.putSerializable("DZF", email);
				intent.putExtras(bundle);
				startActivity(intent);
				finish();
			}
		});
		bt2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				
				new AlertDialog.Builder(InfoZFXX.this).setMessage("ȷ��ɾ�����߷���Ϣ��")
				.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						
					}
				})
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {						
					@Override
					public void onClick(DialogInterface dialog, int which) {
						progressDialog=ProgressDialog.show(InfoZFXX.this,"����ɾ��������","���Ե�...");
						new Thread(new Runnable() {
							@Override
							public void run() {
								
								json = WebServiceUtil.everycanforStr("","","","id","","","", id,"deleteZFJL");
								Message message = new Message();
								message.what = 1;
								handler.sendMessage(message);
						        
							}
						}).start();
					}

				 }).show();
				
				
			}
		});
		
		
		
		
		 t1.setText(email.getProName());
		 t2.setText(email.getYearND());
		 t3.setText(email.getYearYF());
		 
		 t4.setText(email.getProSchedule());
		 t5.setText(email.getExistProblem());
		 t6.setText(email.getAdviseDo());
		 t7.setText(email.getChangeCondition());
		 
	}
	

}
