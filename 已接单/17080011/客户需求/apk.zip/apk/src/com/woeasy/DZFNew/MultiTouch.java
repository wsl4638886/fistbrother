package com.woeasy.DZFNew;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;


import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.FloatMath;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("FloatMath")
@TargetApi(Build.VERSION_CODES.ECLAIR)
public class MultiTouch extends Activity implements OnTouchListener {
	/**
	 * 鍥剧墖娴忚銆佺缉鏀撅拷?鎷栧姩銆佽嚜鍔ㄥ眳锟�??
	 */
	private String resource_id;
	Matrix matrix = new Matrix();
	Matrix savedMatrix = new Matrix();
	DisplayMetrics dm;
	ImageView imgView;
	Bitmap bitmap;
	private TextView textView;

	float minScaleR;// 锟�??锟斤拷缂╂斁姣斾緥
	static final float MAX_SCALE = 4f;// 锟�??锟斤拷缂╂斁姣斾緥

	static final int NONE = 0;// 鍒濆鐘讹拷?
	static final int DRAG = 1;// 鎷栧姩
	static final int ZOOM = 2;// 缂╂斁
	int mode = NONE;

	PointF prev = new PointF();
	PointF mid = new PointF();
	float dist = 1f;
	private int nowid = 0;
	private ArrayList<String> lists;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.multitouch);

		Intent intent = this.getIntent();
		Bundle bundle = intent.getExtras();
		resource_id = bundle.getString("id");
		lists = bundle.getStringArrayList("list");
		nowid = bundle.getInt("position");

		imgView = (ImageView) findViewById(R.id.multitouch_imageView);// 鑾峰彇鎺т欢
		textView = (TextView) findViewById(R.id.indicator);// 鑾峰彇鎺т欢

		File pic = new File(resource_id);

		bitmap = decodeFile2(pic);
		if (bitmap == null) {
			Toast.makeText(MultiTouch.this, "鍔犺浇澶辫触", 3000).show();
			return;
		}
		imgView.setImageBitmap(bitmap);

		imgView.setOnTouchListener(this);// 璁剧疆瑙﹀睆鐩戝惉
		dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);// 鑾峰彇鍒嗚鲸锟�??
		minZoom();
		center();
		imgView.setImageMatrix(matrix);
		if (lists != null) {
			textView.setText((nowid + 1) + "/" + lists.size());
		}
	}

	private Bitmap decodeFile2(File f) {
		try {
			// decode image size
			BitmapFactory.Options o = new BitmapFactory.Options();
			o.inJustDecodeBounds = true;
			BitmapFactory.decodeStream(new FileInputStream(f), null, o);

			// Find the correct scale value. It should be the power of 2.
			final int REQUIRED_SIZE = 500;
			int width_tmp = o.outWidth, height_tmp = o.outHeight;
			int scale = 1;
			while (true) {
				if (width_tmp / 2 < REQUIRED_SIZE || height_tmp / 2 < REQUIRED_SIZE)
					break;
				width_tmp /= 2;
				height_tmp /= 2;
				scale *= 2;
			}

			// decode with inSampleSize
			BitmapFactory.Options o2 = new BitmapFactory.Options();
			o2.inSampleSize = scale;
			return BitmapFactory.decodeStream(new FileInputStream(f), null, o2);
		} catch (FileNotFoundException e) {
		}
		return null;
	}

	/**
	 * 瑙﹀睆鐩戝惉
	 */
	public boolean onTouch(View v, MotionEvent event) {

		switch (event.getAction() & MotionEvent.ACTION_MASK) {
		// 涓荤偣鎸変笅
		case MotionEvent.ACTION_DOWN:
			savedMatrix.set(matrix);
			prev.set(event.getX(), event.getY());
			mode = DRAG;
			break;
		// 鍓偣鎸変笅
		case MotionEvent.ACTION_POINTER_DOWN:
			dist = spacing(event);
			// 濡傛灉杩炵画涓ょ偣璺濈澶т簬10锛屽垯鍒ゅ畾涓哄鐐规ā锟�??
			if (spacing(event) > 10f) {
				savedMatrix.set(matrix);
				midPoint(mid, event);
				mode = ZOOM;
			}
			break;
		case MotionEvent.ACTION_UP:
		case MotionEvent.ACTION_POINTER_UP:
			if (mode == DRAG) {
				if (lists == null) {
					center();
				} else if (event.getX() - prev.x > 20 && nowid > 0) {
					nowid = nowid - 1;
					bitmap = decodeFile2(new File(lists.get(nowid)));
					imgView.setImageBitmap(bitmap);
					textView.setText((nowid + 1) + "/" + lists.size());

					center();
				} else if ((event.getX() - prev.x) < -20 && nowid < lists.size() - 1) {
					nowid = nowid + 1;
					bitmap = decodeFile2(new File(lists.get(nowid)));
					imgView.setImageBitmap(bitmap);
					textView.setText((nowid + 1) + "/" + lists.size());
					center();
				}
			}
			mode = NONE;
			break;
		case MotionEvent.ACTION_MOVE:
			if (mode == DRAG) {
				matrix.set(savedMatrix);
				matrix.postTranslate(event.getX() - prev.x, event.getY() - prev.y);
			} else if (mode == ZOOM) {
				float newDist = spacing(event);
				if (newDist > 10f) {
					matrix.set(savedMatrix);
					float tScale = newDist / dist;
					matrix.postScale(tScale, tScale, mid.x, mid.y);
				}
			}
			break;
		}
		imgView.setImageMatrix(matrix);
		CheckView();
		return true;
	}

	/**
	 * 闄愬埗锟�??锟斤拷锟�??锟斤拷缂╂斁姣斾緥锛岃嚜鍔ㄥ眳锟�??
	 */
	private void CheckView() {
		float p[] = new float[9];
		matrix.getValues(p);
		if (mode == ZOOM) {
			if (p[0] < minScaleR) {
				matrix.setScale(minScaleR, minScaleR);
			}
			if (p[0] > MAX_SCALE) {
				matrix.set(savedMatrix);
			}
		}
		center();
	}

	/**
	 * 锟�??锟斤拷缂╂斁姣斾緥锛屾渶澶т负100%
	 */
	private void minZoom() {
		minScaleR = Math.min((float) dm.widthPixels / (float) bitmap.getWidth(),
				(float) dm.heightPixels / (float) bitmap.getHeight());
		if (minScaleR < 1.0) {
			matrix.postScale(minScaleR, minScaleR);
		}
	}

	private void center() {
		center(true, true);
	}

	/**
	 * 妯悜銆佺旱鍚戝眳锟�??
	 */
	protected void center(boolean horizontal, boolean vertical) {

		if (bitmap == null) {
			return;
		}

		Matrix m = new Matrix();
		m.set(matrix);
		RectF rect = new RectF(0, 0, bitmap.getWidth(), bitmap.getHeight());
		m.mapRect(rect);

		float height = rect.height();
		float width = rect.width();

		float deltaX = 0, deltaY = 0;

		if (vertical) {
			// 鍥剧墖灏忎簬灞忓箷澶у皬锛屽垯灞呬腑鏄剧ず銆傚ぇ浜庡睆骞曪紝涓婃柟鐣欑┖鍒欏線涓婄Щ锛屼笅鏂圭暀绌哄垯锟�??锟斤拷锟�??
			int screenHeight = dm.heightPixels;
			if (height < screenHeight) {
				deltaY = (screenHeight - height) / 2 - rect.top;
			} else if (rect.top > 0) {
				deltaY = -rect.top;
			} else if (rect.bottom < screenHeight) {
				deltaY = imgView.getHeight() - rect.bottom;
			}
		}

		if (horizontal) {
			int screenWidth = dm.widthPixels;
			if (width < screenWidth) {
				deltaX = (screenWidth - width) / 2 - rect.left;
			} else if (rect.left > 0) {
				deltaX = -rect.left;
			} else if (rect.right < screenWidth) {
				deltaX = screenWidth - rect.right;
			}
		}
		matrix.postTranslate(deltaX, deltaY);
	}

	/**
	 * 涓ょ偣鐨勮窛锟�??
	 */
	private float spacing(MotionEvent event) {
		float x = event.getX(0) - event.getX(1);
		float y = event.getY(0) - event.getY(1);
		return FloatMath.sqrt(x * x + y * y);
	}

	/**
	 * 涓ょ偣鐨勪腑锟�??
	 */
	private void midPoint(PointF point, MotionEvent event) {
		float x = event.getX(0) + event.getX(1);
		float y = event.getY(0) + event.getY(1);
		point.set(x / 2, y / 2);
	}

	// 鐩戝惉杩斿洖锟�??
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			this.finish();
			// 璁剧疆鍒囨崲鍔ㄧ敾锛屼粠宸﹁竟杩涘叆锛屽彸杈癸拷?锟�??
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	public void btn_back(View v) {
		this.finish();
	}
}
