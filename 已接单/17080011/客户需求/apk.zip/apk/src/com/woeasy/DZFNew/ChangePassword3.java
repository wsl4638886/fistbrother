package com.woeasy.DZFNew;



import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class ChangePassword3 extends Activity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.changepassword3);
		
	}

	public void btn_back(View v){
		this.finish();
	}
	
}
