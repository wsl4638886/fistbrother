package com.woeasy.model;

import java.io.Serializable;

public class ChoseUser implements Serializable {
    public String ID;
    public String username; 
    public String jp; 
    public String qp;
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getJp() {
		return jp;
	}
	public void setJp(String jp) {
		this.jp = jp;
	}
	public String getQp() {
		return qp;
	}
	public void setQp(String qp) {
		this.qp = qp;
	} 
    
}
