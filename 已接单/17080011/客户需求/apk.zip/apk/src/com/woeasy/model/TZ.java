package com.woeasy.model;

import java.io.Serializable;

public class TZ implements Serializable {
	private int XWGL_ID;
	private String XWGL_BT;
	private String XWGL_ZW;
	private String XWGL_FWR;
	private String XWGL_FWRQ;
	private String XWGL_CreaterID;
	private String XWGL_CreaterName;
	private String XWGL_CreateTime;
	private String XWGL_ModifierID;
	private String XWGL_ModifierName;
	private String XWGL_ModifyTime;

	public int getXWGL_ID() {
		return XWGL_ID;
	}
	public void setXWGL_ID(int xWGL_ID) {
		XWGL_ID = xWGL_ID;
	}
	public String getXWGL_BT() {
		return XWGL_BT;
	}
	public void setXWGL_BT(String xWGL_BT) {
		XWGL_BT = xWGL_BT;
	}
	public String getXWGL_ZW() {
		return XWGL_ZW;
	}
	public void setXWGL_ZW(String xWGL_ZW) {
		XWGL_ZW = xWGL_ZW;
	}
	public String getXWGL_FWR() {
		return XWGL_FWR;
	}
	public void setXWGL_FWR(String xWGL_FWR) {
		XWGL_FWR = xWGL_FWR;
	}
	public String getXWGL_FWRQ() {
		return XWGL_FWRQ;
	}
	public void setXWGL_FWRQ(String xWGL_FWRQ) {
		XWGL_FWRQ = xWGL_FWRQ;
	}
	public String getXWGL_CreaterID() {
		return XWGL_CreaterID;
	}
	public void setXWGL_CreaterID(String xWGL_CreaterID) {
		XWGL_CreaterID = xWGL_CreaterID;
	}
	public String getXWGL_CreaterName() {
		return XWGL_CreaterName;
	}
	public void setXWGL_CreaterName(String xWGL_CreaterName) {
		XWGL_CreaterName = xWGL_CreaterName;
	}
	public String getXWGL_CreateTime() {
		return XWGL_CreateTime;
	}
	public void setXWGL_CreateTime(String xWGL_CreateTime) {
		XWGL_CreateTime = xWGL_CreateTime;
	}
	public String getXWGL_ModifierID() {
		return XWGL_ModifierID;
	}
	public void setXWGL_ModifierID(String xWGL_ModifierID) {
		XWGL_ModifierID = xWGL_ModifierID;
	}
	public String getXWGL_ModifierName() {
		return XWGL_ModifierName;
	}
	public void setXWGL_ModifierName(String xWGL_ModifierName) {
		XWGL_ModifierName = xWGL_ModifierName;
	}
	public String getXWGL_ModifyTime() {
		return XWGL_ModifyTime;
	}
	public void setXWGL_ModifyTime(String xWGL_ModifyTime) {
		XWGL_ModifyTime = xWGL_ModifyTime;
	}

}
