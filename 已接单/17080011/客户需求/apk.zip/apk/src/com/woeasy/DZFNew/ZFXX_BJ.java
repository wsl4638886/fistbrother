package com.woeasy.DZFNew;



import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.kobjects.base64.Base64;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;
import com.woeasy.model.DZF;
import com.woeasy.model.MyBean;
import com.woeasy.model.ROWS;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import cn.buaa.util.FileUtils;
import cn.buaa.util.NetHelper;
import cn.buaa.util.UploadUtil;
import cn.buaa.util.WebServiceUtil;
import android.widget.AdapterView.OnItemLongClickListener;

@SuppressLint({ "WorldReadableFiles", "WorldWriteableFiles" })
public class ZFXX_BJ extends Activity implements AMapLocationListener{

	private TextView text1,text2,text3;
	private String spname,uxm,officeTel;
	private DZF ap;
	private String Camerapath,json,wz;
	private MyBean email = new MyBean();
	private NoScrollGridView detail;
	public static ZFXX_BJ list_Act;
	private ProgressDialog progressDialog;
	private Button up;
	private Calendar c = Calendar.getInstance();
	private EditText e1,e2,e3,e4;
	private int flag = 0;
	private String value1, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12,
	value13, value14, value15, value16, value17, value18, value19, value20, value21, value22, value23, value24,
	value25, value26, value27, value28, value29, value30, value31;
	private boolean webbing = false;
	// ����AMapLocationClient����󣬶�λ�����
		private AMapLocationClient mLocationClient = null;
		// ����mLocationOption���󣬶�λ����
		public AMapLocationClientOption mLocationOption = null;
	private String WD, JD;
	private String method = "update";
	private Handler handler = new Handler() {
		@SuppressWarnings("unchecked")
		@Override
		public void handleMessage(android.os.Message msg) {

			if (msg.what == 1) {
			} else if (msg.what == 2) {
				progressDialog.dismiss();
				Toast.makeText(ZFXX_BJ.this, "�޸ĳɹ�", Toast.LENGTH_SHORT).show();
				ZFXX_BJ.this.finish();
				if(json!=null){
					if (ZFXX_list.listact != null) {
						ZFXX_list.listact.onRefresh();
						ZFXX_BJ.this.finish();
					}
					
					
				}
			} else if (msg.what == 3) {

			}

		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ryxx_zfxx2);
		spname = getSharedPreferences("ydjtLogin",
				Context.MODE_WORLD_READABLE + Context.MODE_WORLD_WRITEABLE)
				.getString("spname", "");
		uxm = getSharedPreferences("ydjtLogin",
				Context.MODE_WORLD_READABLE + Context.MODE_WORLD_WRITEABLE)
				.getString("uxm", "");
		//����activityʱ���Զ�����������
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		list_Act = this;
		detail = (NoScrollGridView) findViewById(R.id.gridView);
		setfirstphoto();
		setdate();
		findView();
		setOnclick();
	}
	
	private void setOnclick() {
		up.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(e1.getText().toString().equals("")){
					Toast.makeText(ZFXX_BJ.this,"����д�����ռ������",3000).show();
				}else{
					findView();
				}
				

			}
		});

	}
	
	
	
	protected void uppic() {
		boolean havenet = NetHelper.IsHaveInternet(ZFXX_BJ.this);
		if (havenet) {
			progressDialog = ProgressDialog.show(ZFXX_BJ.this, "�����ϴ���������", "���Ե�...");
			new Thread() {
				@Override
				public void run() {
					if (email.getUrls() != null && email.getUrls().length > 0) {
						String fileString;
						for (int i = 0; i < email.getUrls().length; i++) {
							if (!email.getUrls()[i].substring(6, email.getUrls()[i].length()).contains("218.92.212.198")) {
								final Map<String, String> params1 = new HashMap<String, String>();
								params1.put("gcid", officeTel);
								params1.put("FileName",
										new File(email.getUrls()[i].substring(6, email.getUrls()[i].length()))
												.getName());
								params1.put("lbid", "0");
								params1.put("userid", spname);
								params1.put("wz", wz);
								final Map<String, File> files = new HashMap<String, File>();
								if (new File(email.getUrls()[i].substring(6, email.getUrls()[i].length())).getName()
										.contains(".mp4")) {
									files.put("uploadfile",
											new File(email.getUrls()[i].substring(6, email.getUrls()[i].length())));
								} else {
									files.put("uploadfile",
											yaosuo(email.getUrls()[i].substring(6, email.getUrls()[i].length())));
								}

								try {
									final String request = UploadUtil.post(WebServiceUtil.getURL() + "/QQCSFJUpload",
											params1, files);
									Log.d("yin", "�ϴ�ͼƬ��" + request);
								} catch (IOException e) {
									e.printStackTrace();
								}

							}
						}
					}
					Message message = new Message();
					message.what = 2;
					handler.sendMessage(message);
				}
			}.start();
		} else {
			new AlertDialog.Builder(ZFXX_BJ.this).setMessage("���������������ã�").setTitle("����������")
					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
						}
					}).show();
		}

	}
	
	public void setdate(){
		text1=(TextView) findViewById(R.id.text1);
		text2=(TextView) findViewById(R.id.text2);
		text3=(TextView) findViewById(R.id.text3);
		e1=(EditText) findViewById(R.id.Ed1);
		e2=(EditText) findViewById(R.id.Ed2);
		e3=(EditText) findViewById(R.id.Ed3);
		e4=(EditText) findViewById(R.id.Ed4);
		detail = (NoScrollGridView) findViewById(R.id.gridView);
		
		up= (Button) findViewById(R.id.up);
		Intent intent = this.getIntent(); 
	    ap=(DZF) intent.getSerializableExtra("DZF");
		text1.setText(ap.getProName());
		e1.setText(ap.getProSchedule());
		e2.setText(ap.getExistProblem());
		e3.setText(ap.getAdviseDo());
		e4.setText(ap.getChangeCondition());
		
	}
		
	public void findView(){
		int mYear = c.get(Calendar.YEAR); // ��ȡ��ǰ���
		int mMonth = c.get(Calendar.MONTH) + 1;// ��ȡ��ǰ�·�
		
		int R = c.get(Calendar.DAY_OF_MONTH);
		int S = c.get(Calendar.HOUR_OF_DAY);
		int F = c.get(Calendar.MINUTE);
		
		text2.setText(String.valueOf(mYear));
		text3.setText(String.valueOf(mMonth));
		
		/***************/
		value1 = ap.getId();
		System.out.print(value11);
		value2 =(String.valueOf( ap.getProSeq()));
		value3 = ap.getProName();
		value4 = String.valueOf(mYear);
		value5 = String.valueOf(mMonth);
		
		value6 = ap.getYearPlanFundSum();
		value7 = ap.getTotalInvestFromBegin();
		value8 = ap.getMonthInvest();
		value9 = ap.getLastInvestThisYear();
		value10 =ap.getZjsyLastyearInvestPercent();
		value11 = ap.getFinishInvestThisYear();
		value12 = ap.getBuildStep();
		value13 = ap.getApproSeq();
		value14 =ap.getPreceiptCode();
		value15 =ap.getDeferReason();
		
		value16 = e1.getText().toString().trim();
		value17 = e2.getText().toString().trim();
		value18 = e3.getText().toString().trim();
		value19 = e4.getText().toString().trim();
		value20=ap.getOfficeTel();
		
		
		
		value29=uxm;
		value30=mYear+"/"+mMonth+"/"+R+" "+S+":"+F+":"+S;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case 0:
			if (resultCode == RESULT_OK) {
				if (!Environment.getExternalStorageState().equals(
						Environment.MEDIA_MOUNTED)) {
					Toast.makeText(this, "SD��������", Toast.LENGTH_SHORT).show();
					return;
				}
				startActivity(new Intent(ZFXX_BJ.this,
						PhotosEdit.class).putExtra("path", Camerapath));
				overridePendingTransition(R.anim.roll_up, R.anim.roll);
			} else {
				Toast.makeText(this, "ȡ������", Toast.LENGTH_SHORT).show();
			}

			break;
		case 4:
			if (resultCode == RESULT_OK) {
				final String aaa = Camerapath;
				String urls2[] = null;
				if (email.getUrls() != null && email.getUrls().length > 0) {
					String urls1[] = new String[email.getUrls().length + 1];
					urls2 = new String[email.getUrls().length + 2];
					for (int i = 0; i < email.getUrls().length; i++) {
						urls1[i] = email.getUrls()[i];
						urls2[i] = email.getUrls()[i];
					}
					urls1[email.getUrls().length] = "file://" + aaa;
					urls2[email.getUrls().length] = "file://" + aaa;
					urls2[email.getUrls().length + 1] = "assets://photoadd.jpg";
					email.setUrls(urls1);
				} else {
					urls2 = new String[2];
					String pp = "file://" + aaa;
					urls2[0] = "file://" + aaa;
					urls2[1] = "assets://photoadd.jpg";
					email.setUrls(new String[] { pp });
				}
				final int p = urls2.length - 1;
				detail.setVisibility(View.VISIBLE);
				detail.setAdapter(new MyGridAdapter(urls2,
						ZFXX_BJ.this));
				detail.setOnItemClickListener(new AdapterView.OnItemClickListener() {
					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position1, long id) {
						if (position1 == p) {
							photo();
						} else {
							imageBrower(position1, email.getUrls());
						}

					}
				});
				detail.setOnItemLongClickListener(new OnItemLongClickListener() {
					@Override
					public boolean onItemLongClick(AdapterView<?> arg0,
							View arg1, final int arg2, long arg3) {
						if (arg2 != p) {
							new AlertDialog.Builder(ZFXX_BJ.this)
									.setMessage("ɾ������Ƭ��")
									.setTitle("ע��")
									.setNegativeButton(
											"ȡ��",
											new DialogInterface.OnClickListener() {
												@Override
												public void onClick(
														DialogInterface arg0,
														int arg1) {
												}
											})
									.setPositiveButton(
											"ȷ��",
											new DialogInterface.OnClickListener() {
												@Override
												public void onClick(
														DialogInterface dialog,
														int which) {
													deletepic(arg2,
															email.getUrls());
												}

											}).show();

						}
						return false;
					}
				});

			}
			break;

		case 5:
			if (resultCode == RESULT_OK) {
				Bundle bundle = data.getExtras();
				ArrayList<String> tDataList = (ArrayList<String>) bundle
						.getSerializable("dataList");
				if (tDataList != null) {

					int le = 0;
					String urls2[] = null;
					if (email.getUrls() != null && email.getUrls().length > 0) {
						le = email.getUrls().length;
					}

					String urls1[] = new String[le + tDataList.size()];
					urls2 = new String[le + tDataList.size() + 1];
					if (le != 0) {
						for (int j = 0; j < le; j++) {
							urls1[j] = email.getUrls()[j];
							urls2[j] = email.getUrls()[j];
						}
					}
					for (int i = 0; i < tDataList.size(); i++) {
						urls1[le + i] = "file://" + tDataList.get(i);
						urls2[le + i] = "file://" + tDataList.get(i);
					}
					urls2[le + tDataList.size()] = "assets://photoadd.jpg";
					email.setUrls(urls1);

					final int p = urls2.length - 1;
					detail.setVisibility(View.VISIBLE);
					detail.setAdapter(new MyGridAdapter(urls2,
							ZFXX_BJ.this));
					detail.setOnItemClickListener(new AdapterView.OnItemClickListener() {
						@Override
						public void onItemClick(AdapterView<?> parent,
								View view, int position1, long id) {
							if (position1 == p) {
								photo();
							} else {
								imageBrower(position1, email.getUrls());
							}

						}
					});
					detail.setOnItemLongClickListener(new OnItemLongClickListener() {
						@Override
						public boolean onItemLongClick(AdapterView<?> arg0,
								View arg1, final int arg2, long arg3) {
							if (arg2 != p) {
								new AlertDialog.Builder(ZFXX_BJ.this)
										.setMessage("ɾ������Ƭ��")
										.setTitle("ע��")
										.setNegativeButton(
												"ȡ��",
												new DialogInterface.OnClickListener() {
													@Override
													public void onClick(
															DialogInterface arg0,
															int arg1) {
													}
												})
										.setPositiveButton(
												"ȷ��",
												new DialogInterface.OnClickListener() {
													@Override
													public void onClick(
															DialogInterface dialog,
															int which) {
														deletepic(arg2,
																email.getUrls());
													}
												}).show();

							}
							return false;
						}
					});

				}

			}
			break;
		}
	}
	
	
	public void getRefresh() {
		final String aaa = Camerapath;
		String urls2[] = null;
		if (email.getUrls() != null && email.getUrls().length > 0) {
			String urls1[] = new String[email.getUrls().length + 1];
			urls2 = new String[email.getUrls().length + 2];
			for (int i = 0; i < email.getUrls().length; i++) {
				urls1[i] = email.getUrls()[i];
				urls2[i] = email.getUrls()[i];
			}
			urls1[email.getUrls().length] = "file://" + aaa;
			urls2[email.getUrls().length] = "file://" + aaa;
			urls2[email.getUrls().length + 1] = "assets://photoadd.jpg";
			email.setUrls(urls1);
		} else {
			urls2 = new String[2];
			String pp = "file://" + aaa;
			urls2[0] = "file://" + aaa;
			urls2[1] = "assets://photoadd.jpg";
			email.setUrls(new String[] { pp });
		}
		final int p = urls2.length - 1;
		detail.setVisibility(View.VISIBLE);
		detail.setAdapter(new MyGridAdapter(urls2, ZFXX_BJ.this));
		detail.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position1, long id) {
				if (position1 == p) {
					photo();
				} else {
					imageBrower(position1, email.getUrls());
				}

			}
		});

		detail.setOnItemLongClickListener(new OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
					final int arg2, long arg3) {
				if (arg2 != p) {
					new AlertDialog.Builder(ZFXX_BJ.this)
							.setMessage("ɾ������Ƭ��")
							.setTitle("ע��")
							.setNegativeButton("ȡ��",
									new DialogInterface.OnClickListener() {
										@Override
										public void onClick(
												DialogInterface arg0, int arg1) {
										}
									})
							.setPositiveButton("ȷ��",
									new DialogInterface.OnClickListener() {
										@Override
										public void onClick(
												DialogInterface dialog,
												int which) {
											deletepic(arg2, email.getUrls());
										}

									}).show();

				}
				return false;
			}
		});

	}
	
	private void setfirstphoto() {
		String urls[] = new String[1];
		urls[0] = "assets://photoadd.jpg";

		detail.setVisibility(View.VISIBLE);
		detail.setAdapter(new MyGridAdapter(urls, ZFXX_BJ.this));
		detail.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position1, long id) {
				photo();
			}
		});
	}

	private void photo() {
		FileUtils.creatSDDir("woyeapp/Pic");

		AlertDialog.Builder builder = new AlertDialog.Builder(
				ZFXX_BJ.this);
		builder.setItems(new String[] { "����", "�������ѡ��" },
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
					/*	if (which == 0) {
							 Intent intent=new Intent(ZFXX.this,CameraActivity2 .class);
	         				 startActivityForResult(intent,1);
						}
						*/
						
						if (which == 0) {

							Date now = new Date();
							SimpleDateFormat d1 = new SimpleDateFormat(
									"yyyyMMddHHmmss");
							String phototime = d1.format(now);
							Camerapath = Environment
									.getExternalStorageDirectory().toString()
									+ "/woyeapp/Pic/" + phototime + ".jpg";
							File file = new File(Camerapath);
							Intent intent = new Intent(
									MediaStore.ACTION_IMAGE_CAPTURE);
							intent.putExtra(MediaStore.EXTRA_OUTPUT,
									Uri.fromFile(file));
							startActivityForResult(intent, 0);

						} else if (which == 1) {
							Intent intent = new Intent(ZFXX_BJ.this,
									AlbumActivity.class);
							Bundle bundle = new Bundle();
							ArrayList<String> dataList = new ArrayList<String>();
							bundle.putStringArrayList("dataList", dataList);
							intent.putExtras(bundle);
							startActivityForResult(intent, 5);

						}

					}
				});
		builder.create().show();

	}
	private void deletepic(int arg2, String[] urls) {
		if (urls.length == 1) {
			email.setUrls(null);
			detail.setVisibility(View.VISIBLE);
			detail.setAdapter(new MyGridAdapter(
					new String[] { "assets://photoadd.jpg" },
					ZFXX_BJ.this));
			detail.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position1, long id) {
					photo();
				}
			});

		} else {
			String a[] = new String[urls.length - 1];
			for (int i = 0; i < arg2; i++) {
				a[i] = urls[i];
			}
			for (int i = arg2; i < a.length; i++) {
				a[i] = urls[i + 1];
			}
			email.setUrls(a);
			String urls2[] = new String[a.length + 1];
			for (int i = 0; i < a.length; i++) {
				urls2[i] = a[i];
			}
			urls2[a.length] = "assets://photoadd.jpg";
			final int p = urls2.length - 1;
			detail.setVisibility(View.VISIBLE);
			detail.setAdapter(new MyGridAdapter(urls2, ZFXX_BJ.this));
			detail.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position1, long id) {
					if (position1 == p) {
						photo();
					} else {
						imageBrower(position1, email.getUrls());
					}

				}
			});
			detail.setOnItemLongClickListener(new OnItemLongClickListener() {
				@Override
				public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
						final int arg2, long arg3) {
					if (arg2 != p) {
						new AlertDialog.Builder(ZFXX_BJ.this)
								.setMessage("ɾ������Ƭ��")
								.setTitle("ע��")
								.setNegativeButton("ȡ��",
										new DialogInterface.OnClickListener() {
											@Override
											public void onClick(
													DialogInterface arg0,
													int arg1) {
											}
										})
								.setPositiveButton("ȷ��",
										new DialogInterface.OnClickListener() {
											@Override
											public void onClick(
													DialogInterface dialog,
													int which) {
												deletepic(arg2, email.getUrls());
											}

										}).show();

					}
					return false;
				}
			});
		}

	}
	

	@SuppressWarnings({ "unused", "resource" })
	private String fileString(String path) {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(path);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte[] buffer = new byte[1024];
		int count = 0;
		try {
			while ((count = fis.read(buffer)) >= 0) {
				baos.write(buffer, 0, count);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new String(Base64.encode(baos.toByteArray()));
	}
	
	@SuppressWarnings("resource")
	private File yaosuo(String path) {
		File file = new File(path);
		FileInputStream fis = null;
		if (file.exists()) {
			try {
				fis = new FileInputStream(file);
				if (fis.available() / 1024 > 1024) {

					Options options = new Options();
					options.inSampleSize = 4;
					Bitmap mBitmap_High = BitmapFactory.decodeFile(path,
							options);
					try {
						BufferedOutputStream bos = new BufferedOutputStream(
								new FileOutputStream(file));
						mBitmap_High.compress(Bitmap.CompressFormat.JPEG, 100,
								bos);
						bos.flush();
						bos.close();
					} catch (IOException e) {
						return file;
					}

					return file;
				} else {
					return file;
				}
			} catch (Exception e) {
				return file;
			}
		} else {
			return null;
		}
	}
	
	
	private void imageBrower(int position, String[] urls) {
		Intent intent = new Intent(ZFXX_BJ.this,
				ImagePagerActivity.class);
		intent.putExtra(ImagePagerActivity.EXTRA_IMAGE_URLS, urls);
		intent.putExtra(ImagePagerActivity.EXTRA_IMAGE_INDEX, position);
		startActivity(intent);
	}
	
	
	public void onLocationChanged(AMapLocation aMapLocation) {
		if (aMapLocation != null) {
			if (aMapLocation.getErrorCode() == 0) {
				// ��λ�ɹ��ص���Ϣ�����������Ϣ
				aMapLocation.getLocationType();// ��ȡ��ǰ��λ�����Դ�������綨λ���������ٷ���λ���ͱ�
				JD = String.valueOf(aMapLocation.getLongitude());// ��ȡ����
				WD = String.valueOf(aMapLocation.getLatitude());// ��ȡγ��
				aMapLocation.getAccuracy();// ��ȡ������Ϣ
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date(aMapLocation.getTime());
				df.format(date);// ��λʱ��
				aMapLocation.getAddress();// ��ַ�����option������isNeedAddressΪfalse����û�д˽�������綨λ����л��е�ַ��Ϣ��GPS��λ�����ص�ַ��Ϣ��
				aMapLocation.getCountry();// ������Ϣ
				aMapLocation.getProvince();// ʡ��Ϣ
				aMapLocation.getCity();// ������Ϣ
				aMapLocation.getDistrict();// ������Ϣ
				aMapLocation.getStreet();// �ֵ���Ϣ
				aMapLocation.getStreetNum();// �ֵ����ƺ���Ϣ
				wz = aMapLocation.getProvince() + aMapLocation.getCity() + aMapLocation.getDistrict()
						+ aMapLocation.getStreet() + aMapLocation.getStreetNum();
				aMapLocation.getCityCode();// ���б���
				aMapLocation.getAdCode();// ��������
				if (flag == 0) {
					flag = 1;
				//	Toast.makeText(ZFXX_XJ.this, "��λ�ɹ�", Toast.LENGTH_SHORT).show();
				}
			} else {
				// ��ʾ������ϢErrCode�Ǵ����룬errInfo�Ǵ�����Ϣ��������������
				Log.e("AmapError", "location Error, ErrCode:" + aMapLocation.getErrorCode() + ", errInfo:"
						+ aMapLocation.getErrorInfo());
				// Toast.makeText(getApplicationContext(), "��λʧ��",
				// Toast.LENGTH_LONG).show();
			}
		}

	}

	private void initLocal() {
		// ��ʼ����λ
		mLocationClient = new AMapLocationClient(getApplicationContext());
		// ���ö�λ�ص�����
		mLocationClient.setLocationListener(this);
		// ��ʼ����λ����
		mLocationOption = new AMapLocationClientOption();
		// ���ö�λģʽΪHight_Accuracy�߾���ģʽ��Battery_SavingΪ�͹���ģʽ��Device_Sensors�ǽ��豸ģʽ
		mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);
		// �����Ƿ񷵻ص�ַ��Ϣ��Ĭ�Ϸ��ص�ַ��Ϣ��
		mLocationOption.setNeedAddress(true);
		// �����Ƿ�ֻ��λһ��,Ĭ��Ϊfalse
		mLocationOption.setOnceLocation(false);// ����Ϊ��ζ�λ
		// �����Ƿ�ǿ��ˢ��WIFI��Ĭ��Ϊǿ��ˢ��
		mLocationOption.setWifiActiveScan(true);
		// �����Ƿ�����ģ��λ��,Ĭ��Ϊfalse��������ģ��λ��
		mLocationOption.setMockEnable(false);
		// ���ö�λ���,��λ����,Ĭ��Ϊ2000ms
		mLocationOption.setInterval(2000);
		// ����λ�ͻ��˶������ö�λ����
		mLocationClient.setLocationOption(mLocationOption);
		// ������λ
		mLocationClient.startLocation();
	}
	

	
		//������ ���ذ�ť
	  public void btn_back(View v) {    
	      	this.finish();
	      }


}


	
