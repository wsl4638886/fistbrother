package com.woeasy.model;

import java.io.Serializable;
/**
 * �����Ŀ��Ϣ��ʵ����
 * @author ytt
 *
 */
public class XKG implements Serializable{
	public String proName;//
	public String wantTo;	
	public String prodq;//
	public String unitName2;//
	public String yearnd;//
	public String proProfession;//
	public String proDivideScope;//
	public String buildContent;//
	public String BY2;//
	public String landTotalArea;//
	public String investTotal;//
	public String attractFund;
	public String beginDate;//
	public String endDate;//
	public String preYearFinish;//
	public String imageProcess;
	public String jhcentralityFund;//
	public String jhattractFund;//
	public String yearWorkPlan;//
	public String yearProPhase;//
	public String proDivideOther;//
	public String landBuildContent;
	public String unitName1;//
	public String seq;//
	public String isFull;//
	public String whsj;
	public String buildInfonew_WFID;
	public String buildInfonew_WFInst;
	public String buildInfonew_WPID;
	public String buildInfonew_Awaiter;
	public String buildInfonew_Handler;
	public String BY3;
	private String background;
	private String locationNumber;
	private String address;
	private String landNum;
	public String getLandNum() {
		return landNum;
	}
	public void setLandNum(String landNum) {
		this.landNum = landNum;
	}
	public String getBY3() {
		return BY3;
	}
	public void setBY3(String bY3) {
		BY3 = bY3;
	}
	public String getBackground() {
		return background;
	}
	public void setBackground(String background) {
		this.background = background;
	}
	public String getLocationNumber() {
		return locationNumber;
	}
	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getBuildInfonew_WFID() {
		return buildInfonew_WFID;
	}
	public void setBuildInfonew_WFID(String buildInfonew_WFID) {
		this.buildInfonew_WFID = buildInfonew_WFID;
	}
	public String getBuildInfonew_WFInst() {
		return buildInfonew_WFInst;
	}
	public void setBuildInfonew_WFInst(String buildInfonew_WFInst) {
		this.buildInfonew_WFInst = buildInfonew_WFInst;
	}
	public String getBuildInfonew_WPID() {
		return buildInfonew_WPID;
	}
	public void setBuildInfonew_WPID(String buildInfonew_WPID) {
		this.buildInfonew_WPID = buildInfonew_WPID;
	}
	public String getBuildInfonew_Awaiter() {
		return buildInfonew_Awaiter;
	}
	public void setBuildInfonew_Awaiter(String buildInfonew_Awaiter) {
		this.buildInfonew_Awaiter = buildInfonew_Awaiter;
	}
	public String getBuildInfonew_Handler() {
		return buildInfonew_Handler;
	}
	public void setBuildInfonew_Handler(String buildInfonew_Handler) {
		this.buildInfonew_Handler = buildInfonew_Handler;
	}
	public String getWantTo() {
		return wantTo;
	}
	public void setWantTo(String wantTo) {
		this.wantTo = wantTo;
	}
	public String getWhsj() {
		return whsj;
	}
	public void setWhsj(String whsj) {
		this.whsj = whsj;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public String getProdq() {
		return prodq;
	}
	public void setProdq(String prodq) {
		this.prodq = prodq;
	}
	public String getUnitName2() {
		return unitName2;
	}
	public void setUnitName2(String unitName2) {
		this.unitName2 = unitName2;
	}
	public String getYearnd() {
		return yearnd;
	}
	public void setYearnd(String yearnd) {
		this.yearnd = yearnd;
	}
	public String getProProfession() {
		return proProfession;
	}
	public void setProProfession(String proProfession) {
		this.proProfession = proProfession;
	}
	public String getProDivideScope() {
		return proDivideScope;
	}
	public void setProDivideScope(String proDivideScope) {
		this.proDivideScope = proDivideScope;
	}
	public String getBuildContent() {
		return buildContent;
	}
	public void setBuildContent(String buildContent) {
		this.buildContent = buildContent;
	}
	public String getBY2() {
		return BY2;
	}
	public void setBY2(String bY2) {
		this.BY2 = bY2;
	}
	public String getLandTotalArea() {
		return landTotalArea;
	}
	public void setLandTotalArea(String landTotalArea) {
		this.landTotalArea = landTotalArea;
	}
	public String getInvestTotal() {
		return investTotal;
	}
	public void setInvestTotal(String investTotal) {
		this.investTotal = investTotal;
	}
	public String getAttractFund() {
		return attractFund;
	}
	public void setAttractFund(String attractFund) {
		this.attractFund = attractFund;
	}
	public String getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getPreYearFinish() {
		return preYearFinish;
	}
	public void setPreYearFinish(String preYearFinish) {
		this.preYearFinish = preYearFinish;
	}
	public String getImageProcess() {
		return imageProcess;
	}
	public void setImageProcess(String imageProcess) {
		this.imageProcess = imageProcess;
	}
	public String getJhcentralityFund() {
		return jhcentralityFund;
	}
	public void setJhcentralityFund(String jhcentralityFund) {
		this.jhcentralityFund = jhcentralityFund;
	}
	public String getJhattractFund() {
		return jhattractFund;
	}
	public void setJhattractFund(String jhattractFund) {
		this.jhattractFund = jhattractFund;
	}
	public String getYearWorkPlan() {
		return yearWorkPlan;
	}
	public void setYearWorkPlan(String yearWorkPlan) {
		this.yearWorkPlan = yearWorkPlan;
	}
	public String getYearProPhase() {
		return yearProPhase;
	}
	public void setYearProPhase(String yearProPhase) {
		this.yearProPhase = yearProPhase;
	}
	public String getProDivideOther() {
		return proDivideOther;
	}
	public void setProDivideOther(String proDivideOther) {
		this.proDivideOther = proDivideOther;
	}
	public String getLandBuildContent() {
		return landBuildContent;
	}
	public void setLandBuildContent(String landBuildContent) {
		this.landBuildContent = landBuildContent;
	}
	public String getUnitName1() {
		return unitName1;
	}
	public void setUnitName1(String unitName1) {
		this.unitName1 = unitName1;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getIsFull() {
		return isFull;
	}
	public void setIsFull(String isFull) {
		this.isFull = isFull;
	}

}
