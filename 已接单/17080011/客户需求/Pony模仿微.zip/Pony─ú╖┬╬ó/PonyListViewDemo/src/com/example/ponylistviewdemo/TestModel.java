package com.example.ponylistviewdemo;

import java.util.ArrayList;
import java.util.List;

public class TestModel {

	private String name;
	private String check;
	private String pinglunCheck;
	private boolean isShow;
	private List<Integer> list_image_msg = new ArrayList<Integer>();
	
	private List<PingLunModel> list_pinglun_msg = new ArrayList<PingLunModel>();
	

	public List<Integer> getList_image_msg() {
		return list_image_msg;
	}

	public void setList_image_msg(List<Integer> list_image_msg) {
		this.list_image_msg = list_image_msg;
	}

	public List<PingLunModel> getList_pinglun_msg() {
		return list_pinglun_msg;
	}

	public void setList_pinglun_msg(List<PingLunModel> list_pinglun_msg) {
		this.list_pinglun_msg = list_pinglun_msg;
	}

	public String getPinglunCheck() {
		return pinglunCheck;
	}

	public void setPinglunCheck(String pinglunCheck) {
		this.pinglunCheck = pinglunCheck;
	}

	public String getCheck() {
		return check;
	}

	public void setCheck(String check) {
		this.check = check;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isShow() {
		return isShow;
	}

	public void setShow(boolean isShow) {
		this.isShow = isShow;
	}

}
