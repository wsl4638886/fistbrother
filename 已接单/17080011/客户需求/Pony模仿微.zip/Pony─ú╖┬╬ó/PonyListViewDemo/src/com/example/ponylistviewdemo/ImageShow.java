package com.example.ponylistviewdemo;

public class ImageShow {

	private int  imageIcon;
	
	

	public ImageShow(int imageIcon) {
		super();
		this.imageIcon = imageIcon;
	}

	public ImageShow() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getImageIcon() {
		return imageIcon;
	}

	public void setImageIcon(int imageIcon) {
		this.imageIcon = imageIcon;
	}



	
	
}
