package com.example.ponylistviewdemo;

public class PingLunModel {

	private String replyNickName;
	private String commentNickName;
	private String replyContentStr;
	
	
	
	
	
	public PingLunModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PingLunModel(String replyNickName, String commentNickName, String replyContentStr) {
		super();
		this.replyNickName = replyNickName;
		this.commentNickName = commentNickName;
		this.replyContentStr = replyContentStr;
	}
	public String getReplyNickName() {
		return replyNickName;
	}
	public void setReplyNickName(String replyNickName) {
		this.replyNickName = replyNickName;
	}
	public String getCommentNickName() {
		return commentNickName;
	}
	public void setCommentNickName(String commentNickName) {
		this.commentNickName = commentNickName;
	}
	public String getReplyContentStr() {
		return replyContentStr;
	}
	public void setReplyContentStr(String replyContentStr) {
		this.replyContentStr = replyContentStr;
	}

	
	
	
}
