package com.example.ponylistviewdemo;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class DemoAdapter extends BaseAdapter {
	private Context mContext;
	private ArrayList<String> list_baoxian;
	LinearLayout linearLayout = null;
	LayoutInflater inflater;
	TextView tex;
	final int VIEW_TYPE = 3;
	final int TYPE_1 = 0;
	final int TYPE_2 = 1;
	final int TYPE_3 = 2;

	public DemoAdapter(Context mContext, ArrayList<String> list_baoxian) {
		super();
		inflater = LayoutInflater.from(mContext);
		this.mContext = mContext;
		this.list_baoxian = list_baoxian;
	}

	@Override
	public int getCount() {
		return list_baoxian.size();
	}

	@Override
	public int getItemViewType(int position) {
		// TODO Auto-generated method stub

		int p = position % 6;
		if (p == 0)
			return TYPE_1;
		else if (p < 3)
			return TYPE_2;
		else if (p < 6)
			return TYPE_3;
		else
			return TYPE_1;

	}

	@Override
	public int getViewTypeCount() {
		// TODO Auto-generated method stub
		return 3;
	}

	@Override
	public Object getItem(int position) {
		return list_baoxian.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		viewHolder1 holder1 = null;
		viewHolder2 holder2 = null;
		viewHolder3 holder3 = null;
		int type = getItemViewType(position);
		// ��convertView����Ҫnew�������ؼ�
		if (convertView == null) {
			// ����ǰ�������ʽ��ȷ��new�Ĳ���
			switch (type) {
			case TYPE_1:
				convertView = inflater.inflate(R.layout.item_one, parent, false);
				holder1 = new viewHolder1();
//				holder1.show_next_one_msg = (Button) convertView.findViewById(R.id.show_next_one_msg);
				// holder1.checkBox =
				// (CheckBox)convertView.findViewById(R.id.checkbox);
				convertView.setTag(holder1);
				break;
			case TYPE_2:
				convertView = inflater.inflate(R.layout.item_two, parent, false);
				holder2 = new viewHolder2();
				holder2.show_next_two = (Button) convertView.findViewById(R.id.show_next_two);
				convertView.setTag(holder2);
				break;
			case TYPE_3:
				convertView = inflater.inflate(R.layout.item_three, parent, false);
				holder3 = new viewHolder3();
				convertView.setTag(holder3);
				break;
			}
		} else {
			// ��convertView������ʽ��ȡ�ò��õĲ���
			switch (type) {
			case TYPE_1:
				holder1 = (viewHolder1) convertView.getTag();
				break;
			case TYPE_2:
				holder2 = (viewHolder2) convertView.getTag();
				break;
			case TYPE_3:
				holder3 = (viewHolder3) convertView.getTag();
				break;
			}
		}

		// ������Դ
		switch (type) {
		case TYPE_1:
			// holder1.textView.setText(Integer.toString(position));
			// holder1.checkBox.setChecked(true);
			
			holder1.show_next_one_msg.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					mContext.startActivity(new Intent(mContext,OneActivity.class));
				Toast.makeText(mContext, "TYPE_1", Toast.LENGTH_LONG).show();	
				}
			});
			break;
		case TYPE_2:
			
			holder2.show_next_two.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Toast.makeText(mContext, "TYPE_2", Toast.LENGTH_LONG).show();	
				}
			});
			break;
		case TYPE_3:
			
			holder3.show_next_three.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Toast.makeText(mContext, "TYPE_3", Toast.LENGTH_LONG).show();
				}
			});
			break;
		}

		return convertView;
	}

	// �������ֵĿؼ���Դ
	class viewHolder1 {
		CheckBox checkBox;
		TextView textView;
		Button show_next_one_msg;
	}

	class viewHolder2 {
		TextView textView;
		Button show_next_two;
	}

	class viewHolder3 {
		ImageView imageView;
		TextView textView;
		Button show_next_three;
	}

}