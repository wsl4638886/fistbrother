package com.example.ponylistviewdemo;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ponylistviewdemo.MainActivity.TestAdapter.ViewHolder;

public class MainActivity extends Activity {

	ListView listView;
	TestAdapter listAdapter;
	ArrayList<TestModel> listString;
	private View headTopView;
	BanJiAdapter banJiAdapter;
	private int[] imgs = new int[] { R.drawable.pic_shop, R.drawable.tx_2, R.drawable.tx_3, R.drawable.tx_4, R.drawable.tx_5, R.drawable.tx_6,
			R.drawable.tx_7, R.drawable.tx_8, R.drawable.tx_9, R.drawable.tx_10 };
	private String msg_ceshi;
	PingLunAdapter pingLunAdapter;
	List<String> list_pinglun_data = new ArrayList<String>();
	private String comment = ""; // ��¼�Ի����е�����
	private Button commentButton; // ���۰�ť
	private EditText commentEdit; // ���������
	private boolean isReply; // �Ƿ��ǻظ�
	private LinearLayout commentLinear; // ������������Բ���
	private int index_pos;
	private int index_pos_huifu_pos;
	private int index_pos_huifu;
	private Button show_dt;
	private Button show_msg;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		show_dt = (Button) findViewById(R.id.show_dt);
		show_msg = (Button) findViewById(R.id.show_msg);
		
		
		
		/**
		 * �����ҵĶ�̬����
		 */
		show_dt.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MainActivity.this.startActivity(new Intent(MainActivity.this,DongTaiActivity.class));
			}
		});
		
		/**
		 * ���붯̬����ҳ�� 
		 */
		show_msg.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MainActivity.this.startActivity(new Intent(MainActivity.this,OneActivity.class));
			}
		});
		
		commentLinear = (LinearLayout) findViewById(R.id.commentLinear);
		commentButton = (Button) findViewById(R.id.commentButton);
		commentEdit = (EditText) findViewById(R.id.commentEdit);

		listView = (ListView) this.findViewById(R.id.listview);
		listString = new ArrayList<TestModel>();
		
		
		/**
		 * �������ݵ����� 
		 */
		TestModel testModel;
		for (int i = 1; i < 30; i++) {
			testModel = new TestModel();
			testModel.setName("pony" + i);
			testModel.setShow(false);
			testModel.setCheck("0");
			testModel.setPinglunCheck("0");
			testModel.setList_pinglun_msg(null);


			listString.add(testModel);
		}
		listAdapter = new TestAdapter(this, listString);
		listView.setAdapter(listAdapter);

		
		/**
		 * ����
		 */
		commentButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (isReply == false) {
					PingLunMethod();
				} else {
					HuiFuMethod();
				}
				commentEdit.setText("");
				commentLinear.setVisibility(View.GONE);
				onFocusChange(false);

			}
		});
	}

	
	/**
	 * ������ʾ�Ĳ��Ե�������
	 * @author wangxuan
	 *
	 */
	public class TestAdapter extends BaseAdapter {
		private Context mContext;
		private List<TestModel> list_result;
		ViewHolder vh = null;
		private List<ImageShow> list_zan = new ArrayList<ImageShow>();

		public TestAdapter(Context mContext, List<TestModel> list_result) {
			super();
			this.mContext = mContext;
			this.list_result = list_result;
		}

		@Override
		public int getCount() {
			return list_result.size();
		}

		@Override
		public Object getItem(int position) {
			return list_result.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {

			String proName = null;

			if (convertView == null) {
				convertView = LayoutInflater.from(mContext).inflate(R.layout.item_one, null);
				vh = new ViewHolder();
				vh.show_icon_msg = (RoundedCornerImageView) convertView.findViewById(R.id.show_icon_msg);
				vh.show_zan = (NoScrollGridView) convertView.findViewById(R.id.show_zan);
				vh.show_msg_zan = (ImageView) convertView.findViewById(R.id.show_msg_zan);
				vh.show_pinglun = (ImageView) convertView.findViewById(R.id.show_pinglun);
				vh.one_image = (ImageView) convertView.findViewById(R.id.one_image);
				vh.show_dainzan_buju = (RelativeLayout) convertView.findViewById(R.id.show_dainzan_buju);
				vh.show_name = (TextView) convertView.findViewById(R.id.show_name);
				vh.line = (Button) convertView.findViewById(R.id.line);
				vh.show_dianzan_msg = (TextView) convertView.findViewById(R.id.show_dianzan_msg);
				vh.show_image = (NoScrollGridView) convertView.findViewById(R.id.show_image);
				vh.replyList = (NoScrollListView) convertView.findViewById(R.id.replyList);

				convertView.setTag(vh);
			} else {
				vh = (ViewHolder) convertView.getTag();
			}

			final TestModel result = list_result.get(position);
			vh.show_name.setText(result.getName());

			if (result.getList_image_msg() != null) {

				if (result.getList_image_msg().size() == 1) {
					vh.show_image.setVisibility(View.GONE);
					vh.one_image.setVisibility(View.VISIBLE);
					vh.one_image.setImageResource(result.getList_image_msg().get(0));
				} else {
					vh.one_image.setVisibility(View.GONE);
					vh.show_image.setVisibility(View.VISIBLE);
					ImageAdapter imageAdapter = new ImageAdapter(mContext, result.getList_image_msg());
					vh.show_image.setAdapter(imageAdapter);
				}

			} else {
				vh.show_image.setVisibility(View.GONE);
			}

			if (result.isShow() == false) {
				System.out.println("=========" + 0);
				vh.show_dainzan_buju.setVisibility(View.GONE);
			} else {
				System.out.println("=========" + 1);
				vh.show_dainzan_buju.setVisibility(View.VISIBLE);
				vh.line.setVisibility(View.VISIBLE);
				vh.show_dianzan_msg.setText(result.getCheck().substring(0, result.getCheck().length() - 1));
			}
			if (result.getPinglunCheck().equals("0")) {
				System.out.println("=========" + 0);
				vh.replyList.setVisibility(View.GONE);
			} else {
				pingLunAdapter = new PingLunAdapter(MainActivity.this, result.getList_pinglun_msg());
				vh.replyList.setAdapter(pingLunAdapter);
				System.out.println("=========" + 1);
				vh.replyList.setVisibility(View.VISIBLE);
			}
			/**
			 * �ظ�����
			 */
			vh.replyList.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
					index_pos_huifu = arg2;
					index_pos_huifu_pos = position;
					isReply = true;
					commentLinear.setVisibility(View.VISIBLE);
					onFocusChange(false);

				}
			});

			/**
			 * ����
			 */
			
			vh.show_msg_zan.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {

					TestModel testModel = new TestModel();
					testModel.setName(list_result.get(position).getName());
					testModel.setShow(true);
					testModel.setPinglunCheck(list_result.get(position).getPinglunCheck());
					testModel.setCheck(list_result.get(position).getCheck() + "������Ա��");
					testModel.setList_image_msg(list_result.get(position).getList_image_msg());
					testModel.setList_pinglun_msg(list_result.get(position).getList_pinglun_msg());
					list_result.set(position, testModel);

					listAdapter.notifyDataSetChanged();
				}
			});

			/**
			 * ����
			 */
			vh.show_pinglun.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					index_pos = position;
					isReply = false;
					commentLinear.setVisibility(View.VISIBLE);
					onFocusChange(true);
				}
			});

			return convertView;
		}

		class ViewHolder {
			RoundedCornerImageView show_icon_msg;
			NoScrollGridView show_zan;
			ImageView show_msg_zan;
			ImageView show_pinglun;

			ImageView one_image;
			RelativeLayout show_dainzan_buju;
			TextView show_name;
			TextView show_dianzan_msg;
			Button line;
			NoScrollListView replyList; // ���ۻظ��б�
			NoScrollGridView show_image;

		}
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * �ж϶Ի������Ƿ���������
	 */
	private boolean isEditEmply() {
		comment = commentEdit.getText().toString().trim();
		if (comment.equals("")) {
			Toast.makeText(getApplicationContext(), "���۲���Ϊ��", Toast.LENGTH_SHORT).show();
			return false;
		}
		commentEdit.setText("");
		return true;
	}

	/**
	 * ��ʾ���������뷨
	 */
	private void onFocusChange(boolean hasFocus) {
		final boolean isFocus = hasFocus;
		(new Handler()).postDelayed(new Runnable() {
			public void run() {
				InputMethodManager imm = (InputMethodManager) commentEdit.getContext().getSystemService(INPUT_METHOD_SERVICE);
				if (isFocus) {
					// ��ʾ���뷨
					imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
				} else {
					// �������뷨
					imm.hideSoftInputFromWindow(commentEdit.getWindowToken(), 0);
				}
			}
		}, 100);
	}

	/**
	 * ���۵�����
	 */

	public void PingLunMethod() {
		TestModel testModel = new TestModel();
		testModel.setName(listString.get(index_pos).getName());
		testModel.setShow(listString.get(index_pos).isShow());
		testModel.setPinglunCheck("1");
		testModel.setCheck(listString.get(index_pos).getCheck());
		testModel.setList_image_msg(listString.get(index_pos).getList_image_msg());
		List<PingLunModel> list_pinglun = new ArrayList<PingLunModel>();
		if (listString.get(index_pos).getList_pinglun_msg() != null) {
			list_pinglun.addAll(listString.get(index_pos).getList_pinglun_msg());
		}
		list_pinglun.add(new PingLunModel(listString.get(index_pos).getName(), "", commentEdit.getText().toString()));
		testModel.setList_pinglun_msg(list_pinglun);
		listString.set(index_pos, testModel);
		listAdapter.notifyDataSetChanged();
	}

	/**
	 * �ظ�������
	 */

	public void HuiFuMethod() {

		TestModel testModel = new TestModel();
		testModel.setName(listString.get(index_pos_huifu_pos).getName());
		testModel.setShow(listString.get(index_pos_huifu_pos).isShow());
		testModel.setPinglunCheck("1");
		testModel.setCheck(listString.get(index_pos_huifu_pos).getCheck());
		testModel.setList_image_msg(listString.get(index_pos_huifu_pos).getList_image_msg());

		
		List<PingLunModel> list_pinglun = new ArrayList<PingLunModel>();
		if (listString.get(index_pos_huifu_pos).getList_pinglun_msg() != null) {
			list_pinglun.addAll(listString.get(index_pos_huifu_pos).getList_pinglun_msg());
		}
		
		
		String replyNickName = listString.get(index_pos_huifu_pos).getName();
		String commentNickName = "����";
		String replyContentStr = commentEdit.getText().toString();
		list_pinglun.add(index_pos_huifu + 1, new PingLunModel(replyNickName, commentNickName, replyContentStr));
		testModel.setList_pinglun_msg(list_pinglun);
		listString.set(index_pos_huifu_pos, testModel);
		listAdapter.notifyDataSetChanged();
	}

}
