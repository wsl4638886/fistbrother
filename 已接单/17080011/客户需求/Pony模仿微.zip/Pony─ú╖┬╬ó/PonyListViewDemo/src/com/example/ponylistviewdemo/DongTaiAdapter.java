package com.example.ponylistviewdemo;

import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class DongTaiAdapter extends BaseAdapter {
	private Context mContext;
	private List<PingLunModel> list_result;
	private SpannableString sb;
	private View phpto_view;

	public DongTaiAdapter(Context mContext, List<PingLunModel> list_result) {
		super();
		this.mContext = mContext;
		this.list_result = list_result;
	}

	@Override
	public int getCount() {
		return 10;
	}

	@Override
	public Object getItem(int position) {
		return list_result.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vh = null;
		String proName = null;

		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(R.layout.dongtai_view_item, null);
			vh = new ViewHolder();
			vh.show_dongtai_list = (NoScrollListView) convertView.findViewById(R.id.show_dongtai_list);
			vh.show_time = (TextView) convertView.findViewById(R.id.show_time);
			convertView.setTag(vh);
		} else {
			vh = (ViewHolder) convertView.getTag();
		}

		String yue_msg = "10��";
		String tian_msg = "01��";
		SpannableString spanString = new SpannableString(yue_msg + "" + tian_msg);
		AbsoluteSizeSpan span_yue = new AbsoluteSizeSpan(25);
		AbsoluteSizeSpan span_tian = new AbsoluteSizeSpan(18);
		spanString.setSpan(span_yue, 0, yue_msg.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		spanString.setSpan(span_tian, yue_msg.length(), yue_msg.length() + tian_msg.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

		spanString.setSpan(new ForegroundColorSpan(Color.parseColor("#333333")), 0, yue_msg.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		spanString.setSpan(new ForegroundColorSpan(Color.parseColor("#ACACAC")), yue_msg.length(), yue_msg.length() + tian_msg.length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		

		if (position == 0) {
			vh.show_time.setText("����");
		} else if (position == 1) {
			vh.show_time.setText("����");
		} else {
			vh.show_time.setText(spanString);
		}

		DongTaiMsgAdapter dongTaiMsgAdapter = new DongTaiMsgAdapter(mContext, null, position);
		vh.show_dongtai_list.setAdapter(dongTaiMsgAdapter);
		return convertView;
	}

	class ViewHolder {
		NoScrollListView show_dongtai_list;
		TextView show_time;

	}
}
