package com.example.ponylistviewdemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

public class DongTaiActivity extends Activity {
	
	private ListView show_dongtai;
	private ListView show_zuotian_view;
	private View jintian_view;
	private View zuotian_view;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_dong_tai);

		jintian_view = LayoutInflater.from(DongTaiActivity.this).inflate(R.layout.dongtai_msg_view_item, null);
		zuotian_view = LayoutInflater.from(DongTaiActivity.this).inflate(R.layout.dongtai_zuotian_view, null);
		show_dongtai = (ListView) findViewById(R.id.show_dongtai);
//		show_dongtai.addHeaderView(jintian_view);
//		show_dongtai.addHeaderView(zuotian_view);
		DongTaiAdapter  dongTaiAdapter = new DongTaiAdapter(DongTaiActivity.this, null);
		show_dongtai.setAdapter(dongTaiAdapter);
		
	}
}
