package com.example.ponylistviewdemo;

import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class DongTaiMsgAdapter extends BaseAdapter {
	private Context mContext;
	private List<PingLunModel> list_result;
	private int  index_pos;

	public DongTaiMsgAdapter(Context mContext, List<PingLunModel> list_result,int index_pos) {
		super();
		this.mContext = mContext;
		this.list_result = list_result;
		this.index_pos = index_pos;
	}

	@Override
	public int getCount() {
		return 3;
	}

	@Override
	public Object getItem(int position) {
		return list_result.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vh = null;
		String proName = null;

		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(R.layout.dongtai_msg_view_item, null);
			vh = new ViewHolder();
			vh.dongtai_image = (ImageView) convertView.findViewById(R.id.dongtai_image);
			vh.show_photo = (ImageView) convertView.findViewById(R.id.show_photo);
			convertView.setTag(vh);
		} else {
			vh = (ViewHolder) convertView.getTag();
		}
//		// ImageShow result = list_result.get(position);
//		PingLunModel pingLunModel = list_result.get(position);
//		vh.replyContent.setText(ss);
		View 	jintian_view = LayoutInflater.from(mContext).inflate(R.layout.dongtai_zuotian_view, null);
		if(position==1){
			vh.dongtai_image.setVisibility(View.GONE);
		}else{
			vh.dongtai_image.setVisibility(View.VISIBLE);
		}
		
		
		if(index_pos==0&&position==0){
			vh.show_photo.setVisibility(View.VISIBLE);
		}else{
			vh.show_photo.setVisibility(View.GONE);
		}
		
		return convertView;
	}

	class ViewHolder {
		ImageView dongtai_image;
		ImageView show_photo;
		
	}
}
