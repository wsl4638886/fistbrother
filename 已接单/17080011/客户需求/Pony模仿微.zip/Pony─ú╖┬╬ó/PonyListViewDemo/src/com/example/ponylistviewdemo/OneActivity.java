package com.example.ponylistviewdemo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class OneActivity extends Activity {

	private Button commentButton; // ���۰�ť
	private EditText commentEdit; // ���������
	private ImageView commentImg; // ���۵�ͼƬ
	private ImageView praiseImg; // ���޵�ͼƬ
	private NoScrollListView commentList;// ���������б�
	private NoScrollGridView show_zan;
	private LinearLayout commentLinear; // ������������Բ���
	private int count; // ��¼����ID
	private int position; // ��¼�ظ����۵�����
	private int[] imgs; // ͼƬ��ԴID����
	private boolean isReply; // �Ƿ��ǻظ�
	private String comment = ""; // ��¼�Ի����е�����
	private CommentAdapter adapter;
	private List<CommentBean> list;
	private ScrollView show_scrollview;
	private List<ImageShow> list_zan = new ArrayList<ImageShow>();
	
	private TextView zan_shuliang;
	private TextView pinglun_shuliang;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_one);
		initViews();
		init();
	}

	/**
	 * ��ʼ��UI����
	 */
	private void initViews() {
		zan_shuliang = (TextView) findViewById(R.id.zan_shuliang);
		pinglun_shuliang = (TextView) findViewById(R.id.pinglun_shuliang);
		show_scrollview = (ScrollView) findViewById(R.id.show_scrollview);
		show_zan = (NoScrollGridView) findViewById(R.id.show_zan);
		commentButton = (Button) findViewById(R.id.commentButton);
		commentEdit = (EditText) findViewById(R.id.commentEdit);
		commentImg = (ImageView) findViewById(R.id.commentImg);
		praiseImg = (ImageView) findViewById(R.id.praiseImg);
		commentList = (NoScrollListView) findViewById(R.id.commentList);
		commentLinear = (LinearLayout) findViewById(R.id.commentLinear);

		ClickListener cl = new ClickListener();
		commentButton.setOnClickListener(cl);
		commentImg.setOnClickListener(cl);
		praiseImg.setOnClickListener(cl);
	}

	/**
	 * ��ʼ������
	 */
	private void init() {
		adapter = new CommentAdapter(this, getCommentData(), R.layout.comment_item, handler);
		commentList.setAdapter(adapter);
		show_scrollview.smoothScrollTo(0, 0);
	}

	/**
	 * ��ȡ�����б�����
	 */
	private List<CommentBean> getCommentData() {
		imgs = new int[] { R.drawable.tx_1, R.drawable.tx_2, R.drawable.tx_3, R.drawable.tx_4, R.drawable.tx_5, R.drawable.tx_6, R.drawable.tx_7,
				R.drawable.tx_8, R.drawable.tx_9, R.drawable.tx_10 };
		list = new ArrayList<CommentBean>();
		count = imgs.length;
		for (int i = 0; i < 3; i++) {
			CommentBean bean = new CommentBean();
			bean.setId(i + 1);
			bean.setCommentImgId(imgs[i]);
			bean.setCommentNickname("Pony" + i);
			bean.setCommentTime("13:" + i + "5");
			bean.setCommnetAccount("12345" + i);
			bean.setCommentContent("������ݺܾ���");
			bean.setReplyList(getReplyData());
			list.add(bean);
		}
		return list;
	}

	/**
	 * ��ȡ�ظ��б�����
	 */
	private List<ReplyBean> getReplyData() {
		List<ReplyBean> replyList = new ArrayList<ReplyBean>();
		return replyList;
	}

	/**
	 * ��ʾ���������뷨
	 */
	private void onFocusChange(boolean hasFocus) {
		final boolean isFocus = hasFocus;
		(new Handler()).postDelayed(new Runnable() {
			public void run() {
				InputMethodManager imm = (InputMethodManager) commentEdit.getContext().getSystemService(INPUT_METHOD_SERVICE);
				if (isFocus) {
					// ��ʾ���뷨
					imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
				} else {
					// �������뷨
					imm.hideSoftInputFromWindow(commentEdit.getWindowToken(), 0);
				}
			}
		}, 100);
	}

	/**
	 * �ж϶Ի������Ƿ���������
	 */
	private boolean isEditEmply() {
		comment = commentEdit.getText().toString().trim();
		if (comment.equals("")) {
			Toast.makeText(getApplicationContext(), "���۲���Ϊ��", Toast.LENGTH_SHORT).show();
			return false;
		}
		commentEdit.setText("");
		return true;
	}

	/**
	 * ��������
	 */
	private void publishComment() {
		CommentBean bean = new CommentBean();
		bean.setId(count);
		bean.setCommentImgId(imgs[count % 10]);
		bean.setCommentNickname("�ǳ�" + count);
		bean.setCommentTime("13:" + count % 6 + "5");
		bean.setCommnetAccount("12345" + count);
		bean.setCommentContent(comment);
		list.add(bean);
		count++;
		adapter.notifyDataSetChanged();
		pinglun_shuliang.setText(list.size()+"");
		
		show_scrollview.fullScroll(ScrollView.FOCUS_DOWN);
//
//		scrollView.fullScroll(ScrollView.FOCUS_UP);����������
	}

	/**
	 * �ظ�����
	 */
	private void replyComment() {
		ReplyBean bean = new ReplyBean();
		bean.setId(count + 10);
		bean.setCommentNickname(list.get(position).getCommentNickname());
		bean.setReplyNickname("���ǻظ�����");
		bean.setReplyContent(comment);
		adapter.getReplyComment(bean, position);
		adapter.notifyDataSetChanged();
	}

	@SuppressLint("HandlerLeak")
	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == 10) {
				isReply = true;
				position = (Integer) msg.obj;
				commentLinear.setVisibility(View.VISIBLE);
//				bottomLinear.setVisibility(View.GONE);
				onFocusChange(true);
			}
		}
	};

	/**
	 * �¼����������
	 */
	private final class ClickListener implements OnClickListener {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.commentButton: // �������۰�ť
				if (isEditEmply()) { // �ж��û��Ƿ���������
					if (isReply) {
						replyComment();
					} else {
						publishComment();
					}
//					bottomLinear.setVisibility(View.VISIBLE);
					commentLinear.setVisibility(View.GONE);
					onFocusChange(false);
				}
				break;
			case R.id.commentImg: // ���۰�ť
				isReply = false;
				commentLinear.setVisibility(View.VISIBLE);
//				bottomLinear.setVisibility(View.GONE);
				onFocusChange(true);
				break;
			case R.id.praiseImg: // ���ް�ť
				Toast.makeText(getApplicationContext(), "���޳ɹ�", Toast.LENGTH_SHORT).show();
				Random random = new Random();
				list_zan.add(new ImageShow(imgs[random.nextInt(10)]));
				BanJiAdapter banJiAdapter = new BanJiAdapter(OneActivity.this, list_zan);
				show_zan.setAdapter(banJiAdapter);
				zan_shuliang.setText(list_zan.size()+"");

				break;
			}
		}
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
		// �жϿؼ��Ƿ���ʾ
		if (commentLinear.getVisibility() == View.VISIBLE) {
			commentLinear.setVisibility(View.GONE);
//			bottomLinear.setVisibility(View.VISIBLE);
		}
	}

}
