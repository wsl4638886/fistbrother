package com.example.ponylistviewdemo;

public class DemoModel {

	private int icon_image;
	private String icon_name;
	private String icon_msg;
	private String icon_number;
	
	
	
	

	public String getIcon_number() {
		return icon_number;
	}

	public void setIcon_number(String icon_number) {
		this.icon_number = icon_number;
	}

	public int getIcon_image() {
		return icon_image;
	}

	public void setIcon_image(int icon_image) {
		this.icon_image = icon_image;
	}

	public String getIcon_name() {
		return icon_name;
	}

	public void setIcon_name(String icon_name) {
		this.icon_name = icon_name;
	}

	public String getIcon_msg() {
		return icon_msg;
	}

	public void setIcon_msg(String icon_msg) {
		this.icon_msg = icon_msg;
	}

}
