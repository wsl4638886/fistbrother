package com.example.ponylistviewdemo;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

public class BanJiAdapter extends BaseAdapter {
	private Context mContext;
	private List<ImageShow> list_xueke_msg;

	public BanJiAdapter(Context mContext, List<ImageShow> list_xueke_msg) {
		super();
		this.mContext = mContext;
		this.list_xueke_msg = list_xueke_msg;
	}

	@Override
	public int getCount() {
		return list_xueke_msg.size();
	}

	@Override
	public Object getItem(int position) {
		return list_xueke_msg.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vh = null;
		String proName = null;

		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(R.layout.item_main, null);
			vh = new ViewHolder();
			vh.show_icon_msg = (RoundedCornerImageView) convertView.findViewById(R.id.show_icon_msg);
			convertView.setTag(vh);
		} else {
			vh = (ViewHolder) convertView.getTag();
		}

		ImageShow result = list_xueke_msg.get(position);
		vh.show_icon_msg.setImageResource(result.getImageIcon());

		return convertView;
	}

	class ViewHolder {
		RoundedCornerImageView show_icon_msg;
	}
}
