package com.example.ponylistviewdemo;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class ImageAdapter extends BaseAdapter {
	private Context mContext;
	private List<Integer> list_result;

	public ImageAdapter(Context mContext, List<Integer> list_result) {
		super();
		this.mContext = mContext;
		this.list_result = list_result;
	}

	@Override
	public int getCount() {
		return list_result.size();
	}

	@Override
	public Object getItem(int position) {
		return list_result.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vh = null;
		String proName = null;

		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(R.layout.item_image, null);
			vh = new ViewHolder();
			vh.show_icon_msg = (ImageView) convertView.findViewById(R.id.show_icon_msg);
			convertView.setTag(vh);
		} else {
			vh = (ViewHolder) convertView.getTag();
		}

		Integer result = list_result.get(position);
		vh.show_icon_msg.setImageResource(result);

		return convertView;
	}

	class ViewHolder {
		ImageView show_icon_msg;
	}
}
