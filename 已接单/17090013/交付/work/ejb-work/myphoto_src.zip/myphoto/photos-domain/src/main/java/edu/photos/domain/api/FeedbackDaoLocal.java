package edu.photos.domain.api;

import java.util.List;

import javax.ejb.Local;

import edu.photos.domain.model.TFeedback;

@Local
public interface FeedbackDaoLocal {

  public void addFeedback(TFeedback feedback);
  
  public void delete(List<Integer> ids);
  
  public List<TFeedback> getAllFeedback();
}
