package edu.photos.domain.dao;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import edu.photos.domain.api.FeedbackDaoLocal;
import edu.photos.domain.model.TFeedback;

/**
 * Session Bean implementation class FeedbackDao
 */
@Stateless
@LocalBean
public class FeedbackDao implements FeedbackDaoLocal {

    @PersistenceContext(unitName = "photos")
    private EntityManager em;

    @Override
    public void addFeedback(TFeedback feedback) {
      em.persist(feedback);
    }

    @Override
    public void delete(List<Integer> ids) {
      StringBuilder sb = new StringBuilder();
      for (Integer i:ids) {
        sb.append(i).append(",");
      }
      sb.append(-99);
      Query query = em.createNativeQuery("delete from t_feedback where id in ("+sb.toString()+")");
      query.executeUpdate();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<TFeedback> getAllFeedback() {
      return em.createNamedQuery("TFeedback.findAll").getResultList();
    }

}
