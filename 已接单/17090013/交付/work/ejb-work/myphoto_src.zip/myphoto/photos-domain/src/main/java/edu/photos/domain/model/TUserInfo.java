package edu.photos.domain.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the t_user_info database table.
 * 
 */
@Entity
@Table(name="t_user_info")
@NamedQuery(name="TUserInfo.findAll", query="SELECT t FROM TUserInfo t")
public class TUserInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="account_type")
	private int accountType;

	private String description;

	private String email;

	private String image;

	private String passwd;

	private String phone;

	private String relname;

	private String username;

	public TUserInfo() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAccountType() {
		return this.accountType;
	}

	public void setAccountType(int accountType) {
		this.accountType = accountType;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getImage() {
		return this.image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getPasswd() {
		return this.passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getRelname() {
		return this.relname;
	}

	public void setRelname(String relname) {
		this.relname = relname;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}