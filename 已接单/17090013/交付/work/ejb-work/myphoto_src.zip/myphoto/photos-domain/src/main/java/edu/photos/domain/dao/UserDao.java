package edu.photos.domain.dao;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import edu.photos.domain.api.UserDaoLocal;
import edu.photos.domain.model.TUserInfo;

/**
 * Session Bean implementation class UserDao
 */
@Stateless
@LocalBean
@SuppressWarnings("unchecked")
public class UserDao implements UserDaoLocal {

    @PersistenceContext(unitName = "photos")
    private EntityManager em;
    
    /**
     * Default constructor. 
     */
    public UserDao() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public List<TUserInfo> getAllUser() {
      return em.createNamedQuery("TUserInfo.findAll").getResultList();
    }

    @Override
    public TUserInfo getUserInfo(String username, String password) {
      Query query = em.createNativeQuery("select * from t_user_info where username='"+username+"' and passwd = '"+password+"' and account_type=1",
          TUserInfo.class);
      return (TUserInfo) query.getResultList().get(0);
    }

    @Override
    public void delete(List<Integer> ids) {
      StringBuilder sb = new StringBuilder();
      for (Integer i:ids) {
        sb.append(i).append(",");
      }
      sb.append(-99);
      Query query = em.createNativeQuery("delete from t_user_info where id in ("+sb.toString()+")");
      query.executeUpdate();
    }

    @Override
    public void AddUser(TUserInfo user) {
      em.persist(user);
    }

    @Override
    public void updateUser(TUserInfo user) {
      // TODO Auto-generated method stub
    }

}
