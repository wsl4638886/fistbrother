package edu.photos.domain.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the t_feedback database table.
 * 
 */
@Entity
@Table(name="t_feedback")
@NamedQuery(name="TFeedback.findAll", query="SELECT t FROM TFeedback t")
public class TFeedback implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String email;

	private String message;

	private String subject;

	@Column(name="submit_name")
	private String submitName;

	public TFeedback() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getSubmitName() {
		return this.submitName;
	}

	public void setSubmitName(String submitName) {
		this.submitName = submitName;
	}

}