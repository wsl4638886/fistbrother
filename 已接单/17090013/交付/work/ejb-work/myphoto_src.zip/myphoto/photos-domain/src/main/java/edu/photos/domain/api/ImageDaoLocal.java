package edu.photos.domain.api;

import java.util.List;

import javax.ejb.Local;

import edu.photos.domain.model.TImageInfo;

@Local
public interface ImageDaoLocal {

  public List<TImageInfo> getImagesByType(int type);
  
  public List<TImageInfo> getAllImages();
  
  public void delete(List<Integer> ids);
  
  public void add(TImageInfo images);
}
