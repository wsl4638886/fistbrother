package edu.photos.domain.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the t_image_info database table.
 * 
 */
@Entity
@Table(name="t_image_info")
@NamedQuery(name="TImageInfo.findAll", query="SELECT t FROM TImageInfo t")
public class TImageInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String category;

	private String description;

	@Column(name="image_type")
	private int imageType;

	private String title;

	private String url;

	public TImageInfo() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getImageType() {
		return this.imageType;
	}

	public void setImageType(int imageType) {
		this.imageType = imageType;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}