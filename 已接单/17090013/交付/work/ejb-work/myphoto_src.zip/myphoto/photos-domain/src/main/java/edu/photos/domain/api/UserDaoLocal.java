package edu.photos.domain.api;

import java.util.List;

import javax.ejb.Local;

import edu.photos.domain.model.TUserInfo;

@Local
public interface UserDaoLocal {

  public List<TUserInfo> getAllUser();
  
  public TUserInfo getUserInfo(String username, String password);
  
  public void delete(List<Integer> ids);
  
  public void AddUser(TUserInfo user);
  
  public void updateUser(TUserInfo user);
}
