package edu.photos.domain.dao;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import edu.photos.domain.api.ImageDaoLocal;
import edu.photos.domain.model.TImageInfo;

/**
 * Session Bean implementation class ImageDao
 */
@Stateless
@LocalBean
@SuppressWarnings("unchecked")
public class ImageDao implements ImageDaoLocal {

    @PersistenceContext(unitName = "photos")
    private EntityManager em;
    /**
     * Default constructor. 
     */
    public ImageDao() {
        // TODO Auto-generated constructor stub
    }
    
    @Override
    public List<TImageInfo> getImagesByType(int type) {
      Query query = em.createNativeQuery("SELECT * FROM t_image_info WHERE IMAGE_TYPE = " + type, TImageInfo.class);
      return query.getResultList();
    }

    @Override
    public List<TImageInfo> getAllImages() {
      return em.createNamedQuery("TImageInfo.findAll").getResultList();
    }

    @Override
    public void delete(List<Integer> ids) {
      StringBuilder sb = new StringBuilder();
      for (Integer i:ids) {
        sb.append(i).append(",");
      }
      sb.append(-99);
      Query query = em.createNativeQuery("delete from t_image_info where id in ("+sb.toString()+")");
      query.executeUpdate();
    }

    @Override
    public void add(TImageInfo images) {
      em.persist(images);
    }

}
