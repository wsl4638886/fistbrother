package edu.photos.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONObject;

import edu.photos.domain.model.TImageInfo;
import edu.photos.service.ImageService;
import edu.photos.web.utils.ResponseResult;
import edu.photos.web.utils.WebConstance;

/**
 * Servlet implementation class ImageServlet
 */
@WebServlet("/images")
public class ImageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB
    private ImageService imageService;
	
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  String action = request.getParameter("action");
      switch(action) {
        case WebConstance.ACTION_QUERY:
          query(request, response);
          break;
        case WebConstance.ACTION_ADD:
          add(request, response);
          break;
        case WebConstance.ACTION_DELETE:
          delete(request, response);
          break;
      }
	}
	
	private void add(HttpServletRequest request, HttpServletResponse response) {
	  String islogin = (String)request.getSession().getAttribute("islogin");
	  if (null != islogin && islogin.equals("true")) {
	    String addData = request.getParameter("addData");
	      if (StringUtils.isNotEmpty(addData)) {
	        try {
	          TImageInfo addObject = JSONObject.parseObject(addData).toJavaObject(TImageInfo.class);
	          imageService.add(addObject);
	          PrintWriter out = response.getWriter();  
	          out.write(JSONObject.toJSONString(ResponseResult.success()));
	        } catch (Exception e) {
	          e.printStackTrace();
	        }
	      }
	  } else {
	    request.getSession().setAttribute("islogin", "false");
        request.getSession().setAttribute("user", null);
        try {
          response.sendRedirect("login.jsp");
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        } 
	  }
      
    }
   
    private void query(HttpServletRequest request, HttpServletResponse response) {
      List<TImageInfo> images = imageService.getIndexPhoto();
      PrintWriter out = null;
      try {
        response.setCharacterEncoding("UTF-8");
        out = response.getWriter();
        out.write(JSONObject.toJSONString(ResponseResult.success(images)));
      } catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    
    private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
      String islogin = (String)request.getSession().getAttribute("islogin");
      if (null != islogin && islogin.equals("true")) {
        String id = request.getParameter("id");
        if (StringUtils.isNotEmpty(id)) {
          List<Integer> ids = new ArrayList<Integer>();
          ids.add(Integer.parseInt(id));
          imageService.delete(ids);
          PrintWriter out = response.getWriter();  
          out.write(JSONObject.toJSONString(ResponseResult.success()));
        }
      } else {
        request.getSession().setAttribute("islogin", "false");
        request.getSession().setAttribute("user", null);
        try {
          response.sendRedirect("login.jsp");
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
      }
    }

}
