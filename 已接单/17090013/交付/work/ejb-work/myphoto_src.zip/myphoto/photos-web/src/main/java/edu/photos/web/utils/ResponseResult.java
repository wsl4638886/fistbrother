package edu.photos.web.utils;

import java.io.Serializable;

public class ResponseResult<T> implements Serializable {
	private static final long serialVersionUID = -5240266255145233704L;

	public static final int OK = 0;
	public static final int INVALID = 998;
	public static final int ERROR = 999;

	private T datas;
	private int code;
	private String message;
	
	private ResponseResult(T data, int code, String message) {
		this.datas = data;
		this.code = code;
		this.message = message;
	}

	public static <T> ResponseResult<T> success() {
		return success(null, null);
	}

	public static <T> ResponseResult<T> success(T datas) {
		return success(datas, null);
	}

	public static <T> ResponseResult<T> success(T datas, String message) {
		return new ResponseResult<T>(datas, OK, message);
	}

	public static <T> ResponseResult<T> failure(String message) {
		return failure(null, message);
	}

	public static <T> ResponseResult<T> failure(T datas, String message) {
		return failure(datas, ERROR, message);
	}

	public static <T> ResponseResult<T> failure(T datas, int code, String message) {
		return new ResponseResult<T>(datas, code, message);
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public T getDatas() {
		return datas;
	}

	public void setDatas(T data) {
		this.datas = data;
	}
}
