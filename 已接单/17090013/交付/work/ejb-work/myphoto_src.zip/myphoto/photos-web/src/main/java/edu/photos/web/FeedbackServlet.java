package edu.photos.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONObject;

import edu.photos.domain.model.TFeedback;
import edu.photos.service.FeedbackService;
import edu.photos.web.utils.ResponseResult;
import edu.photos.web.utils.WebConstance;

/**
 * Servlet implementation class FeedbackServlet
 */
@WebServlet("/feedback")
public class FeedbackServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB
	private FeedbackService feedbackService;
	
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  String action = request.getParameter("action");
      switch(action) {
        case WebConstance.ACTION_QUERY:
          query(request, response);
          break;
        case WebConstance.ACTION_ADD:
          add(request, response);
          break;
        case WebConstance.ACTION_DELETE:
          delete(request, response);
          break;
      }
	}
	
	private void add(HttpServletRequest request, HttpServletResponse response) {
	  String feedbackData = request.getParameter("feedbackData");
	  if (StringUtils.isNotEmpty(feedbackData)) {
	    try {
	      TFeedback feedback = JSONObject.parseObject(feedbackData).toJavaObject(TFeedback.class);
	      feedbackService.addFeedback(feedback);
	      PrintWriter out = response.getWriter();  
	      out.write(JSONObject.toJSONString(ResponseResult.success()));
	    } catch (Exception e) {
	      e.printStackTrace();
	    }
	  }
    }
   
    private void query(HttpServletRequest request, HttpServletResponse response) {
      if (request.getSession().getAttribute("islogin").equals("true")) {
        List<TFeedback> images = feedbackService.getAllFeedback();
        PrintWriter out = null;
        try {
          response.setCharacterEncoding("UTF-8");
          out = response.getWriter();
          out.write(JSONObject.toJSONString(ResponseResult.success(images)));
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
      } else {
        request.getSession().setAttribute("islogin", "false");
        request.getSession().setAttribute("user", null);
        try {
          response.sendRedirect("login.jsp");
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
      }
    }
    
    private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
      if (request.getSession().getAttribute("islogin").equals("true")) {
        String id = request.getParameter("id");
        if (StringUtils.isNotEmpty(id)) {
          List<Integer> ids = new ArrayList<Integer>();
          ids.add(Integer.parseInt(id));
          feedbackService.delete(ids);
          PrintWriter out = response.getWriter();  
          out.write(JSONObject.toJSONString(ResponseResult.success()));
        }
      } else {
        request.getSession().setAttribute("islogin", "false");
        request.getSession().setAttribute("user", null);
        try {
          response.sendRedirect("login.jsp");
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
      }
    }

}
