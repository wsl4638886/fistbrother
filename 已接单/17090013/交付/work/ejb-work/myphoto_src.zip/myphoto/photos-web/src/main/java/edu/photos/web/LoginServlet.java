package edu.photos.web;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import edu.photos.domain.model.TUserInfo;
import edu.photos.service.UserService;

@WebServlet(name = "loginServlet", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @EJB
    private UserService userService;
    
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
      if ("true".equals(request.getSession().getAttribute("islogin"))) {
        
      }
      String username = request.getParameter("username");
      String password = request.getParameter("password");
      TUserInfo user = null;
      if (StringUtils.isNotEmpty(username) && StringUtils.isNotEmpty(password) ) {
        user = userService.login(username, password);
      }
      
      if (null != user) {
        request.getSession().setAttribute("islogin", "true");
        request.getSession().setAttribute("user", user);
        response.sendRedirect("admin");
      } else {
        request.getSession().setAttribute("islogin", "false");
        request.getSession().setAttribute("user", null);
        response.sendRedirect("login.jsp");
      }
    }
}
