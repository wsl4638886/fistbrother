package edu.photos.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;

import edu.photos.domain.model.TImageInfo;
import edu.photos.domain.model.TUserInfo;
import edu.photos.service.ImageService;
import edu.photos.service.UserService;
import edu.photos.web.utils.ResponseResult;

/**
 * Servlet implementation class IndexServlet
 */
@WebServlet("/index")
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB
	private ImageService imageService;
	
	@EJB
	private UserService userService;
	
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  List<TImageInfo> images = imageService.getIndexPhoto();
	  List<TUserInfo> users = userService.getAllUser();
	  if (users != null && !users.isEmpty()) {
	    for (TUserInfo user : users) {
	      user.setPasswd("");
	    }
	  }
	  JSONObject resultData = new JSONObject();
	  resultData.put("users", users);
	  resultData.put("images", images);
	  response.setCharacterEncoding("UTF-8");
	  PrintWriter out = response.getWriter();  
      out.write(JSONObject.toJSONString(ResponseResult.success(resultData)));
	}
}
