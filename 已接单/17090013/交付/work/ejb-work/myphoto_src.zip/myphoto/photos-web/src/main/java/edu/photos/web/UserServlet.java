package edu.photos.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONObject;

import edu.photos.domain.model.TUserInfo;
import edu.photos.service.UserService;
import edu.photos.web.utils.ResponseResult;
import edu.photos.web.utils.WebConstance;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet(name = "userServlet", urlPatterns = "/user")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB
    private UserService userService;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		switch(action) {
		  case WebConstance.ACTION_QUERY:
		    query(request, response);
		    break;
		  case WebConstance.ACTION_ADD:
		    add(request, response);
            break;
		  case WebConstance.ACTION_DELETE:
		    delete(request, response);
            break;
		  case WebConstance.ACTION_UPDATE:
            break;
		}
	}
	
	private void add(HttpServletRequest request, HttpServletResponse response) {
	  String islogin = (String)request.getSession().getAttribute("islogin");
      if (null != islogin && islogin.equals("true")) {
        String addData = request.getParameter("addData");
          if (StringUtils.isNotEmpty(addData)) {
            try {
              TUserInfo addObject = JSONObject.parseObject(addData).toJavaObject(TUserInfo.class);
              userService.add(addObject);
              PrintWriter out = response.getWriter();  
              out.write(JSONObject.toJSONString(ResponseResult.success()));
            } catch (Exception e) {
              e.printStackTrace();
            }
          }
      } else {
        request.getSession().setAttribute("islogin", "false");
        request.getSession().setAttribute("user", null);
        try {
          response.sendRedirect("login.jsp");
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        } 
      }
	}
	
	private void query(HttpServletRequest request, HttpServletResponse response) {
	  String islogin = (String)request.getSession().getAttribute("islogin");
      if (null != islogin && islogin.equals("true")) {
        List<TUserInfo> users = userService.getAllUser();
        PrintWriter out = null;
        try {
          response.setCharacterEncoding("UTF-8");
          out = response.getWriter();
          out.write(JSONObject.toJSONString(ResponseResult.success(users)));
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
      } else {
        request.getSession().setAttribute("islogin", "false");
        request.getSession().setAttribute("user", null);
        try {
          response.sendRedirect("login.jsp");
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        } 
      }
    }
	
	private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
	  String islogin = (String)request.getSession().getAttribute("islogin");
      if (null != islogin && islogin.equals("true")) {
        String id = request.getParameter("id");
        if (StringUtils.isNotEmpty(id)) {
          List<Integer> ids = new ArrayList<Integer>();
          ids.add(Integer.parseInt(id));
          userService.delete(ids);
          PrintWriter out = response.getWriter();  
          out.write(JSONObject.toJSONString(ResponseResult.success()));
        }
      } else {
        request.getSession().setAttribute("islogin", "false");
        request.getSession().setAttribute("user", null);
        try {
          response.sendRedirect("login.jsp");
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
      }
    }

}
