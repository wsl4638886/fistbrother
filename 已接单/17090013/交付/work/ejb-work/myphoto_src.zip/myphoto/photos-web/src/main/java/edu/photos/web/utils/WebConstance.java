package edu.photos.web.utils;

public class WebConstance {
  
  public static final String ACTION_DELETE = "delete";
  
  public static final String ACTION_ADD = "add";
  
  public static final String ACTION_QUERY = "query";
  
  public static final String ACTION_UPDATE = "update";
}
