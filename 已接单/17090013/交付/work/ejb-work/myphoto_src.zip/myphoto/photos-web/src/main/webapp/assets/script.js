var wow = null;
jQuery(document).ready(function($) {
 
	$.post("/myphotos/index",null,function(data){
	   if (data != null &&  data.code == 0) {
		   if (data.datas.images.length > 0) {
			 var htmlTmp = '{{#images}}' +
						   '<figure class="effect-oscar  wowload fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">' +
						   '	<img src="{{url}}" alt="{{title}}">' +
						   '	<figcaption>' +
						   '		<h2>{{title}}</h2>' +
						   '		<p>{{description}}<br>' +
						   '		<a href="{{url}}" title="{{title}}" data-gallery="">View more</a></p>' +            
						   '	</figcaption>' +
						   '</figure>' +
						   '{{/images}}';
			 $('#works').html(Mustache.render(htmlTmp, data.datas));
		   }
		   
		   if (data.datas.users.length > 0) {
			   var htmlTmp =   '{{#users}}' +
							   '<div class=" col-sm-6 col-xs-12">' +
							   '<figure class="effect-chico">' +
							   '	<img src="{{image}}" alt="{{relname}}" class="img-responsive">' +
							   '	<figcaption>' +
							   '		<p>' +
							   '		<b>{{relname}}</b><br>' +
							   '		{{description}}<br>' +
							   '		{{phone}}<br>' +
							   '		{{email}}<br>' +
							   '		</p>' +            
							   '	</figcaption>' +
							   '</figure>' +
							   '</div>' +
							   '{{/users}}';
			   $('#partners-detail').html(Mustache.render(htmlTmp, data.datas));
		   }
		   

		    wow = new WOW(
		  		  {
		  		    boxClass:     'wowload',  // animated element css class (default is wow)
		  		    animateClass: 'animated', // animation css class (default is animated)
		  		    offset:       0,          // distance to the element when triggering the animation (default is 0)
		  		    mobile:       true,       // trigger animations on mobile devices (default is true)
		  		    live:         true        // act on asynchronously loaded content (default is true)
		  		  }
		  		);
		  	wow.init();
		  	
		  	$('.carousel').swipe( {
		  	     swipeLeft: function() {
		  	         $(this).carousel('next');
		  	     },
		  	     swipeRight: function() {
		  	         $(this).carousel('prev');
		  	     },
		  	     allowPageScroll: 'vertical'
		  	 });
	   } 
	}, "json");
	
    $(".scroll a, .navbar-brand, .gototop").click(function(event){   
    event.preventDefault();
    $('html,body').animate({scrollTop:$(this.hash).offset().top}, 600,'swing');
    $(".scroll li").removeClass('active');
    $(this).parents('li').toggleClass('active');
    });
    
    // listener
    $('body').off('click', '#send-feedback').on('click', '#send-feedback', function() {
    	var data = {};
    	data.submitName = $('#feedback').find("input[name='submitName']").val();
    	data.email = $('#feedback').find("input[name='email']").val();
    	data.subject = $('#feedback').find("input[name='subject']").val();
    	data.message = $('#feedback').find("textarea[name='message']").val();
    	
    	var requestData = {action:"add"};
    	requestData.feedbackData = JSON.stringify(data);
    	$.post("/myphotos/feedback",requestData,function(data){
    		$('#feedback').find("input[name='submitName']").val("");
        	$('#feedback').find("input[name='email']").val("");
        	$('#feedback').find("input[name='subject']").val("");
        	$('#feedback').find("textarea[name='message']").val("");
    	});
    	
    	$("#footer-ends").click();
    });
});





