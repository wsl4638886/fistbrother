package edu.photos.service;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import edu.photos.domain.dao.UserDao;
import edu.photos.domain.model.TUserInfo;
import edu.photos.service.api.UserServiceLocal;

/**
 * Session Bean implementation class UserService
 */
@Stateless
@LocalBean
public class UserService implements UserServiceLocal {

    @EJB
    private UserDao userDao;

    @Override
    public TUserInfo login(String username, String password) {
      TUserInfo user = userDao.getUserInfo(username, password);
      return user;
    }

    @Override
    public List<TUserInfo> getAllUser() {
      return userDao.getAllUser();
    }

    @Override
    public void delete(List<Integer> ids) {
      userDao.delete(ids);
      
    }

    @Override
    public void add(TUserInfo user) {
      userDao.AddUser(user);
    }

}
