package edu.photos.service.api;

import java.util.List;

import javax.ejb.Local;

import edu.photos.domain.model.TFeedback;

@Local
public interface FeedbackServiceLocal {

  public void addFeedback(TFeedback feedback);
  
  public List<TFeedback> getAllFeedback();
  
  public void delete(List<Integer> ids);
  
}
