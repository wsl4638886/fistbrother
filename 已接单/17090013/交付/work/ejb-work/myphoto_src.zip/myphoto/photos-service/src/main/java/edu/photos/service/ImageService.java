package edu.photos.service;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import edu.photos.domain.dao.ImageDao;
import edu.photos.domain.model.TImageInfo;
import edu.photos.service.api.ImageServiceLocal;

/**
 * Session Bean implementation class ImageService
 */
@Stateless
@LocalBean
public class ImageService implements ImageServiceLocal {

    @EJB
    private ImageDao imageDao;

    @Override
    public List<TImageInfo> getIndexPhoto() {
      return imageDao.getAllImages();
    }

    @Override
    public void delete(List<Integer> ids) {
      imageDao.delete(ids);
      
    }

    @Override
    public void add(TImageInfo image) {
      imageDao.add(image);
    }

   
}
