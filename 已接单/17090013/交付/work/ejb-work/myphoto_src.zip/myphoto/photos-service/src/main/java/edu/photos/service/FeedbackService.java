package edu.photos.service;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import edu.photos.domain.dao.FeedbackDao;
import edu.photos.domain.model.TFeedback;
import edu.photos.service.api.FeedbackServiceLocal;

/**
 * Session Bean implementation class FeedbackService
 */
@Stateless
@LocalBean
public class FeedbackService implements FeedbackServiceLocal {

  @EJB
  private FeedbackDao feedbackDao;
  
  @Override
  public void addFeedback(TFeedback feedback) {
    try {
      feedbackDao.addFeedback(feedback);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override
  public List<TFeedback> getAllFeedback() {
    // TODO Auto-generated method stub
    return feedbackDao.getAllFeedback();
  }

  @Override
  public void delete(List<Integer> ids) {
    feedbackDao.delete(ids);
  }

}
