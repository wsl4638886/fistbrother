package edu.photos.service.api;

import java.util.List;

import javax.ejb.Local;

import edu.photos.domain.model.TImageInfo;

@Local
public interface ImageServiceLocal {
  public List<TImageInfo> getIndexPhoto();
  
  public void delete(List<Integer> ids);
  
  public void add(TImageInfo image);
}
