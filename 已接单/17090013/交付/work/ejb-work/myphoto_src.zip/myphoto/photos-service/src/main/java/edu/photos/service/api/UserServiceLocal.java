package edu.photos.service.api;

import java.util.List;

import javax.ejb.Local;

import edu.photos.domain.model.TUserInfo;

@Local
public interface UserServiceLocal {
  public TUserInfo login(String username, String password);
  
  public List<TUserInfo> getAllUser();
  
  public void delete(List<Integer> ids);
  
  public void add(TUserInfo user);
}
