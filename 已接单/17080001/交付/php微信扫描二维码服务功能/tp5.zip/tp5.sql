/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50611
Source Host           : localhost:3306
Source Database       : tp5

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2017-08-03 17:11:13
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tp_users
-- ----------------------------
DROP TABLE IF EXISTS `tp_users`;
CREATE TABLE `tp_users` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `avatar` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `mobile` char(11) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tp_users
-- ----------------------------
INSERT INTO `tp_users` VALUES ('1', '张三', '/uploads/images/0.jpg', '15950452241');
INSERT INTO `tp_users` VALUES ('2', '李四', '/uploads/images/avatar.jpg', '15950555555');
INSERT INTO `tp_users` VALUES ('3', '卡普', '/uploads/images/timg.jpg', '15999999999');
INSERT INTO `tp_users` VALUES ('4', 'luffy', '/uploads/images/timg_1.jpg', '15874785985');
INSERT INTO `tp_users` VALUES ('5', 'nami', '/uploads/images/timg_2.jpg', '15998574856');

-- ----------------------------
-- Table structure for tp_user_service
-- ----------------------------
DROP TABLE IF EXISTS `tp_user_service`;
CREATE TABLE `tp_user_service` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `service_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tp_user_service
-- ----------------------------
INSERT INTO `tp_user_service` VALUES ('1', '1', '送饭', '1501745696', '1501745955');
INSERT INTO `tp_user_service` VALUES ('2', '1', '送饭', '1501746085', '1501746184');
INSERT INTO `tp_user_service` VALUES ('3', '1', '送饭', '1501746194', '1501746218');
INSERT INTO `tp_user_service` VALUES ('4', '1', '送饭', '1501746220', '1501746856');
INSERT INTO `tp_user_service` VALUES ('5', '1', '送饭', '1501746900', '1501746906');
INSERT INTO `tp_user_service` VALUES ('6', '2', '送饭', '1501748513', '1501748519');
