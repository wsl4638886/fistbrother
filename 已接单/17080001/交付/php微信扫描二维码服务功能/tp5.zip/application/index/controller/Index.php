<?php
namespace app\index\controller;

class Index extends \think\Controller
{
    public function index()
    {
       
       $userid = session('userid');
    
       if(!empty($userid)){
           $this->setEnd($userid);
           
       }else{
           $lists = db('users')->select();
           $sname = mb_convert_encoding(input('cat'),'utf-8','gb2312');
           if(empty($sname)){
               echo '缺少参数，请输入工作内容！';exit();
           }
            $this->assign('users',$lists);
            $this->assign('sname',input('cat'));
            return $this->fetch();
       }
       
    }
    
    public function setEnd($userid){
        $where['userid'] = $userid;
        $where['end_time'] = 0;
        $info = db('user_service')->where($where)->order('id desc')->find();
        $ctime = time();
        $res = false;
        if(!empty($info)){
              if($info['start_time'] < strtotime(date('Y-m-d'))){  //非今日开始服务。重置
                  $end_time = strtotime(date('Y-m-d 23:59:59',$info['start_time']));
                }else{
                    $end_time = $ctime;
                }
             $res = db('user_service')->where('id='.$info['id'])->setField('end_time',$end_time);
        }else{
             echo '当前没有进行中的服务！';//exit();
        }
        if($res){
            echo '服务结束，当前服务总计:'.$this->format_time($end_time-$info['start_time']);
            
        }
        session('userid',0);
    }
    
    function format_time($seconds=0){
        $hour = 0;
        $minute = 0;
        if($seconds>=3600){
            $hour = intval($seconds/3600);
            $seconds = $seconds%3600;
        }
       
        if($seconds>=60){
            $minute =intval($seconds/60);
            $seconds = $seconds%60;
        }
        return $hour.'小时'.$minute.'分钟'.$seconds.'秒钟';
        
    }
    
    public function start_post(){
        $userid = input('userid');
        $suserid =  session('userid');
        $sname = input('sname')?input('sname'):'送饭';
//        $sname = mb_convert_encoding($sname,'utf-8','gb2312');
        if(!empty($userid)){
            if(!empty($suserid) && $userid!=$suserid){
                $this->error('不能给其他用开启服务！');
            }
            session('userid',$userid);
            $time = time();
            $data['userid'] = $userid;

            $data['end_time'] = 0;
            $info = db('user_service')->where($data)->find();
            if(empty($info)){
                $data['start_time'] = $time;
                $data['service_name'] = $sname;
                $res = db('user_service')->insert($data);
            }else{
                if($info['start_time'] < strtotime(date('Y-m-d'))){  //非今日开始服务。重置
                    $data['end_time'] = strtotime(date('Y-m-d 23:59:59',$info['start_time']));
                    $res = db('user_service')->where('id='.$info['id'])->update($data);
                    unset($data['end_time']);
                    $data['start_time'] = $time;
                     $data['service_name'] = $sname;
                     $res = db('user_service')->insert($data);
                }else{
                    $this->error('当前用户已经在服务中！');
                }
//                $data['service_name'] = $sname;
//                $res = db('user_service')->where('id='.$info['id'])->update($data);
                
            }
            if($res){
                $this->success('服务开始，开始时间:'.date('Y-m-d H:i:s'));
            }
        }else{
            $this->error('系统错误！');
        }
        
      
    }
}
