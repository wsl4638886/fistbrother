<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:71:"E:\code\code_2017\tp5\public/../application/index\view\index\index.html";i:1501746971;}*/ ?>
<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"/>
	<meta name="format-detection" content="telephone=no" />

        <link href="__CSS__/common.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
     <div class="header">
		<p class="title-app" style="float:left;margin-left:20%">服务记时系统</p>
    </div>
        
        <div class="users">
            <?php if(is_array($users) || $users instanceof \think\Collection || $users instanceof \think\Paginator): $i = 0; $__LIST__ = $users;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$user): $mod = ($i % 2 );++$i;?>
            <div class="lists" id="<?php echo $user['id']; ?>" uname="<?php echo $user['username']; ?>"  onclick="start_record(this)">
            <div class="person left">
                    <img src="<?php echo $user['avatar']; ?>"  />
            </div>
            <div class="reply left">
                    <div class="floors">
                            <div class="re">
                                    <p class="name-s left"><?php echo $user['username']; ?></p>
                            </div>
                    </div>
                    <p class="cont-reply"><?php echo $user['mobile']; ?></p>
                  
            </div>
    </div>
                
            <?php endforeach; endif; else: echo "" ;endif; ?>
      
            </div>
    </body>
    <script src="__JS__/jquery-2.0.3.min.js"></script>
    <script>
        
        function start_record(obj){
           var $this = $(obj),username = $this.attr('uname'),uid = $this.attr('id');
           if(confirm('用户：'+username+'确定开始服务？')){
              $.post(
                '<?php echo url("start_post"); ?>',{userid:uid},function(data){
                    console.log(data.msg);
                    alert(data.msg);
                }  
                )
           }
        }
    </script>
</html>
