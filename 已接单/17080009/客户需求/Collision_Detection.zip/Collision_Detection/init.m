clear;
clc;

% add all subfolders to matlab path for this session
addpath(pwd)
addpath(fullfile(pwd, 'navigation'))

% load bus objects into workspace
load('busObjects','-mat');

% load navigation graph
posVec = uint16(positionVector);
edges = uint16(streetEdges);
deg = double(degreeOfEdges(posVec, edges));
%speedVector = speedLimitgenerator(...);


% open simulink model
open_system('demo','window');
