% script written by Michael von Wenckstern <vonwenckstern@se-rwth.de>
% this scripts draws all map points and the existing edges from one
% map point to another map point
% this illustrates the map graph

clear;
posVec = positionVector;
e = streetEdges;

e2 = reshape(e', 1, size(e,1)*2); % turn it to one row vector
posVec2 = posVec(e2, :);
posVec3 = [posVec2(1:2:end, :) posVec2(2:2:end, :)];
posVec4 = posVec3;
posVec4(:, 3) = posVec3(:, 3) - posVec3(:, 1);
posVec4(:, 4) = posVec3(:, 4) - posVec3(:, 2);

hold off;
plot(posVec(:, 1), -1*posVec(:, 2), '*');
hold on;
quiver(posVec4(:,1), -1*posVec4(:,2), posVec4(:,3), -1*posVec4(:, 4),'MaxHeadSize', 100, 'AutoScale', 'Off');
