posVec = [1 -6.5; 1 -5.5; 1 -4.5; 4 -4.5; 4 -2; 6.5 -2; 6.5 -4.5; 9.5 -4.4; 9.5 -5.5];
e = [1 2; 2 9; 9 8; 1 3; 3 4; 4 5; 5 6; 6 7; 7 8];

e2 = reshape(e', 1, size(e,1)*2); % turn it to one row vector
posVec2 = posVec(e2, :);
%posVec3 = reshape(posVec2, size(posVec2, 1)/2, 4);
posVec3 = [posVec2(1:2:end, :) posVec2(2:2:end, :)];
posVec4 = posVec3;
posVec4(:, 3) = posVec3(:, 3) - posVec3(:, 1);
posVec4(:, 4) = posVec3(:, 4) - posVec3(:, 2);

hold off;
plot(posVec(:, 1), -1*posVec(:, 2), '*');
hold on;
quiver(posVec4(:,1), -1*posVec4(:,2), posVec4(:,3), -1*posVec4(:, 4),'MaxHeadSize', 1, 'AutoScale', 'off');
