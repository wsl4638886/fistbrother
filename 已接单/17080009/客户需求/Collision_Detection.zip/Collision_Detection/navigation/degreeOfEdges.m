% written by Michael von Wenckstern <vonwenckstern@se-rwth.de>
% this function saves the degree of the edge vector in a deg vector
% mapping is done through index position
function deg = degreeOfEdges(posVec, e)
    posVec = double(posVec);
    e = double(e);
    e2 = reshape(e', 1, size(e,1)*2); % turn it to one row vector
    posVec2 = posVec(e2, :);
    diff = (posVec2(2:2:end, :)-posVec2(1:2:end, :)); % vector containing the direction of the edges
    n = (diff(:,1).^2 + diff(:,2).^2).^(0.5);
    deg = acos(diff(:, 1)./ n);
    % case differentation for quadrant III and IV
    ind = find(diff(:,2) > 0);
    deg(ind) = 2*pi - deg(ind);
end