function e = addRange(e, start, ende)
% adds to a vector the pair-wise range
% e.g. start = 5; end = 8 adds to e the following matrix
% [5 6; 6 7; 7 8]
    
    if start < ende
        e = [e; (start:ende-1)' (start+1:ende)'];
    else
        e = [e; (start:-1:ende+1)' (start-1:-1:ende)'];
    end

end

