% written by Michael von Wenckstern <vonwenckstern@se-rwth.de>
% this function is needed to wrap the dijsktra results in an 1x2000
% array having a fixed size; otherwise the coder cannot integrate
% the function to the rest of the Simulink model
function [n, navigationPoints] = startDijkstra(AorV,xyCorE,SID,FID)
    navigationPoints = zeros(1, 2000);
    n = zeros(1,1);
    [~, navPoints] = dijkstra(AorV, xyCorE, SID, FID);
    n = size(navPoints, 2);
    if n > 2000
        n = 2000;
    end
    navigationPoints(1, 1:n) = navPoints(1, 1:n);