% written by Michael von Wenckstern <vonwenckstern@se-rwth.de>
% function maps x,y coordinates in mm to point position
% driveDirection of car in radiant
% this point position can be used as start point in the
% navigation algorithm
function point = mapCoordinateToPoint(x, y, driveDirection, vecPos, e, deg)
    x = double(x);
    y = double(y);
    driveDirection = double(driveDirection);
    vecPos = double(vecPos);
    e = double(e);
    deg = double(deg);
    driveDirection = truncateAngle(driveDirection);
    mini = driveDirection - 0.5; % - 30�
    if(mini >= 0)
        ind = find(deg > mini & deg <= driveDirection);
    else
        mini = mini + 2*pi;
        ind = find(deg > mini & deg <= 2*pi | deg >= 0 & deg <= driveDirection);
    end
    
    max = driveDirection + 0.5; % + 30�
    if(max < 2*pi)
        ind = [ind; find(deg >= driveDirection & deg < max)];
    else
        max = max - 2*pi;
        ind = [ind; find(deg >= 0 & deg < max | deg >= driveDirection & deg <= 2*pi)];
    end

    % now we have all indices of edges what have the same angle as the
    % car's drive direction with a tolerance of +- 30�
    e1 = e(ind, :);
    v = vecPos(e1(:, 1), :);
    dist = (v(:, 1)-x).^2 + (v(:, 2)-y).^2; % since we minimize only we can save the root operation
    [~, I] = min(dist); % get indices of point having minimum distance
   point = e(ind(I(1)), 1);
end

% truncates all angles to the interval [0, 2*pi]
function deg = truncateAngle(deg)
    deg = rem(deg, 2*pi);
    if(deg < 0)
        deg = deg + 2*pi;
    end
end