% written by Michael von Wenckstern <vonwenckstern@se-rwth.de>
% it draws a route going from one point to another point
% use this function in the following way:
% drawRoute(1, 264)
% the points are the points in the powerpoint presentation
% 'StreckePunkte.pptm'
function drawRoute(startPoint, endPoint)
posVec = positionVector;                                                 % Load vector containing image coordinates for all reachable map positions
e = streetEdges;                                                         % Load vector with all edges of graph
[~, points] = dijkstra(posVec, e, startPoint, endPoint);                 % Calculates waypoints of shortest path with dijkstra algirithm
im = imread('../Strecke.png');                                           % Loads image to multidimensional array
posPoints = posVec(points,:);                                            % Creates vector of image coordinates for the path
posRect = (length(im)/3000)*[posPoints 10*ones(size(posPoints, 1), 2)];  % Creates matrix with 4 columns: first two are posPoints, second two are filled with 10s
im = insertShape(im, 'FilledRectangle', posRect, 'Color', 'blue');       % Inserts blue rectangles for each waypoint on image

warning('off', 'Images:initSize:adjustingMag');                          % Turns certain warnings off
imshow(im);                                                              % Shows image
