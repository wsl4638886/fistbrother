classdef Adress < Simulink.IntEnumType
  enumeration
    None(0)
    Ahornstrasse_55(264)
    Hermannstrasse_15(923)
		Hilfe_1(230)
		Hilfe_2(240)
		Hilfe_3(255)
		Hilfe_4(260)
		Hilfe_5(129)
		Hilfe_6(596)
		Hilfe_7(600)
		Hilfe_8(392)
		Hilfe_9(350)
  end
end