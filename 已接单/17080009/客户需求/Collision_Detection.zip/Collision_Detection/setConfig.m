function setConfig(name)
    load_system(name);
    Simulink.BlockDiagram.loadActiveConfigSet(name, 'demoSettings.m');
    save_system(name);
end