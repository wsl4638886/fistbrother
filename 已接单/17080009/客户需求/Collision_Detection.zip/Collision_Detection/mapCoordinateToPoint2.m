% written by Michael von Wenckstern <vonwenckstern@se-rwth.de>
% function maps x,y coordinates in mm to point position
% driveDirection of car in radiant
% this point position can be used as start point in the
% navigation algorithm
function point = mapCoordinateToPoint2(x, y, vecPos)
    x = double(x);
    y = double(y);
    vecPos = double(vecPos);
    
    point = 0;
    dist = inf;
    for i=1:length(vecPos)
        x2 = x-vecPos(i,1);
        y2 = y-vecPos(i,2);
        if(dist>sqrt(x2^2 + y2^2))
            dist=sqrt(x2^2 + y2^2);
            point = i;
        end
    end