<?php

error_reporting(E_ALL);
set_time_limit(0);
header("Content-type:text/html;charset=utf-8");
define("SCRIPT_PATH",  dirname(__FILE__));
$year = date('Y');
session_start(); 
include("../common/mysql.php");
include("../common/function.php");



ini_set('date.timezone', 'Asia/Shanghai');  //设置时区

init_mysql();


$post = $_POST;

if(!empty($post)){
 
  $res = Mysql::save('tp_old',$post);
  
  if($res){
    header('Location: old.php');
  }
}else{
  $oid = $_GET['id'];

$old = Mysql::findOne('select * from tp_old where id='.$oid);

}




?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/public.css">
    <link rel="stylesheet" type="text/css" href="css/information.css">
    <style>
    .threecols{
      width: 100%
    }
.threecols span{

  display: block;
  height: 3rem;
}
.jkdabtn{
  text-align: left;
}
    </style>
</head>
<body>
<div class="nrwrap">
    <div class="inner">
      
        <div class="nrbox">
              <div class="addjkda">
                  <form action="" method="POST">
            <div class="threecols">
             <input type="hidden" value="<?php echo $old['id'] ?>" name="id" />
                     <span>
                        <label>老人名称：</label>
                        <input type="text" name="oname" value="<?php echo $old['oname']; ?>">
                    </span>
                     <span>
                        <label>老人年龄：</label>
                      <input type="text" name="age"  value="<?php echo $old['age'] ?>">
                    </span>
                     <span>
                        <label>性别：</label>
                       <select name="sex">
                          <option value='0'>请选择</option>
                           <option value='男' <?php if($old['sex'] == '男') echo 'selected=true' ?>>男</option>
                            <option value='女' <?php if($old['sex'] == '女') echo 'selected=true' ?>>女</option>
                        </select>
                    </span>
                    <div style="padding-top: 15px;">
                    <span  >
                        <label>房间号：</label>
                        <input type="text" name="roomid"  value="<?php echo $old['roomid'] ?>" >
                    </span>
                    <span>
                        <label>床位号：</label>
                        <input type="text" name="bedid" value="<?php echo $old['bedid'] ?>">
                    </span>
                   
                </div>
                
            </div> <div class="jkdabtn">
                    <a href="javascript:$('form').submit()">确定</a>
                
                  
                </div>
                      </form>
          </div>
         
          
    </div>

</div>
<script type="text/javascript" src="lib/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/jedate.min.js"></script>
<script>
    // jeDate({
    //     dateCell:"#starttime",
    //     format:"YYYY/MM/DD/ hh:mm",
    //     isTime:true
    // });

    // jeDate({
    //     dateCell:"#endtime",
    //     format:"YYYY/MM/DD/  hh:mm",
    //     isTime:true
    // })
    
    $('.black2 a').click(function(){
        var page = $(this).attr('_page');
//        alert(href);
        $('input[name=p]').val(page);
        $('form').submit();
    })

    function dodelete(oid){
      if(confirm('确定要删除当前信息？')){
        $.post(
            '',{op:'del',id:oid},
            function(data){
              alert(data);
              window.location.reload();
            }
          )
      }
    }
</script>
</body>
</html>