<?php

error_reporting(E_ALL);
set_time_limit(0);
header("Content-type:text/html;charset=utf-8");
define("SCRIPT_PATH",  dirname(__FILE__));
$year = date('Y');
session_start(); 
include("../common/mysql.php");
include("../common/function.php");



ini_set('date.timezone', 'Asia/Shanghai');  //设置时区

init_mysql();


$post = $_POST;
// var_dump($post);
if($post['op'] == 'del'){  //删除
  if(empty($post['id'])){
    echo '参数错误，缺少老人ID!';
  }else{
    $sql = 'delete from tp_old where id='.$post['id'];
    $res = Mysql::query($sql);
    if($res){
      echo '删除成功！';
    }else{
      echo '删除失败！';
    }
  }
  exit();

}

$where = '1=1 ';
if(!empty($post)){
    // if(!empty($post['id']))  $where.=' and id="'.$post['id'].'"';
    if(!empty($post['oname']))  $where.=' and oname="'.$post['oname'].'"';
    if(!empty($post['sex']))  $where.=' and sex="'.$post['sex'].'"';
    if(!empty($post['age']))  $where.=' and age >='.($post['age']);
    if(!empty($post['roomid']))  $where.=' and roomid ='.($post['roomid']);
    if(!empty($post['bedid']))  $where.=' and bedid ='.($post['bedid']);
}

$count = Mysql::findOne('select count(*) as count from tp_old where '.$where);
$total_rows = $count['count'];

$limit = 5;
$page = $_REQUEST['p']?$_REQUEST['p']:1;
$start = ($page-1)*5;

$sql='select * from tp_old where '.$where.' order by id desc limit '.$start.','.$limit;
$lists = Mysql::querytoarray($sql);


// var_dump($lists);

$pagehtml = get_page_html($total_rows,$page,$limit);

//var_dump($_SERVER);die();
function get_page_html($total_rows,$page=1,$limit=5){
    $total_page = ceil($total_rows/$limit);
    $html = '';
    if($page==1){
        $html .= '<span class="disabled"> &lt; </span><span class="current">1</span>';
    }else{
        $html .= '<a _page="'.($page-1).'"> &lt; </a><a _page="1">1</a>';
    }
    
    for($i=2;$i<=$total_page;$i++){
        if($page != $i){
            $html .= '<a _page="'.$i.'">'.$i.'</a>';
        }else{
            $html .= '<span class="current">'.$i.'</span>';
        }
        
    }
    
    
     if($page==$total_page){
        $html .= '<span class="disabled"> &gt; </span>';
    }else{
        $html .= '<a _page="'.($page+1).'">  &gt;  </a>';
    }
    
    return $html;
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/public.css">
    <link rel="stylesheet" type="text/css" href="css/information.css">
</head>
<body>
<div class="nrwrap">
    <div class="inner">
      
        <div class="nrbox">
              <div class="addjkda">
                  <form action="" method="POST">
            <div class="threecols">
           
                     <span>
                        <label>老人名称：</label>
                        <input type="text" name="oname" value="<?php echo $post['catname']; ?>">
                    </span>
                     <span>
                        <label>老人年龄：</label>
                      <input type="text" name="age"  value="<?php echo $post['age'] ?>">
                    </span>
                     <span>
                        <label>性别：</label>
                       <select name="sex">
                          <option value='0'>请选择</option>
                           <option value='男'>男</option>
                            <option value='女'>女</option>
                        </select>
                    </span>
                    <div style="padding-top: 15px;">
                    <span  >
                        <label>房间号：</label>
                        <input type="text" name="roomid"  value="<?php echo $post['roomid'] ?>" >
                    </span>
                    <span>
                        <label>床位号：</label>
                        <input type="text" name="bedid" value="<?php echo $post['bedid'] ?>">
                    </span>
                   
                </div>
                
            </div> <div class="jkdabtn">
                    <a href="javascript:$('form').submit()">搜索</a>
                
                    <a href="javascript:$('form').reset()">重置</a>
                </div>
                      </form>
          </div>
            <div class="addjkda">
              <table width="930" border="1" bordercolor=" #d2d2d2" cellspacing="0" style="text-align: center;">
                 <tr>
                   <td height="30px;" >	NO</td>
                   <td>老人名称</td>
                   <td>年龄</td>
                    <td>性别</td>
                     <td>房间号</td>
                      <td>床位号</td>
                     <td>操作</td>

                 </tr>
                 <?php foreach ($lists as $k=>$v){ ?>
                 <tr>
                  <td height="30px;"><?php echo $v['id'] ?></td>
                  <td><?php echo $v['oname']; ?></td>
                  <td><?php echo $v['age'] ?></td>
                  <td><?php echo $v['sex'] ?></td>
                  <td><?php echo $v['roomid'] ?></td>
                      <td><?php echo $v['bedid'] ?></td>
                    <td>
                      <a href="javascript:dodelete('<?php echo $v["id"] ?>')">删除</a>
                        <a href="old_add.php?id=<?php echo $v["id"] ?>">编辑</a>
                    </td>
                 </tr>
                 <?php } ?>
               </table>
            </div>
            <div class="black2">
                <?php echo $pagehtml; ?>
                <!--<span class="disabled"> < </span><span class="current">1</span><a href="#?page=2">2</a><a href="#?page=3">3</a><a href="#?page=4">4</a><a href="#?page=5">5</a><a href="#?page=6">6</a><a href="#?page=7">7</a>...<a href="#?page=10">10</a><a href="#?page=11">11</a><a href="#?page=2"> > </a>-->
            </div>
    </div>

</div>
<script type="text/javascript" src="lib/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/jedate.min.js"></script>
<script>
    // jeDate({
    //     dateCell:"#starttime",
    //     format:"YYYY/MM/DD/ hh:mm",
    //     isTime:true
    // });

    // jeDate({
    //     dateCell:"#endtime",
    //     format:"YYYY/MM/DD/  hh:mm",
    //     isTime:true
    // })
    
    $('.black2 a').click(function(){
        var page = $(this).attr('_page');
//        alert(href);
        $('input[name=p]').val(page);
        $('form').submit();
    })

    function dodelete(oid){
      if(confirm('确定要删除当前信息？')){
        $.post(
            '',{op:'del',id:oid},
            function(data){
              alert(data);
              window.location.reload();
            }
          )
      }
    }
</script>
</body>
</html>