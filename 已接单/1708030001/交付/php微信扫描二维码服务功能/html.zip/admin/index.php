<?php

error_reporting(E_ALL);
set_time_limit(0);
header("Content-type:text/html;charset=utf-8");
define("SCRIPT_PATH",  dirname(__FILE__));
$year = date('Y');
session_start(); 
include("../common/mysql.php");
include("../common/function.php");



ini_set('date.timezone', 'Asia/Shanghai');  //设置时区

init_mysql();


$post = $_POST;

$where = '1=1 ';
if(!empty($post)){
    if(!empty($post['id']))  $where.=' and id="'.$post['id'].'"';
    if(!empty($post['catname']))  $where.=' and service_name="'.$post['catname'].'"';
    if(!empty($post['userid']))  $where.=' and userid='.$post['userid'];
    if(!empty($post['start_time']))  $where.=' and start_time >='.strtotime($post['start_time']);
    if(!empty($post['end_time']))  $where.=' and end_time <='.strtotime($post['end_time']);
}

$count = Mysql::findOne('select count(*) as count from tp_user_service where '.$where);
$total_rows = $count['count'];

$limit = 5;
$page = $_REQUEST['p']?$_REQUEST['p']:1;
$start = ($page-1)*5;

$sql='select * from tp_user_service where '.$where.' order by id desc limit '.$start.','.$limit;
$lists = Mysql::querytoarray($sql);


//$lists = Mysql::query($sql);

$users = Mysql::querytoarray('select * from tp_users order by id desc');
foreach ($users as $k=>$v){
    $u_arr[$v['id']] = $v['username'];
}

$pagehtml = get_page_html($total_rows,$page,$limit);

//var_dump($_SERVER);die();
function get_page_html($total_rows,$page=1,$limit=5){
    $total_page = ceil($total_rows/$limit);
    $html = '';
    if($page==1){
        $html .= '<span class="disabled"> &lt; </span><span class="current">1</span>';
    }else{
        $html .= '<a _page="'.($page-1).'"> &lt; </a><a _page="1">1</a>';
    }
    
    for($i=2;$i<=$total_page;$i++){
        if($page != $i){
            $html .= '<a _page="'.$i.'">'.$i.'</a>';
        }else{
            $html .= '<span class="current">'.$i.'</span>';
        }
        
    }
    
    
     if($page==$total_page){
        $html .= '<span class="disabled"> &gt; </span>';
    }else{
        $html .= '<a _page="'.($page+1).'">  &gt;  </a>';
    }
    
    return $html;
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/public.css">
    <link rel="stylesheet" type="text/css" href="css/information.css">
</head>
<body>
<div class="nrwrap">
    <div class="inner">
      
        <div class="nrbox">
              <div class="addjkda">
                  <form action="" method="POST">
            <div class="threecols">
             <span>
                        <label>NO:</label>
                        <input type="text" name="id" value="<?php echo $post['id'] ?>">
                    </span>
                     <span>
                        <label>工作名称：</label>
                        <input type="text" name="catname" value="<?php echo $post['catname']; ?>">
                    </span>
                     <span>
                        <label>工作人员：</label>
                      <select name="userid">
                          <option value='0'>请选择</option>
                          <?php foreach ($users as $user){ ?>
                           <option value="<?php echo $user['id'] ?>" <?php if($user['id']==$post['userid']) echo 'selected=true'; ?> ><?php echo $user['username'] ?></option>
                          <?php }?>
                       
                       
                      </select>
                    </span>
                     <span>
                        <label>老人姓名：</label>
                        <input type="text" name="aged_name" <?php echo $post['aged_name'] ?>>
                    </span>
                    <div style="padding-top: 15px;">
                    <span  >
                        <label>房间号：</label>
                        <input type="text" name="room_no"  <?php echo $post['room_no'] ?>>
                    </span>
                    <span>
                        <label>床位号：</label>
                        <input type="text" name="bed_no" <?php echo $post['bed_no'] ?>>
                    </span>
                    <span>
                        <label>开始时间：</label>
                         <input class="datainp" name="start_time" id="starttime" type="text" placeholder="" value="<?php echo $post['start_time'] ?>"   readonly>
                    </span><span>
                        <label>结束时间：</label> 
                    <input class="datainp" name="end_time" id="endtime" type="text" placeholder="" value="<?php echo $post['end_time'] ?>" style="width: 130px;" readonly>
                    
                    <input type="hidden" name="p" value="1" />
                    </span>
                </div>
                
            </div> <div class="jkdabtn">
                    <a href="javascript:$('form').submit()">搜索</a>
                
                    <a href="javascript:$('form').reset()">重置</a>
                </div>
                      </form>
          </div>
            <div class="addjkda">
              <table width="930" border="1" bordercolor=" #d2d2d2" cellspacing="0" style="text-align: center;">
                 <tr>
                   <td height="30px;" >	NO</td>
                   <td>工作人员</td>
                   <td>工作名称</td>
                    <td>老人姓名</td>
                     <td>房间号</td>
                      <td>床位号</td>
                       <td>开始时间</td>
                        <td>结束时间</td>

                 </tr>
                 <?php foreach ($lists as $k=>$v){ ?>
                 <tr>
                  <td height="30px;"><?php echo $v['id'] ?></td>
                  <td><?php echo $u_arr[$v['userid']]; ?></td>
                  <td><?php echo $v['service_name'] ?></td>
                  <td><?php echo $v['aged_name'] ?></td>
                  <td><?php echo $v['room_no'] ?></td>
                      <td><?php echo $v['bed_no'] ?></td>
                       <td><?php echo date('Y-m-d H:i:s',$v['start_time']) ?></td>
                        <td><?php echo date('Y-m-d H:i:s',$v['end_time']) ?></td>
                 </tr>
                 <?php } ?>
               </table>
            </div>
            <div class="black2">
                <?php echo $pagehtml; ?>
                <!--<span class="disabled"> < </span><span class="current">1</span><a href="#?page=2">2</a><a href="#?page=3">3</a><a href="#?page=4">4</a><a href="#?page=5">5</a><a href="#?page=6">6</a><a href="#?page=7">7</a>...<a href="#?page=10">10</a><a href="#?page=11">11</a><a href="#?page=2"> > </a>-->
            </div>
    </div>

</div>
<script type="text/javascript" src="lib/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/jedate.min.js"></script>
<script>
    jeDate({
        dateCell:"#starttime",
        format:"YYYY/MM/DD/ hh:mm",
        isTime:true
    });

    jeDate({
        dateCell:"#endtime",
        format:"YYYY/MM/DD/  hh:mm",
        isTime:true
    })
    
    $('.black2 a').click(function(){
        var page = $(this).attr('_page');
//        alert(href);
        $('input[name=p]').val(page);
        $('form').submit();
    })
</script>
</body>
</html>