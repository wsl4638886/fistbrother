/*
Navicat MySQL Data Transfer

Source Server         : phpstudy_local
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : tp5

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2017-08-09 23:19:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tp_details`
-- ----------------------------
DROP TABLE IF EXISTS `tp_details`;
CREATE TABLE `tp_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL,
  `oname` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `sex` varchar(2) NOT NULL,
  `roomid` int(11) NOT NULL,
  `bedid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tp_details
-- ----------------------------
INSERT INTO `tp_details` VALUES ('4', '1', '宋奶奶', '88', '女', '6', '2');
INSERT INTO `tp_details` VALUES ('5', '22', '宋奶奶', '88', '女', '6', '2');
INSERT INTO `tp_details` VALUES ('6', '23', '刘大爷', '79', '男', '3', '1');
INSERT INTO `tp_details` VALUES ('7', '24', '刘大爷', '79', '男', '3', '1');
INSERT INTO `tp_details` VALUES ('8', '25', '余奶奶', '79', '女', '6', '1');
INSERT INTO `tp_details` VALUES ('9', '26', '宋奶奶', '88', '女', '6', '2');
INSERT INTO `tp_details` VALUES ('10', '27', '宋奶奶', '88', '女', '6', '2');
INSERT INTO `tp_details` VALUES ('11', '28', '余奶奶', '79', '女', '6', '1');
INSERT INTO `tp_details` VALUES ('12', '29', '余奶奶', '79', '女', '6', '1');
INSERT INTO `tp_details` VALUES ('13', '30', '宋奶奶', '88', '女', '6', '2');

-- ----------------------------
-- Table structure for `tp_job`
-- ----------------------------
DROP TABLE IF EXISTS `tp_job`;
CREATE TABLE `tp_job` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `jname` char(10) NOT NULL,
  `nature` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tp_job
-- ----------------------------
INSERT INTO `tp_job` VALUES ('1', '送开水', '0');
INSERT INTO `tp_job` VALUES ('2', '洗衣服', '0');
INSERT INTO `tp_job` VALUES ('3', '送饭', '0');
INSERT INTO `tp_job` VALUES ('4', '做饭', '0');
INSERT INTO `tp_job` VALUES ('5', '扫地', '0');
INSERT INTO `tp_job` VALUES ('6', '剪指甲', '0');
INSERT INTO `tp_job` VALUES ('7', '理发', '0');
INSERT INTO `tp_job` VALUES ('8', '聊天', '0');
INSERT INTO `tp_job` VALUES ('9', '散步', '0');
INSERT INTO `tp_job` VALUES ('10', '清洁', '0');

-- ----------------------------
-- Table structure for `tp_old`
-- ----------------------------
DROP TABLE IF EXISTS `tp_old`;
CREATE TABLE `tp_old` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oname` varchar(11) CHARACTER SET utf8 NOT NULL,
  `age` int(11) NOT NULL,
  `sex` varchar(3) CHARACTER SET utf8 NOT NULL,
  `roomid` int(11) NOT NULL,
  `bedid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tp_old
-- ----------------------------
INSERT INTO `tp_old` VALUES ('1', '宋奶奶', '88', '女', '6', '2');
INSERT INTO `tp_old` VALUES ('2', '余奶奶', '79', '女', '6', '1');

-- ----------------------------
-- Table structure for `tp_users`
-- ----------------------------
DROP TABLE IF EXISTS `tp_users`;
CREATE TABLE `tp_users` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `avatar` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `mobile` char(11) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tp_users
-- ----------------------------
INSERT INTO `tp_users` VALUES ('1', '张三', '/uploads/images/0.jpg', '15950452241');
INSERT INTO `tp_users` VALUES ('2', '李四', '/uploads/images/avatar.jpg', '15950555555');
INSERT INTO `tp_users` VALUES ('3', '卡普', '/uploads/images/timg.jpg', '15999999999');
INSERT INTO `tp_users` VALUES ('4', 'luffy', '/uploads/images/timg_1.jpg', '15874785985');
INSERT INTO `tp_users` VALUES ('5', 'nami', '/uploads/images/timg_2.jpg', '15998574856');

-- ----------------------------
-- Table structure for `tp_user_service`
-- ----------------------------
DROP TABLE IF EXISTS `tp_user_service`;
CREATE TABLE `tp_user_service` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `service_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tp_user_service
-- ----------------------------
INSERT INTO `tp_user_service` VALUES ('1', '1', '送饭', '1501745696', '1501745955');
INSERT INTO `tp_user_service` VALUES ('2', '1', '送饭', '1501746085', '1501746184');
INSERT INTO `tp_user_service` VALUES ('3', '1', '送饭', '1501746194', '1501746218');
INSERT INTO `tp_user_service` VALUES ('4', '1', '送饭', '1501746220', '1501746856');
INSERT INTO `tp_user_service` VALUES ('5', '1', '送饭', '1501746900', '1501746906');
INSERT INTO `tp_user_service` VALUES ('6', '2', '送饭', '1501748513', '1501748519');
INSERT INTO `tp_user_service` VALUES ('7', '4', '送饭', '1501767767', '1501767790');
INSERT INTO `tp_user_service` VALUES ('8', '4', '送饭', '1501767795', '1501767819');
INSERT INTO `tp_user_service` VALUES ('9', '5', '送饭', '1501767825', '1501767873');
INSERT INTO `tp_user_service` VALUES ('10', '3', '送饭', '1501767899', '1501767944');
INSERT INTO `tp_user_service` VALUES ('11', '3', '送饭', '1501767951', '1501771374');
INSERT INTO `tp_user_service` VALUES ('12', '2', '拖地', '1502024013', '1502024223');
INSERT INTO `tp_user_service` VALUES ('17', '1', '拖地', '1502030181', '1502030194');
INSERT INTO `tp_user_service` VALUES ('18', '1', '烧饭', '1502030186', '1502030191');
INSERT INTO `tp_user_service` VALUES ('19', '1', '烧饭', '1502033572', '1502033585');
INSERT INTO `tp_user_service` VALUES ('20', '1', '拖地', '1502034010', '1502034013');
INSERT INTO `tp_user_service` VALUES ('21', '1', '扫地', '1502289555', '1502289624');
INSERT INTO `tp_user_service` VALUES ('22', '1', '扫地', '1502289638', '1502289715');
INSERT INTO `tp_user_service` VALUES ('23', '1', '扫地', '1502289737', '1502289739');
INSERT INTO `tp_user_service` VALUES ('24', '3', '扫地', '1502289746', '1502289758');
INSERT INTO `tp_user_service` VALUES ('25', '3', '扫地', '1502289799', '1502289801');
INSERT INTO `tp_user_service` VALUES ('26', '1', '扫地', '1502289839', '1502289847');
INSERT INTO `tp_user_service` VALUES ('29', '1', '扫地', '1502290045', '1502290052');
INSERT INTO `tp_user_service` VALUES ('30', '3', '扫地', '1502290055', '1502290058');
