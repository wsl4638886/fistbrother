package com.hzyc.filmsystem.dialogs;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import com.hzyc.filmsystem.normals.SWTResourceManager;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import com.hzyc.filmsystem.normals.ResourceManager;
import org.eclipse.swt.widgets.Link;

public class FilmInformationDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	protected String movie_id;
	private Table table;
	private List<Map<String,Object>>list=new LinkedList<Map<String,Object>>();
	private JDBCUtil ju=new JDBCUtil();

	
	public FilmInformationDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	
	public Object open(String id) {
		this.movie_id=id;
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	
	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		shell.setSize(822, 731);
		shell.setText("\u5F71\u7247\u8BE6\u60C5");
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBounds(0, 0, 816, 703);
		
		table = new Table(composite, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(39, 62, 733, 450);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(126);
		tableColumn.setText("\u5F71\u7247\u540D\u79F0");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(68);
		tableColumn_1.setText("\u56FD\u5BB6");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(100);
		tableColumn_2.setText("\u5BFC\u6F14");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(94);
		tableColumn_3.setText("\u7247\u957F");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(66);
		tableColumn_4.setText("\u8BED\u8A00");
		
		TableColumn tableColumn_5 = new TableColumn(table, SWT.NONE);
		tableColumn_5.setWidth(128);
		tableColumn_5.setText("\u4E0A\u7EBF\u65F6\u95F4");
		
		TableColumn tableColumn_6 = new TableColumn(table, SWT.NONE);
		tableColumn_6.setWidth(121);
		tableColumn_6.setText("\u4E0B\u7EBF\u65F6\u95F4");
		
		Button button = new Button(composite, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		button.setBounds(569, 21, 66, 27);
		button.setText("\u5173\u95ED");
		
		Link link_1 = new Link(composite, SWT.NONE);
		link_1.addSelectionListener(new SelectionAdapter() {
			//��һҳ
			public void widgetSelected(SelectionEvent e) {
			}
		});
		
		link_1.setBounds(116, 544, 77, 33);
		link_1.setText("<a>\u4E0B\u4E00\u9875</a>");
		
		Link link = new Link(composite, 0);
		link.addSelectionListener(new SelectionAdapter() {
			//��ҳ
			public void widgetSelected(SelectionEvent e) {
			}
		});
		link.setText("<a>\u9996\u9875</a>");
		link.setBounds(49, 544, 60, 33);
		
		Link link_2 = new Link(composite, 0);
		link_2.addSelectionListener(new SelectionAdapter() {
			//��һҳ
			public void widgetSelected(SelectionEvent e) {
			}
		});
		link_2.setText("<a>\u4E0A\u4E00\u9875</a>");
		link_2.setBounds(213, 544, 77, 33);
		
		Link link_3 = new Link(composite, 0);
		link_3.addSelectionListener(new SelectionAdapter() {
			//βҳ
			public void widgetSelected(SelectionEvent e) {
			}
		});
		link_3.setText("<a>\u5C3E\u9875</a>");
		link_3.setBounds(309, 544, 77, 33);
		
		
		
		list=ju.query("select * from movie_info where id="+movie_id );
		for(Map<String,Object>map:list){
			String movie_name=map.get("movie_name").toString();
			String country=map.get("country").toString();
			String director=map.get("director").toString();
			String movie_long=map.get("movie_long").toString();
			String language=map.get("language").toString();
			String online=map.get("online_date").toString();
			String downline_date=map.get("downline_date").toString();
			String [] s ={movie_name,country,director,movie_long,language,online,downline_date};
			TableItem tableItem = new TableItem(table, SWT.NONE);
			tableItem.setText(s);
		}

	}

}
