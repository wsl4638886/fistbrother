package com.hzyc.filmsystem.dialogs;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import com.hzyc.filmsystem.normals.SWTResourceManager;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.TableColumn;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Scale;
import com.hzyc.filmsystem.normals.ResourceManager;

public class StatisticsSellDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Table table;
	private Text text;
	private Text txtss;
	private Text text_1;
	private JDBCUtil ju;
	private int year;
	private String sum;
	private Text text_2;
	private Text text_3;
	private Text text_4;
	private Text text_5;
	private Text text_6;

	public StatisticsSellDialog(Shell parent, int style) {
		super(parent, style);
		setText("ͳ�����۶�");
	}

	public Object open(int year,String sum) {
		this.year=year;
		this.sum=sum;
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		shell.setSize(1043, 499);
		shell.setText(getText());
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackgroundImage(ResourceManager.getPluginImage("cinema.management", "images/lan32_\u526F\u672Coo.jpg"));
		composite.setBackgroundMode(SWT.INDETERMINATE);
		composite.setBounds(0, 0, 1037, 471);
		
		table = new Table(composite, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(42, 140, 310, 284);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(63);
		tableColumn.setText("\u6708\u4EFD");
		
		TableColumn tblclmns = new TableColumn(table, SWT.NONE);
		tblclmns.setWidth(100);
		tblclmns.setText("\u9500\u552E\u989DS/\u5143");
		
		TableColumn tblclmnSs = new TableColumn(table, SWT.NONE);
		tblclmnSs.setWidth(126);
		tblclmnSs.setText("S:SUM(%)");
		
		
		text = new Text(composite, SWT.NONE);
		text.setEnabled(false);
		text.setBounds(53, 29, 43, 26);
		text.setText(String.valueOf(year));
		
		Label lblNewLabel = new Label(composite, SWT.NONE);
		lblNewLabel.setBounds(102, 29, 420, 26);
		lblNewLabel.setText("\u5E74\u6BCF\u4E2A\u6708\u7684\u9500\u552E\u989D\u4EE5\u53CA\u5360\u5168\u5E74\u603B\u9500\u552E\u989D\u7684\u6BD4\u4F8B");
		
		txtss = new Text(composite, SWT.NONE);
		txtss.setText("\u6CE8\uFF1A\u9500\u552E\u989D\uFF1AS\uFF0C \u603B\u9500\u552E\u989D\uFF1ASUM");
		txtss.setBounds(63, 62, 277, 23);
		
		Label label = new Label(composite, SWT.NONE);
		label.setBounds(42, 91, 82, 23);
		label.setText("\u603B\u9500\u552E\u989D\uFF1A");
		
		text_1 = new Text(composite, SWT.NONE);
		text_1.setEnabled(false);
		text_1.setBounds(130, 91, 120, 23);
		text_1.setText(sum+"Ԫ");
		
		Composite composite_1 = new Composite(composite, SWT.NONE);
		composite_1.setBounds(366, 108, 661, 316);
		
		
			Label label_1 = new Label(composite_1, SWT.SEPARATOR | SWT.VERTICAL);
			label_1.setBackground(SWTResourceManager.getColor(255, 0, 0));
			label_1.setBounds(25, 28, 2, 231);
			
			Label label_2 = new Label(composite_1, SWT.SEPARATOR | SWT.HORIZONTAL);
			label_2.setBounds(26, 257, 571, 2);
			
			text_2 = new Text(composite_1, SWT.NONE);
			text_2.setEnabled(false);
			text_2.setForeground(SWTResourceManager.getColor(169, 169, 169));
			text_2.setText("     ^");
			text_2.setBounds(0, 16, 34, 23);
			
			text_3 = new Text(composite_1, SWT.NONE);
			text_3.setEnabled(false);
			text_3.setText("\r\n>");
			text_3.setBounds(590, 242, 25, 23);
			
			text_4 = new Text(composite_1, SWT.NONE);
			text_4.setEnabled(false);
			text_4.setText("\u6BD4\u4F8B%");
			text_4.setBounds(29, 0, 45, 23);
			
			text_5 = new Text(composite_1, SWT.MULTI);
			text_5.setEnabled(false);
			text_5.setText("\r\n100\r\n\r\n90\r\n\r\n80\r\n\r\n70\r\n\r\n60\r\n\r\n50\r\n\r\n40\r\n\r\n30\r\n\r\n20\r\n\r\n10\r\n\r\n0");
			text_5.setBounds(2, 28, 17, 256);
			
			text_6 = new Text(composite_1, SWT.NONE);
			text_6.setEnabled(false);
			text_6.setText("\u6708\u4EFD");
			text_6.setBounds(606, 261, 45, 23);
			
			Label lblNewLabel_1 = new Label(composite_1, SWT.NONE);
			lblNewLabel_1.setBounds(45, 265, 29, 41);
			lblNewLabel_1.setText("  \u4E00\r\n  \u6708");
			
			Label label_3 = new Label(composite_1, SWT.NONE);
			label_3.setText("  \u4E8C\r\n  \u6708");
			label_3.setBounds(94, 265, 29, 41);
			
			Label label_4 = new Label(composite_1, SWT.NONE);
			label_4.setText("  \u4E09\r\n  \u6708");
			label_4.setBounds(138, 265, 29, 41);
			
			Label label_5 = new Label(composite_1, SWT.NONE);
			label_5.setText("  \u56DB\r\n  \u6708");
			label_5.setBounds(185, 265, 29, 41);
			
			Label label_6 = new Label(composite_1, SWT.NONE);
			label_6.setText("  \u4E94\r\n  \u6708");
			label_6.setBounds(233, 265, 29, 41);
			
			Label label_7 = new Label(composite_1, SWT.NONE);
			label_7.setText("  \u516D\r\n  \u6708");
			label_7.setBounds(275, 265, 29, 41);
			
			Label label_8 = new Label(composite_1, SWT.NONE);
			label_8.setText("  \u4E03\r\n  \u6708");
			label_8.setBounds(321, 265, 29, 41);
			
			Label label_9 = new Label(composite_1, SWT.NONE);
			label_9.setText("  \u516B\r\n  \u6708");
			label_9.setBounds(367, 265, 29, 41);
			
			Label label_10 = new Label(composite_1, SWT.NONE);
			label_10.setText("  \u4E5D\r\n  \u6708");
			label_10.setBounds(414, 265, 29, 41);
			
			Label label_11 = new Label(composite_1, SWT.NONE);
			label_11.setText("  \u5341\r\n  \u6708");
			label_11.setBounds(465, 265, 29, 41);
			
			Label label_12 = new Label(composite_1, SWT.NONE);
			label_12.setText(" \u5341 \u4E00\r\n  \u6708");
			label_12.setBounds(511, 265, 29, 41);
			
			Label label_13 = new Label(composite_1, SWT.NONE);
			label_13.setText("  \u5341\u4E8C\r\n  \u6708");
			label_13.setBounds(546, 265, 39, 41);
		
		
		for(int i=1;i<13;i++){
			ProgressBar progressBar = new ProgressBar(composite_1, SWT.VERTICAL);
			progressBar.setBounds(i*45, 45, 29, 214);
			ju=new JDBCUtil();
			String j=i>9?String.valueOf(i):"0"+i;
			String sql="SELECT price FROM ticket_info WHERE DATE LIKE '"+year+"-"+j+"-%'";
			List<Map<String,Object>>list=ju.query(sql);
			double sums=0;
			for(Map<String,Object>map:list){
				sums+=Double.parseDouble(map.get("price").toString());
			}
			
			double p=sums/Double.parseDouble(sum)*100;
		    int a = (int) Math.round(p);//ȡ��
		    progressBar.setSelection(a);
		    TableItem tableItem = new TableItem(table, SWT.NONE);
	        String[]str={j,String.valueOf(sums),a+""};
		    tableItem.setText(str);
			
		}

	}
}
