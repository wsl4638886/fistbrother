package com.hzyc.filmsystem.editors;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import com.hzyc.filmsystem.dialogs.FilmUpdateDialog;
import com.hzyc.filmsystem.normals.ResourceManager;
import com.hzyc.filmsystem.normals.SWTResourceManager;

public class FilmUpdateEditor extends EditorPart {

	public static final String ID = "com.hzyc.filmsystem.editors.FilmUpdateEditor"; //$NON-NLS-1$

	private Table table;
	private JDBCUtil ju=new JDBCUtil();
	private int page=1;
	private int pageSize=10;
	private List<Map<String,Object>>list=new LinkedList<Map<String,Object>>();

	public FilmUpdateEditor() {
	}

	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.BORDER);
		container.setBackgroundMode(SWT.INDETERMINATE);
		
		final Composite composite = new Composite(container, SWT.NONE);
		composite.setBounds(10, 28, 877, 527);
		
		Label label = new Label(composite, SWT.BORDER);
		label.setFont(SWTResourceManager.getFont("΢���ź�", 10, SWT.NORMAL));
		label.setBounds(10, 10, 68, 24);
		label.setText("\u7535\u5F71\u4FE1\u606F:");
		
		table = new Table(composite, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(10, 41, 814, 360);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tblclmnId = new TableColumn(table, SWT.NONE);
		tblclmnId.setWidth(40);
		tblclmnId.setText("id");
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(113);
		tableColumn.setText("\u7535\u5F71\u540D\u79F0");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(81);
		tableColumn_1.setText("\u56FD\u5BB6");
		
		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(100);
		tblclmnNewColumn.setText("\u5BFC\u6F14");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(77);
		tableColumn_2.setText("\u7247\u957F");
		
		TableColumn tblclmnNewColumn_1 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_1.setWidth(67);
		tblclmnNewColumn_1.setText("\u8BED\u8A00");
		
		TableColumn tblclmnNewColumn_2 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_2.setWidth(100);
		tblclmnNewColumn_2.setText("\u5185\u5BB9\u7B80\u4ECB");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(100);
		tableColumn_4.setText("\u4E0A\u7EBF\u65F6\u95F4");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(100);
		tableColumn_3.setText("\u4E0B\u7EBF\u65F6\u95F4");
		
		
		
		
		
		Menu menu = new Menu(table);
		table.setMenu(menu);
		
		MenuItem menuItem = new MenuItem(menu, SWT.NONE);
		menuItem.addSelectionListener(new SelectionAdapter() {
			
			
			public void widgetSelected(SelectionEvent e) {
				//ӰƬ�޸�
               TableItem[]items=table.getSelection();
				for(TableItem item:items){
					FilmUpdateDialog update=new FilmUpdateDialog(composite.getShell(),SWT.NONE);
					update.open(item.getText(0));
				}
				
			}
		});
		menuItem.setText("\u4FE1\u606F\u4FEE\u6539");
		
		Link link_4 = new Link(composite, SWT.NONE);
		link_4.addSelectionListener(new SelectionAdapter() {
			//ˢ��
			public void widgetSelected(SelectionEvent e) {
				table.removeAll();
				list=ju.query("select * from movie_info limit "+(page-1)*pageSize+","+pageSize);       
				for(Map<String,Object>map:list){
					TableItem tableItem = new TableItem(table, SWT.NONE);
					String[]s={map.get("id").toString(),map.get("movie_name").toString(),map.get("country").toString(),map.get("director").toString(),map.get("movie_long").toString(),map.get("language").toString(),
							      map.get("content_produce").toString(),map.get("online_date").toString(),map.get("downline_date").toString()};
					tableItem.setText(s);
				}
			}
		});
		link_4.setBounds(664, 17, 44, 17);
		link_4.setText("<a>\u5237\u65B0</a>");
		
		list=ju.query("select * from movie_info limit "+(page-1)*pageSize+","+pageSize);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String[]s={map.get("id").toString(),map.get("movie_name").toString(),map.get("country").toString(),map.get("director").toString(),map.get("movie_long").toString(),map.get("language").toString(),
					      map.get("content_produce").toString(),map.get("online_date").toString(),map.get("downline_date").toString()};
			tableItem.setText(s);
		}
		

	}

	public void setFocus() {
	}

	public void doSave(IProgressMonitor monitor) {
	}

	public void doSaveAs() {
	}

	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		this.setSite(site);
		this.setInput(input);
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isSaveAsAllowed() {
		return false;
	}
	public void query(){
		table.removeAll();
		list=ju.query("select * from movie_info limit "+(page-1)*pageSize+","+pageSize);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String[]s={map.get("id").toString(),map.get("movie_name").toString(),map.get("country").toString(),map.get("director").toString(),map.get("movie_long").toString(),map.get("language").toString(),
					      map.get("content_produce").toString(),map.get("online_date").toString(),map.get("downline_date").toString()};
			tableItem.setText(s);
		}
	}
}
