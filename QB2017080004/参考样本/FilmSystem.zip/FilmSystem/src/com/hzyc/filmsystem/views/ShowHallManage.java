package com.hzyc.filmsystem.views;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.ExpandBar;
import org.eclipse.swt.widgets.ExpandItem;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;
import com.hzyc.filmsystem.normals.SWTResourceManager;

import com.hzyc.filmsystem.platform.Application;
import com.hzyc.filmsystem.dialogs.CinemaManagerment;
import com.hzyc.filmsystem.dialogs.QuestionDialog;
import com.hzyc.filmsystem.dialogs.ShowHallDeleteDialog;
import com.hzyc.filmsystem.dialogs.ShowHallDialog;
import com.hzyc.filmsystem.editors.ShowRoomAddEditor;
import com.hzyc.filmsystem.editors.ShowRoomUpdateEditor;
import com.hzyc.filmsystem.input.MyInput;

public class ShowHallManage extends ViewPart {

	public static final String ID = "com.hzyc.cinema.views.ShowHallManage"; //$NON-NLS-1$

	public ShowHallManage() {
	}

	/**
	 * Create contents of the view part.
	 * @param parent    ��ӳ����������
	 */
	@Override
	public void createPartControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		
		
		ExpandBar expandBar = new ExpandBar(container, SWT.NONE);
		expandBar.setFont(SWTResourceManager.getFont("����", 18, SWT.BOLD));
		expandBar.setBounds(97, 144, 204, 282);
		expandBar.setBackgroundMode(SWT.INDETERMINATE);
		
		ExpandItem expandItem = new ExpandItem(expandBar, SWT.NONE);
		expandItem.setExpanded(true);
		expandItem.setText("\u653E\u6620\u5385\u7BA1\u7406");
		
		final Composite composite = new Composite(expandBar, SWT.NONE);
		expandItem.setControl(composite);
		
		Button button = new Button(composite, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			//��ӳ����Ϣ����
			MyInput input=new MyInput();
			public void widgetSelected(SelectionEvent e) {
				input.setName("");
				input.setToolTipText("��ӳ����Ϣ����");
				try {
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input,ShowRoomAddEditor.ID);
				} catch (PartInitException e1) {
					e1.printStackTrace();
				}
			}
		});
		button.setFont(SWTResourceManager.getFont("����", 15, SWT.NORMAL));
		button.setBounds(10, 10, 163, 42);
		button.setText("\u653E\u6620\u5385\u4FE1\u606F\u6DFB\u52A0");
		
		Button button_1 = new Button(composite, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			//��ӳ����Ϣ�޸�
			MyInput input=new MyInput();
			public void widgetSelected(SelectionEvent e) {
				input.setName("");
				input.setToolTipText("��ӳ����Ϣ�޸�");
				try {
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input,ShowRoomUpdateEditor.ID);
				} catch (PartInitException e1) {
					e1.printStackTrace();
				}
			}
		});
		button_1.setText("\u653E\u6620\u5385\u4FE1\u606F\u4FEE\u6539");
		button_1.setFont(SWTResourceManager.getFont("����", 15, SWT.NORMAL));
		button_1.setBounds(10, 68, 163, 42);
		
		Button button_2 = new Button(composite, SWT.NONE);
		button_2.addSelectionListener(new SelectionAdapter() {
			//��ӳ����Ϣɾ��
			public void widgetSelected(SelectionEvent e) {
				ShowHallDeleteDialog ahdd=new ShowHallDeleteDialog(composite.getShell(), SWT.NONE);
				ahdd.open();
			}
		});
		button_2.setText("\u653E\u6620\u5385\u4FE1\u606F\u5220\u9664");
		button_2.setFont(SWTResourceManager.getFont("����", 15, SWT.NORMAL));
		button_2.setBounds(10, 123, 163, 42);
		
		Button button_3 = new Button(composite, SWT.NONE);
		button_3.addSelectionListener(new SelectionAdapter() {
			//��ӳ����Ϣ��ѯ
			public void widgetSelected(SelectionEvent e) {
				ShowHallDialog sd=new ShowHallDialog(container.getShell(), SWT.NONE);
				sd.open();
			}
		});
		button_3.setText("\u653E\u6620\u5385\u4FE1\u606F\u67E5\u8BE2");
		button_3.setFont(SWTResourceManager.getFont("����", 15, SWT.NORMAL));
		button_3.setBounds(10, 176, 163, 42);
		expandItem.setHeight(230);
		
		Button button_4 = new Button(container, SWT.NONE);
		button_4.addSelectionListener(new SelectionAdapter() {
			//�˳�@Override
			public void widgetSelected(SelectionEvent e) {
				QuestionDialog qd = new QuestionDialog(container.getShell(), SWT.NONE);
				String message="��ȷ��Ҫ�˳��ý��棿";
				String result=qd.open(message).toString();
				if(result.equals("ok")){
					Application a=new Application();
				    a.stop();
				    try {
						a.start(null);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		button_4.setFont(SWTResourceManager.getFont("����", 15, SWT.BOLD));
		button_4.setBounds(50, 595, 91, 39);
		button_4.setText("\u9000 \u51FA");

		createActions();
		initializeToolBar();
		initializeMenu();
	}

	
	private void createActions() {
		// Create the actions
	}

	
	private void initializeToolBar() {
		IToolBarManager toolbarManager = getViewSite().getActionBars()
				.getToolBarManager();
	}

	
	private void initializeMenu() {
		IMenuManager menuManager = getViewSite().getActionBars()
				.getMenuManager();
	}

	@Override
	public void setFocus() {
		// Set the focus
	}
}
