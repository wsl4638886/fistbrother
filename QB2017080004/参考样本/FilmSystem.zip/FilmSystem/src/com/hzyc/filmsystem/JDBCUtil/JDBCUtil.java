package com.hzyc.filmsystem.JDBCUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class JDBCUtil {
	private Connection conn=null;
	private Statement stmt=null;
	private ResultSet rs=null;
	//Connection conn = DriverManager.getConnection("jdbc:mysql://49.140.97.246:3308/tf39", "root", "mysql");
	private String url="jdbc:mysql://localhost:3308/tf39";
	private String user="root";
	private String password="mysql";
	//��������
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	//��ȡ����
	public Connection getConn(){
		try {
			conn=DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
			conn=null;
		}
		return conn;
		
	}
	//��ȡ������
	public int update(String sql){
		try {
			stmt=getConn().createStatement();
			return stmt.executeUpdate(sql);//����
		} catch (SQLException e) {
			e.printStackTrace();
			return -1;
		}finally{
			release();
		}
	}
	
	public List<Map<String,Object>> query(String sql){
		List<Map<String,Object>> list=new LinkedList<Map<String,Object>>();
		try {
			stmt=getConn().createStatement();
			rs=stmt.executeQuery(sql);
			ResultSetMetaData rsmd=rs.getMetaData();
			int count=rsmd.getColumnCount();
			while(rs.next()){
				Map<String,Object> map=new HashMap<String,Object>();
				for(int i=0;i<count;i++){
					String key=rsmd.getColumnName(i+1);
					Object value=rs.getObject(key);
					map.put(key, value);
				}
				list.add(map);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}finally{
			release();
		}
		return list;
	}
	
	public void release(){
		if(rs!=null){
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(stmt!=null){
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	

}
