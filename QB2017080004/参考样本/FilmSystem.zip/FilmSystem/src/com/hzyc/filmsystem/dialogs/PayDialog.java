package com.hzyc.filmsystem.dialogs;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.TraverseEvent;
import org.eclipse.swt.events.TraverseListener;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import com.hzyc.filmsystem.normals.SWTResourceManager;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;

public class PayDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text text;
	private Text text_1;
	private String price;
	private List<String>seat=new ArrayList<String>();//��λλ��
	private List<String>code=new LinkedList<String>();//code ���α���
	private String show_id;
	private Label lblNewLabel_1;
	private Text text_3;
	private JDBCUtil ju;
	private MessageBox box;

	public PayDialog(Shell parent, int style) {
		super(parent, style);
		setText("��Ʊ");
	}

	public Object open(String price,List<String>code,List<String>seat,String show_id) {
		this.price=price;
		for(int i=0;i<code.size();i++){
			this.code.add(code.get(i));
		}
		this.seat=seat;
		this.show_id=show_id;
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		shell.setSize(544, 375);
		shell.setText(getText());
		
		final Composite composite = new Composite(shell, SWT.NONE);
		composite.setBounds(0, 10, 538, 337);
		
		Label lblNewLabel = new Label(composite, SWT.NONE);
		lblNewLabel.setForeground(org.eclipse.wb.swt.SWTResourceManager.getColor(0, 0, 0));
		lblNewLabel.setBounds(36, 80, 80, 31);
		lblNewLabel.setText("\u6240\u9700\u91D1\u989D\uFF1A");
		composite.setBackgroundMode(SWT.INDETERMINATE);
		
		text = new Text(composite, SWT.READ_ONLY);
		text.setForeground(SWTResourceManager.getColor(255, 140, 0));
		text.setBounds(134, 80, 100, 23);
		
		Label label = new Label(composite, SWT.NONE);
		label.setForeground(org.eclipse.wb.swt.SWTResourceManager.getColor(0, 0, 0));
		label.setBounds(36, 136, 80, 31);
		label.setText("\u652F\u4ED8\u91D1\u989D\uFF1A");
		
		text_1 = new Text(composite, SWT.BORDER);
		text_1.addTraverseListener(new TraverseListener() {
			public void keyTraversed(TraverseEvent arg0) {
				double change=Double.parseDouble(text_1.getText())-Double.parseDouble(text.getText());
				if(change<0){
					 box=new MessageBox(shell,SWT.ICON_INFORMATION);
					 box.setText("��ʾ��Ϣ");
					 box.setMessage("���Ľ���");
					 box.open();
				}else{
					String money=String.valueOf(change);
					text_3.setText(money);
				}
			}
		});
		
		text_1.setForeground(SWTResourceManager.getColor(255, 140, 0));
		text_1.setBounds(135, 136, 99, 23);
		
		text_3 = new Text(composite, SWT.BORDER);
		text_3.addFocusListener(new FocusAdapter() {
			//��ʾ����
			public void focusGained(FocusEvent e) {
				double change=Double.parseDouble(text_1.getText())-Double.parseDouble(text.getText());
				String money=String.valueOf(change);
				text_3.setText(money);
			}
		});
		
		text_3.setBounds(134, 189, 100, 23);
		
		Button button = new Button(composite, SWT.NONE);
		
		button.addSelectionListener(new SelectionAdapter() {
			//ȷ��֧��
			public void widgetSelected(SelectionEvent e) {
				ju= new JDBCUtil();
				for(int j=0;j<code.size();j++){
					String ticket_code=code.get(j);
					List<Map<String,Object>>list=ju.query("select * from show_plan where show_id="+show_id);
					for(Map<String,Object>map:list){
						String movie_id=map.get("film_id").toString();
						String date = map.get("show_date").toString();
						String start_time=map.get("start_time").toString();
						String hall_name=map.get("hall_name").toString();
						String price=map.get("ticket_price").toString();
						String seat_position=seat.get(j);
						String sql="insert into ticket_info(bar_code_num,movie_id,date,start_time,hall_name,seat_position,price,show_id) values" +
								"('"+ticket_code+"',"+movie_id+",'"+date+"','"+start_time+"','"+hall_name+"','"+seat_position+"',"+price+","+show_id+")";
						ju.update(sql);
					}
				}
				
				/**����Ʊ*/
				for(int i=0;i<seat.size();i++){
					PuySuccessfulDialog psfd=new PuySuccessfulDialog(composite.getShell(), SWT.NONE);
					psfd.open(code.get(i),show_id);	
				}
				shell.dispose();
				
			}
		});
		button.setBounds(393, 189, 113, 59);
		button.setText("\u786E\u5B9A\u652F\u4ED8");
		
		text.setText(price);
		text_1.forceFocus();
		lblNewLabel_1 = new Label(composite, SWT.NONE);
		lblNewLabel_1.setForeground(org.eclipse.wb.swt.SWTResourceManager.getColor(0, 0, 0));
		lblNewLabel_1.setBounds(36, 189, 80, 23);
		lblNewLabel_1.setText("\u627E      \u96F6\uFF1A");
		
		

	}
}
