package com.hzyc.filmsystem.views;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import com.hzyc.filmsystem.dialogs.FilmContentProduceDialog;
import com.hzyc.filmsystem.dialogs.PayDialog;
import com.hzyc.filmsystem.dialogs.QuestionDialog;
import com.hzyc.filmsystem.dialogs.SearchDialog;
import com.hzyc.filmsystem.normals.ResourceManager;
import com.hzyc.filmsystem.normals.SWTResourceManager;
import com.hzyc.filmsystem.platform.Application;
import com.hzyc.filmsystem.views.BuyTicketSystemView;

public class BuyTicketSystemView extends ViewPart {

	public static final String ID = "com.hzyc.filmsystem.views.BuyTicketSystemView"; //$NON-NLS-1$
	private Text text;
	private JDBCUtil ju=new JDBCUtil();
	private Text text_4;
	private String s_date;
	private String e_date;
	private List<String>codes=new LinkedList<String>();
	private String film_id;
	private double price_sum;
	private Table table;
	private Table table_1;
	private String price;
	public static String close;

	public BuyTicketSystemView() {
	}

	public void createPartControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.BORDER | SWT.NO_REDRAW_RESIZE);
		container.setBackgroundImage(ResourceManager.getPluginImage("cinema.management", "images/lan2_\u526F\u672C.jpg"));
		container.setBackgroundMode(SWT.INDETERMINATE);
		container.setSize(1204, 900);
		{
			Label label = new Label(container, SWT.NONE);
			label.setBounds(22, 41, 126, 24);
			label.setText("\u9009\u62E9\u65E5\u671F\uFF1A");
		}
		
		    final DateTime dateTime = new DateTime(container, SWT.BORDER | SWT.DROP_DOWN);
			dateTime.setBounds(171, 41, 119, 24);
		
		{
			Label lblid = new Label(container, SWT.NONE);
			lblid.setBounds(37, 256, 145, 25);
			lblid.setText("\u9009\u62E9\u5F71\u7247 id\uFF1A");
		}
		{
			text = new Text(container, SWT.BORDER | SWT.READ_ONLY);//ӰƬid
			text.setBounds(188, 256, 70, 24);
			
		}
		
		Label lblNewLabel_1 = new Label(container, SWT.NONE);
		lblNewLabel_1.setImage(SWTResourceManager.getImage(BuyTicketSystemView.class, "/cn/com/weizhen/dialog/http_imgload (5)_\u526F\u672C.jpg"));
		lblNewLabel_1.setBounds(1095, 0, 2, 705);
		
		Label label = new Label(container, SWT.NONE);
		label.setBounds(348, 43, 165, 35);
		label.setText("\u67E5\u770B\u8FD1\u671F\u653E\u6620\u7535\u5F71\u60C5\u51B5\uFF1A");
		
		Button button = new Button(container, SWT.BORDER | SWT.ARROW | SWT.RIGHT);
		button.addSelectionListener(new SelectionAdapter() {
			/*�鿴���ڷ�ӳ��Ӱ*/
			public void widgetSelected(SelectionEvent e) {
				table.removeAll();
				int year=dateTime.getYear();
				int month=dateTime.getMonth()+1;
				int day=dateTime.getDay();
				SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			    String times=year+"-"+month+"-"+day;
			    String time_2s=year+"-"+month+"-"+(day+2);
			     try {
					Date time=sdf.parse(times);
					 s_date=sdf.format(time);
					Date time_2=sdf.parse(time_2s);
					e_date=sdf.format(time_2);
				} catch (ParseException e1) {
					e1.printStackTrace();
				}
			    
				String sql="select id,movie_name,director,movie_long,content_produce from movie_info where id in" +
			      "(select film_id from show_plan where show_date between '"+s_date+"' and '"+e_date+"')";
                     System.out.println(sql);
                     List<Map<String,Object>>list=ju.query(sql);
	                 for(Map<String,Object>map:list){
	                    TableItem tableItem = new TableItem(table, SWT.NONE);
		                String []s={map.get("id").toString(),map.get("movie_name").toString(),map.get("director").toString(),map.get("movie_long").toString()};
		                tableItem.setText(s);
	                 }
			}
		});
		button.setBounds(519, 46, 27, 17);
		button.setText("\u786E\u5B9A");
		
		Label label_1 = new Label(container, SWT.NONE);
		label_1.setBounds(271, 258, 138, 23);
		label_1.setText("\u67E5\u770B\u8BE5\u5F71\u7247\u653E\u6620\u8BA1\u5212");
		
		Button btnNewButton = new Button(container, SWT.BORDER | SWT.ARROW | SWT.RIGHT);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			/*ѡ��ӰƬ���鿴��ӳ�ƻ�**/
			public void widgetSelected(SelectionEvent e) {
				table_1.removeAll();
				 film_id=text.getText();
					List<Map<String,Object>>listn=ju.query("select hall_name from show_plan where film_id="+film_id+" and show_date between '"+s_date+"' and '"+e_date+"'");
					for(Map<String,Object>map:listn){
						 String hall_name=map.get("hall_name").toString();
						 String sql="select show_id, show_date,start_time,end_time,ticket_price,ticket_count,row_count," +
							"column_count from show_plan ,show_hall  where film_id="+film_id+" and " +
									"show_plan.hall_name='"+hall_name+"'and show_date between '"+s_date+"' and '"+e_date+"'";
					System.out.println("---"+sql);
						 List<Map<String,Object>> list_1=ju.query(sql);
						 
					for(/*Map<String,Object>maps:list_1*/int i =0 ;i<list_1.size();i++){
						Map<String,Object> maps = list_1.get(i);
						TableItem tableItem = new TableItem(table_1, SWT.NONE);
						 price=maps.get("ticket_price").toString();
						 String[]s={maps.get("show_id").toString(),hall_name,maps.get("show_date").toString(),maps.get("start_time").toString(),maps.get("end_time").toString(),
								 maps.get("ticket_price").toString(),maps.get("ticket_count").toString(),maps.get("row_count").toString(),maps.get("column_count").toString()};
						 tableItem.setText(s);
					}
					}
					
				
				
			}
		});
		btnNewButton.setBounds(415, 261, 27, 17);
		btnNewButton.setText("New Button");
		{
			Label lblid_1 = new Label(container, SWT.NONE);
			lblid_1.setBounds(37, 508, 174, 24);
			lblid_1.setText("\u9009\u62E9\u653E\u6620\u8BA1\u5212id:");
		}
		{
			text_4 = new Text(container, SWT.BORDER | SWT.READ_ONLY);//��ӳ�ƻ�id
			text_4.setBounds(247, 510, 73, 23);
		}
		
		
		
		Button button_1 = new Button(container, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			//���ȷ����Ʊ*
			public void widgetSelected(SelectionEvent e) {
				codes.clear();
				 SearchDialog sd=new SearchDialog(container.getShell(), SWT.NONE);
				 
				 int n = sd.seatList.size();
				String show_id=text_4.getText();
						
						//*��������룬���  
						List<Integer> randNum = new LinkedList<Integer>();
						for(int i=0;i<n;i++){
							for (int j = 0; j < 13; j++) {
								randNum.add((int) (Math.random() * 10));
							}
							String code="";
							for(int k=0;k<randNum.size();k++){
								 code=code+randNum.get(k);
							}
							 code="TH"+code;
							codes.add(code);
							code="";
							randNum.clear();
						}
						
					 price_sum=n*Double.parseDouble(price);//������
					PayDialog pd=new PayDialog(container.getShell(), SWT.NONE);
					pd.open(String.valueOf(price_sum),codes,sd.seatList,show_id);
					
					text.setText("");
					text_4.setText("");
					table.removeAll();
					table_1.removeAll();
				}
			
		});
		button_1.setBounds(601, 613, 82, 45);
		button_1.setText("\u786E\u5B9A\u8D2D\u4E70");
		
		table = new Table(container, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(37, 106, 456, 129);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tblclmnid = new TableColumn(table, SWT.NONE);
		tblclmnid.setWidth(63);
		tblclmnid.setText("\u5F71\u7247id");
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(155);
		tableColumn.setText("\u5F71\u7247\u540D\u79F0");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(100);
		tableColumn_1.setText("\u5BFC\u6F14");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(123);
		tableColumn_2.setText("\u7247\u957F");
		
		Menu menu = new Menu(table);
		table.setMenu(menu);
		
		MenuItem menuItem = new MenuItem(menu, SWT.NONE);
		menuItem.addSelectionListener(new SelectionAdapter() {
            //�鿴ӰƬ����
			public void widgetSelected(SelectionEvent e) {
				TableItem[]items=table.getSelection();
				for(TableItem item:items){
					 film_id=item.getText(0);
				}
				FilmContentProduceDialog fpd=new FilmContentProduceDialog(container.getShell(), SWT.NONE);
				fpd.open(film_id);
			}
		});
		menuItem.setText("\u67E5\u770B\u5F71\u7247\u5185\u5BB9");
		
		MenuItem menuItem_1 = new MenuItem(menu, SWT.NONE);
		menuItem_1.addSelectionListener(new SelectionAdapter() {
			//ѡ���Ƭ
			public void widgetSelected(SelectionEvent e) {
				TableItem[]items=table.getSelection();
				for(TableItem item:items){
					 text.setText(item.getText(0));
				}
			}
		});
		menuItem_1.setText("\u9009\u62E9\u8BE5\u7247");
		
		Label label_2 = new Label(container, SWT.NONE);
		label_2.setText("   \u6CE8\uFF1A\u70B9\u51FB\u53F3\u952E\u67E5\u770B\u5F71\u7247\u5185\u5BB9\uFF0C\u9009\u62E9");
		label_2.setBounds(32, 71, 258, 25);
		
		table_1 = new Table(container, SWT.BORDER | SWT.FULL_SELECTION);
		table_1.setBounds(35, 300, 787, 180);
		table_1.setHeaderVisible(true);
		table_1.setLinesVisible(true);
		
		TableColumn tblclmnid_1 = new TableColumn(table_1, SWT.NONE);
		tblclmnid_1.setWidth(73);
		tblclmnid_1.setText("\u653E\u6620\u8BA1\u5212id");
		
		TableColumn tableColumn_4 = new TableColumn(table_1, SWT.NONE);
		tableColumn_4.setWidth(114);
		tableColumn_4.setText("\u653E\u6620\u5385\u540D\u79F0");
		
		TableColumn tableColumn_5 = new TableColumn(table_1, SWT.NONE);
		tableColumn_5.setWidth(110);
		tableColumn_5.setText("\u4E0A\u6620\u65F6\u95F4");
		
		TableColumn tableColumn_6 = new TableColumn(table_1, SWT.NONE);
		tableColumn_6.setWidth(113);
		tableColumn_6.setText("\u5F00\u573A\u65F6\u95F4");
		
		TableColumn tableColumn_7 = new TableColumn(table_1, SWT.NONE);
		tableColumn_7.setWidth(202);
		tableColumn_7.setText("\u7ED3\u675F\u65F6\u95F4");
		
		TableColumn tableColumn_8 = new TableColumn(table_1, SWT.NONE);
		tableColumn_8.setWidth(74);
		tableColumn_8.setText("\u7968\u4EF7");
		
		TableColumn tableColumn_9 = new TableColumn(table_1, SWT.NONE);
		tableColumn_9.setWidth(73);
		tableColumn_9.setText("\u5269\u4F59\u7968\u6570");
		
		Menu menu_1 = new Menu(table_1);
		table_1.setMenu(menu_1);
		
		MenuItem menuItem_2 = new MenuItem(menu_1, SWT.NONE);
		menuItem_2.addSelectionListener(new SelectionAdapter() {
        //ѡ��üƻ�
		 public void widgetSelected(SelectionEvent e) {
			 TableItem[]items=table_1.getSelection();
				for(TableItem item:items){
					text_4.setText(item.getText(0));
				}
			}
		});
		menuItem_2.setText("\u9009\u62E9");
		
		
		
		Label label_3 = new Label(container, SWT.NONE);
		label_3.setBounds(37, 557, 99, 24);
		label_3.setText("\u9009\u62E9\u5EA7\u4F4D");
		
		Button btnNewButton_1 = new Button(container, SWT.ARROW | SWT.RIGHT);
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				//�õ���ӳ�ƻ���Id
				String id = text_4.getText().trim();
				//�õ���Ӱ�ı��
				String filmId = text.getText().trim();
				SearchDialog sd = new SearchDialog(new Shell(),SWT.NONE);
				sd.open(id,filmId);
			}
		});
		btnNewButton_1.setBounds(146, 554, 27, 24);
		btnNewButton_1.setText("New Button");
		
		Button button_2 = new Button(container, SWT.NONE);
		button_2.addSelectionListener(new SelectionAdapter() {
			//�˳�
			public void widgetSelected(SelectionEvent e) {
				QuestionDialog qd = new QuestionDialog(container.getShell(), SWT.NONE);
				String message="��ȷ��Ҫ�˳���Ʊ���棿";
				String result=qd.open(message).toString();
				if(result.equals("ok")){
					Application a=new Application();
				    a.stop();
					try {
						a.start(null);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		button_2.setBounds(743, 613, 82, 45);
		button_2.setText("\u9000\u51FA");
		
		
		
		createActions();
		initializeToolBar();
		initializeMenu();
	}
	
	private void createActions() {
	}

	private void initializeToolBar() {
		IToolBarManager toolbarManager = getViewSite().getActionBars()
				.getToolBarManager();
	}

	private void initializeMenu() {
		IMenuManager menuManager = getViewSite().getActionBars()
				.getMenuManager();
	}

	public void setFocus() {
	}
}
