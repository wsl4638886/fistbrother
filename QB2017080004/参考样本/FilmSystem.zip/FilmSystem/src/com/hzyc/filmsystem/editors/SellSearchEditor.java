package com.hzyc.filmsystem.editors;

import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import com.hzyc.filmsystem.editors.SellSearchEditor;
import com.hzyc.filmsystem.normals.SWTResourceManager;

public class SellSearchEditor extends EditorPart {

	public static final String ID = "com.hzyc.filmsystem.editors.SellSearchEditor"; //$NON-NLS-1$

	private Text text;
	private Text text_1;
	private Text text_2;
	private Table table;
	private MessageBox box;
	private JDBCUtil ju;
	 private Text text_3;
	private int page=1;
	private int pageSize=20;

	public SellSearchEditor() {
	}

	
	public void createPartControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		
		Label label = new Label(container, SWT.NONE);
		label.setBounds(199, 27, 480, 28);
		label.setText("  \u9500    \u552E    \u660E    \u7EC6     \u67E5     \u8BE2");
		
		text = new Text(container, SWT.READ_ONLY);
		text.setText("\u67E5\u8BE2");
		text.setBounds(54, 98, 42, 23);
		
		final DateTime dateTime = new DateTime(container, SWT.BORDER | SWT.DROP_DOWN);
		dateTime.setBounds(102, 97, 109, 24);
		
		text_1 = new Text(container, SWT.NONE);
		text_1.setText("\u81F3");
		text_1.setBounds(217, 97, 22, 23);
		
		final DateTime dateTime_1 = new DateTime(container, SWT.BORDER | SWT.DROP_DOWN);
		dateTime_1.setBounds(245, 96, 109, 24);
		
		text_2 = new Text(container, SWT.READ_ONLY);
		text_2.setText("\u65F6\u95F4\u6BB5\u7684\u9500\u552E\u660E\u7EC6");
		text_2.setBounds(368, 97, 156, 23);
		
		table = new Table(container, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(54, 148, 796, 437);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(112);
		tableColumn.setText("\u5F71\u7247\u540D\u79F0");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(114);
		tableColumn_1.setText("\u653E\u6620\u5385\u540D\u79F0");
		
		TableColumn tableColumn_5 = new TableColumn(table, SWT.NONE);
		tableColumn_5.setWidth(86);
		tableColumn_5.setText("\u653E\u6620\u5385\u7C7B\u578B");
		
		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(100);
		tblclmnNewColumn.setText("\u5F71\u7247\u8BED\u8A00");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(179);
		tableColumn_2.setText("\u653E\u6620\u65F6\u95F4");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(100);
		tableColumn_3.setText("\u552E\u51FA\u7968\u6570");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(100);
		tableColumn_4.setText("\u6536\u5165");
		
		
		
		Button button = new Button(container, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			//������ϸ��ѯ
			public void widgetSelected(SelectionEvent e) {
				table.removeAll();
				String time1=dateTime.getYear()+"-"+(dateTime.getMonth()+1)+"-"+dateTime.getDay();
				String time2=dateTime_1.getYear()+"-"+(dateTime_1.getMonth()+1)+"-"+dateTime_1.getDay();
				if(time1.compareTo(time2)>=0){
					box=new MessageBox(container.getShell(), SWT.ICON_INFORMATION);
					box.setText("��ʾ��Ϣ");
					box.setMessage("ʱ��˳�򲻶ԣ�������ѡ��");
					box.open();
				}else{
	           String sql="SELECT DISTINCT mi.movie_name,sh.hall_name,sh.hall_type,mi.language,ti.date,ti.start_time,sp.ticket_count,sh.seat_count,ti.price " +
	           		"FROM movie_info mi,ticket_info ti,show_hall sh,show_plan sp " +
	           		"WHERE ti.date BETWEEN '"+time1+"' AND '"+time2+"' AND ti.movie_id=sp.film_id  AND ti.show_id=sp.show_id AND ti.hall_name=sh.hall_name AND ti.movie_id=id LIMIT "+(page-1)*pageSize+","+pageSize; 
					ju=new JDBCUtil();
					ju.query(sql);
					List<Map<String,Object>> list=ju.query(sql); 
					double price_sum=0;
					for(Map<String,Object>map:list){
						String movie_name=map.get("movie_name").toString();
						String hall_name=map.get("hall_name").toString();
						String type=map.get("hall_type").toString();
						String language=map.get("language").toString();
						String date=map.get("date").toString();
						String s_time=map.get("start_time").toString();
						String date1=date+" "+s_time;
						int ticket_count=Integer.parseInt(map.get("ticket_count").toString());
						int seat_count=Integer.parseInt(map.get("seat_count").toString());
						int n=seat_count-ticket_count;
						double price=Double.parseDouble(map.get("price").toString());
						price_sum=n*price;
						TableItem tableItem = new TableItem(table, SWT.NONE);
						String [] s={movie_name,hall_name,type,language,date1,String.valueOf(n),String.valueOf(price_sum)};
						tableItem.setText(s);
					}
					

				}
			}
		});
		button.setBounds(546, 97, 49, 27);
		button.setText("\u67E5\u8BE2");
		
		Link link = new Link(container, SWT.NONE);
		link.addSelectionListener(new SelectionAdapter() {
           //��ҳ
			public void widgetSelected(SelectionEvent e) {
				page=1;
				querys();
				
			}
		});
		link.setBounds(80, 612, 49, 23);
		link.setText(" <a>\u9996\u9875</a>");
		
		Link link_1 = new Link(container, SWT.NONE);
		link_1.addSelectionListener(new SelectionAdapter() {
			//��һҳ
			public void widgetSelected(SelectionEvent e) {
				if(page>1){
					page--;
				}
				querys();
		}
	});
		link_1.setBounds(149, 612, 75, 23);
		link_1.setText(" <a>\u4E0A\u4E00\u9875</a>");
		
		Link link_2 = new Link(container, SWT.NONE);
		link_2.addSelectionListener(new SelectionAdapter() {
			//��һҳ
			public void widgetSelected(SelectionEvent e) {
				String sql="SELECT DISTINCT mi.movie_name,sh.hall_name,sh.hall_type,mi.language,ti.date,ti.start_time,sp.ticket_count,sh.seat_count,ti.price " 
                    +"FROM movie_info mi,ticket_info ti,show_hall sh,show_plan sp "
                    +"WHERE ti.date BETWEEN '2012-3-7' AND '2012-4-15' " 
                    +"AND ti.movie_id=sp.film_id  AND ti.show_id=sp.show_id AND ti.hall_name=sh.hall_name AND ti.movie_id=id ";
			
			int count = ju.query(sql).size();
			if (count % pageSize == 0) {
				if (page < count / pageSize) {
					page++;
				}
			} else {
				if (page < count / pageSize + 1) {
					page++;
				}
			}
			querys();
			}
		});
		link_2.setBounds(232, 612, 75, 23);
		link_2.setText(" <a>\u4E0B\u4E00\u9875</a>");
		
		Link link_3 = new Link(container, SWT.NONE);
		link_3.addSelectionListener(new SelectionAdapter() {
			//βҳ@Override
			public void widgetSelected(SelectionEvent e) {
				String sql="SELECT DISTINCT mi.movie_name,sh.hall_name,sh.hall_type,mi.language,ti.date,ti.start_time,sp.ticket_count,sh.seat_count,ti.price " 
                    +"FROM movie_info mi,ticket_info ti,show_hall sh,show_plan sp "
                    +"WHERE ti.date BETWEEN '2012-3-7' AND '2012-4-15' " 
                    +"AND ti.movie_id=sp.film_id  AND ti.show_id=sp.show_id AND ti.hall_name=sh.hall_name AND ti.movie_id=id ";

			int count=ju.query(sql).size();
			if(count%pageSize==0){
				page=count/pageSize;
			}else {
				page=count/pageSize+1;
			}
			querys();
			}
		});
		link_3.setBounds(313, 612, 59, 23);
		link_3.setText(" <a>\u5C3E\u9875</a>");
		
		Label label_1 = new Label(container, SWT.NONE);
		label_1.setBounds(432, 612, 22, 23);
		label_1.setText("\u7B2C");
		
		text_3 = new Text(container, SWT.BORDER);
		text_3.setBounds(460, 612, 42, 23);
		
		Label label_2 = new Label(container, SWT.NONE);
		label_2.setText("\u9875");
		label_2.setBounds(508, 612, 22, 23);
		
		Button btnNewButton = new Button(container, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			//��ҳ��ѯ
			public void widgetSelected(SelectionEvent e) {
				page =Integer.parseInt(text_3.getText());
				querys();
			}
		});
		btnNewButton.setAlignment(SWT.RIGHT);
		btnNewButton.setBounds(546, 612, 22, 23);
		btnNewButton.setText("go");

	}

	public void setFocus() {
	}

	public void doSave(IProgressMonitor monitor) {
	}

	public void doSaveAs() {
	}

	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		this.setSite(site);
		this.setInput(input);
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isSaveAsAllowed() {
		return false;
	}
	
	public void querys(){
		table.removeAll();
		double price_sum=0;
		String sql="SELECT DISTINCT mi.movie_name,sh.hall_name,sh.hall_type,mi.language,ti.date,ti.start_time,sp.ticket_count,sh.seat_count,ti.price " 
            +"FROM movie_info mi,ticket_info ti,show_hall sh,show_plan sp "
            +"WHERE ti.date BETWEEN '2012-3-7' AND '2012-4-15' " 
            +"AND ti.movie_id=sp.film_id  AND ti.show_id=sp.show_id AND ti.hall_name=sh.hall_name AND ti.movie_id=id ";//limit "+(page-1)*pageSize+","+pageSize;
	    List<Map<String,Object>>list=ju.query(sql);
	    
		for(Map<String,Object>map:list){
			String movie_name=map.get("movie_name").toString();
			String hall_name=map.get("hall_name").toString();
			String type=map.get("hall_type").toString();
			String language=map.get("language").toString();
			String date=map.get("date").toString();
			String s_time=map.get("start_time").toString();
			String date1=date+" "+s_time;
			int ticket_count=Integer.parseInt(map.get("ticket_count").toString());
			int seat_count=Integer.parseInt(map.get("seat_count").toString());
			int n=seat_count-ticket_count;
			double price=Double.parseDouble(map.get("price").toString());
			price_sum=n*price;
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String [] s={movie_name,hall_name,type,language,date1,String.valueOf(n),String.valueOf(price_sum)};
			tableItem.setText(s);
		}
	}
}
