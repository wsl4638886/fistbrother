package com.hzyc.filmsystem.input;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IPersistableElement;

public class MyInput implements IEditorInput {
	private String name;
	private String ToolTipText;

	public void setName(String name) {
		this.name = name;
	}

	public void setToolTipText(String toolTipText) {
		ToolTipText = toolTipText;
	}

	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}

	@Override
	public boolean exists() {
		return false;
	}

	@Override
	public ImageDescriptor getImageDescriptor() {
		return null;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public IPersistableElement getPersistable() {
		return null;
	}

	@Override
	public String getToolTipText() {
		return ToolTipText;
	}

}
