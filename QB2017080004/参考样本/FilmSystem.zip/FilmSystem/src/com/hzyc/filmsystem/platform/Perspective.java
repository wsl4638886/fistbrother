package com.hzyc.filmsystem.platform;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

import com.hzyc.filmsystem.dialogs.BuyTicketDialog;
import com.hzyc.filmsystem.dialogs.CinemaManagerment;
import com.hzyc.filmsystem.views.BuyTicketSystemView;
import com.hzyc.filmsystem.views.FilmManageView;
import com.hzyc.filmsystem.views.ShowPlanView;
import com.hzyc.filmsystem.platform.Application;
import com.hzyc.filmsystem.views.BuyTicketSystemView;

public class Perspective implements IPerspectiveFactory {
	
	public void createInitialLayout(IPageLayout layout) {
		if(Application.sign==1){
			//�����ǹ���Ա
			layout.addView(FilmManageView.ID, IPageLayout.LEFT, 0.5f, layout.getEditorArea());
			
		}else{
			//�������û�
		layout.addView(BuyTicketSystemView.ID, IPageLayout.LEFT, 0.5f, layout.getEditorArea());
		}
		}
	}

