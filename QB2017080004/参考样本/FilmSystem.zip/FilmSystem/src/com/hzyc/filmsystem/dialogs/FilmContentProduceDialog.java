package com.hzyc.filmsystem.dialogs;

import java.util.List;
import java.util.Map;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import com.hzyc.filmsystem.normals.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class FilmContentProduceDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text text;
	private Text text_1;
	private String film_id;
	private JDBCUtil ju=new JDBCUtil();
	private Button button;

	public FilmContentProduceDialog(Shell parent, int style) {
		super(parent, style);
		setText("ӰƬ���ݼ��");
	}

	public Object open(String film_id) {
		this.film_id=film_id;
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		
		shell.setSize(749, 484);
		shell.setText(getText());
		
		Label label = new Label(shell, SWT.NONE);
		label.setBounds(33, 27, 87, 45);
		label.setText("\u5F71\u7247\u540D\u79F0\uFF1A");
		
		text = new Text(shell, SWT.READ_ONLY);
		text.setBounds(138, 28, 148, 29);
		
		text_1 = new Text(shell, SWT.BORDER | SWT.READ_ONLY | SWT.WRAP | SWT.MULTI);
		text_1.setText("  ");
		text_1.setForeground(SWTResourceManager.getColor(102, 102, 204));
		text_1.setBounds(52, 75, 620, 332);
		
		button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		button.setBounds(641, 27, 63, 27);
		button.setText("\u5173\u95ED");
		String sql="select movie_name,content_produce from movie_info where id="+film_id;
		List<Map<String,Object>>list=ju.query(sql);
		for(Map<String,Object>map:list){
			text.setText(map.get("movie_name").toString());
			text_1.setText(map.get("content_produce").toString());
		}

	}
}
