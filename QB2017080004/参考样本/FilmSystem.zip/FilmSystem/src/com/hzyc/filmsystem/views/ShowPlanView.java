package com.hzyc.filmsystem.views;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.ExpandBar;
import org.eclipse.swt.widgets.ExpandItem;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import com.hzyc.filmsystem.dialogs.QuestionDialog;
import com.hzyc.filmsystem.editors.DeleteShowPlanEditor;
import com.hzyc.filmsystem.editors.ShowPlanEditor;
import com.hzyc.filmsystem.input.MyInput;
import com.hzyc.filmsystem.normals.ResourceManager;
import com.hzyc.filmsystem.normals.SWTResourceManager;
import com.hzyc.filmsystem.platform.Application;


public class ShowPlanView extends ViewPart {
	public ShowPlanView() {
	}

	public static final String ID = "com.hzyc.filmsystem.views.ShowPlanView"; //$NON-NLS-1$

	/**
	 * Create contents of the view part.
	 * @param parent   ��ӳ�ƻ�����
	 */
	@Override
	public void createPartControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		container.setBackgroundImage(ResourceManager.getPluginImage("cinema.management", "images/sky_\u526F\u672C.jpg"));
		container.setBackgroundMode(SWT.INDETERMINATE);
		{
			ExpandBar expandBar = new ExpandBar(container, SWT.NONE);
			expandBar.setFont(SWTResourceManager.getFont("����", 18, SWT.BOLD));
			expandBar.setBounds(87, 122, 230, 311);
			expandBar.setBackgroundMode(SWT.INDETERMINATE);
			{
				ExpandItem expandItem = new ExpandItem(expandBar, SWT.NONE);
				expandItem.setExpanded(true);
				expandItem.setText("\u4E0A\u6620\u8BA1\u5212\u7BA1\u7406");
				{
					Composite composite = new Composite(expandBar, SWT.NONE);
					expandItem.setControl(composite);
					{
						Button button = new Button(composite, SWT.NONE);
						button.addSelectionListener(new SelectionAdapter() {
							//��ӳ�ƻ�����
							MyInput input=new MyInput();
							public void widgetSelected(SelectionEvent e) {
								input.setName("");
								input.setToolTipText("��ӳ�ƻ�����");
								try {
									PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input, ShowPlanEditor.ID);
								} catch (PartInitException e1) {
									e1.printStackTrace();
								}
							}
						});
						button.setFont(SWTResourceManager.getFont("����", 16, SWT.NORMAL));
						button.setBounds(31, 10, 156, 40);
						button.setText("\u4E0A\u6620\u8BA1\u5212\u6DFB\u52A0");
					}
					{
						Button button = new Button(composite, SWT.NONE);
						button.addSelectionListener(new SelectionAdapter() {
							//��ӳ�ƻ�ɾ��
							MyInput input = new MyInput();
							public void widgetSelected(SelectionEvent e) {
								input.setName("");
								input.setToolTipText("��ӳ�ƻ�ɾ��");
								try {
									PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input,DeleteShowPlanEditor.ID);
								} catch (PartInitException e1) {
									e1.printStackTrace();
								}
							}
						});
						button.setText("\u4E0A\u6620\u8BA1\u5212\u5220\u9664");
						button.setFont(SWTResourceManager.getFont("����", 16, SWT.NORMAL));
						button.setBounds(31, 62, 156, 40);
					}
					{
						Button button = new Button(composite, SWT.NONE);
						button.addSelectionListener(new SelectionAdapter() {
							//��ӳ�ƻ���ѯ
							MyInput input = new MyInput();
							public void widgetSelected(SelectionEvent e) {
								input.setName("");
								input.setToolTipText("��ӳ�ƻ���ѯ");
								try {
									PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input,ShowPlanManageEditor.ID);
								} catch (PartInitException e1) {
									e1.printStackTrace();
								}
							}
						});
						button.setText("\u4E0A\u6620\u8BA1\u5212\u67E5\u8BE2");
						button.setFont(SWTResourceManager.getFont("����", 16, SWT.NORMAL));
						button.setBounds(31, 119, 156, 40);
					}
				}
				expandItem.setHeight(250);
			}
		}
		{
			Button button = new Button(container, SWT.NONE);
			button.addSelectionListener(new SelectionAdapter() {
				//�˳�@Override
				public void widgetSelected(SelectionEvent e) {
					QuestionDialog qd = new QuestionDialog(container.getShell(), SWT.NONE);
					String message="��ȷ��Ҫ�˳��ý��棿";
					String result=qd.open(message).toString();
					if(result.equals("ok")){
						Application a=new Application();
					    a.stop();
					    try {
							a.start(null);
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
				}
			});
			button.setFont(SWTResourceManager.getFont("����", 15, SWT.BOLD));
			button.setBounds(66, 605, 90, 39);
			button.setText("\u9000 \u51FA");
		}

		createActions();
		initializeToolBar();
		initializeMenu();
	}

	private void createActions() {
		// Create the actions
	}

	private void initializeToolBar() {
		IToolBarManager toolbarManager = getViewSite().getActionBars()
				.getToolBarManager();
	}

	private void initializeMenu() {
		IMenuManager menuManager = getViewSite().getActionBars()
				.getMenuManager();
	}

	@Override
	public void setFocus() {
		// Set the focus
	}

}
