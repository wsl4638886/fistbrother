package com.hzyc.filmsystem.dialogs;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.SWT;
import com.hzyc.filmsystem.normals.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Text;

public class QuestionDialog extends Dialog {

	public Object result;
	protected Shell shell;
	private String message;
	private Text text;

	
	public QuestionDialog(Shell parent, int style) {
		super(parent, style);
		setText("��ʾ��Ϣ");
	}

	
	public Object open(String message) {
		this.message=message;
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	
	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		shell.setBackgroundMode(SWT.INDETERMINATE);
		shell.setSize(450, 255);
		shell.setText(getText());
		
		Group group = new Group(shell, SWT.NONE);
		group.setBounds(28, 10, 388, 204);
		
		
		Button button = new Button(group, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			//ȷ��@Override
			public void widgetSelected(SelectionEvent e) {
				result="ok";
				shell.dispose();
			}
		});
		button.setBounds(93, 141, 58, 27);
		button.setText("\u786E\u5B9A");
		
		Button button_1 = new Button(group, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			//ȡ��@Override
			public void widgetSelected(SelectionEvent e) {
				result="";
				shell.dispose();
			}
		});
		button_1.setBounds(243, 141, 58, 27);
		button_1.setText("\u53D6\u6D88");
		
		text = new Text(group, SWT.READ_ONLY | SWT.WRAP);
		text.setBounds(60, 71, 276, 23);
		text.setText(message);

	}
}
