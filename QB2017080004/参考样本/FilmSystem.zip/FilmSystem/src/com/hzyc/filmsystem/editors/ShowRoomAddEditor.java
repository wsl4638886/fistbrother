package com.hzyc.filmsystem.editors;

import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import com.hzyc.filmsystem.editors.ShowRoomAddEditor;
import com.hzyc.filmsystem.normals.ResourceManager;
import com.hzyc.filmsystem.normals.SWTResourceManager;

public class ShowRoomAddEditor extends EditorPart {

	public static final String ID = "com.hzyc.filmsystem.editors.ShowRoomAddEditor"; //$NON-NLS-1$

	private JDBCUtil ju=new JDBCUtil();
	private MessageBox box;
	private Text text;//����
	private Text text_2;//����
	private Text text_3;//����

	public ShowRoomAddEditor() {
	}

	@Override
	public void createPartControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.V_SCROLL);
		container.setBackgroundMode(SWT.INDETERMINATE);
		
		Label label = new Label(container, SWT.NONE);
		label.setBounds(26, 24, 94, 32);
		label.setText("\u653E\u6620\u5385\u4FE1\u606F\uFF1A");
		
		Label label_1 = new Label(container, SWT.NONE);
		label_1.setBounds(26, 271, 112, 33);
		label_1.setText("\u5EA7\u4F4D\u4F4D\u7F6E\u5B89\u6392\uFF1A");
		
		Label label_2 = new Label(container, SWT.NONE);
		label_2.setBounds(59, 102, 79, 33);
		label_2.setText("\u540D      \u79F0\uFF1A");
		
		text = new Text(container, SWT.BORDER);
		text.setBounds(150, 99, 215, 36);
		
		Label label_3 = new Label(container, SWT.NONE);
		label_3.setBounds(59, 160, 72, 33);
		label_3.setText("\u7C7B      \u578B\uFF1A");
		
		final Button button_3 = new Button(container, SWT.RADIO);
		button_3.setBounds(165, 155, 60, 30);
		button_3.setText("\u666E\u901A");
		
		final Button btnd = new Button(container, SWT.RADIO);
		btnd.setBounds(264, 155, 50, 30);
		btnd.setText("3D");
		
		final Button btnImax = new Button(container, SWT.RADIO);
		btnImax.setBounds(349, 154, 60, 33);
		btnImax.setText("IMAX");
		
		Label label_5 = new Label(container, SWT.NONE);
		label_5.setBounds(48, 333, 72, 27);
		label_5.setText("\u884C     \u6570\uFF1A");
		
		text_2 = new Text(container, SWT.BORDER);
		text_2.setBounds(149, 333, 120, 23);
		
		Label label_6 = new Label(container, SWT.NONE);
		label_6.setBounds(48, 389, 72, 32);
		label_6.setText("\u5217   \u6570\uFF1A");
		
		text_3 = new Text(container, SWT.BORDER);
		text_3.setBounds(149, 389, 120, 23);
		
		Button button = new Button(container, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				text.setText("");
				button_3.setSelection(false);
				btnd.setSelection(false);
				btnImax.setSelection(false);
			}
		});
		button.setBounds(60, 216, 60, 32);
		button.setText("\u91CD  \u7F6E");
		
		Button btnNewButton = new Button(container, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				text_2.setText("");
				text_3.setText("");
			}
		});
		btnNewButton.setBounds(28, 453, 72, 32);
		btnNewButton.setText("\u91CD  \u7F6E");
		
		final Combo combo = new Combo(container, SWT.READ_ONLY);
		combo.setItems(new String[] {"\u5DF2\u5B58\u5728\u7684\u653E\u6620\u5385"});
		combo.setBounds(404, 24, 149, 25);
		combo.select(0);
		
		Button button_1 = new Button(container, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			//��ӳ������
			public void widgetSelected(SelectionEvent e) {
				String hall_name=text.getText();
				String hall_type="";
				if(button_3.getSelection()){
					hall_type="��ͨ";
				}else if(btnd.getSelection()){
					hall_type="3D";
					
				}else if(btnImax.getSelection()){
					hall_type="IMAX";
				}
				
				int row_count=Integer.parseInt(text_2.getText());
				int column_count=Integer.parseInt(text_3.getText());
				int seat_count=row_count*column_count;
				String sql="insert into show_hall values('"+hall_name+"','"+hall_type+"',"+seat_count+","+row_count+","+column_count+");";
				System.out.println("---------"+sql);
				int a=ju.update(sql);
				
				if(a>0){
					box=new MessageBox(container.getShell(), SWT.ICON_INFORMATION);
					box.setText("��ʾ��Ϣ");
					box.setMessage("���ӳɹ�");
					box.open();
					
				}else {
					box=new MessageBox(container.getShell(), SWT.ICON_INFORMATION);
					box.setText("��ʾ��Ϣ");
					box.setMessage("����ʧ��");
					box.open();
				}
				text.setText("");
				button_3.setSelection(false);
				btnd.setSelection(false);
				btnImax.setSelection(false);
				text_2.setText("");
				text_3.setText("");
				
				combo.removeAll();
				List<Map<String,Object>>list=ju.query("select hall_name from show_hall");
				for(Map<String,Object>maps:list){
					combo.add(maps.get("hall_name").toString());
				}
			}
		});
		button_1.setBounds(323, 528, 72, 43);
		button_1.setText("\u6DFB  \u52A0");
		
		Label lblNewLabel = new Label(container, SWT.NONE);
		lblNewLabel.setImage(SWTResourceManager.getImage(ShowRoomAddEditor.class, "/cn/com/weizhen/dialog/33_2_\u526F\u672C.gif"));
		lblNewLabel.setBounds(590, 27, 468, 629);
		
		List<Map<String,Object>>list=ju.query("select hall_name from show_hall");
		for(Map<String,Object>maps:list){
			combo.add(maps.get("hall_name").toString());
		}
		
		button_3.getSelection();

	}

	public void setFocus() {
	}

	public void doSave(IProgressMonitor monitor) {
	}

	public void doSaveAs() {
	}

	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		this.setSite(site);
		this.setInput(input);
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isSaveAsAllowed() {
		return false;
	}
}
