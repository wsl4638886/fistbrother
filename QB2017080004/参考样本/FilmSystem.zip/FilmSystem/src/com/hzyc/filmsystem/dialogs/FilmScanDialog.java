package com.hzyc.filmsystem.dialogs;



import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import com.hzyc.filmsystem.normals.SWTResourceManager;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import com.hzyc.filmsystem.normals.ResourceManager;
import org.eclipse.swt.widgets.Link;

public class FilmScanDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Table table;
	private JDBCUtil ju=new JDBCUtil();
	public static String m_id;
	private int page = 1;
	private int pageSize = 20;
	

	public FilmScanDialog(Shell parent, int style) {
		super(parent, style);
		setText("ӰƬ��Ϣ�鿴");
	}

	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		shell.setSize(815, 616);
		shell.setText(getText());
		
		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(72, 42, 689, 441);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tblclmnId = new TableColumn(table, SWT.NONE);
		tblclmnId.setWidth(63);
		tblclmnId.setText("id");
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(158);
		tableColumn.setText("\u5F71\u7247\u540D\u79F0");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(101);
		tableColumn_1.setText("\u7247\u957F");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(88);
		tableColumn_2.setText("\u8BED\u8A00");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(126);
		tableColumn_3.setText("\u4E0A\u7EBF\u65F6\u95F4");
		
		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(136);
		tblclmnNewColumn.setText("\u4E0B\u7EBF\u65F6\u95F4");
		
		Menu menu = new Menu(table);
		table.setMenu(menu);
		
		MenuItem menuItem = new MenuItem(menu, SWT.NONE);
		menuItem.addSelectionListener(new SelectionAdapter() {
			//ѡ���Ƭ
			public void widgetSelected(SelectionEvent e) {
				TableItem [] items=table.getSelection();
				for(TableItem item:items){
					m_id=item.getText(0);
				}
			}
		});
		menuItem.setText("\u9009\u62E9\u8BE5\u7247");
		
		
		
		Label label = new Label(shell, SWT.NONE);
		label.setBounds(10, 9, 82, 17);
		label.setText("\u5F71\u7247\u90E8\u5206\u4FE1\u606F");
		
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		button.setBounds(730, 512, 69, 27);
		button.setText("\u5173\u95ED");
		
		String sql="select * from movie_info limit "+(page-1)*pageSize+","+pageSize;
		List<Map<String,Object>>list=new LinkedList<Map<String,Object>>();
		list=ju.query(sql);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			System.out.println(sql);
			String[]str={map.get("id").toString(),map.get("movie_name").toString(),map.get("movie_long").toString(),map.get("language").toString(),map.get("online_date").toString(),map.get("downline_date").toString()};
		tableItem.setText(str);
		}

	}
	
	public void query(){
		table.removeAll();
		String sql="select * from movie_info limit "+(page-1)*pageSize+","+pageSize;
		List<Map<String,Object>>list=new LinkedList<Map<String,Object>>();
		list=ju.query(sql);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String[]str={map.get("id").toString(),map.get("movie_name").toString(),map.get("movie_long").toString(),map.get("language").toString(),map.get("online_date").toString(),map.get("downline_date").toString()};
		tableItem.setText(str);
		}
	}
}
