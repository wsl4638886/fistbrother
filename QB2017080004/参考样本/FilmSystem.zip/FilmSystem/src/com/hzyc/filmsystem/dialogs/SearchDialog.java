package com.hzyc.filmsystem.dialogs;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import com.hzyc.filmsystem.normals.ResourceManager;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.widgets.Label;
import com.hzyc.filmsystem.normals.SWTResourceManager;

public class SearchDialog extends Dialog {

	protected static final String open = null;
	protected Object result;
	protected Shell shell;
	//��ӳ�ƻ��ı��
	private String id;
	//��Ӱ�ı��
	private String filmId;
	private JDBCUtil ju;
	
	private List<String> selectedList;
	
	public static List<String> seatList;

	public SearchDialog(Shell parent, int style) {
		super(parent, style);
		setText("ѡ��");
	}

	public Object open(String id,String filmId) {
		this.id = id;
		this.filmId = filmId;
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN | SWT.MAX);
		shell.setSize(872, 571);
		shell.setText(getText());
		
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			//ȷ������
			public void widgetSelected(SelectionEvent e) {
				seatList = new ArrayList<String>();
				seatList=selectedList;
				shell.dispose();
			}
		});
		button.setBounds(632, 20, 70, 27);
		button.setText("\u786E\u5B9A");
	
		
		selectedList = new ArrayList<String>();
		ju = new JDBCUtil();
		
		String sql = "SELECT * FROM show_hall ,show_plan   WHERE show_hall.hall_name = show_plan.hall_name AND " +
				"show_plan.show_id = "+id;
		System.out.println(sql);
		//�õ���ӳ���Ĺ�ģ
		List<Map<String, Object>> list = ju.query(sql);
		
		if(list.size() > 0){
			int row = Integer.parseInt(list.get(0).get("row_count").toString());
			int column = Integer.parseInt(list.get(0).get("column_count").toString());
			
			for(int i =  0 ; i < row ;i++){
				for(int j = 0 ; j < column ; j++){
					final Button btnNewButton = new Button(shell, SWT.NONE);
					btnNewButton.setData((i+1)+"-"+(j+1));
					btnNewButton.setImage(ResourceManager.getImage("/FilmSystem/icons/t01603156c685ddb67c.jpg"));
					
					Label label = new Label(shell, SWT.NONE);
					label.setBounds(62+j*30, 57, 27, 18);
					label.setText("  "+(j+1));
					
					Label label_1 = new Label(shell, SWT.NONE);
					label_1.setBounds(35, 81+25*i, 24, 18);
					label_1.setText("  "+(i+1));
					
					String sql1 = "SELECT * FROM show_hall sh,show_plan sp, ticket_info ti  WHERE sh.hall_name = sp.hall_name AND " +
					"sp.show_id = "+id+" AND sp.show_id = ti.show_id AND ti.movie_id = "+filmId+"";
					System.out.println(sql1);
					List<Map<String, Object>> list1 = ju.query(sql1);
					if(list1.size()>0){
						for(int m = 0 ; m < list1.size();m++){
							if(((i+1)+"-"+(j+1)).equals(list1.get(m).get("seat_position").toString())){
								btnNewButton.setEnabled(false);
							}
					    }
					}
					
					
					btnNewButton.addSelectionListener(new SelectionAdapter() {
						
						public void widgetSelected(SelectionEvent e) {
							
							//�õ���ǰѡ�еİ�ť�ı�ʶ
							String data = btnNewButton.getData().toString();
							if(selectedList.size()>0){
								
								for(int k = 0 ; k < selectedList.size(); k++){
									System.out.println("��λ�ţ�"+data);
									System.out.println("��ȡ��ѡ��λ��"+selectedList.get(k));
									System.out.println(data.equals(selectedList.get(k).toString()));
									if(data.equals(selectedList.get(k).toString())){
										
										//֤���˰�ť֮ǰ��ѡ�е�״̬������Ҫ�������δѡ�е�״̬
										btnNewButton.setImage(ResourceManager.getImage("/FilmSystem/icons/t01603156c685ddb67c.jpg"));
										
										selectedList.remove(k);
										break;
									}else if(k == selectedList.size()-1){
										
										selectedList.add(data);
										btnNewButton.setImage(org.eclipse.wb.swt.ResourceManager.getPluginImage("FilmSystem", "icons/0x230a0a0.jpg"));
										break;
									}
								}
							}else{
								selectedList.add(data);
								btnNewButton.setImage(org.eclipse.wb.swt.ResourceManager.getPluginImage("FilmSystem", "icons/0x230a0a0.jpg"));
								}
						}
					});
					btnNewButton.setBounds(65+j*30, 80+i*25, 24, 18);
				}
			}
		}
		
	}
}
