package com.hzyc.filmsystem.editors;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import com.hzyc.filmsystem.dialogs.StatisticsSellDialog;
import com.hzyc.filmsystem.normals.ResourceManager;
import com.hzyc.filmsystem.normals.SWTResourceManager;

public class PercentageEditor extends EditorPart {

	public static final String ID = "com.hzyc.filmsystem.editors.PercentageEditor"; //$NON-NLS-1$

	private Table table;
	private Table table_1;
	private Text text;
	private Text text_1;
	private JDBCUtil ju;
	private MessageBox box;

	public PercentageEditor() {
	}

	
	public void createPartControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		container.setBackgroundImage(ResourceManager.getPluginImage("cinema.management", "images/lan1_\u526F\u672C.jpg"));
		container.setBackgroundMode(SWT.INDETERMINATE);
		
		Label label = new Label(container, SWT.NONE);
		label.setBounds(51, 44, 78, 17);
		label.setText("\u67E5\u8BE2\u8BE5\u6708");
		
		final DateTime dateTime = new DateTime(container, SWT.DROP_DOWN | SWT.SHORT);
		dateTime.setBounds(135, 39, 115, 24);
		
		Label label_2 = new Label(container, SWT.NONE);
		label_2.setBounds(256, 45, 162, 17);
		label_2.setText("\u5404\u4E2A\u653E\u6620\u5385\u7684\u4E0A\u5EA7\u7387");
		
		Button btnNewButton = new Button(container, SWT.ARROW | SWT.RIGHT);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				table.removeAll();
				ju=new JDBCUtil();
				String date=(dateTime.getMonth()+1)>9 ?String.valueOf(dateTime.getMonth()+1) :"0"+(dateTime.getMonth()+1);
				String time=dateTime.getYear()+"-"+date;
				String sql="select * from show_hall";		
				List<Map<String,Object>>list=ju.query(sql);
				
				for(int i=0;i<list.size();i++){
					TableItem tableItem = new TableItem(table, SWT.NONE);
					String sql1="select * from ticket_info ti,show_hall sh where ti.hall_name='"+list.get(i).get("hall_name").toString()+"' and " +
							"ti.hall_name=sh.Hall_name and ti.date like '"+time+"-%'";
					List<Map<String,Object>>list1=ju.query(sql1);
					if(list1.size()>0){
						int seat_count=Integer.parseInt(list1.get(0).get("seat_count").toString());
						int seats=seat_count*list1.size();
						String sql2="select * from ticket_info where hall_name='"+list.get(i).get("hall_name").toString()+"' and date like '"+time+"-%'";
						List<Map<String,Object>>list2=ju.query(sql2);
						int tickets=list2.size();
						double p=(double)tickets/seats*100;
						DecimalFormat format=new DecimalFormat("00.00");
						String percent=format.format(p);
						String ss[]={list.get(i).get("hall_name").toString(),list.get(i).get("hall_type").toString(),String.valueOf(seats),String.valueOf(tickets),percent};
						tableItem.setText(ss);
					}else{
						List<Map<String,Object>>list3=ju.query("select * from show_hall where hall_name='"+list.get(i).get("hall_name").toString()+"'");
						String h_name=list3.get(0).get("hall_name").toString();
						String h_type=list3.get(0).get("hall_type").toString();
						String ss[]={h_name,h_type,"0","0","00.00"};
						tableItem.setText(ss);
					}
				}
					
			}
		});
		btnNewButton.setBounds(428, 46, 21, 17);
		btnNewButton.setText("New Button");
		
		table = new Table(container, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(48, 67, 520, 244);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(123);
		tableColumn.setText("\u653E\u6620\u5385\u540D\u79F0");
		
		TableColumn tableColumn_8 = new TableColumn(table, SWT.NONE);
		tableColumn_8.setWidth(100);
		tableColumn_8.setText("\u653E\u6620\u5385\u7C7B\u578B");
		
		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(100);
		tblclmnNewColumn.setText("\u9884\u8BA1\u552E\u51FA\u7968\u6570");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(100);
		tableColumn_3.setText("\u5B9E\u9645\u552E\u51FA\u7968\u6570");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(92);
		tableColumn_4.setText("\u4E0A\u5EA7\u7387(%)");
		
		
		Label lblNewLabel = new Label(container, SWT.NONE);
		lblNewLabel.setBounds(36, 389, 78, 17);
		lblNewLabel.setText("\u8BE5\u65F6\u95F4\u6BB5\uFF1A");
		
		final DateTime dateTime_1 = new DateTime(container, SWT.DROP_DOWN);
		dateTime_1.setBounds(120, 382, 106, 24);
		
		Label label_1 = new Label(container, SWT.NONE);
		label_1.setBounds(229, 383, 21, 17);
		label_1.setText("\u81F3");
		
		final DateTime dateTime_2 = new DateTime(container, SWT.DROP_DOWN);
		dateTime_2.setBounds(256, 382, 106, 24);
		
		Label lblNewLabel_1 = new Label(container, SWT.NONE);
		lblNewLabel_1.setBounds(364, 389, 234, 17);
		lblNewLabel_1.setText("\u4E0A\u5EA7\u7387\u524D\u4E94\u4F4D\u7684\u5F71\u7247\u53CA\u4E0A\u5EA7\u7387");
		
		Button btnNewButton_1 = new Button(container, SWT.CENTER);
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			//������ǰ��λ��ӰƬ
			public void widgetSelected(SelectionEvent e) {
				Map<String,Integer>names=new HashMap<String,Integer>();//���ӰƬ���ƺ�������Ʊ��
				Map<String,Integer>seat_count=new HashMap<String, Integer>();//���ӰƬ���ƺͶ�Ӧ��ӳ����λ�����൱��Ӧ����Ʊ��
				Map<String,Double>percentage=null;//���ӰƬ���ƺͶ�Ӧ�ı��� �磺{���棬5.0}
				List<Map<String,Double>>plist=new LinkedList<Map<String,Double>>();//���ÿһ��percentage �磺{{���棬5.0}��{���ڣ�6.5}...}
				String time_1=dateTime_1.getYear()+"-"+(dateTime_1.getMonth()+1)+"-"+dateTime_1.getDay();
				String time_2=dateTime_2.getYear()+"-"+(dateTime_2.getMonth()+1)+"-"+dateTime_2.getDay();
				if(time_1.compareTo(time_2)>0){
					box=new MessageBox(container.getShell(), SWT.ICON_INFORMATION);
					box.setText("��ʾ��Ϣ");
					box.setMessage("ʱ��ǰ��˳�򲻶ԣ�������ѡ��");
					box.open();
				}else{
					ju=new JDBCUtil();
					int n1=0,n2=0,seat_count1=0,seat_count2=0;
					String sql="SELECT  * FROM movie_info mi,ticket_info ti WHERE ti.movie_id=mi.id AND ti.date  BETWEEN  '"+time_1+"' and '"+time_2+"'";
					List<Map<String,Object>>list=ju.query(sql);
					if(list.size()>0){
						for(int i=0;i<list.size();i++){
							String name=list.get(i).get("movie_name").toString();
							String m_id=list.get(i).get("movie_id").toString();
							if(names.containsKey(name)){//�ж�ӰƬ������ͬ��ӰƬ��Ų�ͬ�����
								n2=ju.query("SELECT * FROM ticket_info WHERE DATE BETWEEN '"+time_1+"' and '"+time_2+"' and movie_id="+m_id).size();
								names.put(name,names.get(name)+n2);
								String movie_id=list.get(i).get("movie_id").toString();
								String sql1="SELECT  ti.show_id,ti.hall_name,sh.seat_count FROM ticket_info ti,show_hall sh WHERE ti.date between '"+time_1+"' and '"+time_2+"' and ti.hall_name=sh.hall_name AND movie_id="+movie_id+" GROUP BY show_id;";
								List<Map<String,Object>>list1=ju.query(sql1);
								for(Map<String,Object>map1:list1){
									 seat_count1+=Integer.parseInt(map1.get("seat_count").toString());
								}
								seat_count.put(name,seat_count.get(name)+seat_count1);
							}else{
								 n1=ju.query("SELECT * FROM ticket_info WHERE DATE BETWEEN '"+time_1+"' and '"+time_2+"' and movie_id="+m_id).size();
								 names.put(name, n1);
								 String movie_id=list.get(i).get("movie_id").toString();
								 String sql1="SELECT  ti.show_id,ti.hall_name,sh.seat_count FROM ticket_info ti,show_hall sh WHERE  ti.date between '"+time_1+"' and '"+time_2+"' AND ti.hall_name=sh.hall_name AND movie_id="+movie_id+" GROUP BY ti.show_id;";
								 List<Map<String,Object>>list1=ju.query(sql1);
								 for(Map<String,Object>map2:list1){
								 seat_count2+=Integer.parseInt(map2.get("seat_count").toString());
								}
								 seat_count.put(name,seat_count2);
						   }
						}
						
						Set<String>set=names.keySet();
						Iterator<String>it=set.iterator();
						while(it.hasNext()){
					      percentage=new HashMap<String, Double>();
					      String name=it.next();
						  int ticket_sum=names.get(name);
						  int seat_sum=seat_count.get(name);
						  double p=(double)ticket_sum/seat_sum*100;//�����ʼ���
						  DecimalFormat format=new DecimalFormat("00.00");//ȡ��λС��
						  String percent=format.format(p);
						  percentage.put(name, Double.parseDouble(percent));
						  plist.add(percentage);
						}
                      
						//����������
						for(int i = 0;i <plist.size()-1;i++){
							for(int j = 0;j<plist.size()-1-i;j++){
								Set<String>set1=plist.get(j).keySet();
								Iterator<String>it1=set1.iterator();
								
								Set<String>set2=plist.get(j+1).keySet();
								Iterator<String>it2=set2.iterator();
								
								while(it1.hasNext()&&it2.hasNext()){
									String name=it1.next();
									String name1=it2.next();
								    
									if(plist.get(j).get(name)<plist.get(j+1).get(name1)){
									   Map<String, Double> t=plist.get(j);
									   plist.set(j, plist.get(j+1));
									   plist.set(j+1, t);
								    }
							   }
						    }
					     }
						//ȥǰ��λ
					    if(plist.size()>5){
					       for(int i=0;i<5;i++){
					         Set<String>set2=plist.get(i).keySet();
						     Iterator<String>it2=set2.iterator();
						     while(it2.hasNext()){
							   String name=it2.next();
							   double per=plist.get(i).get(name);
							   TableItem tableItem = new TableItem(table_1, SWT.NONE);
							   String []st={name,String.valueOf(per)};
							   tableItem.setText(st);
						     }
					      }
				       }else{
					      for(int i=0;i<plist.size();i++){
						    Set<String>set2=plist.get(i).keySet();
						    Iterator<String>it2=set2.iterator();
						    while(it2.hasNext()){
						       String name=it2.next();
						       double per=plist.get(i).get(name);
							   TableItem tableItem = new TableItem(table_1, SWT.NONE);
							   String []st={name,String.valueOf(per)};
							   tableItem.setText(st);
						    }
					     }
				      }
				    }else {
					  box=new MessageBox(container.getShell(), SWT.ICON_INFORMATION);
					  box.setText("��ʾ��Ϣ");
					  box.setMessage("���޽����");
					  box.open();
				   }
				}
			}
		});
		btnNewButton_1.setBounds(604, 387, 51, 24);
		btnNewButton_1.setText("\u67E5\u8BE2");
		
		table_1 = new Table(container, SWT.BORDER | SWT.FULL_SELECTION);
		table_1.setBounds(102, 432, 318, 188);
		table_1.setHeaderVisible(true);
		table_1.setLinesVisible(true);
		
		TableColumn tableColumn_5 = new TableColumn(table_1, SWT.NONE);
		tableColumn_5.setWidth(147);
		tableColumn_5.setText("\u5F71\u7247\u540D\u79F0");
		
		TableColumn tableColumn_7 = new TableColumn(table_1, SWT.NONE);
		tableColumn_7.setWidth(150);
		tableColumn_7.setText("\u4E0A\u5EA7\u7387(%)");
		
		Composite composite = new Composite(container, SWT.NONE);
		composite.setBounds(678, 382, 287, 341);
		
		text = new Text(composite, SWT.NONE);
		text.setText("\u9500\u552E\u989D\u7EDF\u8BA1\uFF1A");
		text.setBounds(20, 33, 118, 23);
		
		text_1 = new Text(composite, SWT.NONE);
		text_1.setText("\u9009\u62E9\u5E74\u4EFD\uFF1A");
		text_1.setBounds(22, 70, 77, 23);
		
		final DateTime dateTime_3 = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN | SWT.SHORT);
		dateTime_3.setBounds(110, 69, 93, 24);
		
		Button button = new Button(composite, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			//��ѯ���۶�
			public void widgetSelected(SelectionEvent e) {
				ju=new JDBCUtil();
				int year=dateTime_3.getYear();
				double sum=0;
				List<Map<String,Object>>list=ju.query("SELECT price FROM ticket_info WHERE DATE LIKE '"+year+"-%'");
				if(list.size()>0){
					for(Map<String,Object>map:list){
						sum+=Double.parseDouble(map.get("price").toString());
					}
					
					StatisticsSellDialog sd=new StatisticsSellDialog(container.getShell(), SWT.NONE);
					sd.open(year,String.valueOf(sum));
			   }else{
				   box=new MessageBox(container.getShell(), SWT.ICON_INFORMATION);
				   box.setText("��ʾ��Ϣ");
				   box.setMessage("���޽����");
				   box.open();
			   }
			}
		});
		button.setBounds(211, 68, 36, 23);
		button.setText("\u786E\u5B9A");

	}

	public void setFocus() {
	}

	public void doSave(IProgressMonitor monitor) {
	}

	public void doSaveAs() {
	}

	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		this.setSite(site);
		this.setInput(input);
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isSaveAsAllowed() {
		return false;
	}
}
