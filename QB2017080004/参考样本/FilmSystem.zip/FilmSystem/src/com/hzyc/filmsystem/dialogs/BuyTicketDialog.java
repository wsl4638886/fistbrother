package com.hzyc.filmsystem.dialogs;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;

import com.hzyc.filmsystem.editors.FilmAddEditor;
import com.hzyc.filmsystem.input.MyInput;
import com.hzyc.filmsystem.normals.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import com.hzyc.filmsystem.normals.ResourceManager;
import com.hzyc.filmsystem.views.BuyTicketSystemView;

import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

public class BuyTicketDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	public static String open="";
	public static String str="";
	public static String ss="";

	public BuyTicketDialog(Shell parent, int style) {
		super(parent, style);
		setText("������Ʊϵͳ");
		ss="ok";
	}

	public Object open() {
		
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN | SWT.MAX);
		shell.setSize(897, 746);
		shell.setText(getText());
		shell.setLayout(null);
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackgroundImage(ResourceManager.getPluginImage("cinema.management", "images/aaa1_\u526F\u672C.jpg"));
		composite.setBounds(0, 0, 891, 718);
		
		Button btnNewButton = new Button(composite, SWT.NONE);
		btnNewButton.addKeyListener(new KeyAdapter() {
			//�س�ȷ��@Override
			public void keyPressed(KeyEvent e) {
				if(e.keyCode==SWT.CR){
					open="ticket";
					str="ok";
					shell.dispose();
				}
			}
		});
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				open="ticket";
				str="ok";
				shell.dispose();
			}
		});
		
		btnNewButton.setBounds(475, 349, 127, 64);
		btnNewButton.setText("\u70B9\u51FB\u8FDB\u5165");

	}
}

