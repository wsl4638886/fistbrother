package com.hzyc.filmsystem.dialogs;

import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import com.hzyc.filmsystem.normals.SWTResourceManager;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import com.hzyc.filmsystem.normals.ResourceManager;

public class ShowHallDeleteDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Table table;
	private JDBCUtil ju=new JDBCUtil();
	private MessageBox box;

	public ShowHallDeleteDialog(Shell parent, int style) {
		super(parent, style);
		setText("��ӳ����Ϣɾ��");
	}

	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		shell.setBackgroundImage(ResourceManager.getPluginImage("cinema.management", "src/cn/com/weizhen/dialog/\u5F71\u9662_\u526F\u672C.jpg"));
		shell.setSize(613, 658);
		shell.setText(getText());
		
		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION | SWT.VIRTUAL);
		table.setBounds(49, 51, 495, 491);
		shell.setBackgroundMode(SWT.INDETERMINATE);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(127);
		tableColumn.setText("\u653E\u6620\u5385\u540D\u79F0");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(104);
		tableColumn_1.setText("\u7C7B\u578B");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(91);
		tableColumn_2.setText("\u5EA7\u4F4D\u6570");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(70);
		tableColumn_3.setText("\u6392\u6570");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(73);
		tableColumn_4.setText("\u5217\u6570");
		
		Menu menu = new Menu(table);
		table.setMenu(menu);
		
		MenuItem menuItem = new MenuItem(menu, SWT.NONE);
		menuItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				//��ӳ��ɾ��
				QuestionDialog qd = new QuestionDialog(shell, SWT.NONE);
				String message="��ȷ��Ҫɾ��������Ϣ��";
				String result=qd.open(message).toString();
				if(result.equals("ok")){
					TableItem[]items=table.getSelection();
					for(TableItem item:items){
						String hall_name=item.getText(0);
						int r=ju.update("delete from show_hall where hall_name='"+hall_name+"';");
						if(r>0){
							box=new MessageBox(shell, SWT.ICON_INFORMATION);
							box.setText("��ʾ��Ϣ");
							box.setMessage("ɾ���ɹ���");
							box.open();
						}else{
							box=new MessageBox(shell, SWT.ICON_INFORMATION);
							box.setText("��ʾ��Ϣ");
							box.setMessage("ɾ��ʧ�ܣ�");
							box.open();
						}
					}
				}
				
				
			}
		});
		menuItem.setText("\u5220\u9664");
		
		MenuItem menuItem_1 = new MenuItem(menu, SWT.NONE);
		menuItem_1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				//ˢ��
				table.removeAll();
				String sql="select * from show_hall";
				List<Map<String,Object>>list=ju.query(sql);
				for(Map<String,Object>map:list){
					TableItem tableItem = new TableItem(table, SWT.NONE);
					String []ss={map.get("hall_name").toString(),map.get("hall_type").toString(),map.get("seat_count").toString(),map.get("row_count").toString(),map.get("column_count").toString()};
					tableItem.setText(ss);
				}
			}
		});
		menuItem_1.setText("\u5237\u65B0");
		
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		button.setBounds(534, 567, 63, 27);
		button.setText("\u9000 \u51FA");
		
		String sql="select * from show_hall";
		List<Map<String,Object>>list=ju.query(sql);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String []ss={map.get("hall_name").toString(),map.get("hall_type").toString(),map.get("seat_count").toString(),map.get("row_count").toString(),map.get("column_count").toString()};
			tableItem.setText(ss);
		}

	}
}
