package com.hzyc.filmsystem.dialogs;



import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import com.hzyc.filmsystem.normals.ResourceManager;

public class UserUpdateDialog extends Dialog {

	
	protected Object result;
	protected Shell shell;
	private Text text;
	private Text text_1;
	private MessageBox box;
	private JDBCUtil ju=new JDBCUtil();
	private Button button_1;
	private Button button;
	private Button button_2;
	private Button button_3;
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public UserUpdateDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(450, 300);
		shell.setText("\u7528\u6237\u6CE8\u518C");
		
		org.eclipse.swt.widgets.Label label = new org.eclipse.swt.widgets.Label(shell, SWT.NONE);
		label.setText("\u7528\u6237\u540D");
		label.setBounds(79, 32, 61, 17);
		
		org.eclipse.swt.widgets.Label label_1 = new org.eclipse.swt.widgets.Label(shell, SWT.NONE);
		label_1.setBounds(79, 75, 61, 17);
		label_1.setText("\u5BC6\u7801");
		
		text = new Text(shell, SWT.BORDER);
		text.setBounds(202, 32, 73, 23);
		
		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(202, 75, 73, 23);
		
		button_3 = new Button(shell, SWT.NONE);
		button_3.addSelectionListener(new SelectionAdapter() {
			//ӰƬ����
			public void widgetSelected(SelectionEvent e) {
				
				String sql="insert into user_info(user_name,pass_word) values('"+text.getText()+"','"+text_1.getText()+"');";
				System.out.println(sql);
				int r=ju.update(sql);
				if(r>0){
					
						box=new MessageBox(shell.getShell(), SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("���ӳɹ�");
						box.open();
					}else {
						box=new MessageBox(shell.getShell(), SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("����ʧ��");
						box.open();
					}
				}
			
			
		});
		button_3.setBounds(79, 128, 80, 27);
		button_3.setText("\u786E\u5B9A\u6DFB\u52A0");
		
		
		
		
		
	
	
	
	
	
	
	}}
		

