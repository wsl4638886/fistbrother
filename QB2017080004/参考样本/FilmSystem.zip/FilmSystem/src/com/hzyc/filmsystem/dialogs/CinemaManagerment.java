package com.hzyc.filmsystem.dialogs;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;


import com.hzyc.filmsystem.normals.SWTResourceManager;
import com.hzyc.filmsystem.views.BuyTicketSystemView;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

public class CinemaManagerment extends Dialog {
	private List<Map<String,Object>>list=new LinkedList<Map<String,Object>>();
	private JDBCUtil ju=new JDBCUtil();

	public static Object ID;

	public CinemaManagerment(Shell parent, int style) {
		super(parent, style);
		setText("�û���¼");
	}
// TODO Auto-generated constructor stub
	

	protected Object result;
	protected Shell shell;
	private Text txtUn;
	private Text txtPw;

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 * @return 
	 */
	
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(450, 300);
		shell.setText(getText());
		
		Label lblUn = new Label(shell, SWT.NONE);
		lblUn.setBounds(132, 87, 61, 17);
		lblUn.setText("�û�����");
		
		txtUn = new Text(shell, SWT.BORDER);
		txtUn.setBounds(214, 87, 73, 23);
		
		Label lblPw = new Label(shell, SWT.NONE);
		lblPw.setBounds(132, 141, 61, 17);
		lblPw.setText("���룺");
		
		txtPw = new Text(shell, SWT.BORDER);
		txtPw.setBounds(214, 141, 73, 23);
		
		Button btnLogin = new Button(shell, SWT.NONE);
		btnLogin.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				//songshuo �ǹ���Ա
				if( "songshuo".equals(txtUn.getText())&& "12345678".equals(txtPw.getText())){
					//�ǹ���Ա
					result = 1;
					shell.close();
				}else{
					//���û�
					result = 0;
					shell.close();
				}
			}
		});
		btnLogin.setBounds(165, 192, 80, 27);
		btnLogin.setText("��¼");
		
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				UserUpdateDialog cm = new UserUpdateDialog(new Shell(),
						SWT.CLOSE | SWT.MAX | SWT.MIN | SWT.APPLICATION_MODAL);//SWT.APPLICATION_MODAL  ģ̬����
				result = cm.open();
				
			}
		});
		
		
		
		button.setBounds(251, 192, 80, 27);
		button.setText("\u6CE8\u518C");

	}
}
