package com.hzyc.filmsystem.dialogs;

import java.util.List;
import java.util.Map;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import com.hzyc.filmsystem.normals.SWTResourceManager;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;

import  com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Text;
import com.hzyc.filmsystem.normals.ResourceManager;

public class DeleteManagerDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Table table;
	private JDBCUtil ju=new JDBCUtil();
	private MessageBox box;
	private Text text;
	private Text text_1;

	public DeleteManagerDialog(Shell parent, int style) {
		super(parent, style);
		setText("����Ա��Ϣ");
	}

	public Object open() {



		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		shell.setSize(807, 488);
		shell.setText(getText());
		shell.setBackgroundMode(SWT.INDETERMINATE);
		
		Group group = new Group(shell, SWT.NONE);
		group.setText("\u7BA1\u7406\u5458\u4FE1\u606F");
		group.setBounds(44, 37, 722, 413);
		
		table = new Table(group, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(77, 51, 542, 291);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(87);
		tableColumn.setText("\u59D3\u540D");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(52);
		tableColumn_1.setText("\u6027\u522B");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(112);
		tableColumn_2.setText("\u8D26\u53F7");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(136);
		tableColumn_3.setText("\u7535\u8BDD");
		
		
		
		Menu menu = new Menu(table);
		table.setMenu(menu);
		
		MenuItem menuItem = new MenuItem(menu, SWT.NONE);
		menuItem.addSelectionListener(new SelectionAdapter() {
			/*����Ա��Ϣɾ��**/
			public void widgetSelected(SelectionEvent e) {
				QuestionDialog qd = new QuestionDialog(shell, SWT.NONE);
				String message="��ȷ��Ҫɾ��������Ϣ��";
				String result=qd.open(message).toString();
				if(result.equals("ok")){
					TableItem []items=table.getSelection();
					for(TableItem item:items){
						String id=item.getText(2);
						int r=ju.update("delete from manager_info where manager_ID='"+id+"'");
						if(r>0){
							box.setText("��ʾ��Ϣ");
							box.setMessage("ɾ���ɹ�");
						    box.open();
						}else{
							box.setText("��ʾ��Ϣ");
							box.setMessage("ɾ��ʧ��");
						    box.open();
						}
					}
				}
			}
		});
		menuItem.setText("\u5220\u9664");
		
		MenuItem menuItem_2 = new MenuItem(menu, SWT.NONE);
		menuItem_2.addSelectionListener(new SelectionAdapter() {
			//����Ա��Ϣ�޸�
			public void widgetSelected(SelectionEvent e) {
				TableItem []items = table.getSelection();
				for(TableItem item:items){
					String count=item.getText(2);
					
				}
			}
		});
		menuItem_2.setText("\u4FEE\u6539");
		
		MenuItem menuItem_1 = new MenuItem(menu, SWT.NONE);
		menuItem_1.addSelectionListener(new SelectionAdapter() {
			/*ˢ�¹���Ա�б�**/
			public void widgetSelected(SelectionEvent e) {
				table.removeAll();
				List<Map<String,Object>>list=ju.query("select * from manager_info");
				for(Map<String,Object>map:list){
					TableItem tableItem = new TableItem(table, SWT.NONE);
					tableItem.setFont(SWTResourceManager.getFont("΢���ź�", 10, SWT.NORMAL));
					String []s={map.get("manager_name").toString(),map.get("sex").toString(),map.get("manager_ID").toString(),map.get("phone_number").toString(),map.get("role").toString()};
					tableItem.setText(s);
				}
			}
		});
		menuItem_1.setText("\u5237\u65B0");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(121);
		tableColumn_4.setText("\u804C\u4F4D");
		
		Label label = new Label(group, SWT.NONE);
		label.setBounds(46, 22, 194, 17);
		label.setText("  \u9009\u62E9\u8981\u5220\u9664\u7684\u884C\uFF0C\u70B9\u51FB\u53F3\u952E\u5220\u9664");
		
		Button button = new Button(group, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		button.setBounds(616, 376, 69, 27);
		button.setText("\u5173\u95ED");
		
		
		List<Map<String,Object>>list=ju.query("select * from manager_info");
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String []s={map.get("manager_name").toString(),map.get("sex").toString(),map.get("manager_ID").toString(),map.get("phone_number").toString(),map.get("role").toString(),map.get("authority").toString(),map.get("pass").toString(),map.get("password").toString()};
			tableItem.setText(s);
		}

	}
}
