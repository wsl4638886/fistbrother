package com.hzyc.filmsystem.views;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.swt.widgets.ExpandBar;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.ExpandItem;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import com.hzyc.filmsystem.dialogs.DeleteManagerDialog;
import com.hzyc.filmsystem.dialogs.FilmDeleteDialog;
import com.hzyc.filmsystem.dialogs.ManagerAddDialog;
import com.hzyc.filmsystem.dialogs.ShowHallDialog;
import com.hzyc.filmsystem.editors.DeleteShowPlanEditor;
import com.hzyc.filmsystem.editors.FilmAddEditor;
import com.hzyc.filmsystem.editors.FilmUpdateEditor;
import com.hzyc.filmsystem.editors.PercentageEditor;
import com.hzyc.filmsystem.editors.SellSearchEditor;
import com.hzyc.filmsystem.editors.ShowPlanEditor;
import com.hzyc.filmsystem.editors.ShowRoomAddEditor;
import com.hzyc.filmsystem.editors.ShowRoomUpdateEditor;
import com.hzyc.filmsystem.input.MyInput;

public class FilmManageView extends ViewPart {

	public static final String ID = "com.hzyc.filmsystem.views.FilmManageView"; //$NON-NLS-1$

	public FilmManageView() {
	}

	/**
	 * Create contents of the view part.
	 * @param parent
	 */
	@Override
	public void createPartControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		{
			ExpandBar expandBar = new ExpandBar(container, SWT.NONE);
			expandBar.setBackgroundMode(SWT.INHERIT_FORCE);
			expandBar.setBounds(158, 10, 156, 213);
			{
				ExpandItem expandItem = new ExpandItem(expandBar, 0);
				expandItem.setText("    \u7EFC\u5408\u4FE1\u606F\u67E5\u8BE2\u7EDF\u8BA1");
				expandItem.setExpanded(true);
				{
					Composite composite = new Composite(expandBar, SWT.NONE);
					expandItem.setControl(composite);
					{
						Button button = new Button(composite, SWT.NONE);
						button.addSelectionListener(new SelectionAdapter() {
							//������ϸ��ѯ
							MyInput input = new MyInput();
							public void widgetSelected(SelectionEvent e) {
								input.setName("");
								input.setToolTipText("������ϸ��ѯ");
								try {
									PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input, SellSearchEditor.ID);
								} catch (PartInitException e1) {
									e1.printStackTrace();
								}
							}
						});
						button.setText("\u9500\u552E\u660E\u7EC6");
						button.setBounds(0, 0, 151, 43);
					}
					{
						Button button1 = new Button(composite, SWT.NONE);
						button1.addSelectionListener(new SelectionAdapter() {
							//�����ʼ����۶�ͳ��
							MyInput input = new MyInput();
							public void widgetSelected(SelectionEvent e) {
								input.setName("");
								input.setToolTipText("�����ʼ����۶�ͳ��");
								try {
									PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input, PercentageEditor.ID);
								} catch (PartInitException e1) {
									e1.printStackTrace();
								}
							}
						});
						button1.setText("\u4E1A\u52A1\u67E5\u8BE2");
						button1.setBounds(0, 43, 151, 43);
					}
				}
				expandItem.setHeight(120);
			}
			{
				ExpandItem expandItem = new ExpandItem(expandBar, 0);
				expandItem.setText("    \u7BA1\u7406\u5458\u4FE1\u606F");
				expandItem.setExpanded(true);
				{
					final Composite composite1 = new Composite(expandBar, SWT.NONE);
					expandItem.setControl(composite1);
					{
						Button button2 = new Button(composite1, SWT.NONE);
						button2.addSelectionListener(new SelectionAdapter() {
							/**����Ա��Ϣ����*/
							public void widgetSelected(SelectionEvent e) {
								ManagerAddDialog ma=new ManagerAddDialog(composite1.getShell(), SWT.NONE);
								ma.open();
							}
						});
						button2.setText("\u7BA1\u7406\u5458\u4FE1\u606F\u6DFB\u52A0");
						button2.setBounds(0, 0, 152, 39);
					}
				}
				expandItem.setHeight(130);
			}
		}
		{
			ExpandBar expandBar = new ExpandBar(container, SWT.NONE);
			expandBar.setBackgroundMode(SWT.INHERIT_FORCE);
			expandBar.setBounds(2, 350, 156, 100);
			{
				ExpandItem expandItem = new ExpandItem(expandBar, 0);
				expandItem.setText("\u4E0A\u6620\u8BA1\u5212\u7BA1\u7406");
				expandItem.setExpanded(true);
				{
					Composite composite2 = new Composite(expandBar, SWT.NONE);
					expandItem.setControl(composite2);
					{
						Button button4 = new Button(composite2, SWT.NONE);
						button4.addSelectionListener(new SelectionAdapter() {
							//��ӳ�ƻ�����
							MyInput input=new MyInput();
							public void widgetSelected(SelectionEvent e) {
								input.setName("");
								input.setToolTipText("��ӳ�ƻ�����");
								try {
									PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input, ShowPlanEditor.ID);
								} catch (PartInitException e1) {
									e1.printStackTrace();
								}
							}
						});
						button4.setText("\u4E0A\u6620\u8BA1\u5212\u6DFB\u52A0");
						button4.setBounds(0, 0, 148, 40);
					}
					{
						Button button5 = new Button(composite2, SWT.NONE);
						button5.addSelectionListener(new SelectionAdapter() {
							//��ӳ�ƻ�ɾ��
							MyInput input = new MyInput();
							public void widgetSelected(SelectionEvent e) {
								input.setName("");
								input.setToolTipText("��ӳ�ƻ�ɾ��");
								try {
									PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input,DeleteShowPlanEditor.ID);
								} catch (PartInitException e1) {
									e1.printStackTrace();
								}
							}
						});
						button5.setText("\u4E0A\u6620\u8BA1\u5212\u5220\u9664");
						button5.setBounds(0, 35, 148, 40);
					}
				}
				expandItem.setHeight(250);
			}
		}
		{
			ExpandBar expandBar_1 = new ExpandBar(container, SWT.NONE);
			expandBar_1.setBounds(2, 10, 150, 180);
			{
				ExpandItem expandItem_1 = new ExpandItem(expandBar_1, 0);
				expandItem_1.setText("\u5F71\u7247\u7BA1\u7406");
				expandItem_1.setExpanded(true);
				{
					Composite composite3 = new Composite(expandBar_1, SWT.NONE);
					expandItem_1.setControl(composite3);
					{
						Button button7 = new Button(composite3, SWT.NONE);
						button7.addSelectionListener(new SelectionAdapter() {
							//ӰƬ����
							MyInput input=new MyInput();
							public void widgetSelected(SelectionEvent e) {
								input.setName("");
								input.setToolTipText("��Ӱ��Ϣ����");
								try {
									PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input,FilmAddEditor.ID);
								} catch (PartInitException e1) {
									e1.printStackTrace();
								}
							}
						});
						button7.setText("\u5F71\u7247\u4FE1\u606F\u6DFB\u52A0");
						button7.setBounds(0, 0, 145, 40);
					}
					{
						Button button8 = new Button(composite3, SWT.NONE);
						button8.addSelectionListener(new SelectionAdapter() {
							//ӰƬ��Ϣ�޸�
							MyInput input=new MyInput();
							public void widgetSelected(SelectionEvent e) {
								input.setName("");
								input.setToolTipText("ӰƬ��Ϣ�޸�");
								try {
									
									PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input, FilmUpdateEditor.ID);
								} catch (PartInitException e1) {
									e1.printStackTrace();
								}
							}
						});
						button8.setText("\u5F71\u7247\u4FE1\u606F\u4FEE\u6539");
						button8.setBounds(0, 36, 145, 40);
					}
					{
						Button button9 = new Button(composite3, SWT.NONE);
						button9.addSelectionListener(new SelectionAdapter() {
							//ӰƬɾ��
							public void widgetSelected(SelectionEvent e) {
								FilmDeleteDialog fdd=new FilmDeleteDialog(container.getShell(), SWT.NONE);
								fdd.open();
							}
						});
						button9.setText("\u5F71\u7247\u4FE1\u606F\u5220\u9664");
						button9.setBounds(0, 72, 145, 40);
					}
					{
						Button button10 = new Button(composite3, SWT.NONE);
						button10.addSelectionListener(new SelectionAdapter() {
							//ӰƬ��Ϣ��ѯ
							public void widgetSelected(SelectionEvent e) {
								FilmDeleteDialog fdd=new FilmDeleteDialog(container.getShell(), SWT.NONE);
								fdd.open();
							}
						});
						button10.setText("\u5F71\u7247\u4FE1\u606F\u67E5\u8BE2");
						button10.setBounds(0, 111, 145, 40);
					}
				}
				expandItem_1.setHeight(230);
			}
		}
		{
			ExpandBar expandBar = new ExpandBar(container, SWT.NONE);
			expandBar.setBounds(2, 194, 156, 150);
			expandBar.setBackgroundMode(SWT.INHERIT_FORCE);
			{
				ExpandItem expandItem = new ExpandItem(expandBar, 0);
				expandItem.setText("\u653E\u6620\u5385\u7BA1\u7406");
				expandItem.setExpanded(true);
				{
					Composite composite = new Composite(expandBar, SWT.NONE);
					expandItem.setControl(composite);
					{
						Button button = new Button(composite, SWT.NONE);
						button.addSelectionListener(new SelectionAdapter() {
							//��ӳ����Ϣ����
							MyInput input=new MyInput();
							public void widgetSelected(SelectionEvent e) {
								input.setName("");
								input.setToolTipText("��ӳ����Ϣ����");
								try {
									PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input,ShowRoomAddEditor.ID);
								} catch (PartInitException e1) {
									e1.printStackTrace();
								}
							}
						});
						button.setText("\u653E\u6620\u5385\u4FE1\u606F\u6DFB\u52A0");
						button.setBounds(0, 0, 148, 42);
					}
					{
						Button button = new Button(composite, SWT.NONE);
						button.addSelectionListener(new SelectionAdapter() {
							//��ӳ����Ϣ�޸�
							MyInput input=new MyInput();
							public void widgetSelected(SelectionEvent e) {
								input.setName("");
								input.setToolTipText("��ӳ����Ϣ�޸�");
								try {
									PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input,ShowRoomUpdateEditor.ID);
								} catch (PartInitException e1) {
									e1.printStackTrace();
								}
							}
						});
						button.setText("\u653E\u6620\u5385\u4FE1\u606F\u4FEE\u6539");
						button.setBounds(0, 40, 148, 42);
					}
					{
						Button button = new Button(composite, SWT.NONE);
						button.addSelectionListener(new SelectionAdapter() {
							//��ӳ����Ϣ�޸�
							MyInput input=new MyInput();
							public void widgetSelected(SelectionEvent e) {
								input.setName("");
								input.setToolTipText("��ӳ����Ϣ�޸�");
								try {
									PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input,ShowRoomUpdateEditor.ID);
								} catch (PartInitException e1) {
									e1.printStackTrace();
								}
							}
						});
						button.setText("\u653E\u6620\u5385\u4FE1\u606F\u5220\u9664");
						button.setBounds(0, 81, 148, 42);
					}
				}
				expandItem.setHeight(230);
			}
		}

		createActions();
		initializeToolBar();
		initializeMenu();
	}

	/**
	 * Create the actions.
	 */
	private void createActions() {
		// Create the actions
	}

	/**
	 * Initialize the toolbar.
	 */
	private void initializeToolBar() {
		IToolBarManager toolbarManager = getViewSite().getActionBars()
				.getToolBarManager();
	}

	/**
	 * Initialize the menu.
	 */
	private void initializeMenu() {
		IMenuManager menuManager = getViewSite().getActionBars()
				.getMenuManager();
	}

	@Override
	public void setFocus() {
		// Set the focus
	}

}
