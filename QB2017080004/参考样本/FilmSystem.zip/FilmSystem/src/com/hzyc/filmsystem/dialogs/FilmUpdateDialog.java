package com.hzyc.filmsystem.dialogs;

import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import com.hzyc.filmsystem.normals.SWTResourceManager;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import com.hzyc.filmsystem.normals.ResourceManager;

public class FilmUpdateDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text text;
	private Text text_1;
	private Text text_2;
	private Text text_3;
	private Text text_4;
	private Text text_5;
	private Text text_6;
	private String id;
	private JDBCUtil ju=new JDBCUtil();
	private MessageBox box;

	public FilmUpdateDialog(Shell parent, int style) {
		super(parent, style);
		setText("ӰƬ��Ϣ�޸�");
	}

	public Object open(String id) {
		this.id=id;
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		shell.setSize(811, 533);
		shell.setText(getText());
		shell.setBackgroundMode(SWT.INDETERMINATE);
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBounds(34, 23, 739, 450);
		
		Label lblId = new Label(composite, SWT.NONE);
		lblId.setBounds(24, 23, 32, 17);
		lblId.setText("id:");
		
		Label label = new Label(composite, SWT.NONE);
		label.setBounds(24, 65, 61, 17);
		label.setText("\u5F71\u7247\u540D\u79F0\uFF1A");
		
		Label label_1 = new Label(composite, SWT.NONE);
		label_1.setBounds(24, 107, 61, 17);
		label_1.setText(" \u56FD     \u5BB6\uFF1A");
		
		Label lblNewLabel = new Label(composite, SWT.NONE);
		lblNewLabel.setBounds(24, 152, 61, 17);
		lblNewLabel.setText("\u5BFC      \u6F14\uFF1A");
		
		Label label_2 = new Label(composite, SWT.NONE);
		label_2.setBounds(24, 199, 61, 17);
		label_2.setText("\u7247      \u957F\uFF1A");
		
		Label label_3 = new Label(composite, SWT.NONE);
		label_3.setBounds(24, 250, 61, 17);
		label_3.setText("\u8BED      \u8A00\uFF1A");
		
		Label label_4 = new Label(composite, SWT.NONE);
		label_4.setBounds(24, 304, 61, 17);
		label_4.setText("\u4E0A\u7EBF\u65F6\u95F4\uFF1A");
		
		Label label_5 = new Label(composite, SWT.NONE);
		label_5.setBounds(24, 353, 61, 17);
		label_5.setText("\u4E0B\u7EBF\u65F6\u95F4\uFF1A");
		
		text = new Text(composite, SWT.BORDER | SWT.READ_ONLY);
		text.setBounds(85, 23, 134, 23);
		
		text_1 = new Text(composite, SWT.BORDER);
		text_1.setBounds(85, 65, 239, 23);
		
		text_2 = new Text(composite, SWT.BORDER);
		text_2.setBounds(91, 107, 166, 23);
		
		text_3 = new Text(composite, SWT.BORDER);
		text_3.setBounds(91, 152, 166, 23);
		
		text_4 = new Text(composite, SWT.BORDER);
		text_4.setBounds(90, 193, 167, 23);
		
		text_5 = new Text(composite, SWT.BORDER);
		text_5.setBounds(91, 250, 166, 23);
		
		final DateTime dateTime = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);
		dateTime.setBounds(91, 304, 123, 24);
		
		final DateTime dateTime_1 = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);
		dateTime_1.setBounds(91, 353, 123, 24);
		
		Label label_6 = new Label(composite, SWT.NONE);
		label_6.setBounds(400, 26, 61, 17);
		label_6.setText("\u5185\u5BB9\u7B80\u4ECB\uFF1A");
		
		text_6 = new Text(composite, SWT.BORDER | SWT.WRAP | SWT.H_SCROLL | SWT.CANCEL | SWT.MULTI);
		text_6.setBounds(400, 59, 276, 262);
		
		
		Button button = new Button(composite, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			/*�ÿ�**/
			public void widgetSelected(SelectionEvent e) {
				text.setText("");
				text_1.setText("");
				text_2.setText("");
				text_3.setText("");
				text_4.setText("");
				text_5.setText("");
				dateTime.setDate(2012, 0, 1);
				dateTime_1.setDate(2012, 0, 1);
			}
		});
		button.setBounds(266, 365, 70, 23);
		button.setText("\u91CD  \u7F6E");
		
		Button button_1 = new Button(composite, SWT.BORDER);
		button_1.addKeyListener(new KeyAdapter() {
			//�޸�ӰƬ
			public void keyPressed(KeyEvent e) {
				
				String id=text.getText();
				String movie_name=text_1.getText();
				String country=text_2.getText();
				String director=text_3.getText();
				String movie_long=text_4.getText();
				String language=text_5.getText();
				String content_produce=text_6.getText();
				int year=dateTime.getYear();
				int month=dateTime.getMonth()+1;
				int day=dateTime.getDay();
				String online_date=year+"-"+month+"-"+day;
				int year_1=dateTime_1.getYear();
				int month_1=dateTime_1.getMonth()+1;
				int day_1=dateTime_1.getDay();
				String downline_date=year_1+"-"+month_1+"-"+day_1;
				String sql="insert into movie_info (movie_name,country,director,movie_long,language,content_produce,online_date,downline_date) values('"+movie_name+"','"+country+"','"+director+"','"+movie_long+"','"+language+"','"+content_produce+"','"+online_date+"','"+downline_date+"')";
				int r=ju.update(sql);
				if(r>0){
					
						box=new MessageBox(shell, SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("�޸ĳɹ�");
						box.open();
						shell.dispose();
					}else {
						box=new MessageBox(shell, SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("�޸�ʧ��");
						box.open();
					}
				
			}
		});
		button_1.addSelectionListener(new SelectionAdapter() {
			/*ȷ���޸�**/
			public void widgetSelected(SelectionEvent e) {
				String message = "��ȷ��Ҫ�޸ĸ�ӰƬ��Ϣ��";
				QuestionDialog qd = new QuestionDialog(shell, SWT.NONE);
				String result=qd.open(message).toString();
				if(result.equals("ok")){
					String id=text.getText();
					String movie_name=text_1.getText();
					String country=text_2.getText();
					String director=text_3.getText();
					String movie_long=text_4.getText();
					String language=text_5.getText();
					String content_produce=text_6.getText();
					int year=dateTime.getYear();
					int month=dateTime.getMonth()+1;
					int day=dateTime.getDay();
					String online_date=year+"-"+month+"-"+day;
					int year_1=dateTime_1.getYear();
					int month_1=dateTime_1.getMonth()+1;
					int day_1=dateTime_1.getDay();
					String downline_date=year_1+"-"+month_1+"-"+day_1;
					String sql="insert into movie_info (movie_name,country,director,movie_long,language,content_produce,online_date,downline_date) values('"+movie_name+"','"+country+"','"+director+"','"+movie_long+"','"+language+"','"+content_produce+"','"+online_date+"','"+downline_date+"')";
					int r=ju.update(sql);
					if(r>0){
						
							box=new MessageBox(shell, SWT.ICON_INFORMATION);
							box.setText("��ʾ��Ϣ");
							box.setMessage("�޸ĳɹ�");
							box.open();
							shell.dispose();
					}else {
							box=new MessageBox(shell, SWT.ICON_INFORMATION);
							box.setText("��ʾ��Ϣ");
							box.setMessage("�޸�ʧ��");
							box.open();
					}
				}
			}
		});
		button_1.setBounds(605, 377, 82, 45);
		button_1.setText("\u786E\u8BA4\u4FEE\u6539");
		
		Button button_2 = new Button(composite, SWT.NONE);
		button_2.addSelectionListener(new SelectionAdapter() {
			/**��Ӱ�����ÿ�*/
			public void widgetSelected(SelectionEvent e) {
				text_6.setText("");
			}
		});
		button_2.setBounds(537, 20, 55, 23);
		button_2.setText("\u91CD \u7F6E");
		
		/*��ӰƬ�޸�DialogĬ����ʾ���޸ĵ�ӰƬԭ��Ϣ*/
		String sql="select * from movie_info where id='"+id+"'";
		List<Map<String,Object>>list=ju.query(sql);
		Map<String,Object>map=list.get(0);
		text.setText(map.get("id").toString());
		text_1.setText(map.get("movie_name").toString());
		text_2.setText(map.get("country").toString());
		text_3.setText(map.get("director").toString());
		text_4.setText(map.get("movie_long").toString());
		text_5.setText(map.get("language").toString());
		int year=Integer.parseInt(map.get("online_date").toString().substring(0, 4));
		int month=Integer.parseInt(map.get("online_date").toString().substring(5, 7))-1;
		int day=Integer.parseInt(map.get("online_date").toString().substring(8));
		dateTime.setDate(year, month, day);
		int year_1=Integer.parseInt(map.get("downline_date").toString().substring(0, 4));
		int month_1=Integer.parseInt(map.get("downline_date").toString().substring(5, 7))-1;
		int day_1=Integer.parseInt(map.get("downline_date").toString().substring(8));
		dateTime_1.setDate(year_1, month_1, day_1);
		text_6.setText(map.get("content_produce").toString());

	}
}
