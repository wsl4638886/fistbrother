package com.hzyc.filmsystem.editors;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import com.hzyc.filmsystem.dialogs.FilmScanDialog;
import com.hzyc.filmsystem.dialogs.ScanShowHallDialog;
import com.hzyc.filmsystem.normals.ResourceManager;
import com.hzyc.filmsystem.normals.SWTResourceManager;

public class ShowPlanEditor extends EditorPart {

	public static final String ID = "com.hzyc.filmsystem.editors.ShowPlanEditor"; //$NON-NLS-1$

	private Table table;
	private Text text;
	private Text text_1;
	private Text text_4;
	private JDBCUtil ju=new JDBCUtil();
	private MessageBox box;
	private int page=1;
	private int pageSize=10;
	private Text text_2;

	public ShowPlanEditor() {
	}
	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setBackgroundMode(SWT.INDETERMINATE);
		
		final Composite composite = new Composite(container, SWT.NONE);
		composite.setBounds(10, 33, 925, 740);
		
		table = new Table(composite, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(10, 10, 819, 293);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tblclmnShowid = new TableColumn(table, SWT.NONE);
		tblclmnShowid.setWidth(56);
		tblclmnShowid.setText("id");
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(110);
		tableColumn.setText("\u653E\u6620\u5385\u540D\u79F0");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(123);
		tableColumn_1.setText("\u4E0A\u6620\u65F6\u95F4");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(88);
		tableColumn_2.setText("\u5F71\u7247\u7F16\u53F7");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(126);
		tableColumn_3.setText("\u5F00\u573A\u65F6\u95F4");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(223);
		tableColumn_4.setText("\u7ED3\u675F\u65F6\u95F4");
		
		TableColumn tableColumn_5 = new TableColumn(table, SWT.NONE);
		tableColumn_5.setWidth(88);
		tableColumn_5.setText("\u7968\u4EF7");
		
		
		
		Button button = new Button(composite, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			//ӰƬ�鿴
			public void widgetSelected(SelectionEvent e) {
				FilmScanDialog fsd=new FilmScanDialog(composite.getShell(), SWT.NONE);
				fsd.open();
				text_1.setText(fsd.m_id);
			}
		});
		button.setBounds(114, 364, 95, 27);
		button.setText("\u5F71\u7247\u67E5\u770B");
		
		Label label_1 = new Label(composite, SWT.NONE);
		label_1.setBounds(35, 369, 61, 17);
		label_1.setText("\u8BA1\u5212\u6DFB\u52A0\uFF1A");
		
		final Composite composite_1 = new Composite(composite, SWT.NONE);
		composite_1.setBounds(40, 399, 706, 224);
		
		Label label_2 = new Label(composite_1, SWT.NONE);
		label_2.setBounds(10, 10, 82, 35);
		label_2.setText("\u6620\u5385\u540D\u79F0\uFF1A");
		
		text = new Text(composite_1, SWT.BORDER);
		text.setFont(SWTResourceManager.getFont("����", 11, SWT.NORMAL));
		text.setBounds(104, 7, 173, 23);
		
		Label label_3 = new Label(composite_1, SWT.NONE);
		label_3.setBounds(10, 59, 82, 23);
		label_3.setText("\u4E0A\u6620\u65F6\u95F4\uFF1A");
		
		final DateTime dateTime = new DateTime(composite_1, SWT.BORDER | SWT.DROP_DOWN);
		dateTime.setBounds(104, 58, 105, 24);
		
		Label label_4 = new Label(composite_1, SWT.NONE);
		label_4.setBounds(10, 116, 82, 35);
		label_4.setText("\u5F71\u7247\u7F16\u53F7\uFF1A");
		
		text_1 = new Text(composite_1, SWT.BORDER);
		text_1.setBounds(104, 113, 173, 23);
		
		
		Label label_5 = new Label(composite_1, SWT.NONE);
		label_5.setBounds(10, 173, 82, 24);
		label_5.setText("\u5F00\u573A\u65F6\u95F4\uFF1A");
		
		final DateTime dateTime_1 = new DateTime(composite_1, SWT.BORDER | SWT.TIME | SWT.LONG);
		dateTime_1.setBounds(104, 173, 82, 24);
		
		Label label_7 = new Label(composite_1, SWT.NONE);
		label_7.setBounds(410, 10, 105, 17);
		label_7.setText("\u7968    \u4EF7\uFF1A");
		
		text_4 = new Text(composite_1, SWT.BORDER);
		text_4.setBounds(521, 7, 126, 23);
		
		Button button_1 = new Button(composite_1, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			//����
			public void widgetSelected(SelectionEvent e) {
				text.setText("");
				dateTime.setDate(2012, 0, 1);
				dateTime_1.setTime(12, 30, 30);
				text_1.setText("");
				text_4.setText("");
				
				
			}
		});
		button_1.setBounds(467, 149, 72, 35);
		button_1.setText("\u91CD \u7F6E");
		
		Button button_2 = new Button(composite_1, SWT.NONE);
		button_2.addSelectionListener(new SelectionAdapter() {
			//ȷ�����ӷ�ӳ�ƻ�
			public void widgetSelected(SelectionEvent e) {
				String hall_names=text.getText();//��ӳ������
				
				int year=dateTime.getYear();
				String month=(dateTime.getMonth()+1)<10 ?"0"+(dateTime.getMonth()+1):String.valueOf((dateTime.getMonth()+1));
				String day=dateTime.getDay()<10 ?"0"+dateTime.getDay():String.valueOf(dateTime.getDay());

				String show_date=year+"-"+month+"-"+day;//��ӳʱ��
				int film_id=Integer.parseInt(text_1.getText());//ӰƬid
				int movie_long=0;
				List<Map<String,Object>>list=ju.query("select movie_long,online_date,downline_date from movie_info where id="+film_id);
				String online_date=list.get(0).get("online_date").toString();
				String downline_date=list.get(0).get("downline_date").toString();
				if(show_date.compareTo(online_date)<0||show_date.compareTo(downline_date)>0){
					box=new MessageBox(composite_1.getShell(),SWT.ICON_INFORMATION);
					box.setText("��ʾ��Ϣ");
					box.setMessage("��ӳʱ������ڵ�Ӱ����ʱ��������ʱ��֮�䣬����������");
					box.open();
				}else{
					String s=list.get(0).get("movie_long").toString();//Ƭ����ʽ��120minute
					int l=s.indexOf("minute");
					String m_long=s.substring(0, l);//ȡ��120
					movie_long=Integer.parseInt(m_long);//ӰƬƬ��
					
					String hour=dateTime_1.getHours()<10 ?"0"+dateTime_1.getHours():String.valueOf(dateTime_1.getHours());
					String minute=dateTime_1.getMinutes()<10 ?"0"+dateTime_1.getMinutes():String.valueOf(dateTime_1.getMinutes());
					String second=dateTime_1.getSeconds()<10 ?"0"+dateTime_1.getSeconds():String.valueOf(dateTime_1.getSeconds());
					String s_time1=hour+":"+minute+":"+second;//����ʱ��
					String s_time=show_date+" "+hour+":"+minute+":"+second;//�����������ʱ��
					SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					int r=0;
					try {
						Date date = sdf.parse(s_time);
						long l1=date.getTime();//�ܺ�����
						long dl=movie_long*60*1000;//����
						long end=l1+dl;
						Date dt=new Date(end);
						String end_time= sdf.format(dt);//����ʱ��
					    double ticket_price=Double.parseDouble(text_4.getText());//Ʊ��
							String ticket_count=text_2.getText().toString();//Ʊ��
							List<Map<String,Object>>list1=ju.query("select * from show_plan where show_date='"+show_date+"' and hall_names='"+hall_names+"' and end_time between '"+s_time+"' and '"+end_time+"' or show_date='"+show_date+"' and hall_names='"+hall_names+"' and start_time between '"+s_time+"' and "+end_time+"'");
							if(list1.size()>0){
								box=new MessageBox(composite_1.getShell(), SWT.ICON_INFORMATION);
								box.setText("��ʾ��Ϣ");
								box.setMessage("�ƻ��г�ͻ����鿪��ʱ��");
								box.open();
							}else{
								String sql="insert into show_plan (hall_names,show_date,film_id,start_time,end_time,ticket_price,ticket_count)values('"+hall_names+"','"+show_date+"',"+film_id+",'"+s_time1+"','"+end_time+"',"+ticket_price+","+ticket_count+")";
								r=ju.update(sql);
							}
							
						 
					} catch (ParseException e1) {
						e1.printStackTrace();
					}
					   if(r>0){
						box=new MessageBox(composite_1.getShell(), SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("���ӳɹ�");
						box.open();
						table.removeAll();
						String sql_1="select * from show_plan";
						List<Map<String,Object>>list_1=ju.query(sql_1);
						
						for(Map<String,Object>map:list_1){
							TableItem tableItem = new TableItem(table, SWT.NONE);
							String[]st={map.get("show_id").toString(),map.get("hall_name").toString(),map.get("show_date").toString(),map.get("film_id").toString()
									,map.get("start_time").toString(),map.get("end_time").toString(),map.get("ticket_price").toString(),map.get("ticket_count").toString(),map.get("s_date").toString(),map.get("e_date").toString()};
							tableItem.setText(st);
						}
					}else {
						box=new MessageBox(composite_1.getShell(), SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("����ʧ��");
						box.open();
					}
				}
			}
		});
		button_2.setBounds(575, 146, 72, 38);
		button_2.setText("\u786E\u8BA4");
		
		Label label_6 = new Label(composite_1, SWT.NONE);
		label_6.setBounds(410, 59, 82, 17);
		label_6.setText("\u7968    \u6570\uFF1A");
		
		text_2 = new Text(composite_1, SWT.BORDER);
		text_2.setBounds(521, 56, 126, 23);
		
		
		
		
		Button button_3 = new Button(composite, SWT.NONE);
		button_3.addSelectionListener(new SelectionAdapter() {
			//��ӳ���鿴@Override
			public void widgetSelected(SelectionEvent e) {
				ScanShowHallDialog sdialog=new ScanShowHallDialog(composite.getShell(),SWT.NONE);
				sdialog.open();
				text.setText(sdialog.hall_name);
				text_2.setText(sdialog.seat_count);
			}
		});
		button_3.setBounds(245, 364, 80, 27);
		button_3.setText("\u653E\u6620\u5385\u67E5\u770B");
		
		Label label = new Label(container, SWT.NONE);
		label.setBounds(31, 10, 74, 17);
		label.setText("\u653E\u6620\u8BA1\u5212\u8868\uFF1A");
		
		String sql="select * from show_plan limit "+(page-1)*pageSize+","+pageSize;
		List<Map<String,Object>>list=new LinkedList<Map<String,Object>>();
		list=ju.query(sql);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			System.out.println(map.get("start_time"));
			System.out.println(map.get("end_time"));
			System.out.println(map.get("ticket_price"));
			System.out.println(map.get("ticket_count")+"---"+map.get("s_date")+"--"+map.get("e_date"));
			String[]s={map.get("show_id").toString(),map.get("hall_name").toString(),map.get("show_date").toString(),map.get("film_id").toString()
					,map.get("start_time").toString(),map.get("end_time").toString(),map.get("ticket_price").toString(),map.get("ticket_count").toString(),map.get("s_date").toString(),map.get("e_date").toString()};
			tableItem.setText(s);
		}

	}

	@Override
	public void setFocus() {
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
	}

	@Override
	public void doSaveAs() {
	}

	@Override
	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		this.setSite(site);
		this.setInput(input);
	}

	@Override
	public boolean isDirty() {
		return false;
	}

	@Override
	public boolean isSaveAsAllowed() {
		return false;
	}
	public void query(){
		table.removeAll();
		String sql="select * from show_plan limit "+(page-1)*pageSize+","+pageSize;
		List<Map<String,Object>>list=new LinkedList<Map<String,Object>>();
		list=ju.query(sql);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String[]s={map.get("show_id").toString(),map.get("hall_names").toString(),map.get("show_date").toString(),map.get("film_id").toString()
					,map.get("start_time").toString(),map.get("end_time").toString(),map.get("ticket_price").toString()};
			tableItem.setText(s);
		}
	}
}
