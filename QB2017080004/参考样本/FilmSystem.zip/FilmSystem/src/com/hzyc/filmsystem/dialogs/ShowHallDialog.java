package com.hzyc.filmsystem.dialogs;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import com.hzyc.filmsystem.normals.SWTResourceManager;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import com.hzyc.filmsystem.normals.ResourceManager;
import org.eclipse.swt.widgets.Link;

public class ShowHallDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Label label;
	private Table table;
	private TableColumn tableColumn;
	private TableColumn tableColumn_1;
	private TableColumn tableColumn_2;
	private TableColumn tableColumn_3;
	private TableItem tableItem;
	private List<Map<String,Object>>list=new LinkedList<Map<String,Object>>();
	private JDBCUtil ju=new JDBCUtil();
	public static String movie_id;
	private TableColumn tableColumn_4;
	private Button btnGo;
	private int page = 1;
	private int pageSize = 10;

	public ShowHallDialog(Shell parent, int style) {
		super(parent, style);
		setText("��ӳ��ʹ������");
	}

	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		shell.setBackgroundImage(ResourceManager.getPluginImage("cinema.management", "images/lan32_\u526F\u672Coo.jpg"));
		shell.setBackgroundMode(SWT.INDETERMINATE);
		shell.setSize(819, 608);
		shell.setText(getText());
		
		final DateTime dateTime = new DateTime(shell, SWT.BORDER | SWT.DROP_DOWN);
		dateTime.setBounds(124, 74, 104, 24);
		
		label = new Label(shell, SWT.NONE);
		label.setText("\u9009\u62E9\u65E5\u671F\uFF1A");
		label.setBounds(33, 74, 85, 24);
		
		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(79, 104, 653, 255);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(120);
		tableColumn.setText("\u653E\u6620\u5385\u540D\u79F0");
		
		tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(113);
		tableColumn_1.setText("\u7C7B\u578B");
		
		tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(146);
		tableColumn_2.setText("\u5F71\u7247\u540D\u79F0");
		
		tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(58);
		tableColumn_4.setText("\u8BED\u8A00");
		
		tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(171);
		tableColumn_3.setText("\u653E\u6620\u65F6\u95F4");
		
		Menu menu = new Menu(table);
		table.setMenu(menu);
		
		MenuItem menuItem = new MenuItem(menu, SWT.NONE);
		menuItem.addSelectionListener(new SelectionAdapter() {
			//�鿴ӰƬ��Ϣ
			public void widgetSelected(SelectionEvent e) {
				FilmInformationDialog fd=new FilmInformationDialog(shell, SWT.NONE);
				fd.open(movie_id);
			}
		});
		menuItem.setText("\u67E5\u770B\u5F71\u7247\u8BE6\u60C5");
		
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		button.setBounds(700, 454, 66, 27);
		button.setText("\u5173\u95ED");
		
		btnGo = new Button(shell, SWT.NONE);
		btnGo.addSelectionListener(new SelectionAdapter() {
			//��ӳ��ʹ������
			public void widgetSelected(SelectionEvent e) {
				Calendar cal1=Calendar.getInstance();
		        cal1.set(dateTime.getYear(), (dateTime.getMonth()), dateTime.getDay());
		        cal1.add(Calendar.DATE, 3);
		         Date  d= cal1.getTime();
		        
		        Calendar cal11=Calendar.getInstance();
		        cal11.set(dateTime.getYear(), (dateTime.getMonth()), dateTime.getDay());
		        cal11.add(Calendar.DATE, -3);
		        Date  d1= cal11.getTime();
		        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		        String d_1=sdf.format(d);
		        String d_2=sdf.format(d1);
				String sql="select movie_id,hall_name,show_id ,date,start_time from ticket_info where date between '"+d_2+"' and '"+d_1+"' group by hall_name  limit "+(page-1)*pageSize+","+pageSize;
				list=ju.query(sql);
				for(Map<String,Object>map:list){
					String hall_name=map.get("hall_name").toString();
					 movie_id=map.get("movie_id").toString();
					 String date=map.get("date").toString()+" "+map.get("start_time").toString();
					list=ju.query("select hall_type from show_hall where hall_name='"+hall_name+"'");
					for(Map<String,Object>map1:list){
						String hall_type=map1.get("hall_type").toString();
						list=ju.query("select movie_name,language from movie_info where id="+movie_id);
						for(Map<String,Object>map2:list){
							String movie_name=map2.get("movie_name").toString();
							String language=map2.get("language").toString();
							String []str={hall_name,hall_type,movie_name,language,date};
							tableItem = new TableItem(table, SWT.NONE);
							tableItem.setText(str);
						}
						
					}
				}
			}
		});
		btnGo.setBounds(713, 71, 53, 27);
		btnGo.setText("\u67E5\u8BE2");
		
		Link link = new Link(shell, SWT.NONE);
		link.addSelectionListener(new SelectionAdapter() {
			//��ҳ
			public void widgetSelected(SelectionEvent e) {
				page = 1;
				Calendar cal1=Calendar.getInstance();
		        cal1.set(dateTime.getYear(), (dateTime.getMonth()), dateTime.getDay());
		        cal1.add(Calendar.DATE, 3);
		         Date  d= cal1.getTime();
		        
		        Calendar cal11=Calendar.getInstance();
		        cal11.set(dateTime.getYear(), (dateTime.getMonth()), dateTime.getDay());
		        cal11.add(Calendar.DATE, -3);
		        Date  d1= cal11.getTime();
		        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		        String d_1=sdf.format(d);
		        String d_2=sdf.format(d1);
		        table.removeAll();
				search(d_2,d_1);
			}
		});
		link.setBounds(80, 390, 66, 27);
		link.setText("\u9996\u9875");
		
		Link link_1 = new Link(shell, 0);
		link_1.addSelectionListener(new SelectionAdapter() {
			//��һҳ
			public void widgetSelected(SelectionEvent e) {
				Calendar cal1=Calendar.getInstance();
		        cal1.set(dateTime.getYear(), (dateTime.getMonth()), dateTime.getDay());
		        cal1.add(Calendar.DATE, 3);
		         Date  d= cal1.getTime();
		        
		        Calendar cal11=Calendar.getInstance();
		        cal11.set(dateTime.getYear(), (dateTime.getMonth()), dateTime.getDay());
		        cal11.add(Calendar.DATE, -3);
		        Date  d1= cal11.getTime();
		        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		        String d_1=sdf.format(d);
		        String d_2=sdf.format(d1);
				String sql="select * from ticket_info where date between '"+d_2+"' and '"+d_1+"' group by hall_name";
				int count = ju.query(sql).size();
				if(count % pageSize == 0){
					if(page < count / pageSize){
						page++;
					}
				}else{
					if(page < count / pageSize +1){
						page++;
					}
				}
				table.removeAll();
				search(d_2,d_1);
			}
		});
		link_1.setText("\u4E0B\u4E00\u9875");
		link_1.setBounds(151, 390, 78, 27);
		
		Link link_2 = new Link(shell, 0);
		link_2.addSelectionListener(new SelectionAdapter() {
			//��һҳ
			public void widgetSelected(SelectionEvent e) {
				Calendar cal1=Calendar.getInstance();
		        cal1.set(dateTime.getYear(), (dateTime.getMonth()), dateTime.getDay());
		        cal1.add(Calendar.DATE, 3);
		         Date  d= cal1.getTime();
		        
		        Calendar cal11=Calendar.getInstance();
		        cal11.set(dateTime.getYear(), (dateTime.getMonth()), dateTime.getDay());
		        cal11.add(Calendar.DATE, -3);
		        Date  d1= cal11.getTime();
		        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		        String d_1=sdf.format(d);
		        String d_2=sdf.format(d1);
				if(page > 1){
					page--;
				}
				table.removeAll();
				search(d_2,d_1);
			}
		});
		link_2.setText("\u4E0A\u4E00\u9875");
		link_2.setBounds(260, 390, 78, 27);
		
		Link link_3 = new Link(shell, 0);
		link_3.addSelectionListener(new SelectionAdapter() {
			//βҳ
			public void widgetSelected(SelectionEvent e) {
				Calendar cal1=Calendar.getInstance();
		        cal1.set(dateTime.getYear(), (dateTime.getMonth()), dateTime.getDay());
		        cal1.add(Calendar.DATE, 3);
		         Date  d= cal1.getTime();
		        
		        Calendar cal11=Calendar.getInstance();
		        cal11.set(dateTime.getYear(), (dateTime.getMonth()), dateTime.getDay());
		        cal11.add(Calendar.DATE, -3);
		        Date  d1= cal11.getTime();
		        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		        String d_1=sdf.format(d);
		        String d_2=sdf.format(d1);
		        
		        String sql="select * from ticket_info where date between '"+d_2+"' and '"+d_1+"' group by hall_name";
				int count = ju.query(sql).size();
				if(count % pageSize == 0){
					page = count / pageSize;
				}else{
					page = count / pageSize+1;
					}
				table.removeAll();
				search(d_2,d_1);
			}
		});
		link_3.setText("\u5C3E\u9875");
		link_3.setBounds(355, 390, 66, 27);
		
	}
	
	public void search(String d_2,String d_1){
		String sql="select movie_id,hall_name,show_id ,date,start_time from ticket_info where date between '"+d_2+"' and '"+d_1+"' group by hall_name  limit "+(page-1)*pageSize+","+pageSize;
		list=ju.query(sql);
		for(Map<String,Object>map:list){
			String hall_name=map.get("hall_name").toString();
			 movie_id=map.get("movie_id").toString();
			 String date=map.get("date").toString()+" "+map.get("start_time").toString();
			list=ju.query("select hall_type from show_hall where hall_name='"+hall_name+"'");
			for(Map<String,Object>map1:list){
				String hall_type=map1.get("hall_type").toString();
				list=ju.query("select movie_name,language from movie_info where id="+movie_id);
				for(Map<String,Object>map2:list){
					String movie_name=map2.get("movie_name").toString();
					String language=map2.get("language").toString();
					String []str={hall_name,hall_type,movie_name,language,date};
					tableItem = new TableItem(table, SWT.NONE);
					tableItem.setText(str);
				}
			}
	     }
	}
}
