package com.hzyc.filmsystem.editors;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import com.hzyc.filmsystem.dialogs.QuestionDialog;
import com.hzyc.filmsystem.editors.ShowRoomUpdateEditor;
import com.hzyc.filmsystem.normals.SWTResourceManager;

public class ShowRoomUpdateEditor extends EditorPart {

	public static final String ID = "com.hzyc.filmsystem.editors.ShowRoomUpdateEditor"; //$NON-NLS-1$

	private Table table;
	private Text text;//����
	private JDBCUtil ju=new JDBCUtil();
	private MessageBox box;
	private Text text_3;//����
	private Text text_4;//����
	private Text text_1;

	public ShowRoomUpdateEditor() {
	}

	@Override
	public void createPartControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		container.setBackgroundMode(SWT.INDETERMINATE);
		
		table = new Table(container, SWT.BORDER | SWT.FULL_SELECTION | SWT.VIRTUAL);
		table.setBounds(23, 89, 404, 298);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(118);
		tableColumn.setText("\u540D  \u79F0");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(86);
		tableColumn_1.setText("\u7C7B  \u578B");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(77);
		tableColumn_2.setText("\u5EA7\u4F4D\u6570\u91CF");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(56);
		tableColumn_3.setText("\u6392\u6570");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(61);
		tableColumn_4.setText("\u884C\u6570");
		
		final Button button_2 = new Button(container, SWT.RADIO);
		button_2.setBounds(118, 509, 45, 17);
		button_2.setText("\u666E\u901A");
		
		final Button btnd = new Button(container, SWT.RADIO);
		btnd.setBounds(195, 509, 45, 17);
		btnd.setText("3D");
		
		final Button btnImax = new Button(container, SWT.RADIO);
		btnImax.setBounds(272, 509, 61, 17);
		btnImax.setText("IMAX");
		
		text = new Text(container, SWT.BORDER);
		text.setBounds(150, 443, 147, 23);
		
		Menu menu = new Menu(table);
		table.setMenu(menu);
		
		MenuItem menuItem = new MenuItem(menu, SWT.NONE);
		menuItem.addSelectionListener(new SelectionAdapter() {
			//ѡ��üƻ��޸�
			public void widgetSelected(SelectionEvent e) {
				TableItem[]items=table.getSelection();
				for(TableItem item:items){
					String hall_name=item.getText(0);
					text.setText(hall_name);
					String type=item.getText(1);
					if(type.equals("��ͨ")){
						button_2.setSelection(true);
					}else if(type.equals("3D")){
						btnd.setSelection(true);
					}else if(type.equals("IMAX")){
						btnImax.setSelection(true);
					}
					text_3.setText(item.getText(3));
					text_4.setText(item.getText(4));
					
				}
			}
		});
		menuItem.setText("\u9009\u62E9");
		
		
		/*Ĭ�ϴ�Editorʱtable��������**/
        List<Map<String,Object>>list=new LinkedList<Map<String,Object>>();
		String sql="select * from show_hall";
		list=ju.query(sql);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String []st={map.get("hall_name").toString(),map.get("hall_type").toString(),map.get("seat_count").toString(),map.get("row_count").toString(),map.get("column_count").toString()};
			tableItem.setText(st);
		}
		
		Label label_1 = new Label(container, SWT.NONE);
		label_1.setBounds(23, 408, 75, 23);
		label_1.setText("\u4FE1\u606F\u4FEE\u6539\uFF1A");
		
		Label label_2 = new Label(container, SWT.NONE);
		label_2.setBounds(36, 446, 45, 17);
		label_2.setText("\u540D \u79F0\uFF1A");
		
		
		Label label_3 = new Label(container, SWT.NONE);
		label_3.setBounds(36, 509, 45, 17);
		label_3.setText("\u7C7B \u578B\uFF1A");
		
		Label label_5 = new Label(container, SWT.NONE);
		label_5.setBounds(509, 67, 84, 17);
		label_5.setText("\u5EA7\u4F4D\u4F4D\u7F6E\u5B89\u6392\uFF1A");
		
		Label label_6 = new Label(container, SWT.NONE);
		label_6.setBounds(528, 110, 61, 17);
		label_6.setText("\u6392   \u6570\uFF1A");
		
		text_3 = new Text(container, SWT.BORDER);
		text_3.setBounds(615, 107, 97, 23);
		
		Label label_7 = new Label(container, SWT.NONE);
		label_7.setBounds(528, 164, 61, 17);
		label_7.setText("\u5217    \u6570\uFF1A");
		
		text_4 = new Text(container, SWT.BORDER);
		text_4.setBounds(615, 161, 97, 23);
		
		
		Button button_1 = new Button(container, SWT.BORDER);
		button_1.addKeyListener(new KeyAdapter() {
			//��ӳ���޸�@Override
			public void keyPressed(KeyEvent e) {
				e.keyCode=13;
				String hall_name=text.getText();
				String hall_type="";
				if(button_2.getSelection()){
					hall_type="��ͨ";
				}else if(btnd.getSelection()){
					hall_type="3D";
					
				}else if(btnImax.getSelection()){
					hall_type="IMAX";
				}
				
				int row_count=Integer.parseInt(text_3.getText());
				int column_count=Integer.parseInt(text_4.getText());
				int seat_count= row_count*column_count;
				String sql="update  show_hall set hall_type='"+hall_type+"',seat_count="+seat_count+",row_count="+row_count+",column_count="+column_count+" where hall_name='"+hall_name+"';";
				int a=ju.update(sql);
				int b=0;
				for(int i=1;i<=row_count;i++){
					for(int j=1;j<=column_count;j++){
						String sql_1="insert into seat_position(hall_name,row_num,column_num,flag)values('"+hall_name+"','"+i+"��','"+j+"��',1)";
						b=ju.update(sql_1);
					}
				}
				if(a>0&&b>0){
					box=new MessageBox(container.getShell(), SWT.ICON_INFORMATION);
					box.setText("��ʾ��Ϣ");
					box.setMessage("�޸ĳɹ�");
					box.open();
					
					/*����table�е�����**/
					table.removeAll();
					String sql_1="select * from show_hall";
					List<Map<String,Object>>list=ju.query(sql_1);
					table.removeAll();
					for(Map<String,Object>map:list){
						TableItem tableItem = new TableItem(table, SWT.NONE);
						String []st={map.get("hall_name").toString(),map.get("hall_type").toString(),map.get("seat_count").toString(),map.get("row_count").toString(),map.get("column_count").toString()};
						tableItem.setText(st);
					}
				}else {
					box=new MessageBox(container.getShell(), SWT.ICON_INFORMATION);
					box.setText("��ʾ��Ϣ");
					box.setMessage("�޸�ʧ��");
					box.open();
				}
				
				
				text.setText("");
				button_2.setSelection(false);
				btnd.setSelection(false);
				btnImax.setSelection(false);
				text_3.setText("");
				text_4.setText("");
			}
		});
		/**���ȷ���޸�*/
		button_1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				QuestionDialog qd = new QuestionDialog(container.getShell(), SWT.NONE);
				String message="��ȷ��Ҫ�޸ĸ�����Ϣ��";
				String result=qd.open(message).toString();
				if(result.equals("ok")){
					String hall_name=text.getText();
					String hall_type="";
					if(button_2.getSelection()){
						hall_type="��ͨ";
					}else if(btnd.getSelection()){
						hall_type="3D";
						
					}else if(btnImax.getSelection()){
						hall_type="IMAX";
					}

					int row_count=Integer.parseInt(text_3.getText());
					int column_count=Integer.parseInt(text_4.getText());
					int seat_count=row_count*column_count;
					String sql="update  show_hall set hall_type='"+hall_type+"',seat_count="+seat_count+",row_count="+row_count+",column_count="+column_count+" where hall_name='"+hall_name+"';";
					int a=ju.update(sql);
					int b=0;
					for(int i=1;i<=row_count;i++){
						for(int j=1;j<=column_count;j++){
							String sql_1="insert into seat_position(hall_name,row_num,column_num,flag)values('"+hall_name+"','"+i+"��','"+j+"��',1)";
							b=ju.update(sql_1);
						}
					}
					if(a>0&&b>0){
						box=new MessageBox(container.getShell(), SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("�޸ĳɹ�");
						box.open();
						
						/*����table�е�����**/
						table.removeAll();
						String sql_1="select * from show_hall";
						List<Map<String,Object>>list=ju.query(sql_1);
						table.removeAll();
						for(Map<String,Object>map:list){
							TableItem tableItem = new TableItem(table, SWT.NONE);
							String []st={map.get("hall_name").toString(),map.get("hall_type").toString(),map.get("seat_count").toString(),map.get("row_count").toString(),map.get("column_count").toString()};
							tableItem.setText(st);
						}
					}else {
						box=new MessageBox(container.getShell(), SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("�޸�ʧ��");
						box.open();
					}
					
					
					text.setText("");
					button_2.setSelection(false);
					btnd.setSelection(false);
					btnImax.setSelection(false);
					text_3.setText("");
					text_4.setText("");
				}
			}
		});
		button_1.setBounds(587, 607, 84, 43);
		button_1.setText("\u786E\u8BA4\u4FEE\u6539");
		
		text_1 = new Text(container, SWT.NONE);
		text_1.setText("\u653E\u6620\u5385\u4FE1\u606F\uFF1A");
		text_1.setBounds(22, 47, 97, 23);

	}

	@Override
	public void setFocus() {
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
	}

	@Override
	public void doSaveAs() {
	}

	@Override
	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		this.setSite(site);
		this.setInput(input);
	}

	@Override
	public boolean isDirty() {
		return false;
	}

	@Override
	public boolean isSaveAsAllowed() {
		return false;
	}
}
