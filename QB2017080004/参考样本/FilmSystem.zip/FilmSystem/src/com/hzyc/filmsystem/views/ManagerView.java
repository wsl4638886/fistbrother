package com.hzyc.filmsystem.views;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.ExpandBar;
import org.eclipse.swt.widgets.ExpandItem;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import com.hzyc.filmsystem.dialogs.DeleteManagerDialog;
import com.hzyc.filmsystem.dialogs.FilmDeleteDialog;
import com.hzyc.filmsystem.dialogs.ManagerAddDialog;
import com.hzyc.filmsystem.dialogs.QuestionDialog;
import com.hzyc.filmsystem.dialogs.ShowHallDeleteDialog;
import com.hzyc.filmsystem.dialogs.ShowHallDialog;
import com.hzyc.filmsystem.editors.DeleteShowPlanEditor;
import com.hzyc.filmsystem.editors.FilmAddEditor;
import com.hzyc.filmsystem.editors.FilmUpdateEditor;
import com.hzyc.filmsystem.editors.PercentageEditor;
import com.hzyc.filmsystem.editors.SellSearchEditor;
import com.hzyc.filmsystem.editors.ShowPlanEditor;
import com.hzyc.filmsystem.editors.ShowRoomAddEditor;
import com.hzyc.filmsystem.editors.ShowRoomUpdateEditor;
import com.hzyc.filmsystem.input.MyInput;
import com.hzyc.filmsystem.normals.ResourceManager;
import com.hzyc.filmsystem.normals.SWTResourceManager;
import com.hzyc.filmsystem.platform.Application;

public class ManagerView extends ViewPart {

	public static final String ID = "com.hzyc.filmsystem.views.ManagerView"; //$NON-NLS-1$
	public ManagerView() {
	}

	public void createPartControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		container.setBackgroundMode(SWT.INDETERMINATE);
		
		ExpandBar expandBar = new ExpandBar(container, SWT.NONE);
		expandBar.setFont(SWTResourceManager.getFont("����", 18, SWT.BOLD));
		expandBar.setBounds(108, 111, 243, 389);
		expandBar.setBackgroundMode(SWT.INDETERMINATE);
		
		final Composite composite = new Composite(expandBar, SWT.NONE);
		
		Button button = new Button(composite, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			//��ӳ����Ϣ����
			MyInput input=new MyInput();
			public void widgetSelected(SelectionEvent e) {
				input.setName("");
				input.setToolTipText("��ӳ����Ϣ����");
				try {
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input,ShowRoomAddEditor.ID);
				} catch (PartInitException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		button.setBounds(21, 10, 109, 27);
		button.setText("\u653E\u6620\u5385\u4FE1\u606F\u6DFB\u52A0");
		
		Button button_1 = new Button(composite, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			//��ӳ����Ϣ�޸�
			MyInput input=new MyInput();
			public void widgetSelected(SelectionEvent e) {
				input.setName("");
				input.setToolTipText("��ӳ����Ϣ�޸�");
				try {
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input,ShowRoomUpdateEditor.ID);
				} catch (PartInitException e1) {
					e1.printStackTrace();
				}
			}
		});
		button_1.setBounds(21, 43, 109, 27);
		button_1.setText("\u653E\u6620\u5385\u4FE1\u606F\u4FEE\u6539");
		
		Button button_2 = new Button(composite, SWT.NONE);
		button_2.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				//��ӳ��ʹ������
				ShowHallDialog sd=new ShowHallDialog(container.getShell(), SWT.NONE);
				sd.open();
			}
		});
		button_2.setBounds(21, 76, 109, 27);
		button_2.setText("\u653E\u6620\u5385\u4FE1\u606F\u67E5\u8BE2");
		
		Button button_7 = new Button(composite, SWT.NONE);
		button_7.addSelectionListener(new SelectionAdapter() {
			//��ӳ��ɾ��
			public void widgetSelected(SelectionEvent e) {
				ShowHallDeleteDialog ahdd=new ShowHallDeleteDialog(composite.getShell(), SWT.NONE);
				ahdd.open();
			}
		});
		button_7.setText("\u653E\u6620\u5385\u4FE1\u606F\u5220\u9664");
		button_7.setBounds(21, 109, 109, 27);
		
		final Composite composite_1 = new Composite(expandBar, SWT.NONE);
		
		Button button_3 = new Button(composite_1, SWT.NONE);
		button_3.addSelectionListener(new SelectionAdapter() {
			//ӰƬ��Ϣ����
			MyInput input=new MyInput();
			public void widgetSelected(SelectionEvent e) {
				input.setName("");
				input.setToolTipText("��Ӱ��Ϣ����");
				try {
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input,FilmAddEditor.ID);
				} catch (PartInitException e1) {
					e1.printStackTrace();
				}
			}
		});
		button_3.setBounds(22, 10, 105, 27);
		button_3.setText("\u5F71\u7247\u4FE1\u606F\u6DFB\u52A0");
		
		Button button_4 = new Button(composite_1, SWT.NONE);
		button_4.addSelectionListener(new SelectionAdapter() {
			//ӰƬ��Ϣ�޸�
			MyInput input=new MyInput();
			public void widgetSelected(SelectionEvent e) {
				input.setName("");
				input.setToolTipText("ӰƬ��Ϣ�޸�");
				try {
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input, FilmUpdateEditor.ID);
				} catch (PartInitException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		button_4.setText("\u5F71\u7247\u4FE1\u606F\u4FEE\u6539");
		button_4.setBounds(22, 43, 105, 27);
		
		Button button_8 = new Button(composite_1, SWT.NONE);
		button_8.addSelectionListener(new SelectionAdapter() {
			//ӰƬ��Ϣɾ��
			public void widgetSelected(SelectionEvent e) {
				FilmDeleteDialog fdd=new FilmDeleteDialog(composite_1.getShell(), SWT.NONE);
				fdd.open();
			}
		});
		button_8.setText("\u5F71\u7247\u4FE1\u606F\u5220\u9664");
		button_8.setBounds(22, 72, 105, 27);
		
		Composite composite_2 = new Composite(expandBar, SWT.NONE);
		
		Button button_5 = new Button(composite_2, SWT.NONE);
		button_5.addSelectionListener(new SelectionAdapter() {
			//��ӳ�ƻ�����
			MyInput input=new MyInput();
			public void widgetSelected(SelectionEvent e) {
				input.setName("");
				input.setToolTipText("��ӳ�ƻ�����");
				try {
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input, ShowPlanEditor.ID);
				} catch (PartInitException e1) {
					e1.printStackTrace();
				}
			}
		});
		button_5.setBounds(24, 10, 102, 27);
		button_5.setText("\u4E0A\u6620\u8BA1\u5212\u6DFB\u52A0");
		
		Button button_9 = new Button(composite_2, SWT.NONE);
		button_9.addSelectionListener(new SelectionAdapter() {
			//��ӳ�ƻ�ɾ��
			MyInput input=new MyInput();
			public void widgetSelected(SelectionEvent e) {
				input.setName("");
				input.setToolTipText("��ӳ�ƻ�ɾ��");
				try {
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input, DeleteShowPlanEditor.ID);
				} catch (PartInitException e1) {
					e1.printStackTrace();
				}
			}
		});
		button_9.setText("\u4E0A\u6620\u8BA1\u5212\u5220\u9664");
		button_9.setBounds(24, 43, 102, 27);
		
		ExpandItem expandItem_2 = new ExpandItem(expandBar, SWT.NONE);
		expandItem_2.setExpanded(true);
		expandItem_2.setText("    \u7EFC\u5408\u4FE1\u606F\u67E5\u8BE2\u7EDF\u8BA1");
		
		Composite composite_3 = new Composite(expandBar, SWT.NONE);
		expandItem_2.setControl(composite_3);
		
		Button button_6 = new Button(composite_3, SWT.NONE);
		button_6.setFont(SWTResourceManager.getFont("����", 15, SWT.NORMAL));
		button_6.addSelectionListener(new SelectionAdapter() {
			//������ϸ��ѯ
			MyInput input = new MyInput();
			public void widgetSelected(SelectionEvent e) {
				input.setName("");
				input.setToolTipText("������ϸ��ѯ");
				try {
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input, SellSearchEditor.ID);
				} catch (PartInitException e1) {
					e1.printStackTrace();
				}
			}
		});
		button_6.setBounds(30, 10, 154, 43);
		button_6.setText("\u9500\u552E\u660E\u7EC6");
		
		Button btnNewButton = new Button(composite_3, SWT.NONE);
		btnNewButton.setFont(SWTResourceManager.getFont("����", 15, SWT.NORMAL));
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			//�����ʼ����۶�ͳ��
			MyInput input = new MyInput();
			public void widgetSelected(SelectionEvent e) {
				input.setName("");
				input.setToolTipText("�����ʼ����۶�ͳ��");
				try {
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().openEditor(input, PercentageEditor.ID);
				} catch (PartInitException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(33, 66, 151, 43);
		btnNewButton.setText("\u4E1A\u52A1\u67E5\u8BE2");
		expandItem_2.setHeight(120);
		
		ExpandItem expandItem_3 = new ExpandItem(expandBar, SWT.NONE);
		expandItem_3.setExpanded(true);
		expandItem_3.setText("    \u7BA1\u7406\u5458\u4FE1\u606F");
		
		final Composite composite_4 = new Composite(expandBar, SWT.NONE);
		expandItem_3.setControl(composite_4);
		
		Button button_10 = new Button(composite_4, SWT.NONE);
		button_10.setFont(SWTResourceManager.getFont("����", 15, SWT.NORMAL));
		button_10.addSelectionListener(new SelectionAdapter() {
			/**����Ա��Ϣ����*/
			public void widgetSelected(SelectionEvent e) {
				ManagerAddDialog ma=new ManagerAddDialog(composite_4.getShell(), SWT.NONE);
				ma.open();
			}
		});
		button_10.setBounds(36, 10, 152, 39);
		button_10.setText("\u7BA1\u7406\u5458\u4FE1\u606F\u6DFB\u52A0");
		
		Button button_12 = new Button(composite_4, SWT.NONE);
		button_12.setFont(SWTResourceManager.getFont("����", 15, SWT.NORMAL));
		button_12.addSelectionListener(new SelectionAdapter() {
			//**����Ա��Ϣ��ѯ
			public void widgetSelected(SelectionEvent e) {
               DeleteManagerDialog dmd=new DeleteManagerDialog(composite_4.getShell(), SWT.NONE);
				dmd.open();
				
			}
		});
		button_12.setText("\u7BA1\u7406\u5458\u4FE1\u606F\u67E5\u8BE2");
		button_12.setBounds(36, 68, 152, 39);
		expandItem_3.setHeight(130);
		
		Button button_11 = new Button(container, SWT.NONE);
		button_11.addSelectionListener(new SelectionAdapter() {
			//�˳�@Override
			public void widgetSelected(SelectionEvent e) {
				QuestionDialog qd = new QuestionDialog(container.getShell(), SWT.NONE);
				String message="��ȷ��Ҫ�˳��ý��棿";
				String result=qd.open(message).toString();
				if(result.equals("ok")){
					Application a=new Application();
				    a.stop();
				    try {
						a.start(null);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		button_11.setFont(SWTResourceManager.getFont("����", 14, SWT.BOLD));
		button_11.setBounds(64, 610, 95, 37);
		button_11.setText("\u9000 \u51FA");
		

		createActions();
		initializeToolBar();
		initializeMenu();
	}

	private void createActions() {
	}

	private void initializeToolBar() {
		IToolBarManager toolbarManager = getViewSite().getActionBars()
				.getToolBarManager();
	}

	private void initializeMenu() {
		IMenuManager menuManager = getViewSite().getActionBars()
				.getMenuManager();
	}

	@Override
	public void setFocus() {
	}
}
