package com.hzyc.filmsystem.views;

import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import com.hzyc.filmsystem.dialogs.UpdateShowPlanDialog;
import com.hzyc.filmsystem.normals.ResourceManager;
import com.hzyc.filmsystem.normals.SWTResourceManager;

public class ShowPlanManageEditor extends EditorPart {

	public static final String ID = "com.hzyc.filmsystem.views.ShowPlanManageEditor"; //$NON-NLS-1$

	private Table table;
	private int page=1;
	private int pageSize=20;
	private JDBCUtil ju;

	public ShowPlanManageEditor() {
	}

	
	public void createPartControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		container.setBackgroundMode(SWT.INDETERMINATE);
		
		table = new Table(container, SWT.BORDER | SWT.FULL_SELECTION);
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		table.setFont(SWTResourceManager.getFont("΢���ź�", 10, SWT.NORMAL));
		table.setBounds(43, 135, 944, 456);
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(62);
		tableColumn.setText("id");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(141);
		tableColumn_1.setText("\u653E\u6620\u5385\u540D\u79F0");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(127);
		tableColumn_2.setText("\u4E0A\u6620\u65F6\u95F4");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(102);
		tableColumn_3.setText("\u5F71\u7247id");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(130);
		tableColumn_4.setText("\u5F00\u573A\u65F6\u95F4");
		
		TableColumn tableColumn_5 = new TableColumn(table, SWT.NONE);
		tableColumn_5.setWidth(190);
		tableColumn_5.setText("\u7ED3\u675F\u65F6\u95F4");
		
		TableColumn tableColumn_6 = new TableColumn(table, SWT.NONE);
		tableColumn_6.setWidth(87);
		tableColumn_6.setText("\u7968\u4EF7");
		
		TableColumn tableColumn_7 = new TableColumn(table, SWT.NONE);
		tableColumn_7.setWidth(100);
		tableColumn_7.setText("\u7968\u6570");
		
		Menu menu = new Menu(table);
		table.setMenu(menu);
		
		MenuItem menuItem_1 = new MenuItem(menu, SWT.NONE);
		menuItem_1.addSelectionListener(new SelectionAdapter() {
			//ˢ��
			public void widgetSelected(SelectionEvent e) {
				table.removeAll();
				List<Map<String,Object>>list=ju.query("select * from show_plan limit "+(page-1)*pageSize+","+pageSize);
				for(Map<String,Object>map:list){
					TableItem tableItem = new TableItem(table, SWT.NONE);
					String []st={map.get("show_id").toString(),map.get("hall_names").toString(),map.get("show_date").toString(),map.get("film_id").toString(),
							map.get("start_time").toString(),map.get("end_time").toString(),map.get("ticket_price").toString(),map.get("ticket_count").toString()};
					tableItem.setText(st);
			}
			}
		});
		menuItem_1.setText("\u5237 \u65B0");
		
		MenuItem menuItem = new MenuItem(menu, SWT.NONE);
		menuItem.addSelectionListener(new SelectionAdapter() {
			//��ӳ�ƻ��޸�
			public void widgetSelected(SelectionEvent e) {
				TableItem []items = table.getSelection();
				for(TableItem item : items){
					String show_id=item.getText();
					UpdateShowPlanDialog dsp = new UpdateShowPlanDialog(container.getShell(), SWT.NONE);
					dsp.open(show_id);
				}
				
			}
		});
		menuItem.setText("\u4FEE\u6539\u8BE5\u8BA1\u5212");
		
		Label label = new Label(container, SWT.NONE);
		label.setFont(SWTResourceManager.getFont("����", 23, SWT.BOLD));
		label.setBounds(262, 40, 405, 31);
		label.setText("\u4E0A  \u6620  \u8BA1  \u5212  \u8BE6  \u60C5");
		
		Link link = new Link(container, SWT.NONE);
		link.addSelectionListener(new SelectionAdapter() {
			//��ҳ
			public void widgetSelected(SelectionEvent e) {
				page = 1;
				query();
			}
		});
		link.setFont(SWTResourceManager.getFont("����", 18, SWT.BOLD));
		link.setBounds(43, 613, 61, 31);
		link.setText("<a>\u9996\u9875</a>");
		
		Link link_1 = new Link(container, 0);
		link_1.addSelectionListener(new SelectionAdapter() {
			//��һҳ
			public void widgetSelected(SelectionEvent e) {
				int count = ju.query("select * from show_plan").size();
				if(count % pageSize == 0){
					if(page < count / pageSize){
						page++;
					}
				}else{
					if(page < count / pageSize +1){
						page++;
					}
				}
				query();
			}
		});
		link_1.setText("<a>\u4E0B\u4E00\u9875</a>");
		link_1.setFont(SWTResourceManager.getFont("����", 18, SWT.BOLD));
		link_1.setBounds(110, 613, 84, 31);
		
		Link link_2 = new Link(container, 0);
		link_2.addSelectionListener(new SelectionAdapter() {
			//��һҳ
			public void widgetSelected(SelectionEvent e) {
				if(page > 1){
					page--;
				}
				query();
			}
		});
		link_2.setText("<a>\u4E0A\u4E00\u9875</a>");
		link_2.setFont(SWTResourceManager.getFont("����", 18, SWT.BOLD));
		link_2.setBounds(200, 613, 84, 31);
		
		Link link_3 = new Link(container, 0);
		link_3.addSelectionListener(new SelectionAdapter() {
			//βҳ
			public void widgetSelected(SelectionEvent e) {
				int pageCount = ju.query("select * from show_plan").size();
				if(pageCount % pageSize == 0){
					page=pageCount / pageSize;
				}else{
					page = pageCount / pageSize + 1;
				}
				query();
			}
		});
		link_3.setText("<a>\u5C3E\u9875</a>");
		link_3.setFont(SWTResourceManager.getFont("����", 18, SWT.BOLD));
		link_3.setBounds(290, 613, 61, 31);
		
		List<Map<String,Object>>list=ju.query("select * from show_plan limit "+(page-1)*pageSize+","+pageSize);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String []st={map.get("show_id").toString(),map.get("hall_name").toString(),map.get("show_date").toString(),map.get("film_id").toString(),
					map.get("start_time").toString(),map.get("end_time").toString(),map.get("ticket_price").toString(),map.get("ticket_count").toString(),map.get("s_date").toString(),map.get("e_date").toString()};
			tableItem.setText(st);
	    }

	}

	public void setFocus() {
	}

	public void doSave(IProgressMonitor monitor) {
	}

	public void doSaveAs() {
	}

	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		this.setSite(site);
		this.setInput(input);
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isSaveAsAllowed() {
		return false;
	}
	
	public void query(){
		table.removeAll();
		List<Map<String,Object>>list=ju.query("select * from show_plan limit "+(page-1)*pageSize+","+pageSize);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String []st={map.get("show_id").toString(),map.get("hall_names").toString(),map.get("show_date").toString(),map.get("film_id").toString(),
					map.get("start_time").toString(),map.get("end_time").toString(),map.get("ticket_price").toString(),map.get("ticket_count").toString()};
			tableItem.setText(st);
	}
	}
}
