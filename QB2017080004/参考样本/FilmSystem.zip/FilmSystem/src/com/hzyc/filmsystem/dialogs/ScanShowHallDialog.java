package com.hzyc.filmsystem.dialogs;

import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import com.hzyc.filmsystem.normals.SWTResourceManager;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import com.hzyc.filmsystem.normals.ResourceManager;

public class ScanShowHallDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Table table;
	private JDBCUtil ju=new JDBCUtil();
	public static String hall_name;
	public static String seat_count;
	

	public ScanShowHallDialog(Shell parent, int style) {
		super(parent, style);
		setText("��ӳ��������Ϣ��ѯ");
	}

	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		shell.setBackgroundMode(SWT.INDETERMINATE);
		shell.setSize(635, 585);
		shell.setText(getText());
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBounds(57, 33, 498, 469);
		
		table = new Table(composite, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(66, 10, 398, 440);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(148);
		tableColumn.setText("\u653E\u6620\u5385\u540D\u79F0");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(116);
		tableColumn_1.setText("\u7C7B\u578B");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(98);
		tableColumn_2.setText("\u5EA7\u4F4D\u6570\u91CF");
		
		Menu menu = new Menu(table);
		table.setMenu(menu);
		
		MenuItem menuItem = new MenuItem(menu, SWT.NONE);
		menuItem.addSelectionListener(new SelectionAdapter() {
			//ѡ��÷�ӳ��@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[]items=table.getSelection();
				for(TableItem item:items){
					hall_name=item.getText(0);
					seat_count=item.getText(2);
				}
			}
		});
		menuItem.setText("\u9009\u62E9\u8BE5\u653E\u6620\u5385");
		
		Button btnNewButton = new Button(shell, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		btnNewButton.setBounds(504, 508, 71, 27);
		btnNewButton.setText("\u5173\u95ED");
		String sql="select hall_name,hall_type,seat_count from show_hall";
		List<Map<String,Object>>list=ju.query(sql);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String[] ss={map.get("hall_name").toString(),map.get("hall_type").toString(),map.get("seat_count").toString()};
			tableItem.setText(ss);
		}

	}

}
