package com.hzyc.filmsystem.dialogs;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import com.hzyc.filmsystem.normals.ResourceManager;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import com.hzyc.filmsystem.normals.SWTResourceManager;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Button;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class UpdateShowPlanDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text text_1;
	private Text text_2;
	private Text text_3;
	private Text text;
	private String show_id;
	private JDBCUtil ju;
	private MessageBox box;

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style  ��ӳ�ƻ��޸�
	 */
	public UpdateShowPlanDialog(Shell parent, int style) {
		super(parent, style);
		setText("��ӳ�ƻ��޸�");
	}

	
	public Object open(String show_id) {
		this.show_id=show_id;
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(887, 491);
		shell.setText(getText());
		shell.setBackgroundMode(SWT.INDETERMINATE);
		
		final Composite composite = new Composite(shell, SWT.NONE);
		composite.setBounds(86, 125, 706, 298);
		
		Label label = new Label(composite, SWT.NONE);
		label.setText("\u6620\u5385\u540D\u79F0\uFF1A");
		label.setBounds(10, 21, 96, 35);
		
		Label label_1 = new Label(composite, SWT.NONE);
		label_1.setText("\u4E0A\u6620\u65F6\u95F4\uFF1A");
		label_1.setBounds(10, 88, 96, 23);
		
		final DateTime dateTime = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);//��ӳʱ��
		dateTime.setBounds(112, 88, 105, 24);
		
		Label label_2 = new Label(composite, SWT.NONE);
		label_2.setText("\u5F71\u7247\u7F16\u53F7\uFF1A");
		label_2.setBounds(10, 153, 96, 35);
		
		text_1 = new Text(composite, SWT.BORDER);//ӰƬ���
		text_1.setBounds(112, 153, 173, 23);
		
		Label label_3 = new Label(composite, SWT.NONE);
		label_3.setText("\u5F00\u573A\u65F6\u95F4\uFF1A");
		label_3.setBounds(10, 215, 96, 24);
		
		final DateTime dateTime_1 = new DateTime(composite, SWT.BORDER | SWT.TIME | SWT.LONG);//����ʱ��
		dateTime_1.setBounds(112, 215, 82, 24);
		
		Label label_4 = new Label(composite, SWT.NONE);
		label_4.setText("\u7968  \u4EF7\uFF1A");
		label_4.setBounds(359, 21, 85, 35);
		
		text_2 = new Text(composite, SWT.BORDER);//Ʊ��
		text_2.setBounds(455, 18, 126, 23);
		
		Button button = new Button(composite, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			//����
			public void widgetSelected(SelectionEvent e) {
				text.setText("");
				dateTime.setDate(2012,3,30);
				text_1.setText("");
				dateTime_1.setTime(12,30,30);
				text_2.setText("");
			}
		});
		button.setText("\u91CD \u7F6E");
		button.setBounds(369, 152, 55, 27);
		
		Button button_1 = new Button(composite, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			//ȷ���޸�
			public void widgetSelected(SelectionEvent e) {
				QuestionDialog qd = new QuestionDialog(shell, SWT.NONE);
				String message="��ȷ��Ҫ�޸ĸ�����Ϣ��";
				String result=qd.open(message).toString();
				if(result.equals("ok")){
					String hall_names=text.getText();//��ӳ������
					
					int year=dateTime.getYear();
					String month=(dateTime.getMonth()+1)<10 ?"0"+(dateTime.getMonth()+1):String.valueOf((dateTime.getMonth()+1));
					String day=dateTime.getDay()<10 ?"0"+dateTime.getDay():String.valueOf(dateTime.getDay());

					String show_date=year+"-"+month+"-"+day;//��ӳʱ��
					int film_id=Integer.parseInt(text_1.getText());//ӰƬid
					int movie_long=0;
					List<Map<String,Object>>list=ju.query("select movie_long,online_date,downline_date from movie_info where id="+film_id);
					String online_date=list.get(0).get("online_date").toString();
					String downline_date=list.get(0).get("downline_date").toString();
					if(show_date.compareTo(online_date)<0||show_date.compareTo(downline_date)>0){
						box=new MessageBox(composite.getShell(),SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("��ӳʱ������ڵ�Ӱ����ʱ��������ʱ��֮�䣬����������");
						box.open();
					}else{
						String s=list.get(0).get("movie_long").toString();//Ƭ����ʽ��120minute
						int l=s.indexOf("minute");
						String m_long=s.substring(0, l);//ȡ��120
						movie_long=Integer.parseInt(m_long);//ӰƬƬ��
						
						String hour=dateTime_1.getHours()<10 ?"0"+dateTime_1.getHours():String.valueOf(dateTime_1.getHours());
						String minute=dateTime_1.getMinutes()<10 ?"0"+dateTime_1.getMinutes():String.valueOf(dateTime_1.getMinutes());
						String second=dateTime_1.getSeconds()<10 ?"0"+dateTime_1.getSeconds():String.valueOf(dateTime_1.getSeconds());
						String s_time1=hour+":"+minute+":"+second;//����ʱ��
						String s_time=show_date+" "+hour+":"+minute+":"+second;//�����������ʱ��
						SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						int r=0;
						try {
							Date date = sdf.parse(s_time);
							long l1=date.getTime();//�ܺ�����
							long dl=movie_long*60*1000;//����
							long end=l1+dl;
							Date dt=new Date(end);
							String end_time= sdf.format(dt);//����ʱ��
						    double ticket_price=Double.parseDouble(text_2.getText());//Ʊ��
								String ticket_count=text_3.getText().toString();//Ʊ��
								List<Map<String,Object>>list1=ju.query("select * from show_plan where show_date='"+show_date+"' and hall_names='"+hall_names+"' and end_time between '"+s_time+"' and '"+end_time+"' or show_date='"+show_date+"' and hall_names='"+hall_names+"' and start_time between '"+s_time+"' and "+end_time+"'");
								if(list1.size()>0){
									box=new MessageBox(composite.getShell(), SWT.ICON_INFORMATION);
									box.setText("��ʾ��Ϣ");
									box.setMessage("�ƻ��г�ͻ����鿪��ʱ��");
									box.open();
								}else{
									String sql="insert into show_plan (hall_names,show_date,film_id,start_time,end_time,ticket_price,ticket_count)values('"+hall_names+"','"+show_date+"',"+film_id+",'"+s_time1+"','"+end_time+"',"+ticket_price+","+ticket_count+")";
									r=ju.update(sql);
								}
						} catch (ParseException e1) {
							e1.printStackTrace();
						}
						   if(r>0){
							box=new MessageBox(composite.getShell(), SWT.ICON_INFORMATION);
							box.setText("��ʾ��Ϣ");
							box.setMessage("�޸ĳɹ�");
							box.open();
							
						   }else {
							   box=new MessageBox(composite.getShell(), SWT.ICON_INFORMATION);
							   box.setText("��ʾ��Ϣ");
							   box.setMessage("�޸�ʧ��");
							   box.open();
						  }
					}
				}
			}
		});
		button_1.setText("\u786E\u8BA4\u4FEE\u6539");
		button_1.setBounds(564, 223, 72, 38);
		
		Label label_5 = new Label(composite, SWT.NONE);
		label_5.setText("\u5EA7\u4F4D\u6570\uFF1A");
		label_5.setBounds(359, 88, 94, 34);
		
		text_3 = new Text(composite, SWT.BORDER | SWT.READ_ONLY);//Ʊ��
		text_3.setBounds(455, 89, 126, 23);
		
		text = new Text(composite, SWT.BORDER);//Ӱ������
		text.setBounds(112, 21, 173, 23);
		
		Button button_2 = new Button(shell, SWT.NONE);
		button_2.addSelectionListener(new SelectionAdapter() {
			//ӰƬ�鿴
			public void widgetSelected(SelectionEvent e) {
				FilmScanDialog fsd=new FilmScanDialog(composite.getShell(), SWT.NONE);
				fsd.open();
				text_1.setText(fsd.m_id);
			}
		});
		button_2.setBounds(86, 82, 92, 27);
		button_2.setText("\u5F71\u7247\u67E5\u770B");
		
		Button button_3 = new Button(shell, SWT.NONE);
		button_3.addSelectionListener(new SelectionAdapter() {
			//��ӳ���鿴
			public void widgetSelected(SelectionEvent e) {
				ScanShowHallDialog sdialog=new ScanShowHallDialog(composite.getShell(),SWT.NONE);
				sdialog.open();
				text.setText(sdialog.hall_name);
				text_3.setText(sdialog.seat_count);
			}
		});
		button_3.setText("\u653E\u6620\u5385\u67E5\u770B");
		button_3.setBounds(213, 82, 92, 27);
		
		List<Map<String,Object>>list = ju.query("select * from show_plan where show_id="+show_id);
		for(Map<String,Object>map:list){
			String hall_names = map.get("hall_names").toString();
			String show_date = map.get("show_date").toString();
			String [] t = show_date.split("-");
			String film_id = map.get("film_id").toString();
			String start_time = map.get("start_time").toString();
			String []t1 = start_time.split(":");
			String ticket_price = map.get("ticket_price").toString();
			String ticket_count = map.get("ticket_count").toString();
			text.setText(hall_names);
			dateTime.setDate(Integer.parseInt(t[0]), Integer.parseInt(t[1]), Integer.parseInt(t[2]));
			text_1.setText(film_id);
			dateTime_1.setTime(Integer.parseInt(t1[0]), Integer.parseInt(t1[1]), Integer.parseInt(t1[2]));
			text_2.setText(ticket_price);
			text_3.setText(ticket_count);
		}

	}

}
