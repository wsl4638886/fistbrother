package com.hzyc.filmsystem.editors;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import com.hzyc.filmsystem.normals.ResourceManager;
import com.hzyc.filmsystem.normals.SWTResourceManager;

public class FilmAddEditor extends EditorPart {

	public static final String ID = "com.hzyc.filmsystem.editors.FilmAddEditor"; //$NON-NLS-1$

	private Text text;
	private Text text_1;
	private Text text_2;
	private Text text_3;
	private Text text_4;
	private Text text_5;
	private JDBCUtil ju=new JDBCUtil();
	private MessageBox box;

	public FilmAddEditor() {
	}

	public void createPartControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		container.setBackgroundMode(SWT.INDETERMINATE);
		
		final Composite composite = new Composite(container, SWT.NONE);
		composite.setBounds(20, 22, 711, 653);
		
		Label label = new Label(composite, SWT.NONE);
		label.setBounds(28, 44, 61, 17);
		label.setText("\u7535\u5F71\u540D\u79F0\uFF1A");
		
		text = new Text(composite, SWT.BORDER);
		text.setBounds(120, 44, 186, 23);
		
		Label label_1 = new Label(composite, SWT.NONE);
		label_1.setBounds(28, 97, 61, 17);
		label_1.setText("\u56FD      \u5BB6\uFF1A");
		
		text_1 = new Text(composite, SWT.BORDER);
		text_1.setBounds(120, 94, 186, 23);
		
		Label label_2 = new Label(composite, SWT.NONE);
		label_2.setBounds(28, 140, 61, 17);
		label_2.setText("\u5BFC      \u6F14\uFF1A");
		
		text_2 = new Text(composite, SWT.BORDER);
		text_2.setBounds(120, 134, 186, 23);
		
		Label label_3 = new Label(composite, SWT.NONE);
		label_3.setBounds(28, 186, 61, 17);
		label_3.setText("\u65F6      \u957F\uFF1A");
		
		text_3 = new Text(composite, SWT.BORDER);
		text_3.setBounds(120, 180, 73, 23);
		
		Label label_4 = new Label(composite, SWT.NONE);
		label_4.setBounds(28, 232, 61, 17);
		label_4.setText("\u8BED      \u8A00\uFF1A");
		
		text_4 = new Text(composite, SWT.BORDER);
		text_4.setBounds(121, 226, 185, 23);
		
		Label label_5 = new Label(composite, SWT.NONE);
		label_5.setBounds(378, 44, 61, 17);
		label_5.setText("\u5185\u5BB9\u7B80\u4ECB\uFF1A");
		
		text_5 = new Text(composite, SWT.BORDER | SWT.WRAP | SWT.H_SCROLL | SWT.CANCEL | SWT.MULTI);
		text_5.setFont(SWTResourceManager.getFont("����", 14, SWT.NORMAL));
		text_5.setBounds(388, 72, 296, 308);
		
		Label label_6 = new Label(composite, SWT.NONE);
		label_6.setBounds(28, 290, 61, 17);
		label_6.setText("\u4E0A\u7EBF\u65F6\u95F4\uFF1A");
		
		final DateTime dateTime = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);
		dateTime.setBounds(121, 283, 109, 24);
		
		Label label_7 = new Label(composite, SWT.NONE);
		label_7.setBounds(28, 345, 61, 17);
		label_7.setText("\u4E0B\u7EBF\u65F6\u95F4\uFF1A");
		
		final DateTime dateTime_1 = new DateTime(composite, SWT.BORDER | SWT.DROP_DOWN);
		dateTime_1.setBounds(120, 338, 110, 24);
		
		Button button = new Button(composite, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			//ˢ��
			public void widgetSelected(SelectionEvent e) {
				text.setText("");
				text_1.setText("");
				text_2.setText("");
				text_3.setText("");
				text_4.setText("");
				dateTime.setDate(2012, 01, 01);
				dateTime_1.setDate(2012, 01, 01);
				
			}
		});
		button.setBounds(78, 401, 61, 27);
		button.setText("\u91CD\u7F6E");
		
		Button btnNewButton = new Button(composite, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			//ӰƬ����
			public void widgetSelected(SelectionEvent e) {
				String movie_name=text.getText();
				String country=text_1.getText();
				String director=text_2.getText();
				String movie_long=text_3.getText();
				String language=text_4.getText();
				String content_produce=text_5.getText();
				int year=dateTime.getYear();
				int month=dateTime.getMonth()+1;
				int day=dateTime.getDay();
				int year_1=dateTime_1.getYear();
				int month_1=dateTime_1.getMonth()+1;
				int day_1=dateTime_1.getDay();
				String sql="insert into movie_info(movie_name,country,director,movie_long,language,content_produce,online_date,downline_date) values('"+movie_name+"','"+country+"','"+director+"','"+movie_long+"minute','"+language+"','"+content_produce+"','"+year+"-"+month+"-"+day+"','"+year_1+"-"+month_1+"-"+day_1+"');";
				System.out.println(sql);
				int r=ju.update(sql);
				if(r>0){
					
						box=new MessageBox(composite.getShell(), SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("���ӳɹ�");
						box.open();
					}else {
						box=new MessageBox(composite.getShell(), SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("����ʧ��");
						box.open();
					}
				}
			
			
		});
		btnNewButton.setBounds(590, 540, 80, 40);
		btnNewButton.setText("\u786E\u8BA4\u6DFB\u52A0");
		
		Button button_2 = new Button(composite, SWT.NONE);
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				text_5.setText("");
			}
		});
		button_2.setBounds(475, 430, 61, 22);
		button_2.setText("\u5185\u5BB9\u91CD\u7F6E");
		
		Label lblNewLabel = new Label(composite, SWT.NONE);
		lblNewLabel.setBounds(199, 186, 61, 17);
		lblNewLabel.setText("minutes");

	}

	public void setFocus() {
	}

	public void doSave(IProgressMonitor monitor) {
	}

	public void doSaveAs() {
	}

	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		this.setSite(site);
		this.setInput(input);
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isSaveAsAllowed() {
		return false;
	}
}
