package com.hzyc.filmsystem.dialogs;

import java.util.List;
import java.util.Map;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import com.hzyc.filmsystem.normals.SWTResourceManager;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.widgets.Link;
import com.hzyc.filmsystem.normals.ResourceManager;

public class FilmDeleteDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Table table;
	private JDBCUtil ju=new JDBCUtil();
	private MessageBox box;
	private int page=1;
	private int pageSize=20;

	public FilmDeleteDialog(Shell parent, int style) {
		super(parent, style);
		setText("ӰƬ��Ϣɾ��");
	}

	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		shell.setSize(1064, 730);
		shell.setText("\u5F71\u7247\u4FE1\u606F");
		
		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(35, 79, 996, 461);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tblclmnMovieid = new TableColumn(table, SWT.NONE);
		tblclmnMovieid.setWidth(70);
		tblclmnMovieid.setText("movie_id");
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(132);
		tableColumn.setText("\u5F71\u7247\u540D\u79F0");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(75);
		tableColumn_1.setText("\u56FD\u5BB6");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(88);
		tableColumn_2.setText("\u5BFC\u6F14");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(79);
		tableColumn_3.setText("\u7247\u957F");
		
		TableColumn tableColumn_5 = new TableColumn(table, SWT.NONE);
		tableColumn_5.setWidth(68);
		tableColumn_5.setText("\u8BED\u8A00");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(193);
		tableColumn_4.setText("\u5185\u5BB9\u7B80\u4ECB");
		
		TableColumn tblclmnOnlinedate = new TableColumn(table, SWT.NONE);
		tblclmnOnlinedate.setWidth(132);
		tblclmnOnlinedate.setText("online_date");
		
		TableColumn tblclmnDownlinedate = new TableColumn(table, SWT.NONE);
		tblclmnDownlinedate.setWidth(128);
		tblclmnDownlinedate.setText("downline_date");
		
		
		
		Menu menu = new Menu(table);
		table.setMenu(menu);
		
		MenuItem menuItem = new MenuItem(menu, SWT.NONE);
		menuItem.addSelectionListener(new SelectionAdapter() {
			//ӰƬɾ��
			public void widgetSelected(SelectionEvent e) {
			    String message = "��ȷ��Ҫɾ����ӰƬ��";
				QuestionDialog qd = new QuestionDialog(shell, SWT.NONE);
				String result=qd.open(message).toString();
				if(result.equals("ok")){
					TableItem[]items=table.getSelection();
					for(TableItem item:items){
						String id=item.getText(0);
						int r=ju.update("delete from movie_info where id="+id);
						if(r>0){
							box=new MessageBox(shell,SWT.ICON_INFORMATION);
							box.setText("��ʾ��Ϣ");
							box.setMessage("ɾ���ɹ�");
							box.open();
						}else{
							box=new MessageBox(shell,SWT.ICON_INFORMATION);
							box.setText("��ʾ��Ϣ");
							box.setMessage("ɾ��ʧ��");
							box.open();
						}
					}
				}
			}
		});
		menuItem.setText("\u5220\u9664");
		
		MenuItem menuItem_1 = new MenuItem(menu, SWT.NONE);
		menuItem_1.addSelectionListener(new SelectionAdapter() {
			//ˢ��
			public void widgetSelected(SelectionEvent e) {
				table.removeAll();
				List<Map<String,Object>>list=ju.query("select * from movie_info");
				for(Map<String,Object>map:list){
					TableItem tableItem = new TableItem(table, SWT.NONE);
					String[] st={map.get("id").toString(),map.get("movie_name").toString(),map.get("country").toString(),map.get("director").toString()
							,map.get("movie_long").toString(),map.get("language").toString(),map.get("content_produce").toString(),map.get("online_date").toString(),
							map.get("downline_date").toString()};
					tableItem.setText(st);
			}
				
			}
		});
		menuItem_1.setText("\u5237\u65B0");
		
		
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		button.setText("\u5173\u95ED");
		button.setBounds(681, 18, 80, 27);
		
		Link link = new Link(shell, SWT.NONE);
		link.addSelectionListener(new SelectionAdapter() {
			//��ҳ
			public void widgetSelected(SelectionEvent e) {
				page=1;
				table.removeAll();
				List<Map<String,Object>>list=ju.query("select * from movie_info limit "+(page-1)*pageSize+","+pageSize);
				for(Map<String,Object>map:list){
					TableItem tableItem = new TableItem(table, SWT.NONE);
					String[] st={map.get("id").toString(),map.get("movie_name").toString(),map.get("country").toString(),map.get("director").toString()
							,map.get("movie_long").toString(),map.get("language").toString(),map.get("content_produce").toString(),map.get("online_date").toString(),
							map.get("downline_date").toString()};
					tableItem.setText(st);
				}
			}
		});
		
		
		link.setBounds(60, 580, 59, 27);
		link.setText(" <a>\u9996\u9875</a>");
		
		Link link_1 = new Link(shell, SWT.NONE);
		link_1.addSelectionListener(new SelectionAdapter() {
			//��һҳ
			public void widgetSelected(SelectionEvent e) {
				String sqlCount = "select * from movie_info";
				int count = ju.query(sqlCount).size();
				if (count % pageSize == 0) {
					if (page < count / pageSize) {
						page++;
					}
				} else {
					if (page < count / pageSize + 1) {
						page++;
					}
				}
				table.removeAll();
				List<Map<String,Object>>list=ju.query("select * from movie_info limit "+(page-1)*pageSize+","+pageSize);
				for(Map<String,Object>map:list){
					TableItem tableItem = new TableItem(table, SWT.NONE);
					String[] st={map.get("id").toString(),map.get("movie_name").toString(),map.get("country").toString(),map.get("director").toString()
							,map.get("movie_long").toString(),map.get("language").toString(),map.get("content_produce").toString(),map.get("online_date").toString(),
							map.get("downline_date").toString()};
					tableItem.setText(st);
				}
			}
		});
		
		
		link_1.setBounds(142, 580, 70, 27);
		link_1.setText(" <a>\u4E0B\u4E00\u9875</a>");
		
		Link link_2 = new Link(shell, SWT.NONE);
		link_2.addSelectionListener(new SelectionAdapter() {
		   //��һҳ
			public void widgetSelected(SelectionEvent e) {
				if(page>1){
					page--;
				}
				table.removeAll();
				List<Map<String,Object>>list=ju.query("select * from movie_info limit "+(page-1)*pageSize+","+pageSize);
				for(Map<String,Object>map:list){
					TableItem tableItem = new TableItem(table, SWT.NONE);
					String[] st={map.get("id").toString(),map.get("movie_name").toString(),map.get("country").toString(),map.get("director").toString()
							,map.get("movie_long").toString(),map.get("language").toString(),map.get("content_produce").toString(),map.get("online_date").toString(),
							map.get("downline_date").toString()};
					tableItem.setText(st);
				}
			}
		});
		
		
		link_2.setBounds(247, 580, 70, 27);
		link_2.setText(" <a>\u4E0A\u4E00\u9875</a>");
		
		Link link_3 = new Link(shell, SWT.NONE);
		link_3.addSelectionListener(new SelectionAdapter() {
			//βҳ
			public void widgetSelected(SelectionEvent e) {
				String sqlCount="select * from movie_info";
				int count=ju.query(sqlCount).size();
				if(count%pageSize==0){
					page=count/pageSize;
				}else {
					page=count/pageSize+1;
				}
				table.removeAll();
				List<Map<String,Object>>list=ju.query("select * from movie_info limit "+(page-1)*pageSize+","+pageSize);
				for(Map<String,Object>map:list){
					TableItem tableItem = new TableItem(table, SWT.NONE);
					String[] st={map.get("id").toString(),map.get("movie_name").toString(),map.get("country").toString(),map.get("director").toString()
							,map.get("movie_long").toString(),map.get("language").toString(),map.get("content_produce").toString(),map.get("online_date").toString(),
							map.get("downline_date").toString()};
					tableItem.setText(st);
				}
			}
		});
		
	
		link_3.setBounds(355, 580, 59, 27);
		link_3.setText(" <a>\u5C3E\u9875</a>");
		
		List<Map<String,Object>>list=ju.query("select * from movie_info limit "+(page-1)*pageSize+","+pageSize);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String[] st={map.get("id").toString(),map.get("movie_name").toString(),map.get("country").toString(),map.get("director").toString()
					,map.get("movie_long").toString(),map.get("language").toString(),map.get("content_produce").toString(),map.get("online_date").toString(),
					map.get("downline_date").toString()};
			tableItem.setText(st);
		}
		

	}
}
