package com.hzyc.filmsystem.editors;

import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import com.hzyc.filmsystem.editors.DeleteShowPlanEditor;
import com.hzyc.filmsystem.normals.SWTResourceManager;

public class DeleteShowPlanEditor extends EditorPart {

	public static final String ID = "com.hzyc.filmsystem.editors.DeleteShowPlanEditor"; //$NON-NLS-1$

	private Table table;
	private JDBCUtil ju=new JDBCUtil();
	private MessageBox box;
	private int page=1;
	private int pageSize=20;

	public DeleteShowPlanEditor() {
	}

	public void createPartControl(Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		
		Label label = new Label(container, SWT.NONE);
		label.setBounds(22, 41, 175, 28);
		label.setText("\u653E\u6620\u8BA1\u5212\u8BE6\u60C5\uFF1A");
		
		table = new Table(container, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(0, 98, 944, 622);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tblclmnId = new TableColumn(table, SWT.NONE);
		tblclmnId.setWidth(62);
		tblclmnId.setText("id");
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(141);
		tableColumn.setText("\u653E\u6620\u5385\u540D\u79F0");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(127);
		tableColumn_1.setText("\u4E0A\u6620\u65F6\u95F4");
		
		TableColumn tblclmnid = new TableColumn(table, SWT.NONE);
		tblclmnid.setWidth(102);
		tblclmnid.setText("\u5F71\u7247id");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(130);
		tableColumn_2.setText("\u5F00\u573A\u65F6\u95F4");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(190);
		tableColumn_3.setText("\u7ED3\u675F\u65F6\u95F4");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(87);
		tableColumn_4.setText("\u7968\u4EF7");
		
		TableColumn tableColumn_5 = new TableColumn(table, SWT.NONE);
		tableColumn_5.setWidth(100);
		tableColumn_5.setText("\u7968\u6570");
		
		
		
		Menu menu = new Menu(table);
		table.setMenu(menu);
		
		MenuItem menuItem = new MenuItem(menu, SWT.NONE);
		menuItem.addSelectionListener(new SelectionAdapter() {
			//ɾ����ӳ�ƻ�
			public void widgetSelected(SelectionEvent e) {
				TableItem []items=table.getSelection();
				for(TableItem item:items){
					String show_id=item.getText(0);
					String hall_names=item.getText(1);
					String show_date=item.getText(2);
					String film_id=item.getText(3);
					String start_time=item.getText(4);
					String end_time=item.getText(5);
					String ticket_price=item.getText(6);
					String ticket_count=item.getText(7);
					String sql="insert into restor_show_plan values("+show_id+",'"+hall_names+"','"+show_date+"',"+film_id+",'"+start_time+"','"+end_time+"',"+
					ticket_price+","+ticket_count+")";
					int res=ju.update(sql);
					
					int rs=ju.update("delete from show_plan where show_id="+show_id);
					if(rs>0){
						box=new MessageBox(container.getShell(), SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("ɾ���ɹ�");
						box.open();
						update();
					}else{
						box=new MessageBox(container.getShell(), SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("ɾ��ʧ��");
						box.open();
					}
				}
			}
		});
		menuItem.setText("\u5220 \u9664");
		
		MenuItem menuItem_1 = new MenuItem(menu, SWT.NONE);
		menuItem_1.addSelectionListener(new SelectionAdapter() {
            //ˢ��
			public void widgetSelected(SelectionEvent e) {
				update();
			}
		});
		menuItem_1.setText("\u5237 \u65B0");
		
		Link link = new Link(container, SWT.NONE);
		link.addSelectionListener(new SelectionAdapter() {
			//��ҳ
			public void widgetSelected(SelectionEvent e) {
				page=1;
				update();
			}
		});
		link.setBounds(65, 585, 81, 27);
		link.setText(" \u9996\u9875");
		
		Link link_1 = new Link(container, 0);
		link_1.addSelectionListener(new SelectionAdapter() {
			//��һҳ
			public void widgetSelected(SelectionEvent e) {
				String sqlCount = "select * from show_plan";
				int count = ju.query(sqlCount).size();
				if (count % pageSize == 0) {
					if (page < count / pageSize) {
						page++;
					}
				} else {
					if (page < count / pageSize + 1) {
						page++;
					}
				}
				
				update();
			}
		});
		link_1.setText(" \u4E0B\u4E00\u9875");
		link_1.setBounds(152, 585, 95, 27);
		
		Link link_2 = new Link(container, 0);
		link_2.addSelectionListener(new SelectionAdapter() {
			//��һҳ
			public void widgetSelected(SelectionEvent e) {
				if(page>1){
					page--;
				}
				update();
			}
		});
		link_2.setText(" \u4E0A\u4E00\u9875");
		link_2.setBounds(265, 585, 95, 27);
		
		Link link_3 = new Link(container, 0);
		link_3.addSelectionListener(new SelectionAdapter() {
			//βҳ
			public void widgetSelected(SelectionEvent e) {
				String sqlCount="select * from show_plan";
				int count=ju.query(sqlCount).size();
				if(count%pageSize==0){
					page=count/pageSize;
				}else {
					page=count/pageSize+1;
				}
				update();
			}
		});
		link_3.setText(" \u5C3E\u9875");
		link_3.setBounds(382, 585, 81, 27);
		List<Map<String,Object>>list=ju.query("select * from show_plan limit "+(page-1)*pageSize+","+pageSize);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String []st={map.get("show_id").toString(),map.get("hall_name").toString(),map.get("show_date").toString(),map.get("film_id").toString(),
					map.get("start_time").toString(),map.get("end_time").toString(),map.get("ticket_price").toString(),map.get("ticket_count").toString(),map.get("s_date").toString(),map.get("e_date").toString()};
			tableItem.setText(st);
		}

	}

	public void setFocus() {
	}

	public void doSave(IProgressMonitor monitor) {
	}

	public void doSaveAs() {
	}

	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		this.setSite(site);
		this.setInput(input);
	}

	public boolean isDirty() {
		return false;
	}

	@Override
	public boolean isSaveAsAllowed() {
		return false;
	}
	public void update(){
		table.removeAll();
		List<Map<String,Object>>list=ju.query("select * from show_plan limit "+(page-1)*pageSize+","+pageSize);
		for(Map<String,Object>map:list){
			TableItem tableItem = new TableItem(table, SWT.NONE);
			String []st={map.get("show_id").toString(),map.get("hall_names").toString(),map.get("show_date").toString(),map.get("film_id").toString(),
					map.get("start_time").toString(),map.get("end_time").toString(),map.get("ticket_price").toString(),map.get("ticket_count").toString()};
			tableItem.setText(st);
	}
	}

}
