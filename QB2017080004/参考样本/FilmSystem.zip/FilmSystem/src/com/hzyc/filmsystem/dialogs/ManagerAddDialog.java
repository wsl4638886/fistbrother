package com.hzyc.filmsystem.dialogs;

import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import com.hzyc.filmsystem.normals.SWTResourceManager;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;
import org.eclipse.swt.custom.CCombo;
import com.hzyc.filmsystem.normals.ResourceManager;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.widgets.Combo;

public class ManagerAddDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text text;
	private Text text_1;
	private Text text_2;
	private JDBCUtil ju=new JDBCUtil();
	private MessageBox box;
	private Text text_8;
	private Button button_2;
	private Text text_10;
	private Label label;
	private Label label_1;
	private Label label_2;
	private Label label_3;
	private Label label_4;
	private Label label_5;
	private Label label_6;
	

	public ManagerAddDialog(Shell parent, int style) {
		super(parent, style);
		setText("����Աע��");
	}

	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN | SWT.APPLICATION_MODAL);
		shell.setBackground(SWTResourceManager.getColor(175, 238, 238));
		shell.setSize(719, 521);
		shell.setText(getText());
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBackgroundMode(SWT.INDETERMINATE);
		composite.setBounds(0, 0, 713, 493);
		
		text = new Text(composite, SWT.BORDER);
		text.setForeground(SWTResourceManager.getColor(230, 230, 250));
		text.setBounds(178, 48, 156, 23);
		
		final Button button = new Button(composite, SWT.RADIO);
		button.setBounds(198, 108, 47, 23);
		button.setText("\u7537");
		
		final Button button_1 = new Button(composite, SWT.RADIO);
		button_1.setBounds(283, 104, 51, 30);
		button_1.setText("\u5973");
		
		text_1 = new Text(composite, SWT.BORDER);
		text_1.addKeyListener(new KeyAdapter() {
			//�˺��ж�@Override
			String count="";
			public void keyPressed(KeyEvent e) {
				if(e.keyCode==8){
					char a=e.character;
					count="";
			    }else{
			    	char[]a={e.character};
				    count=count+new String(a);
				    StringTokenizer s = new StringTokenizer(count);
				    char []ss = s.toString().toCharArray();
				    
				    }
				    
			    }
			}
		);
		text_1.setForeground(SWTResourceManager.getColor(211, 211, 211));
		text_1.setBounds(198, 156, 156, 23);
		
		text_2 = new Text(composite, SWT.BORDER | SWT.READ_ONLY);
		text_2.setEnabled(false);
		text_2.setForeground(SWTResourceManager.getColor(112, 128, 144));
		text_2.setBounds(198, 207, 156, 23);
		text_2.setText("12345678");
		
		final Combo combo = new Combo(composite, SWT.READ_ONLY);
		combo.setItems(new String[] {"\u7ECF\u7406", "\u5F71\u7247\u7BA1\u7406\u5458", "\u653E\u6620\u5385\u7BA1\u7406\u5458", "\u4E0A\u6620\u8BA1\u5212\u7BA1\u7406\u5458"});
		combo.setBounds(198, 348, 156, 25);
		combo.select(0);
		
		final Button button_3 = new Button(composite, SWT.NONE);
		button_3.addKeyListener(new KeyAdapter() {
			/*����Ա��Ϣ����**/
			public void keyPressed(KeyEvent e) {
				if(e.character==SWT.CTRL){
					String manager_name=text.getText();
					String sex="";
					if(button.getSelection()){
						sex="��";
					}else if(button_1.getSelection()){
						sex="Ů";
					}
					String manager_ID=text_1.getText();
					int l=ju.query("select * from manager_info where manager_ID='"+manager_ID+"'").size();
					if(l>0){
						box=new MessageBox(shell, SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("���˺��Ѵ��ڣ�����������");
						box.open();
					}else{
						String password=text_2.getText();
						String call=text_8.getText();
						String pass=text_10.getText();
						String role=combo.getSelection().toString();
						String authority="";
						if(role.equals("����")){
							authority="M";
						}else if(role.equals("ӰƬ����Ա")){
							authority="film";
						}else if(role.equals("��ӳ������Ա")){
							authority = "hall";
						}else if(role.equals("��ӳ�ƻ�����Ա")){
							authority = "plan";
						}
						String sql="insert into manager_info values('"+manager_name+"','"+sex+"','"+manager_ID+"','"+password+"','"+call+"','"+pass+"','"+role+"','"+authority+"')";
						int row=ju.update(sql);
						if(row>0){
							box=new MessageBox(shell, SWT.ICON_INFORMATION);
							box.setText("��ʾ��Ϣ");
							box.setMessage("���ӳɹ�");
							box.open();
							shell.dispose();
						}else {
							box=new MessageBox(shell, SWT.ICON_INFORMATION);
							box.setText("��ʾ��Ϣ");
							box.setMessage("����ʧ��");
							box.open();
						}
					}
				}
				
			}
		});
		button_3.setBounds(474, 428, 85, 35);
		button_3.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				//����Ա��Ϣ����
				String manager_name=text.getText();
				String sex="";
				if(button.getSelection()){
					sex="��";
				}else if(button_1.getSelection()){
					sex="Ů";
				}
				String manager_ID=text_1.getText();
				int l=ju.query("select * from manager_info where manager_ID='"+manager_ID+"'").size();
				if(l>0){
					box=new MessageBox(shell, SWT.ICON_INFORMATION);
					box.setText("��ʾ��Ϣ");
					box.setMessage("���˺��Ѵ��ڣ�����������");
					box.open();
				}else{
					String password=text_2.getText();
					String call=text_8.getText();
					String pass=text_10.getText();
					String role=combo.getText();
					String authority="";
					if(role.equals("����")){
						authority="M";
					}else if(role.equals("ӰƬ����Ա")){
						authority="film";
					}else if(role.equals("��ӳ������Ա")){
						authority = "hall";
					}else if(role.equals("��ӳ�ƻ�����Ա")){
						authority = "plan";
					}
					String sql="insert into manager_info values('"+manager_name+"','"+sex+"','"+manager_ID+"','"+password+"','"+call+"','"+pass+"','"+role+"','"+authority+"')";
					int row=ju.update(sql);
					if(row>0){
						box=new MessageBox(shell, SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("���ӳɹ�");
						box.open();
						shell.dispose();
					}else {
						box=new MessageBox(shell, SWT.ICON_INFORMATION);
						box.setText("��ʾ��Ϣ");
						box.setMessage("����ʧ��");
						box.open();
					}
				}
				
			}
		});
		button_3.setText("\u786E\u8BA4\u6DFB\u52A0");
		
		text_8 = new Text(composite, SWT.BORDER);
		text_8.setForeground(SWTResourceManager.getColor(255, 69, 0));
	    text_8.setBounds(198, 257, 156, 23);
		
		button_2 = new Button(composite, SWT.NONE);
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		button_2.setText("\u53D6\u6D88");
		button_2.setBounds(618, 428, 85, 35);
		
		text_10 = new Text(composite, SWT.BORDER);
		text_10.setForeground(SWTResourceManager.getColor(230, 230, 250));
		text_10.setBounds(198, 300, 156, 23);
		
		label = new Label(composite, SWT.NONE);
		label.setBounds(102, 51, 65, 23);
		label.setText("\u59D3\u540D\uFF1A");
		
		label_1 = new Label(composite, SWT.NONE);
		label_1.setText("\u6027\u522B\uFF1A");
		label_1.setBounds(102, 108, 65, 23);
		
		label_2 = new Label(composite, SWT.NONE);
		label_2.setText("\u8D26\u53F7\uFF1A");
		label_2.setBounds(102, 158, 65, 23);
		
		label_3 = new Label(composite, SWT.NONE);
		label_3.setText("\u5BC6\u7801\uFF1A");
		label_3.setBounds(102, 207, 65, 23);
		
		label_4 = new Label(composite, SWT.NONE);
		label_4.setText("\u7535\u8BDD\uFF1A");
		label_4.setBounds(102, 257, 65, 23);
		
		label_5 = new Label(composite, SWT.NONE);
		label_5.setText("\u5BC6\u94A5\uFF1A");
		label_5.setBounds(102, 302, 65, 23);
		
		label_6 = new Label(composite, SWT.NONE);
		label_6.setText("\u804C\u4F4D\uFF1A");
		label_6.setBounds(102, 350, 65, 23);
		
		Label label_7 = new Label(composite, SWT.NONE);
		label_7.setBounds(374, 306, 185, 17);
		label_7.setText("\u51FA\u751F\u6708\u65E5\uFF0C\u598210\u67083\u65E5\uFF1A1003");
		
		

	}
}
