package com.hzyc.filmsystem.dialogs;

import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import com.hzyc.filmsystem.normals.SWTResourceManager;

import com.hzyc.filmsystem.JDBCUtil.JDBCUtil;
import com.hzyc.filmsystem.platform.Application;

public class PuySuccessfulDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text text;
	private Text text_2;
	private Text text_3;
	private Text text_4;
	private Text text_5;
	private Text text_6;
	private Text text_7;
	private Text text_8;
	private Text text_9;
	private Text text_10;
	private Text text_11;
	private MessageBox box;
	private JDBCUtil ju=new JDBCUtil();
	private String code;
	private String show_id;
	private Text text_12;
	
     //�򿪶��ͬһ���Ի���
	public PuySuccessfulDialog(Shell parent, int style) {
		super(parent, style);
		setText("��Ʊ��ʾ");
	}

	public Object open(String code,String show_id) {
		this.code=code;
		this.show_id=show_id;
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.MIN);
		shell.setSize(776, 404);
		shell.setText("\u8D2D\u7968\u6210\u529F");
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBounds(52, 70, 672, 275);
		composite.setBackgroundMode(SWT.INDETERMINATE);
		
		Composite composite_1 = new Composite(composite, SWT.BORDER);
		composite_1.setBounds(0, 0, 502, 275);
		
		Label lblDate = new Label(composite_1, SWT.WRAP);
		lblDate.setBounds(35, 23, 40, 36);
		lblDate.setText("\u65E5 \u671F\uFF1A\r\nDATE");
		
		text_5 = new Text(composite_1, SWT.BORDER | SWT.READ_ONLY);
		text_5.setEnabled(false);
		text_5.setBounds(81, 36, 134, 23);
		
		
		Label lblTime = new Label(composite_1, SWT.WRAP);
		lblTime.setBounds(243, 23, 40, 38);
		lblTime.setText("\u65F6 \u95F4\uFF1A\r\nTIME");
		
		text_6 = new Text(composite_1, SWT.BORDER | SWT.READ_ONLY);
		text_6.setEnabled(false);
		text_6.setBounds(291, 36, 168, 23);
		
		Label lblMovie = new Label(composite_1, SWT.WRAP);
		lblMovie.setBounds(35, 89, 46, 36);
		lblMovie.setText("\u5F71  \u7247\uFF1A\r\nMOVIE");
		
		text_7 = new Text(composite_1, SWT.BORDER | SWT.READ_ONLY);
		text_7.setEnabled(false);
		text_7.setBounds(86, 102, 229, 23);
		
		Label lblHall = new Label(composite_1, SWT.WRAP);
		lblHall.setBounds(35, 163, 40, 41);
		lblHall.setText("\u5385 \u540D\uFF1A\r\nHALL");
		
		text_8 = new Text(composite_1, SWT.BORDER | SWT.READ_ONLY);
		text_8.setEnabled(false);
		text_8.setBounds(81, 170, 129, 23);
		
		Label lblPrice = new Label(composite_1, SWT.WRAP);
		lblPrice.setBounds(237, 163, 46, 36);
		lblPrice.setText("\u7968 \u4EF7\uFF1A\r\nPRICE");
		
		text_9 = new Text(composite_1, SWT.BORDER | SWT.READ_ONLY);
		text_9.setEnabled(false);
		text_9.setBounds(291, 170, 91, 23);
		
		Label lblSeat = new Label(composite_1, SWT.WRAP);
		lblSeat.setBounds(29, 216, 46, 34);
		lblSeat.setText("\u5EA7 \u4F4D\uFF1A\r\nSEAT");
		
		text_10 = new Text(composite_1, SWT.BORDER | SWT.READ_ONLY);
		text_10.setEnabled(false);
		text_10.setBounds(81, 219, 34, 23);
		
		Label label_7 = new Label(composite_1, SWT.NONE);
		label_7.setBounds(127, 222, 20, 20);
		label_7.setText("\u6392");
		
		text_11 = new Text(composite_1, SWT.BORDER | SWT.READ_ONLY);
		text_11.setEnabled(false);
		text_11.setBounds(153, 218, 34, 23);
		
		Label label_8 = new Label(composite_1, SWT.NONE);
		label_8.setBounds(205, 222, 26, 17);
		label_8.setText("\u53F7");
		
		Label label_1 = new Label(composite_1, SWT.NONE);
		label_1.setBounds(253, 220, 104, 34);
		label_1.setText("\u5BF9 \u53F7 \u5165 \u5EA7");
		
		text = new Text(composite, SWT.NONE);
		text.setEnabled(false);
		text.setText("\u4EC5  \u9650");
		text.setBounds(508, 33, 54, 23);
		
		text_2 = new Text(composite, SWT.NONE);
		text_2.setEnabled(false);
		text_2.setText("\u4F7F  \u7528");
		text_2.setBounds(568, 62, 70, 23);
		
		text_3 = new Text(composite, SWT.MULTI);
		text_3.setEnabled(false);
		text_3.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		text_3.setText("   \u4E00\u4EBA\u4E00\u7968\r\n   \u6495\u6BC1\u65E0\u6548");
		text_3.setBounds(522, 147, 104, 50);
		
		Label lblNewLabel_1 = new Label(composite, SWT.NONE);
		lblNewLabel_1.setBounds(522, 203, 127, 23);
		
		text_4 = new Text(composite, SWT.READ_ONLY);
		text_4.setEnabled(false);
		text_4.setBounds(522, 232, 127, 23);
		
		text_12 = new Text(composite, SWT.NONE);
		text_12.setEnabled(false);
		text_12.setText("\u5F53  \u65E5");
		text_12.setBounds(508, 62, 54, 23);
		
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			/**ȡƱ*/
			public void widgetSelected(SelectionEvent e) {
				List<Map<String,Object>>list=ju.query("select hall_name, ticket_count from show_plan where show_id="+show_id);
				for(Map<String,Object>map:list){
                    int count=Integer.parseInt(map.get("ticket_count").toString());
					count-=1;
					int t=ju.update("update show_plan set ticket_count="+count+" where show_id="+show_id);
					if(t>0){
						box=new MessageBox(shell, SWT.ICON_INFORMATION);
						box.setText("��Ϣ��ʾ");
						box.setMessage("WELCOME");
						box.open();
						shell.dispose();
					}else{
						box=new MessageBox(shell, SWT.ICON_INFORMATION);
						box.setText("��Ϣ��ʾ");
						box.setMessage("δȡ��Ʊ");
					}
				}
			}
	});
		button.setBounds(595, 29, 80, 27);
		button.setText("\u53D6 \u7968");
		
		/**Ʊ��Ϣ*/
		List<Map<String,Object>>list=ju.query("select * from ticket_info where bar_code_num='"+code+"'");
		for(Map<String,Object>map:list){
			
			text_5.setText(map.get("date").toString());
			text_6.setText(map.get("start_time").toString());
			text_8.setText(map.get("hall_name").toString());
			text_9.setText(map.get("price").toString());
			text_4.setText(String.valueOf(code));
			String []seat=map.get("seat_position").toString().split("-");
			text_10.setText(seat[0]);
			text_11.setText(seat[1]);
			String film_id=map.get("movie_id").toString();
			List<Map<String,Object>>lists=ju.query("select movie_name from movie_info where id="+film_id);
			for(Map<String,Object>maps:lists){
				text_7.setText(maps.get("movie_name").toString());
			}
			
		}

	}
}
